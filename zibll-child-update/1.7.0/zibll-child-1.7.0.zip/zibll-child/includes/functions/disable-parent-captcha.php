<?php
/**
 * 用 Cloudflare Turnstile 取代父主题自带的人机验证（滑块 / 图形 / 腾讯 / 极验）。
 *
 * 背景：
 *   父主题通过 _pz('user_verification_type') 决定在前台表单输出哪种机器验证框，
 *   并在服务端 zib_ajax_man_machine_verification() 里按同一 option 校验（见
 *    zibll/action/function.php:918 / :946）。两个分支都受同一个 option 控制 ——
 *   把它在运行时强制为空，父主题既不输出验证框、服务端也因 $type='' 不匹配任何分支
 *   而直接跳过校验。
 *
 * 为什么必须在本文件被「子主题 functions.php 顶部、require 父主题 inc.php 之前」加载：
 *   zibll_options 是 autoload 选项，WP 引导阶段就把所有 autoload 选项读进缓存；
 *   而且父主题在 inc.php 阶段就会调用 _pz()，把读到的 zibll_options 填进 _pz 的
 *   静态缓存。若过滤器注册太晚（例如在 zib_require 的模块里），第一次读取已经被
 *   缓存为未过滤值，之后注册的过滤器永远赶不上 —— _pz 一直返回原始 'slider'。
 *   因此本过滤器必须抢在父主题核心加载之前挂上（与 functions.php 里已有的
 *   pre_option_stylesheet 同款先例）。
 *
 * 实现要点：
 *   - 挂 pre_option_zibll_options：它在 get_option 最开头拦截，不受 autoload 缓存影响。
 *   - 回调用 $wpdb 直读原始值，避免与 get_option 形成递归、也避免被早前的缓存短路。
 *   - 父主题一律不改；数据库里 user_verification_type 原值不变，移除本文件即恢复原状。
 *   - 安全闸门：仅当 Turnstile 总开关开启时才取代父主题验证，避免「两者都关」导致前台
 *     完全无人机验证。
 *   - 后台设置页（is_admin 且非 ajax）不覆盖：保留真实值，避免 UI 下拉错位或保存时
 *     把空值写回数据库；前台页面渲染与 admin-ajax 前台请求（登录/注册/评论均走
 *     admin-ajax）照常覆盖。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('pre_option_zibll_options', 'zibll_child_disable_parent_captcha', 0);

/**
 * pre_option_zibll_options 回调：Turnstile 开启时强制 user_verification_type 为空。
 *
 * @param mixed $pre get_option 传入的初始值（通常 false）。
 * @return mixed 非 false 则 get_option 直接采用本返回值。
 */
function zibll_child_disable_parent_captcha($pre)
{
    // 已有更靠前的值则原样放过（一般不发生）。
    if (false !== $pre) {
        return $pre;
    }

    // 后台设置页不做覆盖：保留真实值，避免 UI 下拉错位或保存时误存空值。
    if (is_admin() && !(defined('DOING_AJAX') && DOING_AJAX)) {
        return false;
    }

    global $wpdb;
    if (!isset($wpdb) || !$wpdb) {
        return false;
    }

    // 仅当 Turnstile 总开关开启时，才用 Turnstile 取代父主题人机验证。
    // 直读 zibll_child_options（不依赖 Turnstile 模块是否加载，避免加载顺序问题）。
    $child_row = $wpdb->get_row(
        $wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", 'zibll_child_options')
    );
    $ts_enabled = false;
    if ($child_row) {
        $child = maybe_unserialize($child_row->option_value);
        if (is_array($child)) {
            $v = isset($child['turnstile_enable']) ? $child['turnstile_enable'] : '';
            $ts_enabled = ($v === true || $v === 1 || $v === '1');
        }
    }
    if (!$ts_enabled) {
        return false;
    }

    // 直读父主题原始值（不经过 get_option，避免递归 / 被早前缓存短路），改写后整体返回。
    $parent_row = $wpdb->get_row(
        $wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", 'zibll_options')
    );
    $opts = $parent_row ? maybe_unserialize($parent_row->option_value) : array();
    if (!is_array($opts)) {
        $opts = array();
    }

    // 强制为空：父主题既不输出验证框，服务端也不再校验。其余键值原样保留。
    $opts['user_verification_type'] = '';

    return $opts;
}
