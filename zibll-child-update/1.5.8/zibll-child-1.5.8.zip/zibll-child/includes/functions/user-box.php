<?php
/**
 * 子比子主题 - 悬停面板「快捷按钮」自定义
 *
 * 功能：在子主题设置面板里，按 zibll 用户权限（user_cap：all/logged/vip/level/auth/自定义角色）
 * 增删/排序前台「个人信息」悬停面板里的快捷按钮；图标可从全部 zibll SVG + Font Awesome 中选。
 *
 * 实现方式（零侵入，不改父主题）：
 *   父主题 zib_header_user_box() 把四个按钮硬编码进 .header-user-href，且无过滤器、有 static 缓存，
 *   子主题无法重定义同名函数。因此服务端按当前用户权限算出可见按钮并拼好 HTML，
 *   前端 JS 在 DOM 就绪后整体替换该行，并兜底保留「退出登录」（即便管理员从列表里删了它）。
 *
 * 同时解决用户原投诉：关闭商城后悬停面板仍显示「我的订单」——
 *   「我的订单」预设带 requires=shop_s，商城关掉时自动不出现；重新开启商城即恢复。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── 开关 / 数据读取 ───────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_active')) {
    /**
     * 总开关。默认开启，开启后用配置替换原生按钮；
     * 关闭则完全沿用父主题原生四按钮（用户中心/我的订单/发布文章/退出登录）。
     */
    function zibll_child_user_box_active()
    {
        return zibll_child_option_enabled('user_box_enable', true);
    }
}

if (!function_exists('zibll_child_user_box_presets')) {
    /** 读取预设动作池（带静态缓存） */
    function zibll_child_user_box_presets()
    {
        static $presets = null;
        if (null === $presets) {
            $file = get_stylesheet_directory() . '/includes/inc/user-box-presets.php';
            $presets = file_exists($file) ? include $file : array();
        }
        return is_array($presets) ? $presets : array();
    }
}

if (!function_exists('zibll_child_user_box_icon_options')) {
    /** 给设置面板用的图标选择器：把 902 个图标整理成 select 选项（值形如 svg:user / fa:pencil） */
    function zibll_child_user_box_icon_options()
    {
        static $opts = null;
        if (null !== $opts) {
            return $opts;
        }
        $opts = array();
        $file = get_stylesheet_directory() . '/includes/inc/user-box-icons.php';
        if (!file_exists($file)) {
            return $opts;
        }
        $icons = include $file;
        if (!empty($icons['svg']) && is_array($icons['svg'])) {
            foreach ($icons['svg'] as $n) {
                $opts['svg:' . $n] = 'SVG: ' . $n;
            }
        }
        if (!empty($icons['fa']) && is_array($icons['fa'])) {
            foreach ($icons['fa'] as $n) {
                $opts['fa:' . $n] = 'FA: ' . $n;
            }
        }
        return $opts;
    }
}

if (!function_exists('zibll_child_user_box_preset_options')) {
    /** 给设置面板用的「预设动作」下拉：列出除 logout 外的全部预设 */
    function zibll_child_user_box_preset_options()
    {
        $presets = zibll_child_user_box_presets();
        $opts = array('' => '— 选择预设动作 —');
        foreach ($presets as $k => $p) {
            if (!empty($p['link_mode']) && 'logout' === $p['link_mode']) {
                continue;
            }
            $opts[$k] = $p['title'];
        }
        return $opts;
    }
}

// ─── 图标 / 链接解析 ───────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_split_icon')) {
    /** 把存储值 svg:user / fa:pencil 拆成 [type, name] */
    function zibll_child_user_box_split_icon($val)
    {
        if (is_string($val) && strpos($val, ':') !== false) {
            $parts = explode(':', $val, 2);
            return array($parts[0], $parts[1]);
        }
        return array('svg', (string) $val);
    }
}

if (!function_exists('zibll_child_user_box_icon_html')) {
    /** 生成图标 HTML（svg 走 zib_get_svg；fa 走 <i class="fa ...">） */
    function zibll_child_user_box_icon_html($type, $name)
    {
        $name = trim((string) $name);
        if ('fa' === $type) {
            return '<i class="fa fa-fw fa-' . esc_attr($name) . '"></i>';
        }
        if (function_exists('zib_get_svg')) {
            return zib_get_svg($name);
        }
        return '';
    }
}

if (!function_exists('zibll_child_user_box_resolve_href')) {
    /** 按预设 token 解析真实链接；自定义链接直接返回（已 esc） */
    function zibll_child_user_box_resolve_href($b)
    {
        if (!empty($b['link_mode']) && 'custom' === $b['link_mode']) {
            $url = trim((string) ($b['custom_link'] ?? ''));
            return $url ? esc_url($url) : '';
        }

        // repeater 里存的是「预设数组 key」（如 my_order）；查预设表拿到真实解析 token（如 order）
        $preset_key = !empty($b['preset']) ? $b['preset'] : '';
        $token      = $preset_key;
        $presets    = zibll_child_user_box_presets();
        if (isset($presets[$preset_key]['preset_key'])) {
            $token = $presets[$preset_key]['preset_key'];
        }
        if (!function_exists('zib_get_user_center_url')) {
            return '';
        }
        switch ($token) {
            case 'user_center':
                return zib_get_user_center_url();
            case 'order':
                return zib_get_user_center_url('order');
            case 'vip':
                return zib_get_user_center_url('vip');
            case 'balance':
                return zib_get_user_center_url('balance');
            case 'income':
                return zib_get_user_center_url('income');
            case 'rebate':
                return zib_get_user_center_url('rebate');
            case 'account':
                return zib_get_user_center_url('account');
            case 'level':
                return zib_get_user_center_url('level');
            case 'auth':
                return zib_get_user_center_url('auth');
            case 'new_post':
                return function_exists('zib_get_new_post_url') ? zib_get_new_post_url() : '';
            default:
                return '';
        }
    }
}

// ─── 可见性判断（对齐 zibll 的 zib_is_can_roles 逻辑） ──────────────

if (!function_exists('zibll_child_user_box_can_see')) {
    /**
     * 当前用户是否满足该按钮的可见权限。
     * @param string $cap      all | logged | vip | level | auth | custom
     * @param int    $level    最低 VIP / 等级（vip、level 时生效）
     * @param string $custom   cap=custom 时，_pz('user_cap') 里注册的自定义角色 key
     */
    function zibll_child_user_box_can_see($cap, $level = 1, $custom = '')
    {
        if (!is_user_logged_in()) {
            return false;
        }
        $uid = get_current_user_id();
        switch ($cap) {
            case 'all':
                return true;
            case 'logged':
                return true;
            case 'vip':
                $lv = function_exists('zib_get_user_vip_level') ? zib_get_user_vip_level($uid) : 0;
                return (int) $lv >= (int) $level;
            case 'level':
                $lv = function_exists('zib_get_user_level') ? zib_get_user_level($uid) : 0;
                return (int) $lv >= (int) $level;
            case 'auth':
                return function_exists('zib_is_user_auth') && zib_is_user_auth($uid);
            case 'custom':
                if ($custom && function_exists('zib_current_user_can')) {
                    return (bool) zib_current_user_can($custom);
                }
                return false;
            default:
                return true;
        }
    }
}

// ─── 组装按钮 ──────────────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_a')) {
    /** 拼一个完整的 <a> 按钮（与父主题 .header-user-href 内部结构一致，配色/图标沿用） */
    function zibll_child_user_box_a($b)
    {
        $color     = !empty($b['color']) ? $b['color'] : 'c-blue';
        $icon_html = !empty($b['icon_html']) ? $b['icon_html'] : '';
        $title     = !empty($b['title']) ? esc_html($b['title']) : '';

        if (!empty($b['is_logout'])) {
            return '<a href="javascript:;" data-toggle="modal" data-target="#modal_signout" data-zib-logout="1">'
                . '<div class="badg mb6 toggle-radius ' . esc_attr($color) . '">' . $icon_html . '</div>'
                . '<div class="' . esc_attr($color) . '">' . $title . '</div></a>';
        }

        $href = !empty($b['href']) ? esc_url($b['href']) : '#';
        return '<a rel="nofollow" href="' . $href . '">'
            . '<div class="badg mb6 toggle-radius ' . esc_attr($color) . '">' . $icon_html . '</div>'
            . '<div class="' . esc_attr($color) . '">' . $title . '</div></a>';
    }
}

if (!function_exists('zibll_child_user_box_buttons')) {
    /**
     * 计算当前用户实际可见的按钮数组（已过滤开关依赖 + 权限）。
     * 返回每项：{is_logout, href, title, icon_html, color}
     */
    function zibll_child_user_box_buttons()
    {
        if (!zibll_child_user_box_active()) {
            return array();
        }
        $rows = zibll_child_get_option('user_box_buttons', array());
        if (!is_array($rows)) {
            return array();
        }

        $presets = zibll_child_user_box_presets();
        $out     = array();

        foreach ($rows as $b) {
            $b = wp_parse_args($b, array(
                'title'       => '',
                'icon_type'   => 'svg',
                'icon'        => 'svg:user',
                'color'       => 'c-blue',
                'link_mode'   => 'preset',
                'preset'      => 'user_center',
                'preset_key'  => '',
                'custom_link' => '',
                'cap'         => 'logged',
                'cap_level'   => 1,
                'cap_custom'  => '',
                'requires'    => '',
            ));

            // 退出登录：单独渲染，并兜底始终保留
            if (!empty($b['link_mode']) && 'logout' === $b['link_mode']) {
                list($itype, $iname) = zibll_child_user_box_split_icon($b['icon']);
                $out[] = array(
                    'is_logout' => true,
                    'title'     => $b['title'] ?: '退出登录',
                    'icon_html' => zibll_child_user_box_icon_html($itype, $iname),
                    'color'     => $b['color'],
                );
                continue;
            }

            // 依赖的主题开关（requires 定义在预设表里，按 preset key 取；关闭则不显示）
            $preset_key = !empty($b['preset']) ? $b['preset'] : '';
            $requires   = '';
            $presets    = zibll_child_user_box_presets();
            if (isset($presets[$preset_key]['requires'])) {
                $requires = $presets[$preset_key]['requires'];
            }
            if (!empty($requires) && !_pz($requires)) {
                continue;
            }

            // 权限可见性
            if (!zibll_child_user_box_can_see($b['cap'], $b['cap_level'], $b['cap_custom'])) {
                continue;
            }

            $href = zibll_child_user_box_resolve_href($b);
            if (!$href) {
                continue;
            }

            list($itype, $iname) = zibll_child_user_box_split_icon($b['icon']);
            $out[] = array(
                'is_logout' => false,
                'href'      => $href,
                'title'     => $b['title'],
                'icon_html' => zibll_child_user_box_icon_html($itype, $iname),
                'color'     => $b['color'],
            );
        }

        return $out;
    }
}

// ─── 前端资源 ──────────────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_assets')) {
    function zibll_child_user_box_assets()
    {
        if (!zibll_child_user_box_active()) {
            return;
        }
        if (!is_user_logged_in()) {
            return; // 仅登录态替换用户按钮行
        }

        $buttons = zibll_child_user_box_buttons();
        if (empty($buttons)) {
            return;
        }

        $html = '';
        foreach ($buttons as $b) {
            $html .= zibll_child_user_box_a($b);
        }

        $uri = get_stylesheet_directory_uri() . '/assets/';
        $ver = wp_get_theme()->get('Version');

        wp_enqueue_script('zc-userbox', $uri . 'js/user-box.js', array('jquery'), $ver, true);
        wp_localize_script('zc-userbox', 'ZIBLL_CHILD_USER_BOX', array('html' => $html));
    }
    add_action('wp_enqueue_scripts', 'zibll_child_user_box_assets', 30);
}
