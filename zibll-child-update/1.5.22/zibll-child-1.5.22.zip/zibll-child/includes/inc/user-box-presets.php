<?php
/**
 * 子比子主题 - 悬停面板「快捷按钮」预设动作池
 *
 * 每条预设对应 zibll 已有的一个真实可打开的目标（用户中心子页 / 投稿页 / 退出登录 / 后台页面等）。
 * 添加按钮时选「预设动作」即可一键带出 文字 + 链接 + 默认可见权限，
 * 管理员只需决定它的「可见权限」「图标」与「排序」即可。
 *
 * ── v1.5.20 分区（group）────────────────────────────────────────────
 * 父主题 zib_header_user_box() 在登录态下会输出**两行** .header-user-href：
 *   第 1 行（zib-header.php:238-249）用户区：用户中心 / 我的订单 / 发布文章 / 退出登录
 *   第 2 行（zib-header.php:251-258）管理员区：**仅 is_super_admin()**，主题设置 / 模块布局 / 商城中心 / 后台管理
 * v1.5.9~1.5.19 子主题只有一份按钮列表，前端整块覆盖导致「改用户区 → 管理员原生四个被污染」。
 * 故按 group 把预设拆成两池，后台两个区域各自可选、互不干扰。
 *
 * 字段说明：
 *   group      所属区域：user（用户区，默认）| admin（管理员区）
 *   title      默认显示文字
 *   icon       默认图标（v1.5.9 起为子比原生格式：zibsvg-xxx / fa fa-xxx，
 *              与 CSF icon 选择器存储值一致；仅作参考默认值，面板里可任意改）
 *   color      按钮配色（zibll 的 c-* 颜色类）
 *   link_mode  preset（走下方 preset_key 解析）| logout（退出登录弹窗）
 *   preset_key 解析链接时用的 token（见 includes/functions/user-box.php 的 switch）
 *   cap        默认可见权限：all / logged / vip / level / auth
 *   requires   依赖的主题开关（_pz 键）；为空表示无依赖。开关关闭时该预设自动不显示。
 *              —— 例：我的订单依赖 shop_s；发布文章依赖 nav_user_newposts_btn。
 *   blank      是否以新窗口打开（父主题管理员区原生四个按钮均带 target="_blank"）
 *   desc       后台选择器里的说明
 */
if (!defined('ABSPATH')) {
    exit;
}

return array(

    // ── 用户区 ────────────────────────────────────────────────────────
    'user_center' => array(
        'group'      => 'user',
        'title'      => '用户中心',
        'icon'       => 'zibsvg-user',
        'color'      => 'c-blue',
        'link_mode'  => 'preset',
        'preset_key' => 'user_center',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '个人主页 / 资料',
    ),
    'my_order' => array(
        'group'      => 'user',
        'title'      => '我的订单',
        'icon'       => 'zibsvg-handbag',
        'color'      => 'c-purple',
        'link_mode'  => 'preset',
        'preset_key' => 'order',
        'cap'        => 'logged',
        'requires'   => 'shop_s',
        'desc'       => '需开启商城（shop_s）；关闭商城后自动隐藏',
    ),
    'new_post' => array(
        'group'      => 'user',
        'title'      => '发布文章',
        'icon'       => 'fa fa-fw fa-pencil-square-o',
        'color'      => 'c-green',
        'link_mode'  => 'preset',
        'preset_key' => 'new_post',
        'cap'        => 'logged',
        'requires'   => 'nav_user_newposts_btn',
        'desc'       => '前台投稿；依赖「导航栏用户卡片-投稿按钮」开启',
    ),
    'my_vip' => array(
        'group'      => 'user',
        'title'      => '我的会员',
        'icon'       => 'zibsvg-vip_1',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'vip',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '会员中心',
    ),
    'my_balance' => array(
        'group'      => 'user',
        'title'      => '我的余额',
        'icon'       => 'fa fa-fw fa-credit-card',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'balance',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '余额 / 积分',
    ),
    'my_income' => array(
        'group'      => 'user',
        'title'      => '创作分成',
        'icon'       => 'fa fa-fw fa-pie-chart',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'income',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '创作收益',
    ),
    'my_rebate' => array(
        'group'      => 'user',
        'title'      => '我的推广',
        'icon'       => 'fa fa-fw fa-share-alt',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'rebate',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '推广佣金',
    ),
    'my_account' => array(
        'group'      => 'user',
        'title'      => '账号设置',
        'icon'       => 'fa fa-fw fa-cog',
        'color'      => 'c-blue',
        'link_mode'  => 'preset',
        'preset_key' => 'account',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '账号 / 绑定',
    ),
    'my_level' => array(
        'group'      => 'user',
        'title'      => '我的等级',
        'icon'       => 'fa fa-fw fa-level-up',
        'color'      => 'c-blue',
        'link_mode'  => 'preset',
        'preset_key' => 'level',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '成长等级',
    ),
    'my_auth' => array(
        'group'      => 'user',
        'title'      => '我的认证',
        'icon'       => 'zibsvg-user-auth',
        'color'      => 'c-blue',
        'link_mode'  => 'preset',
        'preset_key' => 'auth',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '实名 / 认证',
    ),
    'logout' => array(
        'group'      => 'user',
        'title'      => '退出登录',
        'icon'       => 'zibsvg-signout',
        'color'      => 'c-red',
        'link_mode'  => 'logout',
        'preset_key' => 'logout',
        'cap'        => 'logged',
        'requires'   => '',
        'desc'       => '弹窗确认退出（兜底始终保留，不会因删除而丢失）',
    ),

    // ── 管理员区（对齐父主题原生四个 + 常用后台入口）──────────────────
    // 这四个与父主题 zib-header.php:251-258 的原生按钮一一对应，
    // 装好子主题不做任何改动时，看到的就是原生效果。
    'admin_theme_options' => array(
        'group'      => 'admin',
        'title'      => '主题设置',
        'icon'       => 'zibsvg-theme',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_theme_options',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '父主题原生按钮：zibll 主题设置页',
    ),
    'admin_widgets' => array(
        'group'      => 'admin',
        'title'      => '模块布局',
        'icon'       => 'fa fa-fw fa-pie-chart',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_widgets',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '父主题原生按钮：小工具 / 模块布局（自定义器）',
    ),
    'admin_shop' => array(
        'group'      => 'admin',
        'title'      => '商城中心',
        'icon'       => 'zibsvg-handbag',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_shop',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '父主题原生按钮：zibpay 商城中心（需启用商城）',
    ),
    'admin_dashboard' => array(
        'group'      => 'admin',
        'title'      => '后台管理',
        'icon'       => 'zibsvg-set',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_dashboard',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '父主题原生按钮：WordPress 后台首页',
    ),

    // 常用后台入口（父主题原生没有，按需添加）
    'admin_posts' => array(
        'group'      => 'admin',
        'title'      => '文章管理',
        'icon'       => 'fa fa-fw fa-file-text-o',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_posts',
        'cap'        => 'editor',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「文章」列表',
    ),
    'admin_users' => array(
        'group'      => 'admin',
        'title'      => '用户管理',
        'icon'       => 'fa fa-fw fa-users',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_users',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「用户」列表',
    ),
    'admin_media' => array(
        'group'      => 'admin',
        'title'      => '媒体库',
        'icon'       => 'fa fa-fw fa-picture-o',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_media',
        'cap'        => 'contributor',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「媒体」库',
    ),
    'admin_comments' => array(
        'group'      => 'admin',
        'title'      => '评论管理',
        'icon'       => 'fa fa-fw fa-comments-o',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_comments',
        'cap'        => 'editor',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「评论」列表（需编辑及以上角色）',
    ),
    'admin_appearance' => array(
        'group'      => 'admin',
        'title'      => '外观管理',
        'icon'       => 'fa fa-fw fa-paint-brush',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_appearance',
        'cap'        => 'editor',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「外观」：主题 / 菜单 / 小工具',
    ),
    'admin_plugins' => array(
        'group'      => 'admin',
        'title'      => '插件管理',
        'icon'       => 'fa fa-fw fa-plug',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_plugins',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「插件」列表',
    ),
    'admin_tools' => array(
        'group'      => 'admin',
        'title'      => '工具',
        'icon'       => 'fa fa-fw fa-wrench',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_tools',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「工具」',
    ),
    'admin_options' => array(
        'group'      => 'admin',
        'title'      => '站点设置',
        'icon'       => 'fa fa-fw fa-cog',
        'color'      => 'c-yellow',
        'link_mode'  => 'preset',
        'preset_key' => 'admin_options',
        'cap'        => 'administrator',
        'requires'   => '',
        'blank'      => true,
        'desc'       => '后台「设置」',
    ),
);
