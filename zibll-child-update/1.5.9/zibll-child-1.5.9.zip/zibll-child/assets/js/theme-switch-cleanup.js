/**
 * 子比子主题 - 切换主题时询问是否清除整合插件数据
 *
 * 后台「外观 → 主题」点击其它主题的「启用」时，拦截该点击并弹出询问框：
 *   - 取消：不切换
 *   - 保留数据并切换：照常切换，不清理
 *   - 清除数据并切换：写入 cookie 标记，切换同时由服务端 switch_theme 钩子执行清理
 *
 * 覆盖三种场景：
 *   1) 主题列表页卡片上的「启用」链接（直接 <a>）；
 *   2) 列表页点开的主题详情 inline 弹窗（.theme-overlay）里的「启用」；
 *   3) 经典 WP 用 Thickbox 打开的主题详情 iframe（theme-install.php）里的「启用」。
 *
 * 关键坑 1：WordPress 自带 theme.js 在「冒泡阶段」给详情弹窗的「启用」链接触发激活，
 * 且绑点比 document 更近，故必须用「捕获阶段」原生监听抢在它前面执行。
 *
 * 关键坑 2：Thickbox 详情是用 <iframe> 打开的独立文档，父页面的事件监听器收不到
 * iframe 内部的点击（跨文档事件不冒泡到父 document）。因此需往 iframe 的 document
 * 里也注入同一套捕获监听；弹窗显示到顶层窗口，确认后使用 top.location 在顶层切换。
 */
(function (rootjQuery) {
    'use strict';

    function setCookie(name, value) {
        if (value === '' || value === null) {
            document.cookie = name + '=; path=/; max-age=0';
        } else {
            document.cookie = name + '=' + encodeURIComponent(value) + '; path=/';
        }
    }

    function btnStyle(bg, color) {
        return {
            border: 'none',
            'border-radius': '4px',
            padding: '8px 14px',
            cursor: 'pointer',
            'font-size': '13px',
            background: bg,
            color: color
        };
    }

    // 在指定 window 的文档里安装一套拦截器（主窗口或 iframe 内均可用）。
    function installInterceptor(win) {
        if (!win || !win.document) { return; }
        var doc = win.document;
        var $ = win.jQuery || rootjQuery;
        if (!$) { return; }

        function openModal(href, themeName) {
            var childName = (window.ZIBLL_CHILD_SWITCH && ZIBLL_CHILD_SWITCH.themeName) || '本子主题';
            // 弹窗挂到顶层窗口，避免被 iframe 尺寸限制
            var topDoc = (win.top && win.top.document) ? win.top.document : doc;
            var $topBody = $(topDoc.body);

            var $overlay = $('<div></div>').css({
                position: 'fixed', left: 0, top: 0, right: 0, bottom: 0,
                background: 'rgba(0,0,0,0.55)', 'z-index': 999999,
                display: 'flex', 'align-items': 'center', 'justify-content': 'center'
            });

            var $box = $('<div></div>').css({
                background: '#fff', 'max-width': '480px', width: '90%',
                'border-radius': '8px', padding: '24px',
                'box-shadow': '0 10px 40px rgba(0,0,0,0.3)',
                'font-family': '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif',
                'font-size': '14px', color: '#1d2327'
            });

            var $title = $('<h2></h2>').css({ margin: '0 0 12px', 'font-size': '18px' }).text('切换主题');

            var $desc = $('<p></p>').css({ 'line-height': '1.6', 'margin': '0 0 20px' });
            $desc.append('你正在离开「');
            $desc.append($('<strong></strong>').text(childName));
            $desc.append('」并启用「');
            $desc.append($('<strong></strong>').text(themeName));
            $desc.append('」。');
            $desc.append($('<br>'));
            $desc.append('本子主题整合的插件（文章评分 / 夏稚前缀 / 评论表情等）会在数据库中保留数据。');
            $desc.append($('<br>'));
            $desc.append($('<strong></strong>').text('是否一并清除这些插件数据？'));

            var $actions = $('<div></div>').css({ display: 'flex', 'justify-content': 'flex-end', gap: '10px' });

            var $cancel = $('<button type="button"></button>').css(btnStyle('#f6f7f7', '#1d2327')).text('取消');
            var $keep   = $('<button type="button"></button>').css(btnStyle('#2271b1', '#fff')).text('保留数据并切换');
            var $clean  = $('<button type="button"></button>').css(btnStyle('#d63638', '#fff')).text('清除数据并切换');

            function close() { $overlay.remove(); }

            $cancel.on('click', function () { close(); });
            $keep.on('click', function () {
                setCookie('zibll_child_cleanup_data', '');
                navigate(win, href);
            });
            $clean.on('click', function () {
                setCookie('zibll_child_cleanup_data', '1');
                navigate(win, href);
            });

            $actions.append($cancel, $keep, $clean);
            $box.append($title, $desc, $actions);
            $overlay.append($box);
            $topBody.append($overlay);

            $overlay.on('click', function (e) {
                if (e.target === $overlay[0]) { close(); }
            });
        }

        // 激活链接可能是相对路径（themes.php?...），按当前窗口地址解析为绝对地址，
        // 并通过顶层窗口完成跳转（iframe 内若只改自身 location 只会刷新 iframe）。
        function navigate(srcWin, href) {
            var abs;
            try {
                abs = (href.indexOf('http') === 0) ? href : new URL(href, srcWin.location.href).href;
            } catch (e) {
                abs = href;
            }
            if (srcWin.top && srcWin.top.location) {
                srcWin.top.location.href = abs;
            } else {
                srcWin.location.href = abs;
            }
        }

        function extractThemeName(anchor) {
            var $a = $(anchor);
            var themeName = '';

            var $card = $a.closest('.theme');
            if ($card.length) {
                var $h = $card.find('.theme-name').filter(':visible').first();
                if (!$h.length) { $h = $card.find('h2, h3').first(); }
                themeName = $.trim($h.text());
            }
            if (!themeName) {
                var $info = $a.closest('.theme-info, .theme-overlay, body');
                var $nameEl = $info.find('.theme-name, .theme-title, h2, h3').filter(':visible').first();
                themeName = $.trim($nameEl.text());
            }
            if (!themeName) { themeName = '其它主题'; }
            return themeName;
        }

        function onActivateClick(e) {
            var el = e.target;
            if (!el || typeof el.closest !== 'function') { return; }

            var anchor = el.closest('a[href*="action=activate"]');
            if (!anchor) { return; }

            var href = anchor.getAttribute('href') || '';
            if (href.indexOf('stylesheet=zibll-child') !== -1) { return; } // 跳过本子主题自身

            e.preventDefault();
            if (typeof e.stopPropagation === 'function') { e.stopPropagation(); }
            if (typeof e.stopImmediatePropagation === 'function') { e.stopImmediatePropagation(); }

            openModal(href, extractThemeName(anchor));
        }

        if (doc.addEventListener) {
            // 第三个参数 true = 捕获阶段，抢在 WordPress 自带激活逻辑之前
            doc.addEventListener('click', onActivateClick, true);
        } else if (doc.attachEvent) {
            doc.attachEvent('onclick', function (ev) { onActivateClick(ev || window.event); });
        }
    }

    // 监听页面新增的 iframe（Thickbox 详情弹窗），加载后往其文档注入同一套拦截器。
    function watchIframes() {
        function inject(iframe) {
            if (!iframe || iframe.getAttribute('data-zibll-intercepted')) { return; }
            iframe.setAttribute('data-zibll-intercepted', '1');
            function tryInject() {
                try {
                    if (iframe.contentWindow && iframe.contentWindow.document) {
                        installInterceptor(iframe.contentWindow);
                    }
                } catch (e) { /* 跨域 iframe，无法注入，忽略 */ }
            }
            if (iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
                tryInject();
            } else {
                iframe.addEventListener('load', tryInject);
            }
        }

        // 处理已经存在的 iframe
        var existing = document.querySelectorAll('iframe');
        for (var i = 0; i < existing.length; i++) { inject(existing[i]); }

        if (typeof MutationObserver !== 'undefined') {
            var obs = new MutationObserver(function (mutations) {
                mutations.forEach(function (m) {
                    if (!m.addedNodes) { return; }
                    m.addedNodes.forEach(function (node) {
                        if (node.nodeType === 1 && node.tagName === 'IFRAME') {
                            inject(node);
                        }
                        // Thickbox 有时先把容器 div 加进来，iframe 稍后加入，subtree 一并观察
                        if (node.nodeType === 1) {
                            var iframes = node.querySelectorAll ? node.querySelectorAll('iframe') : [];
                            for (var j = 0; j < iframes.length; j++) { inject(iframes[j]); }
                        }
                    });
                });
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
        }
    }

    // 主窗口安装 + 监听 iframe
    installInterceptor(window);
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', watchIframes);
    } else {
        watchIframes();
    }
})(jQuery);
