/**
 * Cloudflare Turnstile —— 前台接入
 * ─────────────────────────────────────────────────────────────
 * 工作方式（刻意不碰父主题任何一行 JS）：
 *
 *  1. 找到需要保护的表单（注册 / 登录 / 找回密码 / 评论），在其内部插入一个
 *     隐藏域 name="cf-turnstile-response"；Turnstile 验证通过后把 token 写进去。
 *  2. 父主题提交时统一走 zib_ajax() → form.serializeObject()，
 *     评论表单也是 _form.serializeObject() 后手工补 action，
 *     所以隐藏域会被自动带上，不需要劫持 zib_ajax() 或改任何提交逻辑。
 *  3. 提交按钮上挂一个捕获阶段的监听：若该表单还没拿到 token 就阻止提交并提示，
 *     避免用户白等一次服务端往返。
 *  4. 每次提交返回后重置控件 —— Turnstile 的 token 是一次性的，
 *     服务端验过之后同一个 token 再验会被判为 timeout-or-duplicate。
 *
 * ⚠️ 关键点：只在表单**真正可见**时才渲染。
 *    父主题的登录/注册/找回密码表单藏在 #u_sign 弹窗和 .tab-pane 里，
 *    未激活时 display:none；在隐藏容器里渲染 Turnstile 拿不到 token，
 *    因此每次弹窗打开 / Tab 切换 / 主题 auto_fun() 时都要重新扫一遍。
 */
(function () {
    'use strict';

    var CFG = window.ZC_TURNSTILE || {};

    // 未开启或配置不全时什么都不做（服务端此时也不会拦截）。
    if (!CFG.siteKey || !CFG.scenes || !CFG.scenes.length) {
        return;
    }

    var FIELD = CFG.field || 'zc_turnstile_response';
    var API = CFG.apiUrl || 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';

    // 父主题提交按钮的几种形态：登录注册用 .signsubmit-loader，
    // 通用 Ajax 按钮用 .wp-ajax-submit / [zibajax="submit"]，评论用 #commentform #submit。
    var BTN_SELECTOR = '.signsubmit-loader, .wp-ajax-submit, [zibajax="submit"], #commentform #submit, form#commentform input[type="submit"], form#commentform button[type="submit"]';

    var apiReady = false;
    var apiLoading = false;

    /** 是否参与渲染（display:none 的元素没有 client rects）。 */
    function isVisible(el) {
        return !!(el && el.getClientRects && el.getClientRects().length);
    }

    /** 统一提示，优先复用父主题的 notyf，没有则退回 alert。 */
    function notify(msg, type) {
        if (typeof window.notyf === 'function') {
            window.notyf(msg, type || 'warning');
            return;
        }
        if (window.jQuery && window.jQuery.notyf) {
            window.jQuery.notyf(msg, type || 'warning');
            return;
        }
        window.alert(msg);
    }

    /**
     * 判定一张表单属于哪个场景；不属于任何受保护场景返回空串。
     *
     * 父主题的注册表单与找回密码表单都叫 form#sign-up（zib-user.php:386 / :259），
     * 只看 id 区分不开，必须读表单里的隐藏域 name="action"。
     * 评论表单里没有 action 隐藏域（由 comment.js 在提交时补上），按 id 判定。
     */
    function sceneOfForm(form) {
        if (!form || form.nodeName !== 'FORM') {
            return '';
        }

        var scene = '';

        if (form.id === 'commentform') {
            scene = 'comment';
        } else {
            var hidden = form.querySelector('input[name="action"]');
            var action = hidden ? (hidden.value || '') : '';
            if (action && CFG.actionMap) {
                scene = CFG.actionMap[action] || '';
            }
        }

        if (!scene || CFG.scenes.indexOf(scene) === -1) {
            return '';
        }

        // 已登录用户跳过（服务端同样会跳过，两边保持一致）。
        if (CFG.skipLogged && CFG.loggedIn) {
            return '';
        }

        return scene;
    }

    function tokenInput(form) {
        return form.querySelector('input[name="' + FIELD + '"]');
    }

    function resetForm(form) {
        var input = tokenInput(form);
        if (input) {
            input.value = '';
        }

        var widgetId = form.getAttribute('data-zc-ts-widget');
        if (widgetId && window.turnstile && typeof window.turnstile.reset === 'function') {
            try {
                window.turnstile.reset(widgetId);
            } catch (e) {
                /* 控件已被移除，忽略 */
            }
        }
    }

    function mount(form) {
        // 已挂载过：若控件容器还在表单里就跳过，被移走（例如评论框被 relocate）则重挂。
        if (form.getAttribute('data-zc-ts') === '1') {
            var old = form.querySelector('.zc-turnstile');
            if (old) {
                return;
            }
            form.removeAttribute('data-zc-ts');
            form.removeAttribute('data-zc-ts-widget');
        }

        // 隐藏容器里渲染拿不到 token，等它可见再说。
        if (!isVisible(form)) {
            return;
        }

        if (!window.turnstile || typeof window.turnstile.render !== 'function') {
            return;
        }

        var holder = document.createElement('div');
        holder.className = 'zc-turnstile';

        // 插到提交按钮那一行前面；找不到就 append 到表单末尾。
        var anchor = form.querySelector('.box-body') || form.querySelector('.but, button, input[type="submit"]');
        if (anchor && anchor.parentNode === form) {
            form.insertBefore(holder, anchor);
        } else {
            form.appendChild(holder);
        }

        var input = tokenInput(form);
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = FIELD;
            form.appendChild(input);
        }
        input.value = '';

        try {
            var widgetId = window.turnstile.render(holder, {
                sitekey: CFG.siteKey,
                theme: CFG.theme || 'auto',
                size: CFG.size || 'normal',
                callback: function (token) {
                    input.value = token || '';
                },
                'error-callback': function () {
                    input.value = '';
                },
                'expired-callback': function () {
                    input.value = '';
                },
                'timeout-callback': function () {
                    input.value = '';
                },
            });

            form.setAttribute('data-zc-ts', '1');
            form.setAttribute('data-zc-ts-widget', String(widgetId));
        } catch (e) {
            if (holder.parentNode) {
                holder.parentNode.removeChild(holder);
            }
        }
    }

    var scanTimer = null;

    function scan() {
        var forms = document.querySelectorAll('form');
        for (var i = 0; i < forms.length; i++) {
            if (sceneOfForm(forms[i])) {
                mount(forms[i]);
            }
        }
    }

    /** modal 有动画，打开后延迟再扫一次确保已经可见。 */
    function scanSoon() {
        if (scanTimer) {
            window.clearTimeout(scanTimer);
        }
        scanTimer = window.setTimeout(function () {
            scanTimer = null;
            scan();
        }, 400);
    }

    function loadApi(callback) {
        if (window.turnstile) {
            apiReady = true;
            callback();
            return;
        }
        if (apiLoading) {
            return;
        }
        apiLoading = true;

        var script = document.createElement('script');
        script.src = API;
        script.async = true;
        script.defer = true;
        script.onload = function () {
            apiReady = !!(window.turnstile && typeof window.turnstile.render === 'function');
            callback();
        };
        script.onerror = function () {
            apiLoading = false;
            notify((CFG.i18n && CFG.i18n.loadFailed) || '人机验证组件加载失败，请检查网络后刷新页面', 'danger');
        };

        (document.head || document.documentElement).appendChild(script);
    }

    function boot() {
        loadApi(function () {
            if (!apiReady) {
                return;
            }
            scan();
            scanSoon();

            if (window.jQuery) {
                // 父主题每次初始化 / 弹窗打开 / Tab 切换都可能让隐藏表单变可见。
                window.jQuery(document).on('auto_fun shown.bs.modal shown.bs.tab', function () {
                    scan();
                    scanSoon();
                });
            }

            window.addEventListener('load', scan);
        });
    }

    // ── 提交守卫：捕获阶段，早于父主题绑在 body/document 上的委托事件 ──
    document.addEventListener(
        'click',
        function (e) {
            var el = e.target;
            if (!el || !el.closest) {
                return;
            }

            var btn = el.closest(BTN_SELECTOR);
            if (!btn) {
                return;
            }

            var form = btn.closest('form');
            if (!form || form.getAttribute('data-zc-ts') !== '1') {
                return;
            }

            var input = tokenInput(form);
            if (input && input.value) {
                return; // 已有 token，放行给父主题
            }

            e.preventDefault();
            e.stopPropagation();
            notify((CFG.i18n && CFG.i18n.needVerify) || '请先完成人机验证后再提交');
        },
        true
    );

    // ── 每次提交返回后重置：token 一次性，用完必须重新挑战 ──
    if (window.jQuery) {
        window.jQuery(document).on('zib_ajax.success', BTN_SELECTOR, function () {
            var form = this.closest ? this.closest('form') : null;
            if (form) {
                resetForm(form);
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
