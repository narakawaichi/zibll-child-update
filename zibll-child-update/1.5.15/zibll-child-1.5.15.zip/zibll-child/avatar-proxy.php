<?php
/**
 * avatar-proxy.php —— Google 头像国内可达反代（子主题自带端点）
 * ─────────────────────────────────────────────────────────────
 * 背景：父主题 zibll 处理 Google 登录时，把 lh3.googleusercontent.com 头像原链
 *       写入用户 custom_avatar，国内直连拉不到 → 头像裂图。
 * 本文件随 zibll-child 子主题分发，放在子主题根目录。子主题本身运行在用户服务器
 * 上（如香港节点，墙外出口），可直连 Google 拉图后吐给国内用户（前面有 CDN/CF 缓存）。
 *
 * 配套子主题模块：includes/functions/google-avatar-proxy.php
 *   该模块把 custom_avatar 里的 googleusercontent 原链改写为
 *   <本文件地址>?u=<urlencoded 原链>
 *
 * 安全：仅放行 Google 头像域名（googleusercontent / google.com），其余一律 403
 *       —— 防止被当成开放代理刷流量。
 * 缓存：输出 Cache-Control 86400s，前面 CDN/CF 边缘缓存。
 *
 * 注意：本文件为独立端点，不依赖 WordPress 环境（直接访问即可执行）。
 */

$u = isset($_GET['u']) ? $_GET['u'] : '';

// 白名单：仅放行 Google 头像域名，防变开放代理被刷
function zibll_avatar_allowed($u)
{
    if (!is_string($u) || $u === '') {
        return false;
    }
    $p = parse_url($u);
    if (!$p || strtolower($p['scheme'] ?? '') !== 'https') {
        return false;
    }
    $h = strtolower($p['host'] ?? '');
    return (bool) preg_match('/^(?:[\w.-]+\.)?googleusercontent\.com$/i', $h)
        || (bool) preg_match('/^(?:[\w.-]+\.)?google\.com$/i', $h);
}

if (!zibll_avatar_allowed($u)) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'forbidden';
    exit;
}

// 限制 Google 头像尺寸，压到 96px，省流量、加快首屏
if (!preg_match('/=s\d+/', $u)) {
    $u .= '=s96-c';
}

// 当前服务器墙外可达 Google，用 curl 拉取
$ch = curl_init($u);
curl_setopt_array($ch, array(
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER         => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (avatar-proxy)',
));
$resp = curl_exec($ch);
if ($resp === false) {
    http_response_code(502);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'fetch failed: ' . curl_error($ch);
    curl_close($ch);
    exit;
}
$hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

if ($code < 200 || $code >= 300) {
    http_response_code(502);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'upstream error: ' . $code;
    exit;
}

$body = substr($resp, $hsize);
header('Content-Type: ' . ($ctype ?: 'image/jpeg'), true);
header('Cache-Control: public, max-age=86400, s-maxage=86400');
header('Access-Control-Allow-Origin: *');
echo $body;
