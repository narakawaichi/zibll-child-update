<?php
/**
 * 站点自定义 PHP 代码（安全草稿区）
 *
 * 本文件用于放置少量站点级、临时或一次性的自定义代码。
 * 说明：子主题在线更新采用【增量模式】——只下载覆盖更新清单内的核心代码文件，
 * 本文件（func.php）不在清单内、且被强制保护，因此更新时不会被覆盖，可放心存放自定义。
 *
 * 注意：
 *   - 长期、可复用的功能请改为 includes/ 下的模块文件，结构更清晰、易维护。
 *   - 以下示例默认均为「注释状态」，不会改动任何运行时行为；
 *     按需取消注释即可生效。请务必保证 PHP 语法正确，错误代码会导致白屏。
 *
 * 子主题三种标准扩展方式（详见 includes/functions/functions.php 第 4 节）：
 *   (a) 模板覆盖：在子主题根目录放同名模板文件（footer.php / single.php …）
 *   (b) 钩子扩展：add_action / add_filter 挂接父主题暴露的钩子
 *   (c) 样式覆盖：在 style.css 中书写更高优先级规则
 *
 * @package zibll-child
 */

// ─── 示例 (b)：钩子扩展 ───────────────────────────────────────
// 给 <body> 追加一个子主题专属 class，便于在 style.css 中做定向覆盖
// （用 WordPress 官方的 body_class 过滤器；父主题本身也在其上追加自己的 class，
//  最终 class 字符串会拼在一起）
// add_filter('body_class', function ($class) {
//     return trim($class . ' zibll-child-active');
// });

// ─── 示例 (b)：移除父主题的某个前端钩子 ───────────────────────
// 父主题函数均已就绪，可直接 remove_action / remove_filter
// （以下为示意，按需替换钩子名与优先级）
// remove_action('wp_footer', 'zib_xxx_function', 10);

// ─── 示例 (b)：调用父主题函数 ────────────────────────────────
// 父主题的所有函数/类在本文件加载时早已可用，可直接调用
// add_action('init', function () {
//     // if (function_exists('_pz')) { $opt = _pz('some_option'); }
// });

// ─── 示例 (a) 提示 ───────────────────────────────────────────
// 若需覆盖某个模板，直接在子主题根目录新建同名 .php 文件即可，
// 例如新建 zibll-child/footer.php 即可覆盖父主题 footer.php，
// 父主题原文件作为回退。无需在此处写任何代码。

// ─── 全屏画廊页排除站点级 NSFW 提示 ─────────────────────────
// 「二次元画廊」插件开启「全屏画廊页」(acag_fullscreen_home) 后，/gallery 与
// /gallery-cat 使用自建纯净模板。此时移除 post-hide 模块的 NSFW 通知栏与弹窗，
// 避免站点级浮层破坏全屏画廊的纯净观感（仅全屏模式 + 画廊页生效，不影响其他页面）。
add_action('wp_footer', function () {
    if (get_option('acag_fullscreen_home', 0)
        && (is_post_type_archive('ac_gallery') || is_tax('gallery_cat'))) {
        remove_action('wp_footer', 'zibph_render_notice_bar', 50);
        remove_action('wp_footer', 'zibph_render_display_modal', 40);
    }
}, 1);

// ─── 放行"作者/编辑/管理员"进入后台（覆盖父主题"非管理员禁止进入后台"） ──
// 父主题 zib-theme.php 默认用 is_super_admin() 拦截所有非管理员（含作者/编辑），
// 重定向回首页，导致作者角色无法用后台古德堡编辑器发文章。
// 此处移除父主题的全局拦截，改为仅放行具备 publish_posts 能力的角色
// （作者/编辑/管理员），其余角色（投稿者/订阅者）仍退回首页，保留原安全意图。
//
// v1.5.16 修正（不改变既有默认行为）：
//  ① 【AJAX 判定】原来用 stristr($_SERVER['PHP_SELF'], 'admin-ajax.php')，
//     这是【任意位置子串匹配】，而 PHP_SELF 在启用 AcceptPathInfo 的环境下
//     可由请求路径构造，形如 /wp-admin/index.php/admin-ajax.php 的请求会让
//     它包含该子串从而跳过整个重定向判断。改用 WP 官方的 wp_doing_ajax()
//     （内部判断 DOING_AJAX 常量，不依赖用户可控的服务器变量）。
//     —— 默认行为与原先一致（admin-ajax 放行），只是判定方式更可靠。
//  ② 【可配置】原先是无条件放宽，站长的父主题「user_disable_admin」设置
//     会被静默降级。现把放宽开关暴露为过滤器，默认 true（保持既有行为不变），
//     站长若希望恢复「仅超管可进后台」，把它返回 false 即可。
add_action('admin_init', function () {
    // 移除父主题默认优先级 10 的全局拦截（本回调优先级 1，先执行可成功移除）
    remove_action('admin_init', 'zib_no_entry_backstage', 10);

    // 默认 true = 维持既有行为（放行作者/编辑/管理员进后台）
    $allow_edit_role = apply_filters('zibll_child_allow_edit_role_admin', true);

    if (!$allow_edit_role) {
        // 站长显式收紧 → 沿用父主题语义：仅超管可进后台
        if (!is_super_admin() && !wp_doing_ajax()) {
            wp_redirect(home_url());
            exit;
        }
        return;
    }

    // 放行能发布文章的角色；其余退回首页
    if (!current_user_can('publish_posts') && !wp_doing_ajax()) {
        wp_redirect(home_url());
        exit;
    }
}, 1);

// ─── 站点专属：新用户注册时不给管理员发邮件通知 ──────────────────────
// 原来这一行是直接加在服务器上的 func.php 末尾，主题一更新就会丢；
// 2026-10-26 并入源码，随主题一起发布，避免更新后又被冲掉。
add_filter('wp_send_new_user_notification_to_admin', '__return_false');
