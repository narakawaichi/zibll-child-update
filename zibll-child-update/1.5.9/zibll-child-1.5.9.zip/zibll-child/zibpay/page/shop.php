<?php
/**
 * 转发垫片 —— 把父主题对子主题目录的引入请求转回父主题真实文件。
 *
 * 【为什么需要这个文件】
 * 父主题 zibpay/functions/admin/admin-options.php 在注册后台页面（商城中心 / 订单明细（zibpay_page））
 * 时，用的是「按当前主题目录拼路径」的引入写法，等价于：
 *
 *     include_once(get_stylesheet_directory() . '/zibpay/page/shop.php');
 *
 * 这个路径在父主题独占时指向 zibll/zibpay/page/shop.php，一切正常；
 * 一旦启用子主题，get_stylesheet_directory() 变成子主题目录 zibll-child/，
 * 而子主题里并没有这份文件，于是每次打开该后台页面都会打印两条 PHP Warning：
 *
 *     Warning: include_once(.../themes/zibll-child/zibpay/page/shop.php):
 *              Failed to open stream: No such file or directory
 *     Warning: include_once(): Failed opening '...' for inclusion
 *
 * 【解决办法】
 * 在子主题的相同路径放一个垫片文件（就是本文件），把引入请求原样转发回父主题的
 * 真实文件。好处是：
 *   1. 修掉 Warning，后台页面恢复正常渲染；
 *   2. **不复制父主题任何业务代码** —— 父主题升级后本垫片自动跟随到新版本，
 *      不会出现「复制的模板过期/漏掉安全修复」的问题；
 *   3. 父主题源码（zibll/ 目录）一个字节都不改，遵守「不改父主题」的约定。
 *
 * 【维护提示】
 * 仅当父主题把 zibpay/page/ 目录改名或删掉本文件时才需要调整；
 * 正常情况下本文件不需要随版本更新。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

$zibll_child_forward_file = get_template_directory() . '/zibpay/page/shop.php';

if (is_readable($zibll_child_forward_file)) {
    require_once $zibll_child_forward_file;
}
