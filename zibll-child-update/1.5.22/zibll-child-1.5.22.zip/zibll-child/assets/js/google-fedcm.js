/**
 * 子比子主题 - Google 一键登录（FedCM / One Tap）前端
 * ─────────────────────────────────────────────────────────────
 * 职责：
 *   1. 加载 Google Identity Services 脚本；
 *   2. 初始化时打开 FedCM（use_fedcm_for_prompt），并挂上一次性 nonce；
 *   3. 渲染「使用 Google 账号登录」按钮（FedCM 按钮流）；
 *   4. 拿到 ID Token 后 POST 到子主题端点完成登录；
 *   5. 浏览器不支持 FedCM 时，把按钮换成父主题原有的 302 跳转链接（降级不失效）。
 *
 * 为什么用按钮流而不是只用自动弹窗：
 *   官方明确 One Tap 自动弹窗受 Chrome「用户手势」与「Friction Access」策略影响，
 *   首次访问常常不弹；而 FedCM 按钮流（use_fedcm_for_button）是用户主动点击，
 *   必定生效，且同样会弹出 Chrome 顶栏那个原生账号选择器 —— 正是我们要的体验。
 *   故：按钮为主（保证可用），autoPrompt 作为可选项（提升回访转化）。
 *
 * ★★ 关于「账号选择器」的两道强制关闭（v1.5.22 修，用户实测发现）：
 *   官网JS 参考明确写着：
 *     · button_auto_select —— 「如果启用此功能，系统会自动登录具有有效Google 会话的
 *       回访用户，从而绕过账号选择器提示。」（默认 false）
 *     · auto_select —— 开启自动登录后「系统会自动返回用户的 ID 令牌凭据，
 *       而无需用户进行任何互动」。
 *   也就是说：只要开了 FedCM 按钮流 + 之前授权过，**回访用户点一下按钮就直接进站了，
 *   根本不弹账号选择器** —— 这在共享电脑 / 误触 / 纠纷场景下就是「静默登错账号」。
 *   本站产品要求是「必须由用户亲手选一次账号」，故两道都显式写 false。
 *   显式写而非依赖默认值：① 语义自解释，后人不会看到「默认 false」就删掉；
 *   ②若 Google 调整默认值，这两行仍能锁住行为。
 *
 * 降级路径（Firefox / Safari / iOS）：
 *   `window.FedCM` 不存在 → 隐藏 Google 按钮容器，显示 fallback 链接
 *   → 指向父主题的 /oauth/google（OAuth2 授权码流程，逻辑完全不同但功能等价）。
 *   不会让用户看到「点了没反应」或任何报错。
 */
(function () {
    'use strict';

    var cfg = window.zibllChildFedcm;
    if (!cfg || !cfg.clientId || !cfg.endpoint) { return; }

    var wrap = document.getElementById('zibll-fedcm-wrap');
    var slot = document.getElementById('zibll-fedcm-slot');
    var fallback = wrap ? wrap.querySelector('.zibll-fedcm-fallback') : null;
    var fallbackLink = wrap ? wrap.querySelector('.zibll-fedcm-fallback-link') : null;
    if (!wrap || !slot) { return; }

    // 降级链接统一用 PHP 下发的父主题地址（已带 rurl 回跳参数）
    if (fallbackLink && cfg.fallbackUrl) {
        fallbackLink.setAttribute('href', cfg.fallbackUrl);
    }

    function showFallback() {
        wrap.hidden = false;
        if (fallback) { fallback.hidden = false; }
        if (slot) { slot.innerHTML = ''; }
    }

    function log() {
        if (cfg.debug && window.console && console.log) {
            console.log.apply(console, ['[zibll-child fedcm]'].concat([].slice.call(arguments)));
        }
    }

    // ── 1. 提交 ID Token ────────────────────────────────────
    function submit(credential) {
        if (!credential) { return; }
        log('got credential');

        // 防重复提交：One Tap 与按钮流可能同时回调
        if (wrap.getAttribute('data-submitting') === '1') { return; }
        wrap.setAttribute('data-submitting', '1');

        var body = new URLSearchParams();
        body.set('token', credential);
        body.set('nonce', cfg.nonce || '');

        fetch(cfg.endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: body.toString()
        }).then(function (res) {
            // 端点成功时是 302 跳转，fetch 会跟随并拿到最终页面 HTML。
            // 失败时端点输出的是带说明的 wp_die 页面（非 JSON），
            // 所以这里不解析 body，直接按状态码决定去留。
            log('endpoint status', res.status, res.url);
            if (res.redirected || res.ok) {
                window.location.href = res.url || cfg.endpoint;
                return;
            }
            wrap.removeAttribute('data-submitting');
            showFallback();
        }).catch(function (err) {
            log('submit failed', err);
            wrap.removeAttribute('data-submitting');
            showFallback();
        });
    }

    // ── 2. 初始化 ──────────────────────────────────────────
    function init(google) {
        if (!google || !google.accounts || !google.accounts.id) {
            showFallback();
            return;
        }

        var initCfg = {
            client_id: cfg.clientId,
            callback: submit,
            // ★ FedCM 开关：不需要任何 Google 白名单，官方要求新应用一律开启。
            //   它把账号选择器交给浏览器代管，不再依赖第三方 Cookie。
            use_fedcm_for_prompt: true,
            // 一次性 nonce，服务端会校验并作废，防重放
            nonce: cfg.nonce || undefined,
            // ★ 关闭 One Tap「自动登录」：官方文档说开启后「系统会自动返回用户的 ID 令牌凭据，
            //   而无需用户进行任何互动」。本站在意「谁登录的」这件事，必须用户亲手确认。
            //   注意：这只管 One Tap 自动登录；按钮流那个由 button_auto_select 单独管（见下）。
            auto_select: false,
            cancel_on_tap_outside: true
        };
        if (cfg.hd) {
            // 限定 Google Workspace 域名（服务端会再校验一次，前端只是提前筛选）
            initCfg.hd = cfg.hd;
        }

        try {
            google.accounts.id.initialize(initCfg);
        } catch (e) {
            log('initialize failed', e);
            showFallback();
            return;
        }

        // ── 3. 渲染按钮（主路径）──
        // 优先 FedCM 按钮流：用户点击后 Chrome 顶部弹出原生账号选择器。
        if (wrap.hidden) { wrap.hidden = false; }

        try {
            google.accounts.id.renderButton(slot, {
                type: 'standard',
                theme: document.body.classList.contains('dark-theme') ? 'filled_black' : 'outline',
                size: 'large',
                text: cfg.text || '使用 Google 账号登录',
                width: Math.min(320, Math.max(200, slot.offsetWidth || 280)),
                // FedCM 按钮流：与 prompt 一样会弹浏览器原生账号选择器
                use_fedcm_for_button: true,
                // ★★ 关键：显式关掉「按钮流自动选择」★★
                //   官方文档原文：「如果启用此功能，系统会自动登录具有有效 Google 会话的回访用户，
                //   从而绕过账号选择器提示。」
                //   即：开启 use_fedcm_for_button 后，回访用户点按钮会**直接登录、没有账号选择器**。
                //   这正是本站要避免的「静默续登」—— 用户点一下就换成了别人（共享电脑/误触/纠纷场景）。
                //   这里显式写 false（虽然它本来就是默认值），目的是：
                //     ① 语义自解释，防止后人看到「默认值是 false」就删掉这行；
                //     ② 若Google 变更默认值，本行仍能锁住行为。
                //   → 效果：每次点按钮都必须弹账号选择器，由用户亲手选一次。
                button_auto_select: false
            });
            log('button rendered (fedcm, auto_select disabled)');
        } catch (e) {
            log('fedcm button failed, fallback to plain button', e);
            try {
                google.accounts.id.renderButton(slot, {
                    type: 'standard',
                    theme: 'outline',
                    size: 'large',
                    text: cfg.text || '使用 Google 账号登录'
                });
            } catch (e2) {
                showFallback();
                return;
            }
        }

        // ── 4. 可选：自动弹窗 ──
        // 首次访问常因 Chrome 手势策略不弹，这是官方已知行为，不影响按钮可用。
        if (cfg.autoPrompt) {
            try {
                google.accounts.id.prompt(function (notif) {
                    // 只取 moment 类型，避免调用已废弃的提示状态方法
                    if (!notif) { return; }
                    var moment = typeof notif.getMomentType === 'function' ? notif.getMomentType() : '';
                    log('prompt moment', moment);
                    // isDismissedMoment / isNotDisplayedMoment / isSkippedMoment
                    // 在 FedCM 下仅部分可用，只用于日志，不影响任何逻辑。
                });
            } catch (e) {
                log('prompt failed', e);
            }
        }
    }

    // ── 5. 加载 GIS ────────────────────────────────────────
    function load() {
        // 已经由别的脚本加载过（例如主题里其它 Google 相关功能）
        if (window.google && window.google.accounts && window.google.accounts.id) {
            init(window.google);
            return;
        }

        // 浏览器不支持 FedCM：直接走降级，不浪费一次网络请求
        if (typeof window.FedCM === 'undefined') {
            log('FedCM unsupported by this browser');
            showFallback();
            return;
        }

        var s = document.createElement('script');
        s.src = 'https://accounts.google.com/gsi/client';
        s.async = true;
        s.defer = true;
        s.onload = function () { init(window.google); };
        s.onerror = function () {
            log('GIS script failed to load');
            showFallback();
        };
        document.head.appendChild(s);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', load);
    } else {
        load();
    }
})();
