/**
 * 子比子主题 - 爱发电支付「新窗口打开」拦截脚本
 * ─────────────────────────────────────────────────────────────
 * 背景：父主题 zibpay 的 pay.js 消费支付跳转的方式是
 *     if (n.url && n.open_url) { window.location.href = n.url; ... }
 * 即【同标签跳转】—— 用户点了爱发电支付后，站内支付页被整页替换，
 * 付款完成后只能手动敲域名回到本站，转化链路在这里断掉。
 *
 * 为什么不能直接改父主题：本子主题铁律之一是「父主题 zibll/ 一律不改」，
 * 只能用子主题的钩子/脚本做零侵入改造。
 *
 * 拦截点：父主题 zib_ajax() 在 $.ajax.success 之后会派发 jQuery 事件
 *     $t.trigger('zib_ajax.success', n)
 *（见 zibll/js/main.js 的 zib_ajax 实现），而 pay.js 的成功回调
 * 是在其后被调用的。因此这里监听该事件并改写响应数据：
 *     · 识别标记：n.afdian_open_window === true（由子主题 PHP 下发）
 *     · 动作一：把 open_url 置为 false，阻断父主题的同标签跳转
 *     · 动作二：把 url 转成 form_html（父主题对 form_html 走表单 POST 提交，
 *               可通过 target=_blank 弹新窗口），从而在新窗口打开爱发电
 *     · 动作三：给出用户可读的提示（付款后关闭新窗口即可回站）
 *
 * 兜底：若本脚本未加载（例如浏览器缓存了旧 JS、或站点优化裁剪了此文件），
 * PHP 侧仍会返回 open_url=true，父主题会退化为同标签跳转 ——
 * 行为退但不会卡死用户。
 */
(function ($) {
    'use strict';

    // 已在本次跳转中提示过，避免重复弹窗
    var hinted = false;

    // 反复检查：某些主题版本可能先派发事件再执行回调，这里用微任务重试兜底
    function tryIntercept(n) {
        if (!n || typeof n !== 'object') { return false; }

        // 只处理本模块标记过的爱发电响应
        if (!n.afdian_open_window || !n.url) { return false; }

        // ① 阻断父主题的同标签跳转
        n.open_url = false;

        // ② 改为表单 POST + target=_blank，在新窗口打开
        if (!n.form_html) {
            var fields = '';
            if (n.afdian_origin) {
                fields += '<input type="hidden" name="afdian_origin" value="' +
                    $('<div>').text(n.afdian_origin).html() + '">';
            }
            n.form_html =
                '<form id="zibll-child-afdian-pay" method="get" action="' +
                $('<div>').text(n.url).html() +
                '" target="_blank" rel="noopener noreferrer" style="display:none;">' +
                fields +
                '</form>';
            n.hide_modal = true; // 关闭收银台弹窗，避免遮挡
        }

        // ③ 给用户一句提示
        if (!hinted && n.afdian_msg) {
            hinted = true;
            if (typeof window.notyf === 'function') {
                window.notyf(n.afdian_msg, 'success', '', 'zibpay_afdian');
            }
        }
        return true;
    }

    $(document).on('zib_ajax.success', function (e, n) {
        if (!tryIntercept(n)) { return; }

        // 父主题对 n.form_html 的处理只是 `_body.append(n.form_html)`
        // （zibll/zibpay/assets/js/pay.js），它【不会自动提交】表单 ——
        // 那条分支是给「易支付 POST 跳转」用的，表单里自带提交脚本。
        // 所以这里自己提交：append 已在父主题中完成（顺序在其后），
        // 用 setTimeout 延到父主题 append 之后再找表单并提交。
        setTimeout(function () {
            var $f = $('#zibll-child-afdian-pay');
            if (!$f.length) { return; }
            try {
                $f[0].submit();
            } catch (err) {
                // 极少数环境（如 CSP 限制）下 submit() 被拦截，
                // 退化为手动打开新窗口，保证用户仍能完成支付。
                window.open($f.attr('action'), '_blank', 'noopener,noreferrer');
            }
        }, 0);
    });
})(jQuery);
