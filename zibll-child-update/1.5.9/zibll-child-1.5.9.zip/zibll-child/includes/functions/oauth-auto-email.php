<?php
/**
 * 子比子主题 - 第三方登录自动写入已验证邮箱
 * ─────────────────────────────────────────────────────────────
 * 解决什么问题
 *   父主题在处理第三方（Google / Microsoft / Facebook / Apple）登录时，
 *   拿得到对方的「已验证邮箱」，但没写进 WordPress 用户邮箱，导致：
 *     · 新用户 user_email 恒为空；
 *     · 站点一开「强制绑定邮箱」，第三方登录后立刻被弹去绑定页，
 *       用户得把 Google 邮箱再手填一遍（本子主题实测复现）。
 *
 * 父主题的两处断点（本子主题不改父主题，故在此补齐）
 *   1) oauth/google/callback.php 组装 $oauth_data 时只取 openid/name/avatar，
 *      email 被留在 getUserInfo 里（oauth2/v2/userinfo 实际返回
 *      email + verified_email:true）。
 *   2) oauth/oauth.php 自动建号用 wp_create_user($login_name, $user_pass)，
 *      第三个参数 $email 没传 → user_email 为空（oauth.php:134）。
 *
 * 判定链（决定跳不跳绑定页）
 *   zib_redirect_user_bind_page()（inc/functions/zib-user.php:972）
 *   挂在 template_redirect 优先级 10，只判断 $user->user_email 是否为空。
 *   本模块挂在优先级 9，早它一步把邮箱补上，因此登录后能真正停在
 *   发起登录的那个页面上，而不是被绑定页劫持。
 *
 * 安全边界（三条都不能省）
 *   · 只认第三方明确标记为「已验证」的邮箱；
 *   · 邮箱已被【其他】账号占用时不抢绑（否则等于给未验证邮箱开后门、可接管账号）；
 *   · 绝不覆盖用户已有的邮箱。
 *
 * 开关：zibll_child_module_enabled('enable_oauth_auto_email')（默认开启）
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('zibll_child_oauth_auto_email')) {
    /**
     * 当前用户邮箱为空、且绑定的第三方账号返回了「已验证邮箱」时，自动写入。
     *
     * @param WP_User|null $user 传入用户对象；为空则取当前登录用户。
     * @return bool 是否写入了邮箱
     */
    function zibll_child_oauth_auto_email($user = null)
    {
        if (!$user instanceof WP_User) {
            $user = wp_get_current_user();
        }

        // 未登录 / 已有邮箱 → 不处理（绝不覆盖用户已有邮箱）
        if (empty($user->ID) || !empty($user->user_email)) {
            return false;
        }

        // 父主题未就绪时的防御性判断
        if (!function_exists('zib_get_user_meta')) {
            return false;
        }

        /**
         * 允许自动填充邮箱的第三方平台白名单。
         *   key   = oauth 类型（对应 oauth_{type}_getUserInfo 这个 user meta）
         *   value = 必须为真的「已验证」字段名；
         *           留空表示该平台只下发已验证邮箱，无需额外校验。
         *
         * 说明：github / twitter / qq / weixin / weibo / alipay / baidu / douyin / gitee
         * 的 getUserInfo 里没有邮箱字段，故不列入。
         */
        $providers = apply_filters('zibll_child_oauth_auto_email_providers', array(
            'google'    => 'verified_email',
            'microsoft' => '',
            'facebook'  => '',
            'apple'     => '',
        ));

        foreach ($providers as $type => $verify_key) {
            $info = zib_get_user_meta($user->ID, 'oauth_' . $type . '_getUserInfo', true);
            if (empty($info) || !is_array($info)) {
                continue;
            }

            $email = '';
            foreach (array('email', 'mail') as $k) {
                if (!empty($info[$k]) && is_string($info[$k])) {
                    $email = trim($info[$k]);
                    break;
                }
            }
            if (!$email || !is_email($email)) {
                continue;
            }

            // 安全闸 ①：只认「已验证」邮箱。
            // 注意 Google 的 oauth2/v2/userinfo 用 verified_email，
            // 而 OIDC 用 email_verified，两种都判。
            if ($verify_key) {
                $verified = false;
                foreach (array($verify_key, 'email_verified') as $vk) {
                    if (isset($info[$vk])) {
                        $verified = filter_var($info[$vk], FILTER_VALIDATE_BOOLEAN);
                        break;
                    }
                }
                if (!$verified) {
                    continue;
                }
            }

            // 安全闸 ②：邮箱已被其他账号占用 → 不抢绑，交回给用户手动绑定
            $owner = email_exists($email);
            if ($owner && (int) $owner !== (int) $user->ID) {
                continue;
            }

            // 写邮箱。旧邮箱为空，WP 的「邮箱已变更」通知本就发不出去，
            // 这里显式屏蔽，避免任何多余邮件。
            add_filter('send_email_change_email', '__return_false');
            $result = wp_update_user(array(
                'ID'         => $user->ID,
                'user_email' => $email,
            ));
            remove_filter('send_email_change_email', '__return_false');

            if (is_wp_error($result)) {
                continue;
            }

            update_user_meta($user->ID, 'zibll_child_oauth_email_source', $type);
            clean_user_cache($user->ID); // 让本次请求后续读取到新值

            return true;
        }

        return false;
    }
}

/**
 * wp_login 适配器。
 * 回调签名为 ($user_login, $user)，首参是用户名字符串，不能直接当用户对象用。
 */
if (!function_exists('zibll_child_oauth_auto_email_on_login')) {
    function zibll_child_oauth_auto_email_on_login($user_login, $user)
    {
        zibll_child_oauth_auto_email($user instanceof WP_User ? $user : null);
    }
}

/*
 * 挂两个点，覆盖全部路径：
 *   ① wp_login（优先级 20）——第三方自动建号时父主题会 do_action('wp_login')，
 *      且此刻 oauth_{type}_getUserInfo 已写好，可第一时间补上邮箱，
 *      回调返回的下一跳就已经是干净状态；
 *   ② template_redirect（优先级 9）——父主题的强制绑定判定挂在优先级 10，
 *      本模块早它一步，兜住「绑定页新建账号」等不走 wp_login 的路径。
 */
if (zibll_child_module_enabled('enable_oauth_auto_email', true)) {
    add_action('wp_login', 'zibll_child_oauth_auto_email_on_login', 20, 2);
    add_action('template_redirect', 'zibll_child_oauth_auto_email', 9);
}
