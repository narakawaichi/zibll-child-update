<?php
/**
 * 子比子主题 - 模块加载入口
 *
 * 使用父主题提供的 zib_require() 批量加载子主题模块文件
 * 父主题 inc/inc.php 已在此之前加载完毕，所有父主题函数均可安全调用
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// 使用父主题的 zib_require() 加载子主题模块（保持与父主题一致的加载风格）
// 顺序要点：theme-updater 必须在 theme-options 之前加载，
// 因为 theme-options 注册面板时会调用 theme-updater 的 zibll_child_get_version() 等函数渲染「主题更新」区。
// rating-plugin-loader 需靠前加载：它会在 WP 插件加载之后、父主题 zib_require_end 触发之前，
// 视情况 require 内置评分插件主文件（独立插件已激活则跳过重载，避免重定义 fatal）。
// 依岸归品牌层：统一后台菜单（Hoarfall 工具）+ 后台视觉（CSF 横幅 / 原生页横幅 / 页内分级导航）
require_once get_stylesheet_directory() . '/includes/brand-menu.php';

zib_require(array(
    'includes/functions/modules-switch', // 模块全量开关：提供 zibll_child_module_enabled()，须早于各插件 loader 以完成早退判断
    'includes/functions/compat-check',  // 运行环境自检：PHP/WP/父主题版本失配时于后台给出明确提示（子比 9.1 + WP 7.1 基线）
    'includes/functions/theme-uninstall', // 卸载数据清理：切换/删除主题时询问并清除本子主题整合插件数据（挂 switch_theme + 后台弹窗 JS）
    'includes/xiazhi-qz-loader',        // 夏稚文章前缀插件「一体化」加载器（条件加载，数据存 post_meta，修复 ajax 懒加载列表前缀不显示）
    'includes/rating-plugin-loader',   // 文章评分插件「一体化」加载器（条件加载，数据兼容独立插件）
    'includes/zibll-comment-emoji-loader', // 评论表情包插件「一体化」加载器（整合 zibll-comment-emoji，替换原月薪喵表情包）
    'includes/functions/functions',
    'includes/functions/oauth-auto-email', // 第三方登录自动写入已验证邮箱（修「强制绑定邮箱」把 OAuth 用户弹去绑定页）
    'includes/functions/google-avatar-proxy', // 谷歌登录头像国内可达：custom_avatar 里的 googleusercontent 改写为墙外反代地址
    'includes/functions/options-backup', // 主题设置备份/恢复/导入：提供 zibll_child_settings_backup_html() 等（供 theme-options 面板引用）
    'includes/functions/user-export-import', // 用户数据导入/导出：流式 JSONL + 分批异步作业，含父主题 zibll 用户扩展数据的备份与恢复（须先于 theme-options 加载）
    'includes/functions/bing-push',      // 必应 URL 推送：提供 zibll_child_bing_panel_html() / zibll_child_bing_ready()（供 theme-options 面板引用）
    'includes/functions/msg-popup',     // 消息通知悬浮弹窗：桌面端/移动端各一套配置，只读复用父主题 ZibMsg 取数与渲染
    'includes/functions/user-box',      // 悬停面板快捷按钮：按用户权限自定义（图标全量 SVG+FA），零侵入前端替换
    'includes/functions/comment-mark',  // 留言标记：后台评论列表加「标记」列 + 按标记筛选（含未标记），
                                        // 前台在留言正文下方显示彩色标签。数据存 comment meta，
                                        // 标记预设由设置页「留言标记」分组维护。默认关闭。
                                        // ⚠️ 必须在 functions 之后：读配置用 zibll_child_get_option()。
    'includes/functions/email-suffix',  // 注册邮箱后缀下拉：只填前缀 + 白名单后缀（服务端 priority=1 前置守卫）
                                        // ⚠️ 必须排在 theme-options 之前：面板字段会引用本模块的
                                        //    zibll_child_email_suffix_import_html() 生成「从父主题导入」区块。
    'includes/functions/login-mode',    // 登录方式切换：邮箱 / 用户名（父主题开了手机号登录时自动多一个入口）
                                        // 纯前端引导 + 提交前提示，后端仍由父主题按内容自动识别。
    'includes/functions/cloudflare-turnstile', // Cloudflare Turnstile 人机验证：注册/登录/找回密码/评论提交前先过 Cloudflare
    'includes/functions/fix-imgbox-keyboard', // 修复：图片灯箱(Swiper)关闭后残留键盘监听劫持评论框/私聊方向键
                                        // ⚠️ 必须排在 theme-options 之前：面板分组会调用本模块的
                                        //    zibll_child_turnstile_status_html() 渲染配置状态，未加载时该区块为空。
                                        //    默认关闭，未开启时不注册任何拦截、不输出任何前台脚本。
                                        //    （disable-parent-captcha 不再在此加载 —— 它已在 functions.php 顶部、
                                        //     require 父主题核心之前挂上 pre_option 过滤器，否则会被提前缓存短路。）
    'includes/functions/comment-image-defer', // 评论配图：选图/粘贴只排队、点发送才上传 + 服务端只洗评论图（去马/转正方向/不动画）
    'includes/functions/afdian-pay',    // 爱发电（Afdian）支付渠道：融入 zibll 收银台 + Webhook 入账（仿父主题 zibpay 网关）
                                        // ⚠️ 必须排在 theme-options 之前：主题设置页的「爱发电支付」分组内容会在
                                        //    注册时【立即】function_exists('zibll_child_afdian_webhook_url') 求值
                                        //    并输出 Webhook 地址；若晚于 theme-options 加载，将被恒判为「模块未加载」。
                                        //    同类须前置的还有 options-backup / user-export-import / bing-push。
    'includes/functions/theme-updater', // WordPress 原生主题更新适配器（依岸归 CDN / GitHub 双源）
    'includes/functions/parent-update-notice', // 父主题「文档&更新」误报修正：子主题启用时父主题拿子主题版本
                                        // （1.6.2）去比官方（9.1），恒判「有更新」。用 CSF 的
                                        // csf_zibll_options_sections 过滤器就地改写说明，不动父主题文件。
    'includes/functions/theme-options', // 子主题独立设置页（CSF）+ 原生更新检查入口
), true);
