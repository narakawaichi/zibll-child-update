<?php
/**
 * 子比子主题 - Cloudflare Turnstile 人机验证
 * ─────────────────────────────────────────────────────────────
 * 目标：在「注册 / 登录 / 找回密码 / 发表评论」这些可能被脚本批量刷的接口上，
 *       先完成 Cloudflare Turnstile 验证，通过后父主题才继续处理该请求。
 *
 * 设计约束（以及为什么只能这样做）：
 *
 * 1) 默认关闭、零侵入。开关未开或凭证没填齐时，本文件**只在最后注册两个
 *    wp_enqueue_scripts 之外的钩子都不加**——准确说是：所有钩子都注册了，
 *    但每个回调第一行就 return，不输出任何脚本、不发任何外网请求、
 *    不改任何父主题行为。唯一的开销是一次 get_option('zibll_child_options')。
 *
 * 2) 服务端拦截点为什么用「同名 action + 优先级 1」：
 *    父主题把 zib_ajax_user_signup / zib_ajax_submit_comment 等注册在默认
 *    优先级 10（见 zibll/action/sign_register.php、action/comment.php）。
 *    本模块注册在**同名 action 的优先级 1**，因此先于父主题执行，校验失败
 *    就按父主题的响应格式 {error:1, msg, ys} 输出 JSON 并 exit。
 *    前端 zib_ajax() 的 notyf 能原样弹出提示，按钮也能正常恢复。
 *    这套路与 includes/functions/email-suffix.php 完全一致，已在线上验证过。
 *
 * 3) 前端为什么是「JS 插隐藏域」而不是改模板：
 *    父主题的注册/登录/找回密码表单（zib_signup_form / zib_signin_form /
 *    zib_resetpassword_form，均在 zibll/inc/functions/zib-user.php）是纯字符串
 *    拼接输出，**没有任何 filter 钩子**。但它们提交时统一走
 *    zib_ajax() → form.serializeObject()，评论表单（#commentform）也是
 *    _form.serializeObject() 后手工补 action=submit_comment。
 *    所以只要在表单内放一个隐藏域，序列化时就会自动带上 token，
 *    既不用劫持 zib_ajax()，也不用碰父主题任何一行代码。
 *
 * 4) 与父主题自带人机验证的关系：
 *    父主题有自己的滑块 / 图形 / 腾讯 / 极验（_pz('user_verification_type')）。
 *    本模块是**额外一层**，两者可叠加、互不影响；本模块关闭时父主题那套照旧。
 *
 * 5) 只拦前台 AJAX：子比的注册、登录、评论都走 admin-ajax.php，故只挂
 *    wp_ajax_* / wp_ajax_nopriv_*。后台建用户、OAuth 建号、WooCommerce 结账
 *    注册等其它路径一律不碰（registration_errors 也**不挂**，避免误伤）。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('ZIBLL_CHILD_TURNSTILE_VERIFY_URL')) {
    define('ZIBLL_CHILD_TURNSTILE_VERIFY_URL', 'https://challenges.cloudflare.com/turnstile/v0/siteverify');
}

if (!defined('ZIBLL_CHILD_TURNSTILE_JS_URL')) {
    define('ZIBLL_CHILD_TURNSTILE_JS_URL', 'https://challenges.cloudflare.com/turnstile/v0/api.js');
}

// 前端隐藏域的名。
// ⚠️ 不要直接叫 `cf-turnstile-response`：Cloudflare 的 widget 在渲染到表单内时，
//    会自动往容器里注入一个同名 `cf-turnstile-response` 隐藏域；一旦与我们自建的
//    隐藏域重名，父主题 serializeObject() 会把同名字段收集成数组，
//    序列化后 PHP 端收到的是数组（强转成字面量 "Array"），当成 token 发往
//    Cloudflare 必返回 invalid-input-response。改用唯一名可彻底消除碰撞。
if (!defined('ZIBLL_CHILD_TURNSTILE_FIELD')) {
    define('ZIBLL_CHILD_TURNSTILE_FIELD', 'zc_turnstile_response');
}

// Turnstile token 正常长度约几百字符；给足余量，同时挡掉超长恶意输入。
if (!defined('ZIBLL_CHILD_TURNSTILE_TOKEN_MAX')) {
    define('ZIBLL_CHILD_TURNSTILE_TOKEN_MAX', 2048);
}

/**
 * 读取本模块的开关型配置。
 *
 * ⚠️ 为什么不用现成的 zibll_child_option_enabled()：
 *    CSF 的 switcher 关闭时保存的是**空字符串**，而它在「未设置」与「设为空」
 *    两种情况下都会回落到 $default，对 default=true 的开关会导致
 *    「关了又自动变回开启」。这里用 array_key_exists 区分这两种情况。
 *
 * @param string $key
 * @param bool   $default
 * @return bool
 */
function zibll_child_turnstile_flag($key, $default)
{
    $options = get_option('zibll_child_options', array());
    if (!is_array($options) || !array_key_exists($key, $options)) {
        return (bool) $default;
    }

    $v = $options[$key];
    if ($v === true || $v === 1 || $v === '1') {
        return true;
    }
    if ($v === false || $v === 0 || $v === '0' || $v === '' || $v === null) {
        return false;
    }

    return (bool) $default;
}

/**
 * Site Key（前台渲染用，可公开）。
 *
 * @return string
 */
function zibll_child_turnstile_site_key()
{
    return trim((string) zibll_child_get_option('turnstile_site_key', ''));
}

/**
 * Secret Key（服务端校验用，绝不下发到前端）。
 *
 * ⚠️ 读取优先级：wp-config.php 常量 > 后台填写的值。
 *    支持在 wp-config.php 里定义常量（推荐生产环境使用）：
 *      define('ZIBLL_CHILD_TURNSTILE_SECRET', '0x...');
 *    常量方式下密钥不落库，数据库备份泄露 / SQL 注入都拿不到它。
 *
 * @return string
 */
function zibll_child_turnstile_secret_key()
{
    if (defined('ZIBLL_CHILD_TURNSTILE_SECRET')) {
        return trim((string) constant('ZIBLL_CHILD_TURNSTILE_SECRET'));
    }

    return trim((string) zibll_child_get_option('turnstile_secret_key', ''));
}

/**
 * 功能是否真正可用：总开关开启 **且** 两把钥匙都填了。
 *
 * 为什么「凭证不全就当关闭」而不是放行：
 *   开着开关却没配密钥时，前端会渲染出必然拿不到 token 的控件，
 *   结果是所有注册/评论被永久锁死。宁可整个功能不生效。
 *
 * @return bool
 */
function zibll_child_turnstile_enabled()
{
    if (!zibll_child_turnstile_flag('turnstile_enable', false)) {
        return false;
    }

    return zibll_child_turnstile_site_key() !== '' && zibll_child_turnstile_secret_key() !== '';
}

/**
 * 场景定义：场景 key => 该场景覆盖的 admin-ajax action 名。
 *
 * action 名取自父主题源码：
 *   zibll/action/sign_register.php   user_signup / signup_captcha /
 *                                    user_signin / user_signin_nopas / signin_captcha /
 *                                    reset_password / resetpassword_captcha
 *   zibll/action/comment.php         submit_comment
 *
 * ⚠️ signup_captcha / signin_captcha / resetpassword_captcha 是「发送验证码」
 *    的接口，同样必须保护——否则短信/邮件轰炸机可以完全绕过前端控件直接打接口。
 *
 * @return array
 */
function zibll_child_turnstile_scene_defs()
{
    static $defs = null;
    if ($defs !== null) {
        return $defs;
    }

    $defs = array(
        'signup'  => array(
            'title'   => '用户注册',
            'actions' => array('user_signup', 'signup_captcha'),
        ),
        'signin'  => array(
            'title'   => '用户登录',
            'actions' => array('user_signin', 'user_signin_nopas', 'signin_captcha'),
        ),
        'resetpw' => array(
            'title'   => '找回密码',
            'actions' => array('reset_password', 'resetpassword_captcha'),
        ),
        'comment' => array(
            'title'   => '发表评论',
            'actions' => array('submit_comment'),
        ),
    );

    return $defs;
}

/**
 * 单个场景是否启用（后台四个独立开关）。
 *
 * @param string $scene
 * @return bool
 */
function zibll_child_turnstile_scene_enabled($scene)
{
    $defs = zibll_child_turnstile_scene_defs();
    if (!isset($defs[$scene])) {
        return false;
    }

    // 注册与评论是主要被刷的地方，默认开；登录/找回密码默认关，避免误伤真实用户。
    $default = ($scene === 'signup' || $scene === 'comment');

    return zibll_child_turnstile_flag('turnstile_scene_' . $scene, $default);
}

/**
 * 当前已启用的场景 key 列表。
 *
 * @return array
 */
function zibll_child_turnstile_active_scenes()
{
    $out = array();
    foreach (array_keys(zibll_child_turnstile_scene_defs()) as $scene) {
        if (zibll_child_turnstile_scene_enabled($scene)) {
            $out[] = $scene;
        }
    }

    return $out;
}

/**
 * 由 admin-ajax 的 action 反查所属场景；不属于任何受保护场景返回空串。
 *
 * @param string $action
 * @return string
 */
function zibll_child_turnstile_scene_of_action($action)
{
    $action = (string) $action;
    if ($action === '') {
        return '';
    }

    foreach (zibll_child_turnstile_scene_defs() as $scene => $def) {
        if (in_array($action, $def['actions'], true)) {
            return $scene;
        }
    }

    return '';
}

/**
 * 调用 Cloudflare siteverify 校验一次性 token。
 *
 * @param string $token           前端提交的 Turnstile token。
 * @param string $expected_action 预期的场景 action（signup/signin/resetpw/comment）。
 * @return array{error:int,msg:string,code:string}
 */
function zibll_child_turnstile_verify_token($token, $expected_action = '')
{
    $token = trim((string) $token);

    if ($token === '') {
        return array('error' => 1, 'msg' => '请先完成人机验证', 'code' => 'missing-input-response');
    }

    if (strlen($token) > ZIBLL_CHILD_TURNSTILE_TOKEN_MAX) {
        return array('error' => 1, 'msg' => '人机验证数据异常，请刷新页面后重试', 'code' => 'invalid-input-response');
    }

    // ⚠️ 故意不传 remoteip：
    //   站点位于阿里云 CDN/WAF 之后，服务端看到的 REMOTE_ADDR 是 CDN 边缘节点 IP，
    //   并非访客真实 IP；一旦把错误的 IP 当作 remoteip 传给 Cloudflare，token 的 IP
    //   绑定校验会判 mismatch 直接失败（error-codes: invalid-input-response）。
    //   Turnstile 的 token 本身已绑定求解时的真实 IP，不传 remoteip 也能正常校验，
    //   且可避免 CDN 场景下的误杀。因此这里只传 secret + response。
    $body = array(
        'secret'   => zibll_child_turnstile_secret_key(),
        'response' => $token,
    );

    // 连接层失败（超时 / DNS / 网络抖动）做一次快速重试，避免 Cloudflare 偶发抖动
    // 直接误伤真实用户。只重试「请求没送达或没拿到响应」的情况——此时 token 尚未
    // 被 Cloudflare 消费，重发是安全的；拿到 HTTP 响应后的一律不再重试。
    $response = false;
    for ($attempt = 1; $attempt <= 2; $attempt++) {
        $response = wp_remote_post(ZIBLL_CHILD_TURNSTILE_VERIFY_URL, array(
            'timeout'     => 5,
            'redirection' => 3,
            'body'        => $body,
            'headers'     => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            ),
        ));

        if (!is_wp_error($response)) {
            break;
        }

        if ($attempt === 1) {
            zibll_child_turnstile_log('siteverify-retry', '', 'request-failed', $response->get_error_message());
        }
    }

    if (is_wp_error($response)) {
        return array(
            'error' => 1,
            'msg'   => '人机验证服务连接失败，请稍后重试',
            'code'  => 'request-failed',
        );
    }

    $raw  = wp_remote_retrieve_body($response);
    $json = json_decode($raw, true);

    if (!is_array($json)) {
        return array(
            'error' => 1,
            'msg'   => '人机验证服务返回异常，请稍后重试',
            'code'  => 'bad-response',
        );
    }

    if (!empty($json['success'])) {
        // 场景绑定校验：widget 渲染时按场景传了 action，siteverify 会原样回显。
        // 回显非空且与当前接口的预期场景不符 → token 是从别的场景（页面）拿的，拒绝。
        // 回显为空说明前端还是没带 action 的旧版脚本（浏览器缓存），放行以保兼容。
        $echo_action = isset($json['action']) ? trim((string) $json['action']) : '';
        if ($expected_action !== '' && $echo_action !== '' && $echo_action !== $expected_action) {
            return array(
                'error' => 1,
                'msg'   => '人机验证与当前操作不匹配，请刷新页面后重新验证',
                'code'  => 'action-mismatch',
            );
        }

        return array('error' => 0, 'msg' => '', 'code' => '');
    }

    $codes = (isset($json['error-codes']) && is_array($json['error-codes'])) ? $json['error-codes'] : array();

    // 密钥类错误是站点配置问题，提示要指向管理员；token 类错误是用户侧问题。
    $config_broken = array(
        'missing-input-secret',
        'invalid-input-secret',
        'bad-request',
    );

    foreach ($codes as $code) {
        if (in_array((string) $code, $config_broken, true)) {
            return array(
                'error' => 1,
                'msg'   => '人机验证服务配置有误（密钥无效或缺失），请联系站点管理员',
                'code'  => (string) $code,
            );
        }
    }

    return array(
        'error' => 1,
        'msg'   => '人机验证未通过或已过期，请刷新页面后重新验证',
        'code'  => $codes ? (string) $codes[0] : 'invalid-input-response',
    );
}

/**
 * 记录拦截日志（写入 PHP error_log / WP_DEBUG_LOG）。
 *
 * 为什么只写 error_log 不入库：被刷时写入量不可预估，入库会拖垮 admin-ajax。
 * 每条一行，只记 action / scene / 错误码 / 来源 IP，绝不记录 token 本身。
 *
 * @param string $action admin-ajax action 名。
 * @param string $scene  场景 key，可为空。
 * @param string $code   错误码。
 * @param string $extra  附加信息（如 wp_error message）。
 * @return void
 */
function zibll_child_turnstile_log($action, $scene, $code, $extra = '')
{
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';

    error_log(sprintf(
        '[zibll-child/turnstile] reject action=%s scene=%s code=%s ip=%s%s',
        $action !== '' ? $action : '-',
        $scene !== '' ? $scene : '-',
        $code !== '' ? $code : '-',
        $ip !== '' ? $ip : '-',
        $extra !== '' ? ' (' . $extra . ')' : ''
    ));
}

/**
 * 以父主题的 AJAX 响应格式失败退出。
 *
 * 结构与 zib_send_json_error() 一致（error / msg / ys），前端 zib_ajax()
 * 的 notyf 与按钮恢复逻辑都能原样工作。
 *
 * @param string $msg
 * @return void
 */
function zibll_child_turnstile_reject($msg)
{
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }

    echo wp_json_encode(array(
        'error' => 1,
        'msg'   => $msg,
        'ys'    => 'danger',
    ));
    exit;
}

/**
 * 前置守卫：抢在父主题同名回调（优先级 10）之前校验 Turnstile。
 *
 * @return void
 */
function zibll_child_turnstile_guard()
{
    if (!zibll_child_turnstile_enabled()) {
        return;
    }

    $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
    $scene  = zibll_child_turnstile_scene_of_action($action);

    if ($scene === '' || !zibll_child_turnstile_scene_enabled($scene)) {
        return;
    }

    // 已登录用户默认跳过：他们的身份已经过认证，再挡一道只会添堵。
    if (zibll_child_turnstile_flag('turnstile_skip_logged', true) && is_user_logged_in()) {
        return;
    }

    $raw = isset($_REQUEST[ZIBLL_CHILD_TURNSTILE_FIELD])
        ? wp_unslash($_REQUEST[ZIBLL_CHILD_TURNSTILE_FIELD])
        : '';

    // 防御：若前端意外把字段提交成数组（早期版本曾因同名双字段触发），
    // 取第一个非空字符串元素，避免把字面量 "Array" 当 token 发往 Cloudflare。
    if (is_array($raw)) {
        $picked = '';
        foreach ($raw as $v) {
            if (is_string($v) && $v !== '') {
                $picked = $v;
                break;
            }
        }
        $raw = $picked;
    }

    $token = trim((string) $raw);

    if ($token === '') {
        zibll_child_turnstile_log($action, $scene, 'missing-input-response');
        zibll_child_turnstile_reject('请先完成人机验证');
    }

    $result = zibll_child_turnstile_verify_token($token, $scene);

    if (!empty($result['error'])) {
        zibll_child_turnstile_log($action, $scene, $result['code'], isset($result['msg']) ? $result['msg'] : '');
        zibll_child_turnstile_reject($result['msg']);
    }

    // 通过：什么都不做，交回父主题继续处理。
}

// 注册所有受保护 action 的前置守卫（含游客与登录态两套钩子）。
foreach (zibll_child_turnstile_scene_defs() as $_ts_scene => $_ts_def) {
    foreach ($_ts_def['actions'] as $_ts_action) {
        add_action('wp_ajax_nopriv_' . $_ts_action, 'zibll_child_turnstile_guard', 1);
        add_action('wp_ajax_' . $_ts_action, 'zibll_child_turnstile_guard', 1);
    }
}
unset($_ts_scene, $_ts_def, $_ts_action);

/**
 * 登记前台资源。仅在功能真正可用时加载，关闭时页面不会多出任何一个请求。
 *
 * @return void
 */
function zibll_child_turnstile_assets()
{
    if (!zibll_child_turnstile_enabled()) {
        return;
    }

    $scenes = zibll_child_turnstile_active_scenes();
    if (!$scenes) {
        return;
    }

    $uri = get_stylesheet_directory_uri() . '/assets/';
    $dir = get_stylesheet_directory() . '/assets/';
    $ver = wp_get_theme()->get('Version');

    // ⚠️ 这两个资源可能在不升主题版本的情况下单独更新（热修复），
    //    若沿用主题版本号做 ver，浏览器与 CDN 会继续命中旧缓存；
    //    这里用文件修改时间做版本号，改一次就自动换 URL。
    $css_file = $dir . 'css/turnstile.css';
    $js_file  = $dir . 'js/cloudflare-turnstile.js';
    $css_ver  = file_exists($css_file) ? $ver . '.' . filemtime($css_file) : $ver;
    $js_ver   = file_exists($js_file) ? $ver . '.' . filemtime($js_file) : $ver;

    wp_enqueue_style('zc-turnstile', $uri . 'css/turnstile.css', array(), $css_ver);
    wp_enqueue_script('zc-turnstile', $uri . 'js/cloudflare-turnstile.js', array(), $js_ver, true);

    // action -> scene 的映射下发给前端，前端靠表单里的隐藏域 name="action"
    // 判断这张表单属于哪个场景（父主题注册/找回密码表单都叫 form#sign-up，
    // 只看 id 无法区分，必须靠 action）。
    $action_scene = array();
    foreach (zibll_child_turnstile_scene_defs() as $scene => $def) {
        foreach ($def['actions'] as $act) {
            $action_scene[$act] = $scene;
        }
    }

    wp_localize_script('zc-turnstile', 'ZC_TURNSTILE', array(
        'siteKey'   => zibll_child_turnstile_site_key(),
        'theme'     => zibll_child_turnstile_theme(),
        'size'      => zibll_child_turnstile_size(),
        'field'     => ZIBLL_CHILD_TURNSTILE_FIELD,
        // render=explicit：由本模块自己决定何时、在哪渲染，避免父主题弹窗里
        // 被自动渲染到隐藏容器上导致拿不到 token。
        'apiUrl'    => ZIBLL_CHILD_TURNSTILE_JS_URL . '?render=explicit',
        'scenes'    => $scenes,
        'actionMap' => $action_scene,
        'skipLogged' => zibll_child_turnstile_flag('turnstile_skip_logged', true),
        'loggedIn'  => is_user_logged_in(),
        'i18n'      => array(
            'needVerify' => '请先完成人机验证后再提交',
            'loadFailed' => '人机验证组件加载失败，请检查网络后刷新页面',
        ),
    ));
}
add_action('wp_enqueue_scripts', 'zibll_child_turnstile_assets', 30);

/**
 * 控件主题（auto / light / dark）。
 *
 * @return string
 */
function zibll_child_turnstile_theme()
{
    $theme = zibll_child_get_option('turnstile_theme', 'auto');

    return in_array($theme, array('auto', 'light', 'dark'), true) ? $theme : 'auto';
}

/**
 * 控件尺寸（normal / flexible / compact）。
 *
 * @return string
 */
function zibll_child_turnstile_size()
{
    $size = zibll_child_get_option('turnstile_size', 'normal');

    return in_array($size, array('normal', 'flexible', 'compact'), true) ? $size : 'normal';
}

/**
 * 后台设置页的状态说明（供 CSF content 字段使用）。
 *
 * @return string
 */
function zibll_child_turnstile_status_html()
{
    $enabled   = zibll_child_turnstile_enabled();
    $switched  = zibll_child_turnstile_flag('turnstile_enable', false);
    $site_key  = zibll_child_turnstile_site_key();
    $secret    = zibll_child_turnstile_secret_key();
    $scenes    = zibll_child_turnstile_active_scenes();
    $defs      = zibll_child_turnstile_scene_defs();
    $skip_log  = zibll_child_turnstile_flag('turnstile_skip_logged', true);

    $rows = array();

    $rows[] = array(
        $switched,
        '总开关',
        $switched ? '已开启' : '已关闭（前台不会有任何变化，服务端也不会拦截任何请求）',
    );
    $rows[] = array(
        $site_key !== '',
        'Site Key',
        $site_key !== '' ? ('已填写（' . esc_html(substr($site_key, 0, 6)) . '…' . esc_html(substr($site_key, -4)) . '）') : '未填写',
    );

    // Secret 来源：wp-config 常量优先生效；都不满足时才回落到数据库里填的值。
    if (defined('ZIBLL_CHILD_TURNSTILE_SECRET')) {
        $rows[] = array(
            true,
            'Secret Key',
            '使用 wp-config.php 常量 ZIBLL_CHILD_TURNSTILE_SECRET（优先生效，不落数据库）',
        );
    } else {
        $rows[] = array(
            $secret !== '',
            'Secret Key',
            $secret !== '' ? ('已填写（' . esc_html(substr($secret, 0, 4)) . '…' . esc_html(substr($secret, -4)) . '）') : '未填写',
        );
    }
    $rows[] = array(
        (bool) $scenes,
        '生效场景',
        $scenes ? implode('、', array_map(function ($s) use ($defs) {
            return isset($defs[$s]) ? $defs[$s]['title'] : $s;
        }, $scenes)) : '没有勾选任何场景，功能不会生效',
    );

    if ($enabled) {
        $rows[] = array(
            true,
            '已登录用户',
            $skip_log ? '跳过验证（只对游客生效）' : '同样需要验证',
        );
    }

    $html = '<div class="zibllc-status" style="margin-top:4px;">';
    foreach ($rows as $r) {
        $html .= '<div class="zibllc-status-row">'
            . '<span class="zibllc-dot ' . ($r[0] ? 'is-ok' : 'is-bad') . '"></span>'
            . '<span class="zibllc-status-title">' . esc_html($r[1]) . '</span>'
            . '<span class="zibllc-status-desc">' . $r[2] . '</span>'
            . '</div>';
    }
    $html .= '</div>';

    // ⚠️ 生产告警：检测到 Cloudflare 官方测试密钥（形如 1x000…AA / 2x000…BB）时，
    //    人机验证等于完全失效——测试密钥对所有 token 直接放行，必须换正式密钥。
    $test_key_hit = (preg_match('/^[123]x0+[A-Za-z]{2}$/', $site_key) || preg_match('/^[123]x0+[A-Za-z]{2}$/', $secret));
    if ($enabled && $test_key_hit) {
        $html .= '<div style="margin:10px 0 0;padding:10px 12px;border:1px solid #d63638;border-left-width:4px;background:#fcf0f1;border-radius:4px;color:#8a2424;font-size:13px;">'
            . '<b>⚠️ 正在使用 Cloudflare 测试密钥！</b>测试密钥会让所有人无条件通过验证，等同于没有人机验证。'
            . '这是联调用的临时配置，正式上线前请到 Cloudflare 控制台换取正式的 Site Key / Secret Key。'
            . '</div>';
    }

    $html .= '<p style="margin:10px 0 0;color:#8c8f94;font-size:12px;">'
        . '密钥在 <a href="https://dash.cloudflare.com/?to=/:account/turnstile" target="_blank" rel="noopener">'
        . 'Cloudflare 控制台 → Turnstile</a> 免费申请，站点密钥（Site Key）与密钥（Secret Key）成对使用。'
        . '联调阶段可先用 Cloudflare 官方文档提供的测试密钥：站点密钥 <code>1x0000000000000000000000AA</code>'
        . '、密钥 <code>1x0000000000000000000000000000000AA</code>，这套组合会直接返回通过，'
        . '可用来确认前后端链路是否打通（若官方调整了测试密钥，以官方文档为准）。'
        . '</p>';

    $html .= '<p style="margin:8px 0 0;color:#8c8f94;font-size:12px;">'
        . '本模块与父主题自带的滑块 / 图形 / 腾讯 / 极验验证是<b>叠加</b>关系，互不影响；'
        . '两者可同时开启。</p>';

    return $html;
}
