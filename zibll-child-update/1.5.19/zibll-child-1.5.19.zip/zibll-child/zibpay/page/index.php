<?php
/**
 * 转发垫片 —— 把父主题对子主题目录的引入请求转回父主题真实文件。
 *
 * 【为什么需要这个文件】
 * 父主题 zibpay/functions/admin/admin.php 注册后台仪表盘「商城统计」小部件时，
 * 用 zib_require('zibpay/page/index') 引入视图文件。而父主题的 zib_require()
 * （zibll/inc/inc.php:67-81）内部是：
 *
 *     require_once get_theme_file_path($data . '.php');
 *
 * get_theme_file_path()（WP 核心 wp-includes/link-template.php:4718）在
 * 「子主题目录存在同名文件」时会【优先返回子主题路径】。于是父主题请求
 * zibpay/page/index 时，拿到的是本文件。
 *
 * ⚠️ v1.5.16 功能修复：本文件此前只有一句 `// Silence is golden.`
 *    （WordPress 目录保护惯例文件），没有转发逻辑 —— 而同目录另外 8 个垫片
 *    （order / shop / income / coupon / product / rebate / withdraw /
 *    charge-card）都正确写了转发。父主题那套商城统计卡片被这个空文件
 *    静默顶掉，付费站点后台仪表盘「商城统计」永久空白，且不报任何错。
 *    现补齐转发逻辑，与同目录其它 8 个垫片保持一致。
 *
 * 【为什么用 require_once】
 * 父主题 zibpay/page/index.php 与本垫片在同一请求内可能被间接二次引入，
 * 故必须 require_once，不能用 require。
 *
 * 【维护提示】
 * 仅当父主题把 zibpay/page/index.php 改名或删除时才需要调整本文件；
 * 正常情况下不需要随版本更新。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

$zibll_child_forward_file = get_template_directory() . '/zibpay/page/index.php';

if (is_readable($zibll_child_forward_file)) {
    require_once $zibll_child_forward_file;
}
