<?php
/**
 * 子比子主题 - 登录方式切换（邮箱 / 用户名）
 * ─────────────────────────────────────────────────────────────
 * 目的：父主题登录表单只有一个「用户名或邮箱」输入框，用户不清楚该填什么。
 *      这里在表单顶部加一组切换按钮，把登录方式明确拆成：
 *        · 邮箱登录（默认，带后缀下拉，和注册页一致）
 *        · 用户名登录
 *        · 手机号登录（仅当父主题开启了手机号登录时出现，避免把原有能力藏掉）
 *
 * 为什么只改前端、不动后端：
 *   父主题 zib_ajax_user_signin()（zibll/action/sign_register.php:188）本来就会
 *   按输入内容自动路由：是邮箱走 get_user_by('email')，是手机号走手机查询，
 *   否则按用户名查。所以「模式」只是给用户的输入引导与前端提示，
 *   后端判定逻辑不需要也不应该改，零风险。
 *
 * 登录的邮箱后缀下拉：
 *   复用注册模块配置的后缀白名单（同一份配置，不再让用户填两遍）。
 *   与注册不同——登录字段名就是 username，不能拆成独立隐藏域，
 *   因此在「点击登录」的捕获阶段把前缀补全成完整邮箱，
 *   父主题随后 serializeObject() 拿到的就是完整地址。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 读取开关型配置（区分「未设置」与「明确设为空」）。
 *
 * ⚠️ 不能直接用 zibll_child_option_enabled()：CSF 的 switcher 关闭时保存的是
 *    空字符串，那个函数在「未设置」和「设为空」都会回落到 default，
 *    default=true 的开关会「关了又自动开」。
 *
 * @param string $key
 * @param bool   $default
 * @return bool
 */
function zibll_child_login_mode_flag($key, $default)
{
    $options = get_option('zibll_child_options', array());
    if (!is_array($options) || !array_key_exists($key, $options)) {
        return (bool) $default;
    }

    $v = $options[$key];
    if ($v === true || $v === 1 || $v === '1') {
        return true;
    }
    if ($v === false || $v === 0 || $v === '0' || $v === '' || $v === null) {
        return false;
    }

    return (bool) $default;
}

/**
 * 功能是否启用。
 *
 * @return bool
 */
function zibll_child_login_mode_enabled()
{
    return zibll_child_login_mode_flag('login_mode_enable', true);
}

/**
 * 登录页可用的邮箱后缀。
 *
 * 与注册模块共用同一份白名单；注册功能未启用或无后缀时返回空数组，
 * 此时登录页退回普通「邮箱地址」输入框，不显示下拉。
 *
 * @return array
 */
function zibll_child_login_mode_suffixes()
{
    if (!function_exists('zibll_child_email_suffix_enabled') || !zibll_child_email_suffix_enabled()) {
        return array();
    }

    return zibll_child_email_suffix_list();
}

/**
 * 登记前台资源。
 *
 * 已登录用户不会看到登录表单（zib_sign_modal 直接 return），无需加载。
 *
 * @return void
 */
function zibll_child_login_mode_assets()
{
    if (!zibll_child_login_mode_enabled() || is_user_logged_in()) {
        return;
    }

    $uri = get_stylesheet_directory_uri() . '/assets/';
    $dir = get_stylesheet_directory() . '/assets/';
    $ver = wp_get_theme()->get('Version');

    $suffixes = zibll_child_login_mode_suffixes();

    // 用文件修改时间做版本号：单独热更新时不会撞浏览器/CDN 缓存。
    $css_file = $dir . 'css/login-mode.css';
    $js_file  = $dir . 'js/login-mode.js';
    $css_ver  = file_exists($css_file) ? $ver . '.' . filemtime($css_file) : $ver;
    $js_ver   = file_exists($js_file) ? $ver . '.' . filemtime($js_file) : $ver;

    // 下拉组件样式与注册模块共用同一份 suffix-picker.css，避免两套视觉漂移。
    if ($suffixes) {
        $picker_file = $dir . 'css/suffix-picker.css';
        $picker_ver  = file_exists($picker_file) ? $ver . '.' . filemtime($picker_file) : $ver;
        wp_enqueue_style('zc-suffix-picker', $uri . 'css/suffix-picker.css', array(), $picker_ver);
    }

    wp_enqueue_style('zc-login-mode', $uri . 'css/login-mode.css', array(), $css_ver);
    wp_enqueue_script('zc-login-mode', $uri . 'js/login-mode.js', array(), $js_ver, true);

    // 父主题开启手机号登录时，多给一个「手机号」入口，而不是把它藏掉。
    $phone = function_exists('_pz') ? (bool) _pz('user_signin_phone_s') : false;

    wp_localize_script('zc-login-mode', 'ZC_LOGIN_MODE', array(
        'phone'    => $phone,
        'suffixes' => array_values($suffixes),
        // 与后台「默认选中的后缀」保持一致；留空则不预选。
        'default'  => $suffixes && function_exists('zibll_child_email_suffix_default')
            ? zibll_child_email_suffix_default()
            : '',
        'i18n'     => array(
            'emailTab'            => '邮箱登录',
            'usernameTab'         => '用户名登录',
            'phoneTab'            => '手机号登录',
            'emailPlaceholder'    => '邮箱地址',
            'emailPrefixPlaceholder' => '邮箱前缀',
            'usernamePlaceholder' => '用户名',
            'phonePlaceholder'    => '手机号',
            'chooseSuffix'        => '选择后缀',
            'needEmail'           => '请输入完整的邮箱地址',
            'needSuffix'          => '请选择邮箱后缀',
            'needUsername'        => '用户名登录请填写用户名，不要带 @',
        ),
    ));
}
add_action('wp_enqueue_scripts', 'zibll_child_login_mode_assets', 30);
