<?php
/**
 * 子比子主题 - 消息通知悬浮弹窗
 *
 * 需求：父主题的消息入口是顶部导航里一个铃铛，必须鼠标悬停才展开，
 *       而且下拉里只有「分类入口 + 未读数」、没有消息正文；移动端更是
 *       直接不渲染该下拉（源码 `!wp_is_mobile()`），新消息还得刷新页面。
 *       本模块把消息做成常驻悬浮窗，桌面端与移动端各有独立配置。
 *
 * 形态（三级）：
 *   收起态（气泡 / 迷你卡 / 胶囊）→ 展开态（面板）
 *   有未读时可自动展开；用户点「×」收起后记为「已读收起」，
 *   之后不再自动展开，直到出现新消息。
 *
 * 零侵入原则：
 *   - 不修改父主题任何文件；只读复用 ZibMsg / zibmsg_* 系列函数。
 *   - 不新增数据表、不写任何用户数据（「全部已读」由 JS 调用父主题
 *     自己的 admin-ajax 动作，见 assets/js/msg-popup.js）。
 *
 * 加载顺序：本文件须在 theme-options 之前被 includes/index.php 注册，
 *           因为设置面板的字段是即时求值的（面板里会调用本文件函数）。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 某一端（pc / ph）的默认配置。
 *
 * @param string $scope pc|ph
 * @return array
 */
function zibll_child_msgpopup_defaults($scope = 'pc')
{
    if ($scope === 'ph') {
        return array(
            'enabled'     => true,     // 该端是否启用
            'pos'         => 'abovetab', // abovetab 导航上方 | br 右下角 | bc 底部居中
            'offy'        => 14,       // 垂直偏移 px
            'collapse'    => 'pill',   // bubble 气泡 | pill 胶囊
            'mode'        => 'drawer', // drawer 底部抽屉 | modal 居中弹窗
            'drawerh'     => 72,       // 抽屉高度 %
            'width'       => 280,      // 居中弹窗宽度 px
            'radius'      => 18,       // 圆角 px
            'depth'       => 'summary', // summary 摘要 | full 完整
            'lines'       => 1,        // 摘要行数 1|2|3
            'limit'       => 5,        // 显示条数
            'scrim'       => true,     // 半透明遮罩
            'grip'        => true,     // 顶部拖拽条
            'auto_expand' => false,    // 有未读自动展开
            'show_mark'   => true,     // 显示「全部已读」
        );
    }

    return array(
        'enabled'     => true,
        'pos'         => 'br',       // br 右下 | bl 左下 | tr 右上 | tl 左上
        'offx'        => 22,         // 水平偏移 px
        'offy'        => 22,         // 垂直偏移 px
        'collapse'    => 'mini',     // bubble 气泡 | mini 迷你卡 | pill 胶囊
        'width'       => 330,        // 面板宽度 px
        'miniw'       => 262,        // 迷你卡宽度 px
        'maxh'        => 340,        // 面板最大高度 px
        'radius'      => 10,
        'depth'       => 'summary',
        'lines'       => 1,
        'limit'       => 5,
        'auto_expand' => false,
        'show_mark'   => true,
    );
}

/**
 * 读取并收敛某一端的配置（缺失项回落默认值，数值做安全钳制）。
 *
 * @param string $scope pc|ph
 * @return array
 */
function zibll_child_msgpopup_conf($scope = 'pc')
{
    static $cache = array();
    if (isset($cache[$scope])) {
        return $cache[$scope];
    }

    $defaults = zibll_child_msgpopup_defaults($scope);
    $saved    = zibll_child_get_option('msg_' . $scope, array());
    $saved    = is_array($saved) ? $saved : array();

    $conf = array();
    foreach ($defaults as $key => $default) {
        $conf[$key] = array_key_exists($key, $saved) ? $saved[$key] : $default;
    }

    // 布尔字段：CSF switcher 可能存 true / '1' / '' / '0'，统一成布尔
    // 注意跳过本端不存在的字段（scrim / grip 只有移动端有）
    foreach (array('enabled', 'scrim', 'grip', 'auto_expand', 'show_mark') as $bool_key) {
        if (!array_key_exists($bool_key, $conf)) {
            continue;
        }
        $v = $conf[$bool_key];
        $conf[$bool_key] = !($v === false || $v === 0 || $v === '0' || $v === '' || $v === null);
    }

    // 数值钳制（防止后台误填导致布局崩坏）
    if ($scope === 'ph') {
        $conf['offy']    = max(0, min(120, (int) $conf['offy']));
        $conf['drawerh'] = max(30, min(95, (int) $conf['drawerh']));
        $conf['width']   = max(220, min(460, (int) $conf['width']));
        $conf['radius']  = max(0, min(30, (int) $conf['radius']));
        if (!in_array($conf['collapse'], array('bubble', 'pill'), true)) {
            $conf['collapse'] = 'pill';
        }
        if (!in_array($conf['mode'], array('drawer', 'modal'), true)) {
            $conf['mode'] = 'drawer';
        }
        if (!in_array($conf['pos'], array('abovetab', 'br', 'bc'), true)) {
            $conf['pos'] = 'abovetab';
        }
    } else {
        $conf['offx']  = max(0, min(200, (int) $conf['offx']));
        $conf['offy']  = max(0, min(200, (int) $conf['offy']));
        $conf['width'] = max(240, min(520, (int) $conf['width']));
        $conf['miniw'] = max(180, min(420, (int) $conf['miniw']));
        $conf['maxh']  = max(140, min(760, (int) $conf['maxh']));
        $conf['radius'] = max(0, min(30, (int) $conf['radius']));
        if (!in_array($conf['collapse'], array('bubble', 'mini', 'pill'), true)) {
            $conf['collapse'] = 'mini';
        }
        if (!in_array($conf['pos'], array('br', 'bl', 'tr', 'tl'), true)) {
            $conf['pos'] = 'br';
        }
    }

    $conf['limit'] = max(1, min(20, (int) $conf['limit']));
    $conf['lines'] = max(1, min(4, (int) $conf['lines']));
    if (!in_array($conf['depth'], array('summary', 'full'), true)) {
        $conf['depth'] = 'summary';
    }

    $cache[$scope] = $conf;
    return $conf;
}

/**
 * 当前请求是否应该输出悬浮窗。
 *
 * 判定顺序刻意从「最便宜」到「最贵」：后台 → 登录态 → 开关 → 父主题函数是否存在。
 *
 * @return bool
 */
function zibll_child_msgpopup_active()
{
    static $active = null;
    if ($active !== null) {
        return $active;
    }

    $active = false;

    do {
        if (is_admin() || wp_doing_ajax() || !is_user_logged_in()) {
            break;
        }
        // 模块总开关（存 zibll_child_modules，与「我的插件」区其他模块一致）
        if (!zibll_child_module_enabled('enable_msg_popup')) {
            break;
        }
        // 父主题消息功能总开关
        if (function_exists('_pz') && !_pz('message_s', true)) {
            break;
        }
        // 父主题消息模块必须已加载（正常前台一定满足；防御异常场景）
        if (!class_exists('ZibMsg') || !function_exists('zibmsg_get_receive_user_args')) {
            break;
        }
        // 两端都关时不输出
        $pc = zibll_child_msgpopup_conf('pc');
        $ph = zibll_child_msgpopup_conf('ph');
        if (!$pc['enabled'] && !$ph['enabled']) {
            break;
        }

        $active = true;
    } while (false);

    /**
     * 允许站点按页面条件进一步收敛（例如只在文章页显示）。
     *
     * @param bool $active
     */
    return $active = (bool) apply_filters('zibll_child_msgpopup_active', $active);
}

/**
 * 取当前用户的消息数据。
 *
 * 复用父主题的查询条件助手，自动带上 all / vip / vipN / admin 可见范围。
 *
 * @param int $limit 取多少条
 * @return array list 消息数组 / total 总条数 / unread 未读数
 */
function zibll_child_msgpopup_fetch($limit = 5)
{
    $uid = get_current_user_id();
    if (!$uid) {
        return array('list' => array(), 'total' => 0, 'unread' => 0);
    }

    $where = array(
        'receive_user' => zibmsg_get_receive_user_args($uid),
        'status'       => 0,
    );

    // 与父主题 zib_get_user_news_msg() 一致：未开启私信时不显示私信类消息
    if (function_exists('_pz') && !_pz('private_s', true)) {
        $where['type'] = array('operator' => '!=', 'value' => 'private');
    }

    $list  = ZibMsg::get($where, 'modified_time', 0, $limit);
    $total = (int) ZibMsg::get_count($where);

    $where_unread                    = $where;
    $where_unread['no_readed_user'] = $uid;
    $unread                          = (int) ZibMsg::get_count($where_unread);

    return array(
        'list'   => is_array($list) ? $list : array(),
        'total'  => $total,
        'unread' => $unread,
        'uid'    => $uid,
    );
}

/**
 * 把懒加载图片就地「激活」。
 *
 * 父主题的图片输出为 src=占位图 + data-src=真实地址，靠主题 JS 在滚动时替换。
 * 但悬浮窗收起时整块是隐藏的（0 高度），触发不到懒加载回调，
 * 面板展开后就会一直显示占位图。这里直接把真实地址提上来，彻底绕开该机制。
 *
 * @param string $html
 * @return string
 */
function zibll_child_msgpopup_live_img($html)
{
    if (!is_string($html) || $html === '' || strpos($html, 'data-src=') === false) {
        return $html;
    }
    return preg_replace('/\ssrc="[^"]*"\s+data-src="([^"]+)"/i', ' src="$1"', $html);
}

/**
 * 判断某条消息对当前用户是否未读。
 *
 * 与父主题 zib_get_msg_box() 的判定保持一致（readed_user 存 `[uid][uid2]`）。
 *
 * @param array $msg
 * @param int   $uid
 * @return bool
 */
function zibll_child_msgpopup_is_unread($msg, $uid)
{
    // ZibMsg::get() 返回的是 stdClass（get_row() 才是单条并已反序列化 meta），
    // 这里统一转数组后再取字段，避免对象/数组两种形态混用。
    $msg    = (array) $msg;
    $readed = isset($msg['readed_user']) ? $msg['readed_user'] : '';
    return (!$readed || !strstr($readed, '[' . $uid . ']'));
}

/**
 * 渲染单条消息。
 *
 * 不走父主题 zib_get_msg_box()：它输出的是「点击后用父主题 ajax-tab 协议
 * 在 #user_msg_content 容器里展开详情」的结构，而那个容器只存在于消息中心页，
 * 搬到悬浮窗里点开无反应。这里自行渲染，点击直接跳消息中心。
 *
 * @param mixed $msg  消息行（对象或数组）
 * @param array $conf 该端配置
 * @param int   $uid
 * @param bool  $unread
 * @return string
 */
function zibll_child_msgpopup_item($msg, $conf, $uid, $unread)
{
    $msg = (array) $msg;

    $title = isset($msg['title']) ? $msg['title'] : '';
    $time  = isset($msg['create_time']) ? $msg['create_time'] : '';

    $icon_html = function_exists('zibmsg_get_msg_img') ? zibmsg_get_msg_img($msg) : '';
    $icon_html = zibll_child_msgpopup_live_img($icon_html);

    $type_text = function_exists('zib_get_msg_type_text') ? zib_get_msg_type_text($msg['type']) : '';
    $time_text = function_exists('zib_get_time_ago') ? zib_get_time_ago($time) : $time;

    // 正文：摘要模式用父主题的 mini 渲染（图片→[图片]、代码→[代码]、表情→[表情:x]）
    $body = '';
    if (method_exists('ZibMsg', 'get_content')) {
        $body = $conf['depth'] === 'full'
            ? ZibMsg::get_content($msg)
            : ZibMsg::get_content($msg, 'mini');
        $body = zibll_child_msgpopup_live_img($body);
    }

    if ($conf['depth'] === 'summary') {
        $body_html = $body ? '<p class="zc-mp-txt zc-clamp' . (int) $conf['lines'] . '">' . $body . '</p>' : '';
    } else {
        $body_html = $body ? '<div class="zc-mp-rich">' . $body . '</div>' : '';
    }

    $html  = '<li class="zc-mp-item' . ($unread ? ' is-unread' : '') . '">';
    $html .= '<span class="zc-mp-ico">' . $icon_html . '</span>';
    $html .= '<div class="zc-mp-body">';
    $html .= '<p class="zc-mp-title">' . esc_html(wp_strip_all_tags($title)) . '</p>';
    $html .= $body_html;
    $html .= '<p class="zc-mp-meta">' . esc_html($time_text) . ($type_text ? ' · ' . esc_html($type_text) : '') . '</p>';
    $html .= '</div></li>';

    return $html;
}

/**
 * 输出某一端的 CSS 变量（两端配置互不影响）。
 *
 * @param string $scope
 * @param array  $conf
 * @return string
 */
function zibll_child_msgpopup_style_vars($scope, $conf)
{
    $id = 'zc-mp-' . $scope;

    if ($scope === 'ph') {
        $vars = array(
            '--zc-offy'    => (int) $conf['offy'] . 'px',
            '--zc-w'       => (int) $conf['width'] . 'px',
            '--zc-radius'  => (int) $conf['radius'] . 'px',
            '--zc-drawerh' => (int) $conf['drawerh'] . '%',
        );
        return '#' . $id . '{' . implode('', array_map(function ($k, $v) {
            return $k . ':' . $v . ';';
        }, array_keys($vars), $vars)) . '}';
    }

    $vars = array(
        '--zc-offx'   => (int) $conf['offx'] . 'px',
        '--zc-offy'   => (int) $conf['offy'] . 'px',
        '--zc-w'      => (int) $conf['width'] . 'px',
        '--zc-miniw'  => (int) $conf['miniw'] . 'px',
        '--zc-maxh'   => (int) $conf['maxh'] . 'px',
        '--zc-radius' => (int) $conf['radius'] . 'px',
    );
    return '#' . $id . '{' . implode('', array_map(function ($k, $v) {
        return $k . ':' . $v . ';';
    }, array_keys($vars), $vars)) . '}';
}

/**
 * 渲染某一端的悬浮窗标记。
 *
 * @param string $scope pc|ph
 * @param array  $conf
 * @param array  $data fetch() 的返回
 * @return string
 */
function zibll_child_msgpopup_html($scope, $conf, $data)
{
    $uid   = $data['uid'];
    $list  = $data['list'];
    $unread = $data['unread'];

    if (!$list) {
        return '';
    }

    $center_url = function_exists('zibmsg_get_conter_url') ? zibmsg_get_conter_url('news') : '';
    $items      = '';
    $mini_rows  = '';
    $mini_shown = 0;

    foreach ($list as $msg) {
        $is_unread = zibll_child_msgpopup_is_unread($msg, $uid);
        $items    .= zibll_child_msgpopup_item($msg, $conf, $uid, $is_unread);

        // 迷你卡只列未读标题，最多 2 条（加摘要会让卡片高度失控）
        if ($is_unread && $mini_shown < 2) {
            $mini_shown++;
            $mini_rows .= '<span class="zc-mp-mini-row">'
                . '<i class="zc-mp-dot" aria-hidden="true"></i>'
                . '<em class="zc-mp-mini-txt">' . esc_html(wp_strip_all_tags($msg->title)) . '</em>'
                . '<b class="zc-mp-mini-time">' . esc_html(zib_get_time_ago($msg->create_time)) . '</b>'
                . '</span>';
        }
    }

    if ($mini_rows === '') {
        $mini_rows = '<span class="zc-mp-mini-row"><em class="zc-mp-mini-txt zc-mp-mute">暂无新消息</em></span>';
    }

    $badge = $unread > 0 ? '<i class="zc-mp-badge">' . (int) $unread . '</i>' : '';
    $rest  = max(0, $unread - $mini_shown);

    // 收起态：只渲染当前选中的那一种，省 DOM
    $collapsed = '';
    if ($conf['collapse'] === 'bubble') {
        $collapsed = '<button type="button" class="zc-mp-bubble" data-act="expand" aria-label="消息通知">'
            . '<i class="fa fa-bell-o" aria-hidden="true"></i>' . $badge . '</button>';
    } elseif ($conf['collapse'] === 'pill') {
        $collapsed = '<button type="button" class="zc-mp-pill" data-act="expand">'
            . '<i class="fa fa-bell-o" aria-hidden="true"></i>'
            . '<span>' . ($unread > 0 ? (int) $unread . ' 条新消息' : '消息通知') . '</span>'
            . '<i class="fa fa-angle-right zc-mp-arrow" aria-hidden="true"></i></button>';
    } else {
        $collapsed = '<div class="zc-mp-mini" data-act="expand" role="button" tabindex="0">'
            . '<span class="zc-mp-chead"><em class="zc-mp-chead-t">消息通知</em>'
            . '<i class="zc-mp-chead-x" data-act="fold" title="收起" aria-hidden="true"></i></span>'
            . '<span class="zc-mp-mini-list">' . $mini_rows . '</span>'
            . '<span class="zc-mp-cfoot">' . ($rest > 0 ? '还有 ' . (int) $rest . ' 条未读' : '展开全部消息') . '</span>'
            . '</div>';
    }

    $mark_btn = $conf['show_mark']
        ? '<button type="button" class="zc-mp-act" data-act="mark">全部已读</button>'
        : '';

    $panel = '<section class="zc-mp-panel" role="dialog" aria-label="消息通知">'
        . '<header class="zc-mp-chead">'
        . '<em class="zc-mp-chead-t">消息通知</em>'
        . '<span class="zc-mp-chead-acts">' . $mark_btn
        . '<button type="button" class="zc-mp-act" data-act="fold" title="收起"><i class="fa fa-angle-down" aria-hidden="true"></i></button>'
        . '<button type="button" class="zc-mp-act" data-act="close" title="关闭，不再自动展开"><i class="fa fa-times" aria-hidden="true"></i></button>'
        . '</span></header>'
        . '<ul class="zc-mp-scroll">' . $items . '</ul>'
        . '<a class="zc-mp-cfoot" href="' . esc_url($center_url ? $center_url : home_url('/')) . '">'
        . '查看全部 ' . (int) $data['total'] . ' 条消息</a>'
        . '</section>';

    $cls = 'zc-mp pos-' . $conf['pos'];
    if ($unread > 0 && $conf['auto_expand']) {
        $cls .= ' is-open';
    }

    return '<div class="' . $cls . '" id="zc-mp-' . esc_attr($scope) . '"'
        . ' data-scope="' . esc_attr($scope) . '"'
        . ' data-unread="' . (int) $unread . '"'
        . ' data-mode="' . esc_attr(isset($conf['mode']) ? $conf['mode'] : 'panel') . '"'
        . ' data-scrim="' . (!empty($conf['scrim']) ? '1' : '0') . '"'
        . ' data-grip="' . (!empty($conf['grip']) ? '1' : '0') . '">'
        . $collapsed . $panel . '</div>';
}

/**
 * 前台输出悬浮窗（含 CSS 变量与 HTML）。
 */
function zibll_child_msgpopup_output()
{
    if (!zibll_child_msgpopup_active()) {
        return;
    }

    $blocks = array();
    foreach (array('pc', 'ph') as $scope) {
        $conf = zibll_child_msgpopup_conf($scope);
        if (!$conf['enabled']) {
            continue;
        }
        $data = zibll_child_msgpopup_fetch($conf['limit']);
        if ($data['total'] < 1) {
            continue; // 完全没有消息时不渲染，省一次 DOM
        }
        $html = zibll_child_msgpopup_html($scope, $conf, $data);
        if ($html === '') {
            continue;
        }
        $blocks[$scope] = array('conf' => $conf, 'html' => $html);
    }

    if (!$blocks) {
        return;
    }

    // 断点与父主题移动端断点保持一致：768px
    echo "\n" . '<style id="zc-msgpopup-vars">';
    foreach ($blocks as $scope => $b) {
        echo '@media ' . ($scope === 'ph' ? '(max-width:768px)' : '(min-width:769px)') . '{'
            . zibll_child_msgpopup_style_vars($scope, $b['conf']) . '}';
    }
    echo '</style>' . "\n";

    echo '<div class="zc-msgpopup-root" aria-live="polite">';
    foreach ($blocks as $scope => $b) {
        echo $b['html'];
    }
    echo '</div>' . "\n";
}

/**
 * 登记前端资源。
 *
 * 只在真正要输出时加载；依赖父主题自带样式（_main 句柄）以便复用变量色。
 */
function zibll_child_msgpopup_assets()
{
    if (!zibll_child_msgpopup_active()) {
        return;
    }

    $uri = get_stylesheet_directory_uri() . '/assets/';
    $ver = wp_get_theme()->get('Version');

    wp_enqueue_style('zc-msgpopup', $uri . 'css/msg-popup.css', array(), $ver);
    wp_enqueue_script('zc-msgpopup', $uri . 'js/msg-popup.js', array(), $ver, true);

    // 「全部已读」复用父主题的 admin-ajax 动作 msg_all_readed，
    // 其内部用 wp_verify_nonce($_REQUEST['_wpnonce'], 'msg_readed') 校验，
    // 因此这里必须用同一个 action 名生成 nonce，不能自造。
    wp_localize_script('zc-msgpopup', 'ZC_MSGPOPUP', array(
        'ajax'   => admin_url('admin-ajax.php'),
        'nonce'  => wp_create_nonce('msg_readed'),
        'userId' => get_current_user_id(),
    ));
}

add_action('wp_enqueue_scripts', 'zibll_child_msgpopup_assets', 30);
add_action('wp_footer', 'zibll_child_msgpopup_output', 20);
