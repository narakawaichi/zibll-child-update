<?php
/**
 * 子比子主题 - 卸载数据清理
 *
 * 需求：当用户切换离开（或后续删除）本子主题时，可以选择「保留」或「清除」本子主题整合插件的全部自有数据。
 *
 * 机制说明（关键坑）：WordPress 不允许直接删除「正在启用」的主题，必须先切换到其它主题。
 * 而切换那一刻，被切走的本子主题仍是启用态、其 PHP 仍在运行 —— 因此可在 switch_theme 钩子里
 * 可靠地执行清理，完美绕开「删除非启用主题时其代码不加载、自身钩子不触发」的固有限制。
 *
 * 交互：后台「外观 → 主题」点击其它主题的「启用」时，由 assets/js/theme-switch-cleanup.js 弹出询问框；
 * 选「清除数据并切换」则通过 cookie 标记，在切换同时删除本子主题整合插件的全部自有数据。
 *
 * 清理范围严格限定为本子主题整合插件的自有数据，绝不动父主题 zibll 与其它插件的任何数据。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 清除本子主题整合插件的全部自有数据。
 * 仅删除下方明确列出的键，不触碰其它任何数据。
 */
function zibll_child_cleanup_integrated_data()
{
    global $wpdb;

    // 先读取评论表情可能自定义过的存储根目录（option 删除后就读不到了）
    $ce_opts = get_option('zibll_comment_emoji_options', array());
    $ce_root = (is_array($ce_opts) && !empty($ce_opts['smilies_root'])) ? $ce_opts['smilies_root'] : '';

    // 1) 选项（option）
    $options = array(
        'zrp_rating_options',              // 文章评分插件设置
        'xiazhi_qz_options',               // 夏稚文章前缀插件设置
        'zibll_comment_emoji_options',     // 评论表情包插件设置
        'zibll_comment_emoji_sort_order',  // 评论表情包排序
        'zibll_child_modules',             // 模块全量开关
        'zibll_child_options',             // 子主题 CSF 设置
        'zibll_child_options_backup',      // 设置备份快照（含爱发电 API 令牌等敏感凭据，务必清除）
        'zibll_child_qq_avatar_done',      // 头像同步一次性标记
        'zibll_child_version',             // 旧版更新器遗留版本选项
        'zibll_child_bak_cleanup_version', // 旧版更新器遗留清扫标记
        'zibll_child_native_cleanup_done', // 原生更新迁移清理标记
        'zibll_child_users_job',           // 用户数据导入/导出任务状态
        'zibll_child_afdian_unmatched',    // 爱发电未匹配订单留痕（含站内订单号等）
        'wpmcs_global_settings',           // 已废弃媒体云接管孤儿 option
        'wpmcs_enabled',                   // 已废弃媒体云接管孤儿 option
    );
    foreach ($options as $opt) {
        delete_option($opt);
    }
    delete_transient('zibll_child_users_coverage'); // 用户扩展数据覆盖率缓存
    delete_transient('zibll_child_users_stats');    // 站点用户规模统计缓存

    if (!empty($wpdb)) {
        // 2) 文章元（postmeta）
        // ⚠️ 安全（v1.5.16）：原实现对 'text' / 'img' 这类【极通用】的
        //    postmeta 键做全站 DELETE。而这两个键在 WP 生态里被无数插件使用，
        //    同文件下方对 'score' 恰恰因为「过于通用」而选择不删 —— 判据自相矛盾，
        //    会静默清空其它插件的数据且不可恢复。
        //    现改为【联合条件精确命中】：只删「同一篇文章上存在夏稚标记
        //    titles_moshi」的 text/img 行，即只清理本子主题自己写入的那些。
        $text_img_keys = array('text', 'img');
        $wpdb->query($wpdb->prepare(
            "DELETE m FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->postmeta} t
                ON t.post_id = m.post_id AND t.meta_key = 'titles_moshi'
             WHERE m.meta_key IN (%s, %s)",
            $text_img_keys[0],
            $text_img_keys[1]
        ));

        $pm_keys = array(
            'titles_moshi',            // 夏稚前缀
            'text_bg_color',           // 夏稚前缀
            'custom_img_prefixes',     // 夏稚前缀
            'zrp_rating_count',        // 文章评分人数
            // 注：评分插件还写过一个无前缀的 'score' 文章元，因过于通用，此处不批量删，避免误伤其它插件。
        );
        foreach ($pm_keys as $k) {
            $wpdb->delete($wpdb->postmeta, array('meta_key' => $k), array('%s'));
        }

        // 3) 用户元（usermeta）：评分按文章 ID 动态生成 zrp_user_rating_{post_id}
        //    用转义后的 LIKE 精确匹配前缀，避免误删。
        $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'zrp_user_rating\\_%'");
    }

    // 4) 上传文件：评论表情（默认回退路径 uploads/zibll-comment-emoji + 可能的自定义 smilies_root）
    //    以及用户数据导入导出的落盘目录（含已导出的用户文件，属敏感数据，必须一并清理）
    $uploads = wp_upload_dir();
    $dirs    = array();
    if (!empty($uploads['basedir'])) {
        $dirs[] = $uploads['basedir'] . '/zibll-comment-emoji';
        $dirs[] = $uploads['basedir'] . '/zibll-child-user-data';
    }
    // ⚠️ 安全（v1.5.16）：$ce_root 来自后台【自由文本框】的 smilies_root 选项，
    //    管理员（或被误导的用户）可能填成 / 、/var/www、父主题目录等。
    //    原实现只判 is_dir() 就丢进删除队列，rrmdir 内部无任何包含性断言，
    //    一旦误填 + 点击「清除数据并切换」= 整站文件被递归删除且不可恢复。
    //    现在：仅当它确实位于 uploads 目录【之下】时才纳入删除。
    if ($ce_root && is_dir($ce_root) && zibll_child_path_in_uploads($ce_root)) {
        $dirs[] = $ce_root;
    }
    foreach ($dirs as $d) {
        zibll_child_rrmdir($d);
    }
}

/**
 * 判断一个路径是否严格位于 uploads 目录【之下】（含符号链接解析后的真实路径）。
 *
 * 安全关键：本函数是递归删除的唯一入口守卫，防止误填的自由文本路径
 * 指向站点根目录、上一级目录或任意系统目录。
 *
 * @param string $path 待检查的路径
 * @return bool
 */
function zibll_child_path_in_uploads($path)
{
    $uploads = wp_upload_dir();
    if (empty($uploads['basedir'])) {
        return false;
    }

    $base = realpath($uploads['basedir']);
    $real = realpath($path);
    if (!$base || !$real) {
        return false;
    }
    $base = wp_normalize_path($base);
    $real = wp_normalize_path($real);

    // uploads 根本身不做递归删除（它属于站点，不属于本子主题）
    if ($real === $base) {
        return false;
    }

    // 必须是 uploads 的【子路径】，不能是 uploads 自身或任何上级目录
    if (strpos($real . '/', $base . '/') !== 0) {
        return false;
    }

    // 兜底：显式拒绝站点根目录及其常见上级（防止 realpath 异常导致的误判）
    foreach (array(ABSPATH, dirname(ABSPATH), dirname(dirname(ABSPATH))) as $forbidden) {
        $forbidden = wp_normalize_path((string) realpath($forbidden));
        if ($forbidden && $real === $forbidden) {
            return false;
        }
    }

    return true;
}

/**
 * 递归删除目录（含其内容），用于清理评论表情的上传目录。
 *
 * ⚠️ 安全（v1.5.16）：本函数是本模块【最危险的操作】，现内置硬性守卫 ——
 *   1) 不跟随符号链接（is_link 直接拒），否则会递归进链接指向的任意系统目录；
 *   2) 目标必须严格位于 uploads 目录之下（zibll_child_path_in_uploads()），
 *      站点根 / 上级目录 / uploads 根本身一律拒绝；
 *   3) 删除后统一 clearstatcache()，避免 realpath 缓存导致后续误判。
 * 即便将来新增调用点漏了上层校验，本函数自身也会兜住，不会退化为「删整站」。
 */
function zibll_child_rrmdir($dir)
{
    if (!is_dir($dir)) {
        return;
    }

    // 守卫 1：符号链接一律不删（is_dir 对指向目录的链接返回 true，会递归进目标）
    if (is_link($dir)) {
        return;
    }

    // 守卫 2：必须位于 uploads 之下
    if (!function_exists('zibll_child_path_in_uploads') || !zibll_child_path_in_uploads($dir)) {
        return;
    }

    // 守卫 3：路径过短的一律视为异常（正常目录至少长于 uploads/NN/xxx）
    if (strlen($dir) < 8) {
        return;
    }
    $items = scandir($dir);
    if ($items === false) {
        return;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            zibll_child_rrmdir($path);
        } else {
            @unlink($path);
        }
    }
    @rmdir($dir);
}

/**
 * 判定本次切换是否应执行数据清理（安全关键）。
 *
 * v1.5.16 起改为【服务端一次性令牌】三重校验，替换原「仅凭裸 cookie 判断」的实现：
 *   1. 必须显式带 zibll_child_cleanup=1（点「保留数据并切换」不会带该参数）；
 *   2. 必须具备 switch_themes 能力且 nonce 校验通过（防 CSRF）；
 *   3. 时间戳必须在 300 秒内（防令牌被记录后重放）。
 * 三者任一不满足 → 一律【静默跳过清理】。宁可不清，也绝不误删。
 *
 * @return bool
 */
function zibll_child_should_cleanup_on_switch()
{
    $flag = isset($_GET['zibll_child_cleanup']) ? sanitize_text_field(wp_unslash($_GET['zibll_child_cleanup'])) : '';
    if ($flag !== '1') {
        return false;
    }
    if (!current_user_can('switch_themes')) {
        return false;
    }
    $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
    if (!wp_verify_nonce($nonce, 'zibll_child_cleanup_data')) {
        return false;
    }
    $ts = isset($_GET['_ts']) ? absint($_GET['_ts']) : 0;
    if ($ts <= 0 || (time() - $ts) > 300 || $ts > (time() + 60)) {
        return false;
    }
    return true;
}

/**
 * 切换主题钩子：若离开的是本子主题且用户选择清除，则执行清理。
 *
 * @param string    $new_name  新主题名
 * @param WP_Theme  $new_theme 新主题对象
 * @param WP_Theme  $old_theme 旧（被切走）主题对象
 */
function zibll_child_maybe_cleanup_on_switch($new_name, $new_theme, $old_theme)
{
    if (!($old_theme instanceof WP_Theme)) {
        return;
    }
    // 仅当被切走的是本子主题才处理
    //
    // v1.5.16 修正（两处）：
    //  ① 原先硬编码字符串 'zibll-child'，站点若改了子主题目录名即静默失效；
    //  ② 不能用 get_stylesheet() 取「自身目录名」—— switch_theme 钩子触发时
    //     option('stylesheet') 已经被改成【新主题】，拿它跟 $old_theme 比必然不等，
    //     清理会被静默跳过。正确做法是拿本文件所在目录名（恒等于本子主题 slug）。
    $self_slug = basename(dirname(__DIR__)); // includes/functions → 主题根目录
    if ($old_theme->get_stylesheet() !== $self_slug) {
        return;
    }

    if (zibll_child_should_cleanup_on_switch()) {
        zibll_child_cleanup_integrated_data();
    }
}
add_action('switch_theme', 'zibll_child_maybe_cleanup_on_switch', 10, 3);

/**
 * 后台主题列表页：挂载切换确认弹窗 JS（仅当本子主题为当前启用主题时）。
 */
function zibll_child_enqueue_switch_modal($hook)
{
    if (!is_admin()) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || !in_array($screen->id, array('themes', 'themes-network'), true)) {
        return;
    }
    // 仅当本子主题为当前启用主题时才需要弹窗
    // v1.5.16：去掉硬编码的 'zibll-child'，改用运行时目录名。
    // 注意：本文件在 includes/index.php 中排在 theme-updater【之前】加载，
    // 故此处不能依赖 ZIBLL_CHILD_UPDATE_THEME 常量（那时还没定义）。
    if (function_exists('get_stylesheet')
        && get_stylesheet() !== wp_normalize_path(basename(get_stylesheet_directory()))) {
        return;
    }

    $js_path = get_stylesheet_directory() . '/assets/js/theme-switch-cleanup.js';
    $js_url  = get_stylesheet_directory_uri() . '/assets/js/theme-switch-cleanup.js';
    // 关键修复：用 JS 文件自身的修改时间作为版本号，而非 style.css 的 Version。
    // style.css 的主题版本可能长期不变，不能用它作为脚本缓存戳；否则浏览器/CDN
    // 可能继续使用旧 JS，后续修复无法及时生效。
    // 改用 filemtime 后，每次更新 JS 资源 URL 必变，浏览器必定重新拉取最新代码。
    $ver     = file_exists($js_path) ? filemtime($js_path) : '1.0.0';
    wp_enqueue_script('zibll-child-switch-cleanup', $js_url, array('jquery'), $ver, true);

    wp_localize_script('zibll-child-switch-cleanup', 'ZIBLL_CHILD_SWITCH', array(
        'themeName'    => function_exists('wp_get_theme') ? wp_get_theme('zibll-child')->get('Name') : '子比子主题',
        // 一次性清理令牌：JS 把它拼到「清除数据并切换」的激活链接上。
        // 服务端 zibll_child_should_cleanup_on_switch() 会校验 nonce + 能力 + 时间戳。
        'cleanupNonce' => wp_create_nonce('zibll_child_cleanup_data'),
        'cleanupTs'    => time(),
    ));
}
add_action('admin_enqueue_scripts', 'zibll_child_enqueue_switch_modal');
