<?php
/**
 * 子比子主题 - 第三方登录自动写入已验证邮箱
 * ─────────────────────────────────────────────────────────────
 * 解决什么问题
 *   父主题在处理第三方（Google / Microsoft / Facebook / Apple）登录时，
 *   拿得到对方的「已验证邮箱」，但没写进 WordPress 用户邮箱，导致：
 *     · 新用户 user_email 恒为空；
 *     · 站点一开「强制绑定邮箱」，第三方登录后立刻被弹去绑定页，
 *       用户得把 Google 邮箱再手填一遍（本子主题实测复现）。
 *
 * 父主题的两处断点（本子主题不改父主题，故在此补齐）
 *   1) oauth/google/callback.php 组装 $oauth_data 时只取 openid/name/avatar，
 *      email 被留在 getUserInfo 里（oauth2/v2/userinfo 实际返回
 *      email + verified_email:true）。
 *   2) oauth/oauth.php 自动建号用 wp_create_user($login_name, $user_pass)，
 *      第三个参数 $email 没传 → user_email 为空（oauth.php:134）。
 *
 * 判定链（决定跳不跳绑定页）
 *   zib_redirect_user_bind_page()（inc/functions/zib-user.php:972）
 *   挂在 template_redirect 优先级 10，只判断 $user->user_email 是否为空。
 *   本模块挂在优先级 9，早它一步把邮箱补上，因此登录后能真正停在
 *   发起登录的那个页面上，而不是被绑定页劫持。
 *
 * 安全边界（三条都不能省）
 *   · 只认第三方明确标记为「已验证」的邮箱；
 *   · 邮箱已被【其他】账号占用时不抢绑（否则等于给未验证邮箱开后门、可接管账号）；
 *   · 绝不覆盖用户已有的邮箱。
 *
 * 开关：zibll_child_module_enabled('enable_oauth_auto_email')（默认开启）
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('zibll_child_oauth_auto_email')) {
    /**
     * 当前用户邮箱为空、且绑定的第三方账号返回了「已验证邮箱」时，自动写入。
     *
     * @param WP_User|null $user 传入用户对象；为空则取当前登录用户。
     * @return bool 是否写入了邮箱
     */
    function zibll_child_oauth_auto_email($user = null)
    {
        if (!$user instanceof WP_User) {
            $user = wp_get_current_user();
        }

        // 未登录 / 已有邮箱 → 不处理（绝不覆盖用户已有邮箱）
        if (empty($user->ID) || !empty($user->user_email)) {
            return false;
        }

        // 父主题未就绪时的防御性判断
        if (!function_exists('zib_get_user_meta')) {
            return false;
        }

        /**
         * 允许自动填充邮箱的第三方平台白名单。
         *   key   = oauth 类型（对应 oauth_{type}_getUserInfo 这个 user meta）
         *   value = 该平台【必须为真】的「已验证」字段名（多个用 | 分隔）。
         *
         * ⚠️ 安全（v1.5.16）：原实现里 microsoft / facebook / apple 三项的验证字段
         *    是【空字符串】，而下方 `if ($verify_key)` 判空后【整段跳过验证】——
         *    等于这三家平台只要 getUserInfo 里有个像邮箱的字符串就会被写进
         *    WordPress 的身份字段 user_email（父主题正是拿它当「已验证」用的）。
         *    Apple 侧更危险：父主题 zibll/oauth/sdk/apple/OAuth2.php:140-144 在
         *    id_token 缺 email 时会回退到 $firstAuthUser['email']，而它来自
         *    zibll/oauth/apple/callback.php:37 的 $_POST['user'] ——【客户端可控】。
         *    即「客户端 POST → 未验证 → user_email」是一条完整的信任链断裂。
         *    现为四家都补上真实存在的验证字段，且验证闸改为「无验证字段即拒绝」，
         *    绝不再因字段为空而放行。
         *
         * 字段依据（均来自父主题已落库的 getUserInfo 结构）：
         *   google    → oauth2/v2/userinfo 用 verified_email；OIDC 用 email_verified
         *   microsoft → Graph /me 用 mail；userPrincipalName 不保证可投递，故不采信
         *   facebook  → Graph /me 顶层 verified
         *   apple     → id_token claims 自带 email_verified
         *
         * 说明：github / twitter / qq / weixin / weibo / alipay / baidu / douyin / gitee
         * 的 getUserInfo 里没有邮箱字段，故不列入。
         */
        $providers = apply_filters('zibll_child_oauth_auto_email_providers', array(
            'google'    => 'verified_email|email_verified',
            'microsoft' => 'mail|email_verified',
            'facebook'  => 'verified|email_verified',
            'apple'     => 'email_verified|verified',
        ));

        foreach ($providers as $type => $verify_keys) {
            $info = zib_get_user_meta($user->ID, 'oauth_' . $type . '_getUserInfo', true);
            if (empty($info) || !is_array($info)) {
                continue;
            }

            $email = '';
            foreach (array('email', 'mail') as $k) {
                if (!empty($info[$k]) && is_string($info[$k])) {
                    $email = trim($info[$k]);
                    break;
                }
            }
            if (!$email || !is_email($email)) {
                continue;
            }

            // 安全闸 ①：只认「已验证」邮箱。
            // ⚠️ 安全（v1.5.16）：原判定是 `if ($verify_key) { ... }`，
            //    验证字段为空时整段跳过 —— 这是本模块最严重的漏洞。
            //    现改为【无条件要求验证标记】：任一候选字段为真才算通过；
            //    一个都没有 → 视为未验证，直接跳过（宁可不同步，也不写入身份字段）。
            $verified = false;
            $candidates = array_merge(
                array_filter(explode('|', (string) $verify_keys)),
                array('email_verified', 'verified')
            );
            foreach (array_unique($candidates) as $vk) {
                if (isset($info[$vk]) && !is_string($info[$vk])
                    && filter_var($info[$vk], FILTER_VALIDATE_BOOLEAN)
                ) {
                    $verified = true;
                    break;
                }
            }
            if (!$verified) {
                continue;
            }

            // 安全闸 ①-b：邮箱域名必须与该平台的官方域一致（纵深防御）。
            // 即使某平台漏发了验证标记，也不至于把任意第三方邮箱写进身份字段。
            $email_domain = strtolower(substr(strrchr($email, '@'), 1));
            $domain_ok = apply_filters('zibll_child_oauth_email_domain_ok', true, $type, $email_domain);
            if (!$domain_ok) {
                continue;
            }

            // 安全闸 ②：邮箱已被其他账号占用 → 不抢绑，交回给用户手动绑定
            $owner = email_exists($email);
            if ($owner && (int) $owner !== (int) $user->ID) {
                continue;
            }

            // 写邮箱。旧邮箱为空，WP 的「邮箱已变更」通知本就发不出去，
            // 这里显式屏蔽，避免任何多余邮件。
            add_filter('send_email_change_email', '__return_false');
            $result = wp_update_user(array(
                'ID'         => $user->ID,
                'user_email' => $email,
            ));
            remove_filter('send_email_change_email', '__return_false');

            if (is_wp_error($result)) {
                continue;
            }

            update_user_meta($user->ID, 'zibll_child_oauth_email_source', $type);
            clean_user_cache($user->ID); // 让本次请求后续读取到新值

            return true;
        }

        return false;
    }
}

/**
 * wp_login 适配器。
 * 回调签名为 ($user_login, $user)，首参是用户名字符串，不能直接当用户对象用。
 */
if (!function_exists('zibll_child_oauth_auto_email_on_login')) {
    function zibll_child_oauth_auto_email_on_login($user_login, $user)
    {
        zibll_child_oauth_auto_email($user instanceof WP_User ? $user : null);
    }
}

/*
 * 挂两个点，覆盖全部路径：
 *   ① wp_login（优先级 20）——第三方自动建号时父主题会 do_action('wp_login')，
 *      且此刻 oauth_{type}_getUserInfo 已写好，可第一时间补上邮箱，
 *      回调返回的下一跳就已经是干净状态；
 *   ② template_redirect（优先级 9）——父主题的强制绑定判定挂在优先级 10，
 *      本模块早它一步，兜住「绑定页新建账号」等不走 wp_login 的路径。
 */
if (zibll_child_module_enabled('enable_oauth_auto_email', true)) {
    add_action('wp_login', 'zibll_child_oauth_auto_email_on_login', 20, 2);
    add_action('template_redirect', 'zibll_child_oauth_auto_email', 9);
}
