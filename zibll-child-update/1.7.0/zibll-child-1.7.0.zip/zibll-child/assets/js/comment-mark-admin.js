/**
 * 子比子主题 - 留言标记（后台评论列表）
 *
 * 只在「评论」列表页加载（见 comment-mark.php 的 admin_enqueue_scripts 判断）。
 * 每个单元格是一个下拉，选中即保存，不刷新页面。
 */

(function ($) {
  'use strict';

  if (typeof window.ZC_COMMENT_MARK === 'undefined') {
    return;
  }

  var cfg = window.ZC_COMMENT_MARK;

  /**
   * 同步单元格里的小圆点颜色（标记被清空时移除圆点）。
   */
  function renderDot($select, color) {
    var $cell = $select.closest('td');
    var $dot = $cell.find('.zcm-dot');

    if (!color) {
      $dot.remove();
      return;
    }

    if (!$dot.length) {
      $dot = $('<span class="zcm-dot"></span>');
      $select.after($dot);
    }

    $dot.css('background-color', color);
  }

  $(document).on('change', '.zcm-select', function () {
    var $select = $(this);
    var commentId = parseInt($select.data('comment'), 10) || 0;
    var mark = $select.val() || '';

    if (!commentId) {
      return;
    }

    $select.prop('disabled', true).addClass('zcm-saving');

    $.post(cfg.ajax, {
      action: 'zibll_child_comment_mark_save',
      nonce: cfg.nonce,
      comment_id: commentId,
      mark: mark
    })
      .done(function (res) {
        if (!res || !res.success) {
          var msg = res && res.data && res.data.message ? res.data.message : cfg.i18n.failed;
          window.alert(msg);
          return;
        }

        renderDot($select, res.data && res.data.color ? res.data.color : '');
        $select.addClass('zcm-saved');

        window.setTimeout(function () {
          $select.removeClass('zcm-saved');
        }, 1200);
      })
      .fail(function () {
        window.alert(cfg.i18n.failed);
      })
      .always(function () {
        $select.prop('disabled', false).removeClass('zcm-saving');
      });
  });
})(jQuery);
