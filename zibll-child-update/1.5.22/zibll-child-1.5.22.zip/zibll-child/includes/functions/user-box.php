<?php
/**
 * 子比子主题 - 悬停面板「快捷按钮」自定义（用户区 / 管理员区 双区域）
 *
 * 功能：在子主题设置面板里，按 zibll 用户权限（user_cap：all/logged/vip/level/auth/自定义角色）
 * 增删/排序前台「个人信息」悬停面板里的快捷按钮；图标可从全部 zibll SVG + Font Awesome 中选。
 *
 * ── v1.5.20 双区域（本次重做的根因与方案）────────────────────────────
 * 【问题】父主题 zib_header_user_box() 在登录态下输出的是**两行** .header-user-href：
 *   第 1 行（zib-header.php:238-249）用户区：用户中心 / 我的订单 / 发布文章 / 退出登录
 *   第 2 行（zib-header.php:251-258）**仅 is_super_admin()**：主题设置 / 模块布局 / 商城中心 / 后台管理
 * v1.5.9~1.5.19 子主题只有一份按钮列表，前端用 $('.sub-user-box .header-user-href')
 * 选中**全部**匹配（桌面盒 + 移动盒 × 两行 = 4 个）后 box.html(newHtml) 整块覆盖，
 * 于是「改用户区」会把管理员原生那四个按钮一起覆盖掉 —— 这就是用户报的「污染」。
 *
 * 【方案】彻底拆成两个独立区域，各有自己的开关 + 列表 + 预设池：
 *   用户区   option: user_box_buttons      开关: user_box_enable
 *   管理员区 option: user_box_admin_buttons 开关: user_box_admin_enable（仅超管）
 * 前端按「盒内第 1 个 = 用户区、第 2 个 = 管理员区」定向替换，各替换各的，互不触碰。
 *
 * 实现方式（零侵入，不改父主题）：
 *   父主题把两行按钮硬编码进 .header-user-href，且无过滤器、有 static $html 缓存，
 *   子主题无法重定义同名函数。因此服务端按当前用户权限算出各区可见按钮并拼好 HTML，
 *   前端 JS 在 DOM 就绪后按区域定向替换，并给用户区兜底保留「退出登录」
 *   （即便管理员从列表里删了它，也不会让用户失去退出入口）。
 *
 * 同时解决用户原投诉：关闭商城后悬停面板仍显示「我的订单」——
 *   「我的订单」预设带 requires=shop_s，商城关掉时自动不出现；重新开启商城即恢复。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── 区域定义 / 开关 / 数据读取 ────────────────────────────────────────

if (!function_exists('zibll_child_user_box_groups')) {
    /**
     * 两个区域的元定义。
     * option / enable 是各自独立的存储键；group 决定预设池分组。
     * admin_area = true 表示该区受父主题 is_super_admin() 约束（第二行本来只有超管有）。
     */
    function zibll_child_user_box_groups()
    {
        return array(
            'user' => array(
                'option'     => 'user_box_buttons',
                'enable'     => 'user_box_enable',
                'group'      => 'user',
                'admin_area' => false,
                'label'      => '用户区',
            ),
            'admin' => array(
                'option'     => 'user_box_admin_buttons',
                'enable'     => 'user_box_admin_enable',
                'group'      => 'admin',
                'admin_area' => true,
                'label'      => '管理员区',
            ),
        );
    }
}

if (!function_exists('zibll_child_user_box_group')) {
    /** 取单个区域定义；$area 非法时回落用户区 */
    function zibll_child_user_box_group($area = 'user')
    {
        $groups = zibll_child_user_box_groups();
        return isset($groups[$area]) ? $groups[$area] : $groups['user'];
    }
}

if (!function_exists('zibll_child_user_box_active')) {
    /**
     * 某区总开关。默认：
     *   用户区   开启（v1.5.3 起一直是默认开，装好即生效）
     *   管理员区 关闭（v1.5.20 新增；默认关闭 = 完全沿用父主题原生四个按钮，零行为变化）
     */
    function zibll_child_user_box_active($area = 'user')
    {
        $g    = zibll_child_user_box_group($area);
        $def  = $g['admin_area'] ? false : true;
        return zibll_child_option_enabled($g['enable'], $def);
    }
}

if (!function_exists('zibll_child_user_box_presets')) {
    /** 读取预设动作池（带静态缓存） */
    function zibll_child_user_box_presets()
    {
        static $presets = null;
        if (null === $presets) {
            $file = get_stylesheet_directory() . '/includes/inc/user-box-presets.php';
            $presets = file_exists($file) ? include $file : array();
        }
        return is_array($presets) ? $presets : array();
    }
}

if (!function_exists('zibll_child_user_box_preset_options')) {
    /**
     * 给设置面板用的「预设动作」下拉。
     * @param string $area user | admin —— 只列出该区分组的预设，避免跨区混选。
     *                          退出登录只在用户区出现（父主题管理员区没有这个按钮）。
     */
    function zibll_child_user_box_preset_options($area = 'user')
    {
        $group = zibll_child_user_box_group($area)['group'];
        $opts  = array('' => '— 选择预设动作 —');
        foreach (zibll_child_user_box_presets() as $k => $p) {
            $p_group = !empty($p['group']) ? $p['group'] : 'user';
            if ($p_group !== $group) {
                continue;
            }
            if (!empty($p['link_mode']) && 'logout' === $p['link_mode']) {
                continue;
            }
            $opts[$k] = $p['title'];
        }
        return $opts;
    }
}

// ─── 图标 / 链接解析 ──────────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_icon_html')) {
    /**
     * 生成图标 HTML。
     * v1.5.9 起设置面板直接用子比原生 CSF icon 选择器，存储值即子比原生格式：
     *   zibsvg-xxx          → zib_get_cfs_icon() 内部转 zib_get_svg(xxx)
     *   fa fa-xxx / fa-xxx  → <i class="fa ...">
     *   customsvg-<svg 代码> → 原样输出 SVG（面板「自定义 SVG 图标代码」粘贴）
     * 同时兼容 v1.5.8 的旧存储格式 svg:xxx / fa:xxx（老站点已保存的配置不受影响）。
     */
    function zibll_child_user_box_icon_html($val)
    {
        $val = trim((string) $val);
        if ('' === $val) {
            return '';
        }

        // ── v1.5.8 旧格式兼容 ──
        if (0 === strpos($val, 'svg:')) {
            return function_exists('zib_get_svg') ? zib_get_svg(substr($val, 4)) : '';
        }
        if (0 === strpos($val, 'fa:')) {
            return '<i class="fa fa-fw fa-' . esc_attr(substr($val, 3)) . '"></i>';
        }

        // ── v1.5.9 原生格式 ──
        if (function_exists('zib_get_cfs_icon')) {
            return zib_get_cfs_icon($val);
        }
        return '';
    }
}

if (!function_exists('zibll_child_user_box_resolve_href')) {
    /**
     * 按预设 token 解析真实链接；自定义链接直接返回（已 esc）。
     * 管理员区 token 全部指向 wp 后台页，与父主题原生四个按钮目标一致。
     */
    function zibll_child_user_box_resolve_href($b)
    {
        if (!empty($b['link_mode']) && 'custom' === $b['link_mode']) {
            $url = trim((string) ($b['custom_link'] ?? ''));
            return $url ? esc_url($url) : '';
        }

        // repeater 里存的是「预设数组 key」（如 my_order）；查预设表拿到真实解析 token（如 order）
        $preset_key = !empty($b['preset']) ? $b['preset'] : '';
        $token      = $preset_key;
        $presets    = zibll_child_user_box_presets();
        if (isset($presets[$preset_key]['preset_key'])) {
            $token = $presets[$preset_key]['preset_key'];
        }

        // ── 管理员区后台页 ──
        switch ($token) {
            case 'admin_theme_options':
                return function_exists('zib_get_admin_csf_url') ? zib_get_admin_csf_url() : admin_url('admin.php?page=zibll_options');
            case 'admin_widgets':
                return function_exists('zib_get_customize_widgets_url') ? zib_get_customize_widgets_url() : admin_url('customize.php');
            case 'admin_shop':
                return admin_url('admin.php?page=zibpay_page#/');
            case 'admin_dashboard':
                return admin_url();
            case 'admin_posts':
                return admin_url('edit.php');
            case 'admin_users':
                return admin_url('users.php');
            case 'admin_media':
                return admin_url('upload.php');
            case 'admin_comments':
                return admin_url('edit-comments.php');
            case 'admin_appearance':
                return admin_url('themes.php');
            case 'admin_plugins':
                return admin_url('plugins.php');
            case 'admin_tools':
                return admin_url('tools.php');
            case 'admin_options':
                return admin_url('options-general.php');
        }

        if (!function_exists('zib_get_user_center_url')) {
            return '';
        }
        switch ($token) {
            case 'user_center':
                return zib_get_user_center_url();
            case 'order':
                return zib_get_user_center_url('order');
            case 'vip':
                return zib_get_user_center_url('vip');
            case 'balance':
                return zib_get_user_center_url('balance');
            case 'income':
                return zib_get_user_center_url('income');
            case 'rebate':
                return zib_get_user_center_url('rebate');
            case 'account':
                return zib_get_user_center_url('account');
            case 'level':
                return zib_get_user_center_url('level');
            case 'auth':
                return zib_get_user_center_url('auth');
            case 'new_post':
                return function_exists('zib_get_new_post_url') ? zib_get_new_post_url() : '';
            default:
                return '';
        }
    }
}

// ─── 可见性判断（对齐 zibll 的 zib_is_can_roles 逻辑） ──────────────

if (!function_exists('zibll_child_user_box_can_see')) {
    /**
     * 当前用户是否满足该按钮的可见权限。
     * @param string $cap      all | logged | vip | level | auth | custom
     *                         | administrator | editor | author | contributor | subscriber
     *                         （WP 原生角色，v1.5.10 起为「该角色**及以上**」语义）
     * @param int    $level    最低 VIP / 等级（vip、level 时生效）
     * @param string $custom   cap=custom 时，_pz('user_cap') 里注册的自定义角色 key
     * @param string $area     user | admin。**仅用户区**启用管理员豁免（见下）。
     *
     * ── v1.5.10 管理员豁免（仅用户区）────────────────────────────────
     * 有 manage_options 的账号（站长/管理员）在**用户区**始终可见全部按钮。
     * 原因：WP 角色判定是「精确相等」，站长是 administrator、普通注册用户是 subscriber，
     * 二者都不等于 author；不豁免的话站长改完设置回到前台看不到任何效果，
     * 只能另开小号才能核对，等于无法自检。其他账号仍严格按下方规则判定。
     *
     * v1.5.20：管理员区**不再豁免**，恒按列表里逐项的 cap 严格判定。
     * 因为该区本来就是给管理员看的，豁免等于「所有管理员区按钮对所有管理员无条件可见」，
     * 逐项配置的权限会变成摆设。
     */
    function zibll_child_user_box_can_see($cap, $level = 1, $custom = '', $area = 'user')
    {
        if (!is_user_logged_in()) {
            return false;
        }

        // 管理员区：不做豁免，走下方逐项严格判定
        // （该区本就是给管理员看的，豁免等于让所有 cap 变成摆设）
        if (!zibll_child_user_box_group($area)['admin_area'] && current_user_can('manage_options')) {
            return true;
        }

        $uid = get_current_user_id();
        switch ($cap) {
            case 'all':
                return true;
            case 'logged':
                return true;
            case 'vip':
                $lv = function_exists('zib_get_user_vip_level') ? zib_get_user_vip_level($uid) : 0;
                return (int) $lv >= (int) $level;
            case 'level':
                $lv = function_exists('zib_get_user_level') ? zib_get_user_level($uid) : 0;
                return (int) $lv >= (int) $level;
            case 'auth':
                return function_exists('zib_is_user_auth') && zib_is_user_auth($uid);
            case 'custom':
                if ($custom && function_exists('zib_current_user_can')) {
                    return (bool) zib_current_user_can($custom);
                }
                return false;
            default:
                // WP 原生角色：v1.5.10 起由「精确匹配」改为「角色层级（及以上）」判断。
                // 每个角色取一个**只属于该层级及其以上**的代表能力，用 user_can() 判定：
                //   subscriber    → read              （所有登录用户都有）
                //   contributor   → edit_posts        （贡献者/作者/编辑/管理员都有；但贡献者不能发布）
                //   author        → publish_posts     （作者/编辑/管理员有，贡献者没有）
                //   editor        → edit_others_posts （编辑/管理员有，作者没有）
                //   administrator → manage_options
                // 于是「选作者」= 作者及以上可见（作者 / 编辑 / 管理员）；
                // 方向上只会向上包含，永远不会漏给更低角色（选编辑时作者仍不可见）。
                $role_caps = array(
                    'subscriber'    => 'read',
                    'contributor'   => 'edit_posts',
                    'author'        => 'publish_posts',
                    'editor'        => 'edit_others_posts',
                    'administrator' => 'manage_options',
                );
                if (isset($role_caps[$cap])) {
                    return user_can(wp_get_current_user(), $role_caps[$cap]);
                }
                return true;
        }
    }
}

// ─── 组装按钮 ─────────────────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_a')) {
    /**
     * 拼一个完整的 <a> 按钮（与父主题 .header-user-href 内部结构一致，配色/图标沿用）。
     * @param array $b     按钮数据；含 blank 时加 target="_blank"（父主题管理员区原生按钮均带）
     */
    function zibll_child_user_box_a($b)
    {
        $color     = !empty($b['color']) ? $b['color'] : 'c-blue';
        $icon_html = !empty($b['icon_html']) ? $b['icon_html'] : '';
        $title     = !empty($b['title']) ? esc_html($b['title']) : '';
        $target    = !empty($b['blank']) ? ' target="_blank"' : '';

        if (!empty($b['is_logout'])) {
            return '<a href="javascript:;" data-toggle="modal" data-target="#modal_signout" data-zib-logout="1">'
                . '<div class="badg mb6 toggle-radius ' . esc_attr($color) . '">' . $icon_html . '</div>'
                . '<div class="' . esc_attr($color) . '">' . $title . '</div></a>';
        }

        $href = !empty($b['href']) ? esc_url($b['href']) : '#';
        return '<a rel="nofollow"' . $target . ' href="' . $href . '">'
            . '<div class="badg mb6 toggle-radius ' . esc_attr($color) . '">' . $icon_html . '</div>'
            . '<div class="' . esc_attr($color) . '">' . $title . '</div></a>';
    }
}

if (!function_exists('zibll_child_user_box_buttons')) {
    /**
     * 计算某区当前用户实际可见的按钮数组（已过滤开关依赖 + 权限）。
     * 返回每项：{is_logout, href, title, icon_html, color, blank}
     *
     * @param string $area user | admin
     */
    function zibll_child_user_box_buttons($area = 'user')
    {
        $g = zibll_child_user_box_group($area);

        if (!zibll_child_user_box_active($area)) {
            return array();
        }

        // 管理员区受父主题 is_super_admin() 约束：非超管那一行本来就不渲染，
        // 这里提前返回可避免给普通账号多算一份无用 HTML。
        if ($g['admin_area'] && !is_super_admin()) {
            return array();
        }

        $rows = zibll_child_get_option($g['option'], array());
        if (!is_array($rows)) {
            return array();
        }

        $presets = zibll_child_user_box_presets();
        $out     = array();

        foreach ($rows as $b) {
            if (!is_array($b)) {
                continue;
            }
            $b = wp_parse_args($b, array(
                'title'       => '',
                'icon'        => 'zibsvg-user',
                'color'       => 'c-blue',
                'link_mode'   => 'preset',
                'preset'      => 'user_center',
                'preset_key'  => '',
                'custom_link' => '',
                'cap'         => 'logged',
                'cap_level'   => 1,
                'cap_custom'  => '',
                'requires'    => '',
                'blank'       => '',
            ));

            // 退出登录：单独渲染，并兜底始终保留（仅用户区有此预设）
            if (!empty($b['link_mode']) && 'logout' === $b['link_mode']) {
                $out[] = array(
                    'is_logout' => true,
                    'title'     => $b['title'] ?: '退出登录',
                    'icon_html' => zibll_child_user_box_icon_html($b['icon']),
                    'color'     => $b['color'],
                );
                continue;
            }

            // 依赖的主题开关（requires 定义在预设表里，按 preset key 取；关闭则不显示）
            // v1.5.10：只对「预设动作」生效。自定义链接与 preset 无关，若照旧去查，
            // 会拿这一行**遗留的** preset 值误判（例：先选过「发布文章」再改成自定义链接，
            // 该行 preset 仍为 new_post → 被父主题「导航栏用户卡片发布按钮」开关连坐隐藏）。
            $preset_key = !empty($b['preset']) ? $b['preset'] : '';
            $requires   = '';
            $link_mode  = !empty($b['link_mode']) ? $b['link_mode'] : 'preset';
            if ('custom' !== $link_mode && isset($presets[$preset_key]['requires'])) {
                $requires = $presets[$preset_key]['requires'];
            }
            if (!empty($requires) && !_pz($requires)) {
                continue;
            }

            // 权限可见性
            if (!zibll_child_user_box_can_see($b['cap'], $b['cap_level'], $b['cap_custom'], $area)) {
                continue;
            }

            $href = zibll_child_user_box_resolve_href($b);
            if (!$href) {
                continue;
            }

            $out[] = array(
                'is_logout' => false,
                'href'      => $href,
                'title'     => $b['title'],
                'icon_html' => zibll_child_user_box_icon_html($b['icon']),
                'color'     => $b['color'],
                'blank'     => !empty($presets[$preset_key]['blank']) || !empty($b['blank']),
            );
        }

        return $out;
    }
}

// ─── 前端资源 ─────────────────────────────────────────────────────────

if (!function_exists('zibll_child_user_box_assets')) {
    function zibll_child_user_box_assets()
    {
        if (!is_user_logged_in()) {
            return; // 仅登录态替换用户按钮行
        }

        $user_buttons   = zibll_child_user_box_buttons('user');
        $admin_buttons  = zibll_child_user_box_buttons('admin');
        $user_active    = zibll_child_user_box_active('user');
        $admin_active   = zibll_child_user_box_active('admin');

        // 两区都没开 → 完全沿用父主题，连脚本都不用下发
        if (!$user_active && !$admin_active) {
            return;
        }
        // 开了但算出来是空数组（比如列表被清空）→ 无内容可注入，也不用下发
        if (empty($user_buttons) && empty($admin_buttons)) {
            return;
        }

        $render = function ($buttons) {
            $html = '';
            foreach ($buttons as $b) {
                $html .= zibll_child_user_box_a($b);
            }
            return $html;
        };

        $uri = get_stylesheet_directory_uri() . '/assets/';
        $ver = wp_get_theme()->get('Version');

        wp_enqueue_script('zc-userbox', $uri . 'js/user-box.js', array('jquery'), $ver, true);

        // ⚠️ 安全（v1.5.16）：不能用 wp_localize_script() 传整段 HTML。
        //    该函数的内部实现会先对值做 html_entity_decode()，再 wp_json_encode()，
        //    于是前面 zibll_child_user_box_a() 里 esc_html() 加上的实体转义会被
        //    【还原回 '<'】；而 wp_json_encode() 默认标志不转义 '/'，配合按钮
        //    配置中的 URL/文本，极易形成 '</script>' 提前闭合脚本块 → 脚本注入。
        //    现改用 wp_add_inline_script() 显式输出，并强制 JSON_HEX_TAG /
        //    JSON_HEX_AMP / JSON_HEX_APOS / JSON_HEX_QUOT，
        //    使 '<'、'>'、'&'、引号全部转成 \uXXXX，'<' 永远不会出现在脚本里。
        $payload = array(
            // v1.5.20：两区各自一份 HTML，前端按盒内行序定向替换，互不污染
            'userHtml'  => $user_active ? $render($user_buttons) : '',
            'adminHtml' => $admin_active ? $render($admin_buttons) : '',
        );
        $json = wp_json_encode(
            $payload,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        if ($json === false) {
            $json = '{"userHtml":"","adminHtml":""}'; // 极端情况下 json_encode 失败，降级为空，绝不输出裸内容
        }
        wp_add_inline_script('zc-userbox', 'window.ZIBLL_CHILD_USER_BOX = ' . $json . ';', 'after');
    }
    add_action('wp_enqueue_scripts', 'zibll_child_user_box_assets', 30);
}
