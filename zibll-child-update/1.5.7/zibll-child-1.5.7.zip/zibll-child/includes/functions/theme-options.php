<?php
/**
 * 子比子主题 - 独立设置页（CSF / Codestar Framework）
 * ─────────────────────────────────────────────────────────────
 * 目的：为子主题（及之后整合进来的依岸归自研插件）提供一个【独立】的后台设置入口，
 *       - 样式与父主题 zibll 完全一致（复用父主题已加载的 CSF 框架，不重复引入）；
 *       - 选项存独立 option key `zibll_child_options`，不污染父主题 `zibll_options`；
 *       - 作为【独立顶级菜单】「子比子主题设置」，与父主题「zibll主题设置」并列（不挂在其下）；
 *       - 所有关键文字说明（标题/页脚/字段说明）均为依岸归自定义，与官方无关。
 *
 * 重要兼容性说明（必读）：
 *   本站点父主题自带的 CSF 是【精简版】，仅支持以下字段类型：
 *     accordion / background / between_number / code_editor / gallery /
 *     group / palette / repeater / select / text / upload
 *   并不包含官方完整版的 switcher / content / callback 等字段。
 *   因此：
 *     - 开/关型选项用「仿父主题 CSF switcher 样式」的自定义开关
 *       （HTML 注入 description + AJAX 即时保存，视觉与父主题开关键一致）；
 *     - 富文本/自定义界面一律写进 section 的 `description`
 *       （CSF 对 description 原样输出、不转义，可放 HTML/链接/按钮）；
 *     - 绝不使用 callback / content 字段（会被静默忽略 → 面板空白）；
 *     - description 注入的自定义 HTML 经 admin_head 注入 scoped CSS（仅本面板）
 *       以复刻 CSF 原生扁平卡片视觉，避免 WP 原生 form-table 风格割裂。
 *
 * 【v1.4.2 重要更正】以上「精简版仅 11 种字段」的判断只适用于旧版父主题。
 *   在【子比 9.1】中，后台 Options 面板实际加载的是完整版 Codestar Framework 2.2.0
 *   （inc/codestar-framework/fields/，含 switcher / submessage / content / callback
 *   全部字段；inc/csf-framework/fields 那 11 种是 ZCSF Widget 渲染器专用，与
 *   后台 Options 面板无关）。因此 v1.4.2 起：
 *     - 新增的「SEO · 必应推送」「备份 & 导入」分组直接使用 CSF 原生
 *       switcher / text / content 字段，由 CSF 统一保存到 zibll_child_options；
 *     - 「基础设置」「我的插件」中的旧式自绘开关（存 zibll_child_modules，
 *       AJAX 即时保存）保持不变 —— 已上线多年、语义可靠，且与 CSF 面板的
 *       option 存储隔离（避免 CSF 保存整组时覆盖开关字段的旧 bug），不迁移。
 *
 * 面板内「主题更新」交互说明：
 *   - 「检查更新」按钮走 AJAX，清除并刷新 WordPress 原生 update_themes 缓存。
 *   - 发现新版本后跳转到「仪表盘 → 更新」，由 WordPress Theme_Upgrader 安装完整 ZIP。
 *   - 独立的「设置 → 子主题更新」菜单页不再使用，更新入口统一收敛到本面板内。
 *
 * 读取方式：前台/后台统一用 zibll_child_get_option('字段id', $default)。
 * 扩展方式：之后整合插件时，仿照下方「我的插件」section 追加即可（见该段注释）。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// 读取封装 zibll_child_get_option() / zibll_child_module_enabled() 见 includes/functions/functions.php
// （本文件在 functions.php 之后加载，可直接调用，无需重复定义）。

// ─── 面板内「检查更新」HTML（供 update section 的 description 注入） ───
// 检查按钮只刷新 WordPress 原生 update_themes transient；安装入口跳转到
// 仪表盘 → 更新，由 WordPress Theme_Upgrader 完成完整 ZIP 替换。
if (!function_exists('zibll_child_update_panel_html')) {
    function zibll_child_update_panel_html()
    {
        if (!function_exists('zibll_child_get_version') || !function_exists('zibll_child_fetch_update_meta')) {
            return '<p class="zibllc-error"><i class="fa fa-fw fa-exclamation-triangle"></i> '
                . '更新模块（theme-updater.php）未加载，请将该文件覆盖到主题目录后重试。</p>';
        }
        if (!current_user_can('manage_options')) {
            return '<p>无权限查看更新信息。</p>';
        }

        // 面板以同一次完整检查的 bundle（meta）作为唯一事实源；native transient
        // 仅用于补充展示 WordPress 更新列表状态，不参与版本决策。
        $local   = zibll_child_get_version();
        $meta    = zibll_child_fetch_update_meta();
        $sources = function_exists('zibll_child_get_update_source_status')
            ? zibll_child_get_update_source_status()
            : array();

        $remote = $meta ? $meta['version'] : '（获取失败）';
        $has_update = $meta !== false && version_compare($meta['version'], $local, '>');
        $status = $meta === false ? 'error' : ($has_update ? 'update' : 'latest');

        $check_nonce = wp_create_nonce('zibll_child_check_update');
        $update_url = admin_url('update-core.php');
        $selected_label = $meta && !empty($meta['_source_label']) ? $meta['_source_label'] : '尚未选择';

        if ($status === 'error') {
            $badge = '<span class="zibllc-badge zibllc-badge-error">'
                . '<i class="fa fa-fw fa-exclamation-circle"></i> 无法获取更新信息</span>'
                . '<span class="zibllc-hint">请检查 Achen / GitHub 更新源或网络连接</span>';
        } elseif ($has_update) {
            $badge = '<span class="zibllc-badge zibllc-badge-update">'
                . '<i class="fa fa-fw fa-arrow-circle-up"></i> 有新版本可用</span>';
        } else {
            $badge = '<span class="zibllc-badge zibllc-badge-ok">'
                . '<i class="fa fa-fw fa-check-circle"></i> 已是最新版本</span>';
        }

        $html  = '<div class="zibllc-update" id="zibllc-update-box">';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">当前本地版本</span>'
            . '<span class="zibllc-v"><code>' . esc_html($local) . '</code></span></div>';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">远程最新版本</span>'
            . '<span class="zibllc-v"><code>' . esc_html($remote) . '</code></span></div>';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">选用更新源</span>'
            . '<span class="zibllc-v">' . esc_html($selected_label) . '</span></div>';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">更新状态</span>'
            . '<span class="zibllc-v">' . $badge . '</span></div>';

        if (!empty($sources)) {
            $html .= '<div class="zibllc-sources"><span class="zibllc-k">来源状态</span><span class="zibllc-source-list">';
            foreach ($sources as $source) {
                $source_class = !empty($source['ok']) ? 'zibllc-source-ok' : 'zibllc-source-error';
                $source_text = !empty($source['ok'])
                    ? ($source['label'] . ' v' . $source['version'])
                    : ($source['label'] . ' 不可用');
                $source_title = !empty($source['error']) ? ' title="' . esc_attr($source['error']) . '"' : '';
                $html .= '<span class="zibllc-source ' . esc_attr($source_class) . '"' . $source_title . '>'
                    . esc_html($source_text) . '</span>';
            }
            $html .= '</span></div>';
        }

        $html .= '<div class="zibllc-actions">'
            . '<button type="button" id="zibllc-check-btn" class="button" data-nonce="' . esc_attr($check_nonce) . '">'
            . '<i class="fa fa-fw fa-refresh"></i> 检查更新</button>';
        if ($has_update) {
            $html .= '<a class="button button-primary" href="' . esc_url($update_url) . '">'
                . '<i class="fa fa-fw fa-cloud-download"></i> 前往 WordPress 更新</a>';
        }
        $html .= '</div>';

        if ($meta !== false && !empty($meta['changelog'])) {
            $html .= '<div class="zibllc-changelog-wrap"><h4 class="zibllc-sub">更新说明（v'
                . esc_html($meta['version']) . '）</h4>'
                . '<div class="zibllc-changelog">' . nl2br(esc_html($meta['changelog'])) . '</div></div>';
        }

        $html .= '<p class="zibllc-foot">检查结果写入 WordPress 原生主题更新缓存；安装时使用完整主题 ZIP，'
            . '由 WordPress Theme_Upgrader 负责替换。站点自定义 PHP 请在 zibll-site-code 插件中维护。</p>';
        $html .= '</div>';

        return $html;
    }
}

// ─── 基础设置里的「开/关」开关（仿父主题 CSF switcher 样式，AJAX 即时保存） ───
// 精简版 CSF 无 switcher 字段，故手写等价的 HTML 结构（42x22 圆角条 + 18px 圆球 + 0.3s 动画，
// 激活位移 20px），样式在 admin_head 注入的 .zibllc-switch-*（复刻父 .csf-field-switcher 观感）。
// 之后新增「只有开/关」的选项，统一在此追加一行（data-key 指向独立 option zibll_child_modules 的字段 id）。
if (!function_exists('zibll_child_switches_html')) {
    function zibll_child_switches_html()
    {
        $switches = array(
            'enable_qq_avatar' => array(
                'title' => 'QQ 邮箱自动头像',
                'desc'  => '开启后：新注册 / 修改邮箱 / 登录 的 QQ 邮箱用户会自动使用 QQ 头像；'
                    . '已主动上传头像的用户不会被覆盖。关闭后停止自动同步（已设置的头像保留）。',
                'on'    => zibll_child_module_enabled('enable_qq_avatar', true),
            ),
        );

        $nonce = wp_create_nonce('zibll_child_save_switch');
        $html  = '<div class="zibllc-switches">';
        foreach ($switches as $key => $s) {
            $html .= '<div class="zibllc-switch-row">'
                . '<label class="zibllc-switch ' . ($s['on'] ? 'zibllc-on' : '') . '">'
                . '<input type="checkbox" class="zibllc-switch-input"'
                . ' data-key="' . esc_attr($key) . '" data-nonce="' . esc_attr($nonce) . '"'
                . ($s['on'] ? ' checked' : '') . '>'
                . '<span class="zibllc-slider"></span>'
                . '</label>'
                . '<div class="zibllc-switch-meta">'
                . '<div class="zibllc-switch-title">' . esc_html($s['title']) . '</div>'
                . '<div class="zibllc-switch-desc">' . esc_html($s['desc']) . '</div>'
                . '</div>'
                . '</div>';
        }
        $html .= '</div>';

        return $html;
    }
}

// ─── 面板内「我的插件」：整合插件全量开关 ───
// 复用 .zibllc-switches 仿父主题 switcher 样式 + AJAX 即时保存（zibll_child_ajax_save_switch）。
// 各插件 loader 通过 zibll_child_module_enabled() 读取同一 option key 完成早退；
// 默认全开（option 未设置该 key 时 zibll_child_option_enabled 返回 true）。
if (!function_exists('zibll_child_module_switches_html')) {
    function zibll_child_module_switches_html()
    {
        $switches = array(
            'module_xiazhi_qz' => array(
                'title' => '夏稚文章前缀',
                'desc'  => '为文章标题添加前缀（图片/文字模式）。关闭后子主题不再加载内置副本；'
                    . '若服务器已启用同名独立插件，则由其托管，互不影响。',
                'on'    => zibll_child_module_enabled('module_xiazhi_qz', true),
            ),
            'module_rating' => array(
                'title' => '文章评分',
                'desc'  => '前台文章评分与平均分展示。关闭后子主题不再加载内置副本；'
                    . '若服务器已启用同名独立插件，则由其托管，评分数据共用、不丢失。',
                'on'    => zibll_child_module_enabled('module_rating', true),
            ),
            'module_comment_emoji' => array(
                'title' => '评论表情包',
                'desc'  => '评论框表情面板（后台可视化上传/分组）。关闭后子主题不再加载内置副本。',
                'on'    => zibll_child_module_enabled('module_comment_emoji', true),
            ),
        );

        $nonce = wp_create_nonce('zibll_child_save_switch');
        $html  = '<div class="zibllc-switches zibllc-switches-modules">';
        foreach ($switches as $key => $s) {
            $html .= '<div class="zibllc-switch-row">'
                . '<label class="zibllc-switch ' . ($s['on'] ? 'zibllc-on' : '') . '">'
                . '<input type="checkbox" class="zibllc-switch-input"'
                . ' data-key="' . esc_attr($key) . '" data-nonce="' . esc_attr($nonce) . '"'
                . ($s['on'] ? ' checked' : '') . '>'
                . '<span class="zibllc-slider"></span>'
                . '</label>'
                . '<div class="zibllc-switch-meta">'
                . '<div class="zibllc-switch-title">' . esc_html($s['title']) . '</div>'
                . '<div class="zibllc-switch-desc">' . esc_html($s['desc']) . '</div>'
                . '</div>'
                . '</div>';
        }
        $html .= '</div>';

        return $html;
    }
}

// ─── 面板内「我的插件」：文章评分插件状态卡（展示整合状态 + 数据一致性佐证） ───
// 复用 .zibllc-* 扁平卡片样式（与主题更新区一致）。
// 运行来源判定：独立插件已激活 → 由其托管；否则若内置副本存在 → 由子主题托管；
// 两者共用同一套存储 key（zrp_rating_options / score / zrp_rating_count / zrp_user_rating_{id}），数据天然一致。
if (!function_exists('zibll_child_rating_plugin_card_html')) {
    function zibll_child_rating_plugin_card_html()
    {
        $standalone = function_exists('zibll_child_rating_standalone_active')
            ? zibll_child_rating_standalone_active() : false;
        $bundled = file_exists(get_stylesheet_directory() . '/includes/rating-plugin/zibll-rating-plugin.php');

        if ($standalone) {
            $src_badge = '<span class="zibllc-badge zibllc-badge-ok"><i class="fa fa-fw fa-plug"></i> 由独立插件 zibll-rating-plugin 托管</span>';
            $src_note  = '服务器已启用同名独立插件，评分功能与历史数据由它提供服务；子主题内置副本处于休眠状态，不会重复加载或冲突。';
        } elseif ($bundled) {
            $src_badge = '<span class="zibllc-badge zibllc-badge-ok"><i class="fa fa-fw fa-check-circle"></i> 由子主题内置副本托管</span>';
            $src_note  = '未启用独立插件，评分功能由子主题内置副本提供；与独立插件共用同一套数据存储，数据自动继承、无需迁移。';
        } else {
            $src_badge = '<span class="zibllc-badge zibllc-badge-error"><i class="fa fa-fw fa-exclamation-triangle"></i> 未检测到评分插件</span>';
            $src_note  = '既未启用独立插件，子主题也未内置评分模块。';
        }

        // 评分功能开关状态（插件自身选项；若无函数则按默认启用展示）
        $enabled = function_exists('zrp_get_option') ? zrp_get_option('rating_enable', true) : true;
        $en_badge = $enabled
            ? '<span class="zibllc-badge zibllc-badge-ok">已启用</span>'
            : '<span class="zibllc-badge zibllc-badge-update">已停用</span>';

        // 已评分文章数（数据一致性佐证）。注意：本卡片在主题加载阶段（早于 zib_require_end）即生成，
        // 彼时插件的 inc/functions.php 尚未加载，故直接查 postmeta、不依赖插件函数。
        $rated = '';
        global $wpdb;
        if (isset($wpdb)) {
            $cnt = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value > 0",
                    'score'
                )
            );
            if ($cnt > 0) {
                $rated = '<div class="zibllc-row"><span class="zibllc-k">已有评分的文章</span>'
                    . '<span class="zibllc-v"><code>' . esc_html($cnt) . '</code> 篇</span></div>';
            }
        }

        $settings_url = admin_url('admin.php?page=zrp_rating_options');

        $html  = '<div class="zibllc-update" id="zibllc-rating-card">';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">模块</span>'
            . '<span class="zibllc-v"><strong>子比主题 - 文章评分插件</strong>（v1.1.0）</span></div>';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">运行来源</span>'
            . '<span class="zibllc-v">' . $src_badge . '</span></div>';
        $html .= '<div class="zibllc-row"><span class="zibllc-k">评分功能</span>'
            . '<span class="zibllc-v">' . $en_badge . '</span></div>';
        $html .= $rated;
        $html .= '<div class="zibllc-actions">'
            . '<a class="button" href="' . esc_url($settings_url) . '"><i class="fa fa-fw fa-star"></i> 评分插件设置</a>'
            . '</div>';
        $html .= '<p class="zibllc-foot">' . esc_html($src_note)
            . '数据存储：选项 <code>zrp_rating_options</code>、文章 meta <code>score</code>/<code>zrp_rating_count</code>、'
            . '用户 meta <code>zrp_user_rating_{文章ID}</code>，独立于子主题，停用或切换来源均不丢失。</p>';
        $html .= '</div>';

        return $html;
    }
}

// ─── 面板内「我的插件」：其余内嵌模块的设置入口 ───
// 这三个内嵌模块（评分 / 标题前缀 / 评论表情）的 CSF 面板均设为 menu_hidden，
// 不再单独占据后台菜单，统一从本面板「我的插件」分组进入 —— 符合「子主题的插件
// 归到子主题设置菜单下」的归类要求。
// 评分模块的卡片由 zibll_child_rating_plugin_card_html() 单独渲染（含运行来源与数据佐证）。
if (!function_exists('zibll_child_embedded_module_cards_html')) {
    function zibll_child_embedded_module_cards_html()
    {
        $modules = array(
            array(
                'title' => '夏稚 · 文章标题前缀',
                'ver'   => 'v1.1.1',
                'desc'  => '给文章标题自动追加自定义前缀（文字或图片），支持按分类与页面差异化配置。',
                'page'  => 'xiazhi_qz_options',
                'icon'  => 'fa-header',
            ),
            array(
                'title' => '评论表情包',
                'ver'   => 'v1.2.0',
                'desc'  => '为评论区提供分组表情，支持后台上传、拖拽排序与远程同步。',
                'page'  => 'zibll_comment_emoji_options',
                'icon'  => 'fa-smile-o',
            ),
        );

        $html = '';
        foreach ($modules as $m) {
            $html .= '<div class="zibllc-update">';
            $html .= '<div class="zibllc-row"><span class="zibllc-k">模块</span>'
                . '<span class="zibllc-v"><strong>' . esc_html($m['title']) . '</strong>（' . esc_html($m['ver']) . '）</span></div>';
            $html .= '<div class="zibllc-row"><span class="zibllc-k">说明</span>'
                . '<span class="zibllc-v">' . esc_html($m['desc']) . '</span></div>';
            $html .= '<div class="zibllc-actions">'
                . '<a class="button" href="' . esc_url(admin_url('admin.php?page=' . $m['page'])) . '">'
                . '<i class="fa fa-fw ' . esc_attr($m['icon']) . '"></i> 前往设置</a></div>';
            $html .= '</div>';
        }

        return $html;
    }
}

/* ─────────────────────────────────────────────────────────────
 * 后台菜单归位：把「子比子主题设置」并入依岸归的「Hoarfall 工具」顶级菜单
 * ─────────────────────────────────────────────────────────────
 * CSF 以 menu_type=menu 注册了独立顶级菜单，这里在 admin_menu 末尾（999）
 * 把面板自身的菜单项搬到 HOARFALL_MENU_SLUG 下，并移除原顶级菜单。
 * 用搬移而非 menu_type=submenu，是为了规避 CSF 在 submenu 模式下
 * 实例迭代顺序不可控导致的 404 问题（内嵌评分模块的选项面板早有同款踩坑记录）。
 * HOARFALL_MENU_SLUG 由 includes/brand-menu.php 定义（加载顺序早于本文件）。
 */
if (!function_exists('zibll_child_reparent_settings_menu')) {
    function zibll_child_reparent_settings_menu()
    {
        global $submenu;

        $top  = defined('HOARFALL_MENU_SLUG') ? HOARFALL_MENU_SLUG : 'hoarfall-tools';
        $slug = 'zibll_child_options';

        // 品牌层未注册顶级菜单时不动手，避免把菜单挂到不存在的位置。
        if (empty($submenu[$top]) || !is_array($submenu[$top])) {
            return;
        }
        if (empty($submenu[$slug]) || !is_array($submenu[$slug])) {
            return;
        }

        foreach ($submenu[$slug] as $item) {
            // 只搬面板自身那一项，避免把其下可能存在的子项一并带走。
            if (isset($item[2]) && $item[2] === $slug) {
                $submenu[$top][] = $item;
            }
        }

        unset($submenu[$slug]);
    }
}
add_action('admin_menu', 'zibll_child_reparent_settings_menu', 999);

// ─── 面板专属样式 + AJAX 脚本（仅本面板 page=zibll_child_options 时注入，不污染全局） ──
// 用 .zibllc-* 前缀 + 仅在 CSP 面板页输出，杜绝与 WP/父主题样式冲突。
add_action('admin_head', 'zibll_child_options_admin_assets');
function zibll_child_options_admin_assets()
{
    if (empty($_GET['page']) || $_GET['page'] !== 'zibll_child_options') {
        return;
    }
    echo '<style id="zibll-child-options-css">
.zibllc-update{font-size:13px;color:#23282d;transition:opacity .2s;}
.zibllc-row{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f0f0f1;}
.zibllc-row:last-of-type{border-bottom:none;}
.zibllc-k{color:#646970;font-weight:500;}
.zibllc-v code{background:#f0f0f1;padding:2px 8px;border-radius:3px;font-size:12px;}
.zibllc-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:3px;font-weight:600;font-size:12px;}
.zibllc-badge-ok{background:#e7f6ea;color:#1a7f37;}
.zibllc-badge-update{background:#fdecec;color:#d63638;}
.zibllc-badge-error{background:#fdecec;color:#d63638;}
.zibllc-hint{display:block;color:#8c8f94;font-size:12px;margin-top:4px;}
.zibllc-sources{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid #f0f0f1;}
.zibllc-source-list{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;}
.zibllc-source{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:3px;font-size:12px;font-weight:600;}
.zibllc-source-ok{background:#e7f6ea;color:#1a7f37;}
.zibllc-source-error{background:#fdecec;color:#d63638;}
.zibllc-actions{margin:14px 0 4px;display:flex;gap:8px;}
.zibllc-changelog-wrap{margin-top:14px;}
.zibllc-sub{margin:0 0 6px;font-size:13px;color:#23282d;}
.zibllc-changelog{background:#fff;border:1px solid #e2e4e7;border-radius:4px;padding:10px 14px;line-height:1.7;color:#3c434a;}
.zibllc-foot{margin-top:14px;color:#8c8f94;font-size:12px;line-height:1.6;}
.zibllc-error{color:#d63638;}
.zibllc-loading{opacity:.45;pointer-events:none;}
/* ── v1.4.2 备份列表（backup section 内） ── */
.zibllc-backup-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px solid #f0f0f1;}
.zibllc-backup-row:last-of-type{border-bottom:none;}
.zibllc-backup-meta{display:inline-flex;align-items:center;gap:8px;min-width:0;}
.zibllc-backup-meta code{background:#f0f0f1;padding:2px 8px;border-radius:3px;font-size:12px;}
.zibllc-backup-actions{flex:0 0 auto;white-space:nowrap;}
/* ── 仿父主题 CSF switcher 的开关键（仅本面板生效） ── */
.zibllc-switches{margin:2px 0 6px;}
.zibllc-switch-row{display:flex;align-items:flex-start;gap:14px;padding:12px 0;border-bottom:1px solid #f0f0f1;}
.zibllc-switch{position:relative;display:inline-block;width:42px;height:22px;flex:0 0 auto;margin-top:1px;cursor:pointer;}
.zibllc-switch .zibllc-switch-input{position:absolute;opacity:0;width:0;height:0;}
.zibllc-slider{position:absolute;inset:0;background:#b4b9be;border-radius:100px;transition:.3s;}
.zibllc-slider:before{content:"";position:absolute;width:18px;height:18px;left:2px;top:2px;background:#fff;border-radius:100px;transition:.3s;}
.zibllc-switch .zibllc-switch-input:checked + .zibllc-slider{background:#46b450;}
.zibllc-switch .zibllc-switch-input:checked + .zibllc-slider:before{transform:translateX(20px);}
.zibllc-switch .zibllc-switch-input:active + .zibllc-slider:before{width:25px;}
.zibllc-switch .zibllc-switch-input:checked:active + .zibllc-slider:before{transform:translateX(12px);width:25px;}
.zibllc-switch-meta{flex:1;min-width:0;}
.zibllc-switch-title{font-weight:600;color:#23282d;font-size:13px;}
.zibllc-switch-desc{color:#8c8f94;font-size:12px;line-height:1.6;margin-top:3px;}
</style>';
    // AJAX：检查更新（点击不刷新、不跳 section，与父主题 CSF 的 AJAX 操作一致）
    echo '<script id="zibll-child-options-js">
(function($){
  $(document).on("click","#zibllc-check-btn",function(e){
    e.preventDefault();
    var $btn=$(this), $box=$("#zibllc-update-box");
    $btn.prop("disabled",true).text("检查中…");
    $box.addClass("zibllc-loading");
    $.post(ajaxurl,{action:"zibll_child_check_update",nonce:$btn.data("nonce")},function(res){
      if(res && res.success && res.data && res.data.html){
        $box.replaceWith(res.data.html);
      }else{
        $btn.prop("disabled",false).text("检查更新");
        $box.removeClass("zibllc-loading");
        alert("检查更新失败，请稍后重试");
      }
    },"json").fail(function(){
      $btn.prop("disabled",false).text("检查更新");
      $box.removeClass("zibllc-loading");
      alert("检查更新失败，请稍后重试");
    });
  });
  // 开/关开关：即时 AJAX 保存（与父主题 CSF switcher 体验一致，不刷新、不跳 section）
  $(document).on("change",".zibllc-switch-input",function(){
    var $inp=$(this), $label=$inp.closest(".zibllc-switch"),
        key=$inp.data("key"), nonce=$inp.data("nonce"),
        val=$inp.is(":checked")?"1":"0";
    $.post(ajaxurl,{action:"zibll_child_save_switch",key:key,value:val,nonce:nonce},function(res){
      if(res && res.success){
        $label.toggleClass("zibllc-on",$inp.is(":checked"));
      }else{
        $inp.prop("checked",!$inp.is(":checked"));
        $label.toggleClass("zibllc-on",$inp.is(":checked"));
        alert("保存失败，请稍后重试");
      }
    },"json").fail(function(){
      $inp.prop("checked",!$inp.is(":checked"));
      $label.toggleClass("zibllc-on",$inp.is(":checked"));
      alert("保存失败，请稍后重试");
    });
  });
})(jQuery);
</script>';
}

// ─── AJAX 处理：检查更新（刷新 WordPress 原生主题更新缓存） ──
add_action('wp_ajax_zibll_child_check_update', 'zibll_child_ajax_check_update');
function zibll_child_ajax_check_update()
{
    check_ajax_referer('zibll_child_check_update', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('无权限');
    }

    $result = function_exists('zibll_child_refresh_native_updates')
        ? zibll_child_refresh_native_updates()
        : array('ok' => false, 'message' => '更新模块未加载');
    if (empty($result['ok'])) {
        wp_send_json_error(!empty($result['message']) ? $result['message'] : '检查更新失败');
    }

    wp_send_json_success(array(
        'html'    => zibll_child_update_panel_html(),
        'message' => !empty($result['message']) ? $result['message'] : '',
    ));
}

// ─── AJAX 处理：保存「开/关」开关（即时写入独立 option zibll_child_modules，避免被 CSF 面板覆盖） ──
add_action('wp_ajax_zibll_child_save_switch', 'zibll_child_ajax_save_switch');
function zibll_child_ajax_save_switch()
{
    check_ajax_referer('zibll_child_save_switch', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('无权限');
    }
    $key = isset($_POST['key']) ? sanitize_key($_POST['key']) : '';
    $val = isset($_POST['value']) ? $_POST['value'] : '0';
    // 仅允许已知开关字段，防止任意写入 option
    $allowed = array('enable_qq_avatar', 'module_xiazhi_qz', 'module_rating', 'module_comment_emoji');
    if (!in_array($key, $allowed, true)) {
        wp_send_json_error('非法字段');
    }
    $opts = get_option('zibll_child_modules', array());
    $opts[$key] = ($val === '1' || $val === 'on' || $val === true) ? '1' : '0';
    update_option('zibll_child_modules', $opts);
    wp_send_json_success(array('key' => $key, 'value' => $opts[$key]));
}

// ─── 注册 CSF 设置面板（仅后台，且 CSF 已加载时） ────────────
if (!function_exists('zibll_child_csf_options')) {
    function zibll_child_csf_options()
    {
        if (!class_exists('CSF')) {
            return;
        }

        $prefix = 'zibll_child_options';

        // 主面板：作为【独立顶级菜单】「子比子主题设置」，与父主题「zibll主题设置」并列。
        // 不挂在其下，避免与父主题设置混淆；文字说明均为依岸归自定义，与官方文案无关。
        CSF::createOptions($prefix, array(
            'menu_title'         => '子比子主题设置',
            'menu_slug'          => 'zibll_child_options',
            'menu_type'          => 'menu',            // 独立顶级菜单（默认即顶级，显式声明更清晰）
            'menu_position'      => 60,                // 与父主题菜单错开位置，互不挤占
            'menu_icon'          => 'dashicons-admin-appearance',
            'framework_title'    => '子比子主题（依岸归维护）',
            'show_in_customizer' => false,
            'save_defaults'      => true,
            'footer_text'        => '子比子主题 · 由依岸归维护 · https://nav.hoarfall.cn/',
            'footer_credit'      => '<i class="fa fa-fw fa-heart-o"></i> ',
            'theme'              => 'light',
        ));

        // 一级分组：基础设置（已有子主题功能的开关 + 外观配置集中放这里）
        // 注：精简版 CSF 无 switcher 字段，开/关型选项改用「仿父主题 CSF switcher 样式」的自定义开关
        //     （zibll_child_switches_html() 注入到 description，AJAX 即时保存，视觉与父主题一致）；
        //     text 等正常字段仍走 CSF 原生，由 CSF 自动保存。
        CSF::createSection($prefix, array(
            'id'          => 'basic',
            'title'       => '基础设置',
            'icon'        => 'fa fa-fw fa-cog',
            'description' => zibll_child_switches_html(),
            'fields'      => array(
                // 其他配置示范：用 text 字段承接任意文本设置（此处以站点副标题为例）
                array(
                    'id'      => 'site_subtitle',
                    'type'    => 'text',
                    'title'   => '站点副标题',
                    'desc'    => '可选，可显示在页脚或前端某处。读取：<code>zibll_child_get_option(\'site_subtitle\')</code>',
                    'default' => '',
                ),
            ),
        ));

        // 一级分组：主题更新（直接在面板内检查/更新，入口统一收敛于此，不再另建独立菜单页）
        // 注意：本精简版 CSF 无 callback 字段，故把更新 UI 作为 section 的 description 原样注入。
        // 「检查更新」走 AJAX 刷新原生缓存，安装入口跳转到 WordPress 更新页。
        CSF::createSection($prefix, array(
            'id'          => 'update',
            'title'       => '主题更新',
            'icon'        => 'fa fa-fw fa-refresh',
            'description' => zibll_child_update_panel_html(),
        ));

        // 一级分组：我的插件（整合依岸归自研插件的集中入口）
        // 首个已整合模块：文章评分插件（zibll-rating-plugin）。
        // 其代码以「内置副本」形式随子主题分发，并通过 rating-plugin-loader 与服务器
        // 已有独立插件实现零冲突、数据一致的共存/接管（详见 includes/rating-plugin-loader.php）。
        CSF::createSection($prefix, array(
            'id'          => 'plugins',
            'title'       => '我的插件',
            'icon'        => 'fa fa-fw fa-puzzle-piece',
            'description' => zibll_child_module_switches_html()
                . zibll_child_rating_plugin_card_html()
                . zibll_child_embedded_module_cards_html()
                . '<p style="margin-top:12px;color:#8c8f94;font-size:12px;">之后整合更多依岸归自研插件时，'
                . '可仿照「内置副本 + 条件加载器」的方式在此追加卡片或子 section，'
                . '前缀统一用 <code>zibll_child_options</code>，读取用 <code>zibll_child_get_option(\'字段id\')</code>。</p>',
        ));

        // 一级分组：SEO · 必应推送（v1.4.2 移植自 Vela 框架；完整 CSF 原生字段）
        // 开关/密钥由 CSF 保存进 zibll_child_options；读取见 includes/functions/bing-push.php
        // 的 zibll_child_bing_ready()。未开启/未填密钥时不会发起任何外网请求。
        CSF::createSection($prefix, array(
            'id'     => 'seo',
            'title'  => 'SEO · 必应推送',
            'icon'   => 'fa fa-fw fa-superpowers',
            'fields' => array(
                array(
                    'id'      => 'bing_push_on',
                    'type'    => 'switcher',
                    'title'   => '启用必应推送',
                    'desc'    => '开启后，文章发布/更新、分类/标签保存时自动把链接提交到必应站长工具（需配置下方 API 密钥）。默认关闭。',
                    'default' => false,
                ),
                array(
                    'id'      => 'bing_api_token',
                    'type'    => 'text',
                    'title'   => '必应 API 密钥',
                    'desc'    => '前往 <a href="https://learn.microsoft.com/en-us/bingwebmaster/getting-access" target="_blank" rel="noopener">必应站长工具</a>获取 API 密钥后粘贴于此。',
                    'default' => '',
                ),
                array(
                    'id'      => 'bing_bulk',
                    'type'    => 'content',
                    'content' => function_exists('zibll_child_bing_panel_html')
                        ? zibll_child_bing_panel_html()
                        : '<p class="zibllc-hint">必应推送模块未加载（bing-push.php）。</p>',
                ),
            ),
        ));

        // 一级分组：备份 & 导入（v1.4.2 移植自 Vela 框架）
        // 自动备份钩子见 includes/functions/options-backup.php；备份含面板配置 + 模块开关。
        CSF::createSection($prefix, array(
            'id'     => 'backup',
            'title'  => '备份 & 导入',
            'icon'   => 'fa fa-fw fa-copy',
            'fields' => array(
                array(
                    'type'    => 'content',
                    'content' => function_exists('zibll_child_settings_backup_html')
                        ? zibll_child_settings_backup_html()
                        : '<p class="zibllc-hint">备份模块未加载（options-backup.php）。</p>',
                ),
            ),
        ));

        // 一级分组：用户数据（v1.5.0 新增）
        // 用户数据批量导出/导入：流式 JSONL 单文件 + 浏览器驱动的分批异步作业，
        // 支撑几千至几万个用户的稳定导出与回导；父主题 zibll 的用户附加功能数据
        // （积分/余额/VIP/签到/勋章/收藏/关注等，全部存于 usermeta）随用户一起备份、1:1 恢复。
        // 实现见 includes/functions/user-export-import.php。
        CSF::createSection($prefix, array(
            'id'     => 'userdata',
            'title'  => '用户数据',
            'icon'   => 'fa fa-fw fa-users',
            'fields' => array(
                array(
                    'type'    => 'content',
                    'content' => function_exists('zibll_child_users_panel_html')
                        ? zibll_child_users_panel_html()
                        : '<p class="zibllc-hint">用户数据模块未加载（user-export-import.php）。</p>',
                ),
            ),
        ));

        // 一级分组：消息弹窗（v1.5.6 新增）
        // 把父主题顶部「悬停才展开、且下拉里只有分类计数没有正文」的消息铃铛，
        // 换成页面内常驻的悬浮窗；并补齐移动端（父主题在移动端直接不渲染该下拉）。
        // 桌面端与移动端各有完全独立的一套参数，改哪边只影响哪边。
        // 消息数据只读复用父主题 ZibMsg / zibmsg_* 系列函数，不新增数据表、不写用户数据。
        // 实现见 includes/functions/msg-popup.php（前端）+ assets/css|js/msg-popup.*。
        // ⚠️ 模块总开关在「我的插件」区（zibll_child_modules 的 enable_msg_popup）。
        CSF::createSection($prefix, array(
            'id'          => 'msgpopup',
            'title'       => '消息弹窗',
            'icon'        => 'fa fa-fw fa-bell-o',
            'description' => '<p style="margin:0 0 6px;color:#8c8f94;font-size:12px;">'
                . '把消息做成页面右下的常驻悬浮窗：收起态可选「气泡 / 迷你卡 / 胶囊」，展开态显示最新 N 条消息（摘要或完整正文）。'
                . '有未读时可自动展开；用户点 × 收起后记为「不再自动展开」，直到出现新消息。</p>'
                . '<p style="margin:0;color:#8c8f94;font-size:12px;">'
                . '桌面端与移动端参数互不影响。模块总开关（一键停用）在「我的插件」区。</p>',
            'fields'      => array(

                // ── 通用（桌面端 / 移动端共用） ──
                array(
                    'id'     => 'msg_common',
                    'type'   => 'fieldset',
                    'title'  => '通用',
                    'fields' => array(
                        array(
                            'id'      => 'scope',
                            'type'    => 'button_set',
                            'title'   => '显示范围',
                            'options' => array('front' => '仅首页', 'all' => '全站'),
                            'default' => 'front',
                            'desc'    => '默认只在站点首页输出悬浮窗，其他页面一律不输出（连一次数据库查询都不会发生）。<br>'
                                . '<strong>「隐藏原生消息按钮」会跟随本设置</strong>：非首页不显示悬浮窗时，父主题的原生按钮保持原样，'
                                . '不会出现「两个入口都没有」的情况。',
                        ),
                    ),
                ),

                // ── 桌面端 ──
                array(
                    'id'     => 'msg_pc',
                    'type'   => 'fieldset',
                    'title'  => '桌面端',
                    'fields' => array(
                        array(
                            'id'      => 'enabled',
                            'type'    => 'switcher',
                            'title'   => '在桌面端显示',
                            'default' => true,
                        ),
                        array(
                            'id'      => 'pos',
                            'type'    => 'button_set',
                            'title'   => '停靠位置',
                            'options' => array('br' => '右下', 'bl' => '左下', 'tr' => '右上', 'tl' => '左上'),
                            'default' => 'br',
                        ),
                        array(
                            'id'      => 'offx',
                            'type'    => 'number',
                            'title'   => '水平偏移',
                            'default' => 22,
                            'desc'    => '距屏幕左右边缘的距离（px），0 ~ 200。',
                        ),
                        array(
                            'id'      => 'offy',
                            'type'    => 'number',
                            'title'   => '垂直偏移',
                            'default' => 22,
                            'desc'    => '距屏幕上下边缘的距离（px），0 ~ 200。',
                        ),
                        array(
                            'id'      => 'collapse',
                            'type'    => 'button_set',
                            'title'   => '收起态形态',
                            'options' => array('bubble' => '气泡', 'mini' => '迷你卡', 'pill' => '胶囊'),
                            'default' => 'mini',
                            'desc'    => '迷你卡会直接列出未读标题（最醒目，但占位最大）；气泡最省地方。',
                        ),
                        array(
                            'id'      => 'width',
                            'type'    => 'number',
                            'title'   => '面板宽度',
                            'default' => 330,
                            'desc'    => 'px，240 ~ 520。',
                        ),
                        array(
                            'id'      => 'miniw',
                            'type'    => 'number',
                            'title'   => '迷你卡宽度',
                            'default' => 262,
                            'desc'    => 'px，180 ~ 420。仅收起态选「迷你卡」时生效。',
                        ),
                        array(
                            'id'      => 'maxh',
                            'type'    => 'number',
                            'title'   => '面板最大高度',
                            'default' => 340,
                            'desc'    => 'px，140 ~ 760。超出后列表内部滚动。',
                        ),
                        array(
                            'id'      => 'radius',
                            'type'    => 'number',
                            'title'   => '圆角',
                            'default' => 10,
                            'desc'    => 'px，0 ~ 30。',
                        ),
                        array(
                            'id'      => 'depth',
                            'type'    => 'button_set',
                            'title'   => '显示深度',
                            'options' => array('summary' => '摘要', 'full' => '完整'),
                            'default' => 'summary',
                            'desc'    => '摘要模式会把图片/代码/表情折叠成文字标记，面板更整齐；完整模式直接输出正文（含配图）。',
                        ),
                        array(
                            'id'      => 'lines',
                            'type'    => 'button_set',
                            'title'   => '摘要行数',
                            'options' => array(1 => '1 行', 2 => '2 行', 3 => '3 行'),
                            'default' => 1,
                            'desc'    => '仅摘要模式生效。',
                        ),
                        array(
                            'id'      => 'limit',
                            'type'    => 'number',
                            'title'   => '显示条数',
                            'default' => 5,
                            'desc'    => '1 ~ 20。',
                        ),
                        array(
                            'id'      => 'auto_expand',
                            'type'    => 'switcher',
                            'title'   => '有未读时自动展开',
                            'default' => false,
                        ),
                        array(
                            'id'      => 'show_mark',
                            'type'    => 'switcher',
                            'title'   => '显示「全部已读」',
                            'default' => true,
                            'desc'    => '调用父主题自身的已读接口，一次性把全部未读标记为已读。',
                        ),
                        array(
                            'id'      => 'hide_native',
                            'type'    => 'switcher',
                            'title'   => '隐藏顶部原生消息按钮',
                            'default' => true,
                            'desc'    => '开启后，父主题顶部导航里那个铃铛按钮不再输出（移除 <code>zib_nav_radius_button</code> 上的回调，'
                                . '不是用 CSS 藏起来），避免与悬浮窗重复。<br>'
                                . '消息中心、用户中心的消息入口完全不受影响；'
                                . '且只在本页确实会显示悬浮窗时才生效（见「通用 → 显示范围」）。',
                        ),
                    ),
                ),

                // ── 移动端 ──
                array(
                    'id'     => 'msg_ph',
                    'type'   => 'fieldset',
                    'title'  => '移动端',
                    'fields' => array(
                        array(
                            'id'      => 'enabled',
                            'type'    => 'switcher',
                            'title'   => '在移动端显示',
                            'default' => true,
                        ),
                        array(
                            'id'      => 'pos',
                            'type'    => 'button_set',
                            'title'   => '停靠位置',
                            'options' => array('abovetab' => '导航上方', 'br' => '右下角', 'bc' => '底部居中'),
                            'default' => 'abovetab',
                            'desc'    => '「导航上方」贴在手主题底部导航栏之上，可避开右下角的「回到顶部」按钮。',
                        ),
                        array(
                            'id'      => 'offy',
                            'type'    => 'number',
                            'title'   => '垂直偏移',
                            'default' => 14,
                            'desc'    => 'px，0 ~ 120。选「底部居中」时同时控制左右。',
                        ),
                        array(
                            'id'      => 'collapse',
                            'type'    => 'button_set',
                            'title'   => '收起态形态',
                            'options' => array('bubble' => '气泡', 'pill' => '胶囊'),
                            'default' => 'pill',
                            'desc'    => '移动端不提供「迷你卡」：97px 高的常驻卡片在小屏上会实打实挡住正文。',
                        ),
                        array(
                            'id'      => 'mode',
                            'type'    => 'button_set',
                            'title'   => '展开方式',
                            'options' => array('drawer' => '底部抽屉', 'modal' => '居中弹窗'),
                            'default' => 'drawer',
                        ),
                        array(
                            'id'      => 'drawerh',
                            'type'    => 'number',
                            'title'   => '抽屉高度',
                            'default' => 72,
                            'desc'    => '占屏幕高度的百分比，30 ~ 95。仅「底部抽屉」生效。',
                        ),
                        array(
                            'id'      => 'width',
                            'type'    => 'number',
                            'title'   => '弹窗宽度',
                            'default' => 280,
                            'desc'    => 'px，220 ~ 460。仅「居中弹窗」生效。',
                        ),
                        array(
                            'id'      => 'radius',
                            'type'    => 'number',
                            'title'   => '圆角',
                            'default' => 18,
                            'desc'    => 'px，0 ~ 30。抽屉形态只作用于顶部两角。',
                        ),
                        array(
                            'id'      => 'depth',
                            'type'    => 'button_set',
                            'title'   => '显示深度',
                            'options' => array('summary' => '摘要', 'full' => '完整'),
                            'default' => 'summary',
                        ),
                        array(
                            'id'      => 'lines',
                            'type'    => 'button_set',
                            'title'   => '摘要行数',
                            'options' => array(1 => '1 行', 2 => '2 行', 3 => '3 行'),
                            'default' => 1,
                        ),
                        array(
                            'id'      => 'limit',
                            'type'    => 'number',
                            'title'   => '显示条数',
                            'default' => 5,
                            'desc'    => '1 ~ 20。',
                        ),
                        array(
                            'id'      => 'scrim',
                            'type'    => 'switcher',
                            'title'   => '半透明遮罩',
                            'default' => true,
                            'desc'    => '展开时压暗页面背景，点击遮罩区域可收起。',
                        ),
                        array(
                            'id'      => 'grip',
                            'type'    => 'switcher',
                            'title'   => '顶部拖拽条',
                            'default' => true,
                            'desc'    => '仅底部抽屉显示。',
                        ),
                        array(
                            'id'      => 'auto_expand',
                            'type'    => 'switcher',
                            'title'   => '有未读时自动展开',
                            'default' => false,
                        ),
                        array(
                            'id'      => 'show_mark',
                            'type'    => 'switcher',
                            'title'   => '显示「全部已读」',
                            'default' => true,
                        ),
                    ),
                ),
            ),
        ));

        // [已移除] 子主题授权模块（license 面板 / 域名绑定激活码 / enhanced_css 授权门控）
        // 于 v1.2.22 完整删除：includes/functions/child-auth.php + child-auth-core.php 已删，
        // 不再依赖任何授权判断，子主题所有功能默认开放。如需自定义 CSS 请改用子主题 style.css。
    }
}

// 父主题 zibll 在 inc/inc.php 中已加载 CSF；子主题 includes 在其后加载，
// 直接在后台注册面板（与父主题 admin-options.php 同风格）。
// 本文件在 theme-updater.php 之后加载（见 includes/index.php），故更新函数已就绪。
if (is_admin() && class_exists('CSF')) {
    zibll_child_csf_options();
}
