<?php
/**
 * 子比子主题 - 运行环境兼容自检
 * ─────────────────────────────────────────────────────────────
 * 目的：在「子比主题 9.1 + WordPress 7.1」这一新基线上，把原本静默发生的
 *       环境失配变成后台可见的明确提示，避免只表现为"某个功能莫名失效"。
 *
 * 检查项：
 *   1. PHP 版本 —— WordPress 7.0 起最低要求由 7.2.24 提升至 7.4，7.1 沿用；
 *      低于 7.4 时 WordPress 本身就不会提供 7.x 更新，主题也应按此要求校准。
 *   2. 父主题核心是否存在 —— 缺 inc/inc.php 时子主题全部功能必然失效。
 *   3. 父主题是否为 zibll 且版本不低于 9.1 —— 本子主题的函数/钩子/缓存键
 *      均已按 9.1 校准（如头像缓存键 zib_get_avatar_cache_key()）。
 *   4. WordPress 版本 —— 低于 6.1 时不存在 update_themes_{UpdateURI} 钩子，
 *      主题更新会回退到 pre_set_site_transient_update_themes 注入（仍可用）。
 *
 * 设计约束：
 *   - 仅后台、仅管理员、仅仪表盘/主题/更新三个页面，且只在真有问题时输出，
 *     不做任何阻断、不改任何数据、不产生额外查询。
 *   - 只读 WordPress 既有常量与函数，不依赖父主题任何业务函数。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('ZIBLL_CHILD_MIN_PHP')) {
    define('ZIBLL_CHILD_MIN_PHP', '7.4'); // WordPress 7.1 最低要求
}
if (!defined('ZIBLL_CHILD_MIN_WP')) {
    define('ZIBLL_CHILD_MIN_WP', '6.1'); // Update URI 主题更新钩子所需
}
if (!defined('ZIBLL_CHILD_MIN_PARENT')) {
    define('ZIBLL_CHILD_MIN_PARENT', '9.1'); // 本子主题已适配的父主题版本
}

/**
 * 收集当前环境的兼容性问题（无问题时返回空数组）。
 *
 * @return array 每项含 level('error'|'warning') 与 text
 */
function zibll_child_env_issues()
{
    $issues = array();

    // 1) PHP 版本
    if (version_compare(PHP_VERSION, ZIBLL_CHILD_MIN_PHP, '<')) {
        $issues[] = array(
            'level' => 'error',
            'text'  => sprintf(
                '当前 PHP 版本为 %s，低于 WordPress 7.1 的最低要求 %s，请先在主机面板升级 PHP。',
                PHP_VERSION,
                ZIBLL_CHILD_MIN_PHP
            ),
        );
    }

    // 2) 父主题核心缺失
    if (defined('ZIBLL_CHILD_PARENT_MISSING') && ZIBLL_CHILD_PARENT_MISSING) {
        $issues[] = array(
            'level' => 'error',
            'text'  => '未找到父主题「子比主题（zibll）」的 inc/inc.php，子主题功能无法工作，请确认父主题已正确安装。',
        );
    }

    // 3) 父主题身份与版本
    //    THEME_VERSION 已由子主题 functions.php 修正为【父主题】版本（非子主题版本）。
    $parent      = function_exists('get_template') ? get_template() : '';
    $parent_ver  = defined('THEME_VERSION') ? (string) THEME_VERSION : '';

    if ($parent && $parent !== 'zibll') {
        $issues[] = array(
            'level' => 'error',
            'text'  => sprintf(
                '当前父主题是「%s」，而本子主题仅适用于子比主题（zibll），请检查「外观 → 主题」的父主题设置。',
                $parent
            ),
        );
    } elseif ($parent_ver !== '' && version_compare($parent_ver, ZIBLL_CHILD_MIN_PARENT, '<')) {
        $issues[] = array(
            'level' => 'warning',
            'text'  => sprintf(
                '父主题版本为 %s，低于本子主题已适配的 %s；个别模块（如头像缓存、控制台输出过滤）可能表现不一致，建议升级父主题。',
                $parent_ver,
                ZIBLL_CHILD_MIN_PARENT
            ),
        );
    }

    // 4) WordPress 版本
    global $wp_version;
    if (!empty($wp_version) && version_compare($wp_version, ZIBLL_CHILD_MIN_WP, '<')) {
        $issues[] = array(
            'level' => 'warning',
            'text'  => sprintf(
                '当前 WordPress 版本为 %s，低于 %s；主题更新将回退为旧的 update_themes 注入方式（功能仍可用，但后台不会显示原生更新入口）。',
                $wp_version,
                ZIBLL_CHILD_MIN_WP
            ),
        );
    }

    return $issues;
}

/**
 * 后台提示输出。
 */
function zibll_child_env_notice()
{
    if (!function_exists('current_user_can') || !current_user_can('manage_options')) {
        return;
    }

    // 仅在这几个与主题/更新直接相关的页面提示，避免全后台打扰
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && !in_array($screen->id, array('dashboard', 'themes', 'update-core'), true)) {
        return;
    }

    $issues = zibll_child_env_issues();
    if (empty($issues)) {
        return;
    }

    foreach ($issues as $issue) {
        $class = ($issue['level'] === 'error') ? 'notice-error' : 'notice-warning';
        echo '<div class="notice ' . esc_attr($class) . ' is-dismissible"><p>'
            . '<strong>子比子主题：</strong>' . esc_html($issue['text'])
            . '</p></div>';
    }
}
add_action('admin_notices', 'zibll_child_env_notice');
