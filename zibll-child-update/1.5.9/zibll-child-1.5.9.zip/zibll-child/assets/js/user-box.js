/**
 * 子比子主题 - 悬停面板快捷按钮替换
 * 仅替换登录态下第一个 .header-user-href（用户快捷按钮行），不动超级管理员第二行。
 * 若配置里没包含「退出登录」，则兜底追加原始退出登录 <a>，确保永不丢失。
 */
(function ($) {
    'use strict';

    function zcReplaceUserBox() {
        if (!window.ZIBLL_CHILD_USER_BOX || !ZIBLL_CHILD_USER_BOX.html) {
            return;
        }

        var box = $('.sub-user-box .header-user-href').first();
        if (!box.length) {
            return;
        }

        var newHtml = ZIBLL_CHILD_USER_BOX.html;

        // 配置里没有退出登录时，把父主题原始的退出登录按钮补回来
        if (newHtml.indexOf('data-zib-logout') === -1) {
            var origLogout = box.find('a[data-target="#modal_signout"]').first();
            if (origLogout.length) {
                newHtml += origLogout[0].outerHTML;
            }
        }

        // 仅替换内部，保留 .header-user-href 自身的 flex 布局类
        box.html(newHtml);
    }

    $(function () {
        zcReplaceUserBox();
    });

    // 登录弹窗完成后，头部用户卡片可能被刷新，重跑一次（幂等）
    $(document).ajaxComplete(function () {
        zcReplaceUserBox();
    });
})(jQuery);
