/**
 * 子比子主题 - 悬停面板快捷按钮替换
 * 替换登录态下【所有】.header-user-href（用户快捷按钮行），不动超级管理员第二行。
 * 若配置里没包含「退出登录」，则兜底追加原始退出登录 <a>，确保永不丢失。
 */
(function ($) {
    'use strict';

    function zcReplaceUserBox() {
        if (!window.ZIBLL_CHILD_USER_BOX || !ZIBLL_CHILD_USER_BOX.html) {
            return;
        }

        // ⚠️ 修复（v1.5.16）：原实现用 .first() 只替换第一个匹配。
        //    但父主题 zib_header_user_box() 带 static $html 缓存，会在
        //    【桌面导航与移动导航各输出一次】同一个用户盒 —— 于是手机端的
        //    那份永远不被替换，自定义按钮在移动端 100% 失效。
        //    现改为遍历全部匹配并逐个替换（操作本身幂等，重复执行无副作用）。
        var boxes = $('.sub-user-box .header-user-href');
        if (!boxes.length) {
            return;
        }

        boxes.each(function () {
            var box = $(this);
            // 逐个生成：退出登录按钮需从【当前这个】盒子里取，避免跨盒取值
            var newHtml = ZIBLL_CHILD_USER_BOX.html;

            // 配置里没有退出登录时，把父主题原始的退出登录按钮补回来
            if (newHtml.indexOf('data-zib-logout') === -1) {
                var origLogout = box.find('a[data-target="#modal_signout"]').first();
                if (origLogout.length) {
                    newHtml += origLogout[0].outerHTML;
                }
            }

            // 仅替换内部，保留 .header-user-href 自身的 flex 布局类
            box.html(newHtml);
        });
    }

    $(function () {
        zcReplaceUserBox();
    });

    // 登录弹窗完成后，头部用户卡片可能被刷新，重跑一次（幂等）
    $(document).ajaxComplete(function () {
        zcReplaceUserBox();
    });
})(jQuery);
