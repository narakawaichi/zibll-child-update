<?php
/**
 * avatar-proxy.php —— Google 头像国内可达反代（子主题自带端点）
 * ─────────────────────────────────────────────────────────────
 * 背景：父主题 zibll 处理 Google 登录时，把 lh3.googleusercontent.com 头像原链
 *       写入用户 custom_avatar，国内直连拉不到 → 头像裂图。
 * 本文件随 zibll-child 子主题分发，放在子主题根目录。子主题本身运行在用户服务器
 * 上（如香港节点，墙外出口），可直连 Google 拉图后吐给国内用户（前面有 CDN/CF 缓存）。
 *
 * 配套子主题模块：includes/functions/google-avatar-proxy.php
 *   该模块把 custom_avatar 里的 googleusercontent 原链改写为
 *   <本文件地址>?u=<urlencoded 原链>
 *
 * 安全（v1.5.16 全面加固）：本端点是全网匿名可访问的，历史上存在 4 个叠加风险：
 *   ① SSRF：白名单只校验【首个 URL】，而 CURLOPT_FOLLOWLOCATION 自动跟随的
 *      30x 跳转目标从未复验 → 借白名单域上的跳转端点即可让服务器代访
 *      127.0.0.1 / 169.254.169.254（云元数据）/ 内网端口；
 *   ② 协议未锁：未限制 CURLOPT_PROTOCOLS，跳转到 file://（读本地文件）、
 *      gopher://（打内网 Redis 等）均无显式拦截；
 *   ③ 同源任意内容：上游 Content-Type 被【原样透传】+ CORS: * + 无 nosniff，
 *      攻击者完全控制响应体与类型，浏览器按 HTML 渲染 → 本域名下的同源 XSS/钓鱼；
 *   ④ 无体积上限：CURLOPT_RETURNTRANSFER 把任意大小的响应整体读进 PHP 内存，
 *      匿名并发即可造成内存尖峰 / PHP-FPM OOM。
 * 现按下述顺序逐条封堵，且【不改变正常 Google 头像的行为】（302 仍可用）。
 *
 * 配套子主题模块：includes/functions/google-avatar-proxy.php
 *   该模块把 custom_avatar 里的 googleusercontent 原链改写为
 *   <本文件地址>?u=<urlencoded 原链>
 *
 * 缓存：输出 Cache-Control 86400s，前面 CDN/CF 边缘缓存。
 *
 * 注意：本文件为独立端点，不依赖 WordPress 环境（直接访问即可执行）。
 */

$u = isset($_GET['u']) ? (string) $_GET['u'] : '';

/**
 * 白名单：仅放行 Google 头像域名，防变开放代理被刷。
 * 强制 https，域名以正则锚定（$ 结尾）——google.com.evil.com / notgoogle.com
 * 这类混淆串无法通过。
 */
function zibll_avatar_allowed($u)
{
    if (!is_string($u) || $u === '') {
        return false;
    }
    $p = parse_url($u);
    if (!$p || strtolower(isset($p['scheme']) ? $p['scheme'] : '') !== 'https') {
        return false;
    }
    // 出现 user/pass@host 形式（凭据注入）一律拒绝
    if (isset($p['user']) || isset($p['pass'])) {
        return false;
    }
    $h = strtolower(isset($p['host']) ? $p['host'] : '');
    if ($h === '') {
        return false;
    }
    return (bool) preg_match('/^(?:[\w.-]+\.)?googleusercontent\.com$/i', $h)
        || (bool) preg_match('/^(?:[\w.-]+\.)?google\.com$/i', $h);
}

if (!zibll_avatar_allowed($u)) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo 'forbidden';
    exit;
}

// 限制 Google 头像尺寸，压到 96px，省流量、加快首屏。
// ⚠️ 安全（v1.5.16）：原判断是「URL 里没有 =sNN 才追加」，
//    攻击者传一个已含 =s99999 的白名单内 URL 即可跳过压缩、放大上游响应。
//    现改为【覆盖式】规范化，无论原值如何都强制收敛到 96px。
$u = preg_replace('/=s\d+(-c)?/i', '=s96-c', $u);
if (strpos($u, '=') === false) {
    $u .= '=s96-c';
}

// 当前服务器墙外可达 Google，用 curl 拉取
$ch = curl_init($u);
curl_setopt_array($ch, array(
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER         => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 3,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_LOW_SPEED_LIMIT => 1024,   // 低于 1KB/s 视为异常慢速流
    CURLOPT_LOW_SPEED_TIME  => 5,
    CURLOPT_MAXFILESIZE    => 2 * 1024 * 1024, // 2MB 上限，超出即中止，防内存尖峰
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (avatar-proxy)',
));
// 安全（v1.5.16）：锁协议为 https，禁止 file:// / gopher:// / ftp:// 等
if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTPS')) {
    curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
    curl_setopt($ch, CURLOPT_REDIR_PROTOCOLS, CURLPROTO_HTTPS);
}
$resp = curl_exec($ch);
if ($resp === false) {
    $err = curl_error($ch);
    curl_close($ch);
    // 细节只写日志，不回显给匿名请求者（避免 DNS/TLS/代理细节泄露 + 连通性 oracle）
    error_log('[zibll-avatar-proxy] fetch failed: ' . $err);
    http_response_code(502);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo 'fetch failed';
    exit;
}
$hsize  = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$code   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$ctype  = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$effurl = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
curl_close($ch);

// 安全（v1.5.16）：★ 跳转后的最终 URL 必须【再次】过白名单 ★
// 首次白名单只挡住了直接提交的 URL；CURLOPT_FOLLOWLOCATION 跟到哪儿，
// 就把请求发到了哪儿。此处不校验就等于白名单形同虚设。
if (!zibll_avatar_allowed($effurl)) {
    error_log('[zibll-avatar-proxy] redirect target rejected: ' . $effurl);
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo 'forbidden redirect target';
    exit;
}

if ($code < 200 || $code >= 300) {
    http_response_code(502);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo 'upstream error';
    exit;
}

// 安全（v1.5.16）：★ Content-Type 白名单 ★
// 原样透传上游 Content-Type 意味着攻击者能让本站域名返回 text/html，
// 浏览器会以 HTML 渲染（配合缺失的 nosniff 还会嗅探 text/plain）→ 同源 XSS。
// 本端点只服务头像，故只接受常见图片类型，其余一律拒绝。
$ctype = strtolower(trim((string) $ctype));
if (!preg_match('#^image/(?:jpeg|jpg|png|gif|webp|bmp|avif)$#', $ctype)) {
    error_log('[zibll-avatar-proxy] unsupported content type: ' . $ctype);
    http_response_code(415);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo 'unsupported content type';
    exit;
}

$body = substr($resp, $hsize);
// 二次兜底：体积超限直接丢弃（MAXFILESIZE 对 chunked 响应不一定生效）
if (strlen($body) > 2 * 1024 * 1024) {
    http_response_code(413);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo 'payload too large';
    exit;
}

header('Content-Type: ' . $ctype, true);
header('Cache-Control: public, max-age=86400, s-maxage=86400');
// 安全（v1.5.16）：补齐安全响应头。
//  - nosniff：禁止 MIME 嗅探
//  - CSP sandbox：即便响应被当作文档渲染也强制沙箱化，禁止脚本执行
//  - 移除 Access-Control-Allow-Origin: *（头像不需要跨域读取，
//    去掉即可阻断第三方站点热链/探测本端点）
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; sandbox");
header('X-Frame-Options: DENY');
echo $body;
