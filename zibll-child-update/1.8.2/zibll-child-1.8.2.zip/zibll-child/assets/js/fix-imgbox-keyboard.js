/**
 * 修复子比主题图片灯箱(Swiper)关闭后残留键盘监听、劫持评论框/私聊方向键的问题。
 *
 * 根因：
 *   themes/zibll/js/imgbox.js 中灯箱 Swiper 配置为
 *     keyboard: { enabled: true, onlyInViewport: false }
 *   关闭灯箱时主题并未 destroy 该 Swiper 实例（imgbox.js 只有 new Swiper() 没有 destroy），
 *   导致其键盘监听永久挂在 document 上，全局吃掉左右方向键。
 *   Swiper 水平轮播只劫持左右（上下键不劫持），于是表现为：
 *     「评论区/私聊里左右方向键不动、上下键正常」。
 *
 * 修复：
 *   监听灯箱关闭（点击关闭按钮 / 背景 / Esc），关闭后禁用 Swiper 键盘监听。
 *   下次打开灯箱会重新 new Swiper 并自动恢复键盘，灯箱内方向键切图不受影响。
 */
(function ($) {
    'use strict';

    function zcDisableImgboxKeyboard() {
        var sw = window.Miniimgbox && window.Miniimgbox.swiper;
        if (sw && sw.keyboard && sw.keyboard.enabled) {
            try { sw.keyboard.disable(); } catch (e) {}
        }
    }

    // 点击关闭（X 图标 / 背景 / 关闭按钮）
    $(document).on('click',
        '#mini-imgbox .img-close, #mini-imgbox .imgbox-bg, #mini-imgbox .imgbox-an .icon-close',
        zcDisableImgboxKeyboard
    );

    // Esc 关闭灯箱
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape' || e.keyCode === 27) {
            setTimeout(zcDisableImgboxKeyboard, 80);
        }
    });
})(jQuery);
