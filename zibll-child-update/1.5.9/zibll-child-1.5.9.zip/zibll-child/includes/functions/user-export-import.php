<?php
/**
 * 子比子主题 - 用户数据导入 / 导出（含父主题 zibll 用户扩展数据）
 * ─────────────────────────────────────────────────────────────
 * 目标：把站点用户数据导出为【单个文件】，并支持从该文件重新导入；
 *       规模可达几千至几万个用户，全程不超时、不中断。
 *
 * ── 一、为什么用「JSONL（JSON Lines）」而不是一个大 JSON 数组？ ──
 *   一个大 JSON 数组必须【整体读入内存】才能解析，几万用户（含 usermeta）
 *   很容易达到几百 MB，注定 OOM / 超时。JSONL 是「一行一个完整 JSON 对象」：
 *     · 导出：边生成边逐行追加写盘，内存占用恒定（不随用户数增长）；
 *     · 导入：逐行 fgets 读取并立刻落库，同样恒定内存；
 *     · 中途中断：行边界天然是还原点，可从任意一行续跑。
 *   因此本模块的文件格式是：
 *     第 1 行  {"_meta":{…}}            ← 头部：格式标记、站点信息、总量、导出参数
 *     第 2~N 行 {"id":1,"u":{…},"m":{…}} ← 每个用户一行
 *   文件扩展名 .jsonl（可选 gzip 压缩，自动按文件头魔数识别，不看扩展名）。
 *
 *   压缩文件的处理策略（导出与导入不对称，这是刻意的）：
 *     · 导出：每次 AJAX 追加写入一段 gzip member，最终得到「多 member 的合法
 *       gzip 文件」—— zlib 手册保证 gzread 会跨 member 连续解压，故不影响回导；
 *       好处是不必为压缩额外读一遍文件，也不占双份磁盘。
 *     · 导入：先把 gzip 一次性流式解压成纯文本，之后每一步续读都只面对纯文本，
 *       用 fseek 精确定位（O(1)）。因为压缩流上的随机定位必须从头重解压，
 *       跨请求续读既慢又依赖 gzseek 语义，解压一次反而最稳最快。
 *
 * ── 二、为什么用「浏览器驱动的分批 AJAX」而不是 WP-Cron / 后台进程？ ──
 *   WP-Cron 依赖前台访问触发、且单次仍受 PHP 执行时限约束；真正的后台
 *   worker 又要求服务器有常驻进程（多数面板站没有）。本模块采用：
 *     前端循环 → 每次 AJAX 只处理「一批」（默认 200~500 个用户）→ 立即返回进度
 *   单次请求工作量恒定、可预期，远低于 30s 的 max_execution_time，天然不超时；
 *   进度写入 option，题目中途关掉浏览器/网络抖动都不会丢状态 ——
 *   下次进入面板可「继续任务」，前端也会自动重试并从断点恢复。
 *
 * ── 三、父主题附加功能（zibll 用户扩展数据）的备份与恢复 ──
 *   子比把用户的「附加功能」数据全部落在 WordPress 标准 usermeta 表里，例如：
 *     积分 points / 积分明细 points_record / 免费积分 free_points_detail
 *     余额 balance / 余额明细 balance_record
 *     VIP 等级 vip_level、到期时间 vip_level_expired、VIP 配置 vip_setting
 *     签到、勋章、收藏、关注、邀请码、头像 custom_avatar、收款二维码、
 *     推广分成 income_rule / rebate_rule、绑定信息 auth_info / oauth_*
 *   因此本模块【以原始行级别】导出、写回 usermeta：
 *     · 导出走 SELECT 原始 meta_value（含序列化字符串），不做反序列化；
 *     · 导入按 key 原样写回，序列化结构 1:1 保真，不经过 update_user_meta 的二次序列化；
 *     · 同一 key 存在多行（WP 允许）也完整保留（行级数组）。
 *   这样「父主题附加功能」的备份/恢复即随用户数据一起完成，且零数据变形。
 *
 * ── 四、安全与稳健性 ──
 *   1. 权限：全部 AJAX 均要求 manage_options + nonce；下载走 admin-post 再校验一次；
 *   2. 落盘目录 uploads/zibll-child-user-data/ 自动写入 index.php + .htaccess 拒绝直连，
 *      文件只能通过带鉴权的 PHP 端点下载；
 *   3. 永远不导出/导入 session_tokens（会话令牌，导入他人的会直接导致会话劫持）；
 *   4. 「保护当前管理员」默认开启：导入时不覆盖【你自己】的密码与角色，
 *      避免导入一个不含管理员的文件后把自己锁在门外；
 *   5. 每个用户导入失败只记录不中止（最多留 50 条错误摘要），保证长任务不因个别脏数据中断；
 *   6. 免费的一致性校验：导入前把文件头部声明的用户总数与实际读到的记录条数对比，
 *      不一致立即在界面提示「文件可能被截断」，杜绝「静默少导」。
 *
 * 读取方式：后台「子比子主题设置 → 用户数据」（theme-options.php 的 userdata 分区）。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('ZIBLL_CHILD_USERS_JOB_OPT')) {
    define('ZIBLL_CHILD_USERS_JOB_OPT', 'zibll_child_users_job');
}
if (!defined('ZIBLL_CHILD_USERS_NONCE')) {
    define('ZIBLL_CHILD_USERS_NONCE', 'zibll_child_users_action');
}
if (!defined('ZIBLL_CHILD_USERS_DIRNAME')) {
    define('ZIBLL_CHILD_USERS_DIRNAME', 'zibll-child-user-data');
}
if (!defined('ZIBLL_CHILD_USERS_FORMAT')) {
    define('ZIBLL_CHILD_USERS_FORMAT', 'zibll-child-users');
}
if (!defined('ZIBLL_CHILD_USERS_FORMAT_VERSION')) {
    define('ZIBLL_CHILD_USERS_FORMAT_VERSION', 1);
}
if (!defined('ZIBLL_CHILD_USERS_STEP_SECONDS')) {
    define('ZIBLL_CHILD_USERS_STEP_SECONDS', 120); // 单步执行时间上限（工作量本身已由批大小约束）
}
if (!defined('ZIBLL_CHILD_USERS_MAX_ERRORS')) {
    define('ZIBLL_CHILD_USERS_MAX_ERRORS', 50);
}
if (!defined('ZIBLL_CHILD_USERS_STALE_SECONDS')) {
    define('ZIBLL_CHILD_USERS_STALE_SECONDS', 600); // 心跳超过该秒数视作任务已死，允许重开
}

/* ══════════════════════════════════════════════════════════════
 * 一、基础工具：目录 / 作业状态 / 流式读写抽象
 * ══════════════════════════════════════════════════════════════ */

/**
 * 导出文件落盘目录（uploads/zibll-child-user-data），首次调用时创建并加保护文件。
 *
 * @param bool $create 传 false 表示「只查询、不创建」—— 后台面板预览统计时用，
 *                     避免仅仅打开一次后台就凭空生成目录。
 * @return string 成功返回目录绝对路径（无尾斜杠），失败返回空串
 */
function zibll_child_users_dir($create = true)
{
    $uploads = wp_upload_dir();
    if (empty($uploads['basedir'])) {
        return '';
    }
    $dir = trailingslashit($uploads['basedir']) . ZIBLL_CHILD_USERS_DIRNAME;

    if (!is_dir($dir)) {
        if (!$create || !wp_mkdir_p($dir)) {
            return '';
        }
    }
    if (!$create) {
        return $dir;
    }

    // 保护：禁止目录索引、禁止通过 Web 直接下载（下载统一走带鉴权的 admin-post 端点）
    $index = $dir . '/index.php';
    if (!file_exists($index)) {
        @file_put_contents($index, "<?php\n// Silence is golden.\n");
    }
    $htaccess = $dir . '/.htaccess';
    if (!file_exists($htaccess)) {
        @file_put_contents(
            $htaccess,
            "# 子比子主题：用户数据导入导出目录，禁止 Web 直连\n"
            . "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\n    Order allow,deny\n    Deny from all\n</IfModule>\n"
        );
    }

    return $dir;
}

/** 读取当前作业状态（无任务返回 false） */
function zibll_child_users_job_get()
{
    $job = get_option(ZIBLL_CHILD_USERS_JOB_OPT, false);
    return is_array($job) && !empty($job['token']) ? $job : false;
}

/** 写入作业状态（不自动加载，避免拖慢每次请求） */
function zibll_child_users_job_set($job)
{
    if (!is_array($job)) {
        return false;
    }
    $job['updated'] = time();
    update_option(ZIBLL_CHILD_USERS_JOB_OPT, $job, false);
    return $job;
}

/** 清除作业状态（保留磁盘文件，便于失败后手动排查） */
function zibll_child_users_job_clear()
{
    delete_option(ZIBLL_CHILD_USERS_JOB_OPT);
}

/**
 * 并发守卫：已有任务正在跑时拒绝开新任务。
 * 心跳（updated）超过 ZIBLL_CHILD_USERS_STALE_SECONDS 视作已死，允许重开。
 *
 * @return true|string true 表示可以开始；字符串为拒绝原因
 */
function zibll_child_users_guard()
{
    $job = zibll_child_users_job_get();
    if (!$job) {
        return true;
    }
    if ($job['status'] !== 'running') {
        return true;
    }
    $alive = (time() - (int) $job['updated']) < ZIBLL_CHILD_USERS_STALE_SECONDS;
    if ($alive) {
        return '已有一个' . ($job['type'] === 'export' ? '导出' : '导入') . '任务正在运行，请先等待其完成或点击「终止任务」。';
    }
    // 心跳已过期：标记为中断，允许重开
    $job['status']  = 'error';
    $job['message'] = '任务长时间无响应，已自动标记为中断。';
    zibll_child_users_job_set($job);
    return true;
}

/**
 * 步进级并发守卫：防止同一个人在两个标签页里同时驱动同一个任务。
 * 前端每次「开始/继续」会生成一个 run_id 并随每一步上报；若任务在 20 秒内
 * 已被【别的 run_id】推进过，判定为另一页面正在执行，直接拒绝，
 * 否则两个进程会各自按游标追加/写回，导致导出重复行或导入重复处理。
 *
 * @param array  $job    作业状态（引用语义由调用方回写）
 * @param string $run_id 本次前端会话标识
 * @return true|string true 通过；字符串为拒绝原因
 */
function zibll_child_users_step_run_guard(&$job, $run_id)
{
    if ($run_id === '') {
        return true; // 未上报（极端兼容），不做限制
    }
    if (!empty($job['run_id'])
        && $job['run_id'] !== $run_id
        && (time() - (int) $job['updated']) < 20) {
        return '该任务正在其它页面中执行，请先关闭其它页面，或点击「终止任务」后重试。';
    }
    $job['run_id'] = $run_id;
    return true;
}

/**
 * 流式写入句柄：$gzip 为真且 zlib 可用时使用 gzip，否则纯文本。
 * 采用「追加」模式，每次 AJAX 请求独立开关句柄 —— 句柄无法跨请求保存。
 * 追加写 gzip 会在文件尾部生成【新的 gzip member】，形成「多 member 的合法 gzip 文件」：
 *   zlib 手册明确保证 gzread 在读到某个 member 结尾后会继续寻找下一个 member
 *   （"Any number of gzip streams may be concatenated in the input file"），
 *   因此第 2 步生成的文件仍可被 gzopen→gzread 完整解压，重新导入毫无问题。
 */
function zibll_child_users_writer_open($path, $gzip)
{
    if ($gzip && function_exists('gzopen')) {
        $h = @gzopen($path, 'ab9');
        if ($h) {
            return array('gz' => true, 'h' => $h);
        }
    }
    $h = @fopen($path, 'ab');
    return $h ? array('gz' => false, 'h' => $h) : false;
}

function zibll_child_users_writer_write($s, $line)
{
    return $s['gz'] ? gzwrite($s['h'], $line) : fwrite($s['h'], $line);
}

function zibll_child_users_writer_close($s)
{
    return $s['gz'] ? gzclose($s['h']) : fclose($s['h']);
}

/** 判断文件是否为 gzip（按魔数，不看扩展名） */
function zibll_child_users_is_gzip($path)
{
    if (!is_readable($path)) {
        return false;
    }
    $h = @fopen($path, 'rb');
    if (!$h) {
        return false;
    }
    $magic = (string) fread($h, 2);
    fclose($h);
    return ($magic === "\x1f\x8b");
}

/**
 * 把 gzip 文件流式解压为纯文本文件（1MB 分块，内存恒定）。
 * 导入侧刻意「先解压、后按纯文本分片读取」：
 *   gzip 是流式压缩，在压缩流上做随机定位需要从头重解压，跨请求续读既慢又
 *   依赖 gzseek 的定位语义；解压成纯文本后全程用 fseek，定位精确且 O(1)。
 */
function zibll_child_users_decompress_to($src, $dest)
{
    if (!function_exists('gzopen')) {
        return false;
    }
    $in = @gzopen($src, 'rb');
    if (!$in) {
        return false;
    }
    $out = @fopen($dest, 'wb');
    if (!$out) {
        gzclose($in);
        return false;
    }

    $ok = true;
    while (!gzeof($in)) {
        $chunk = gzread($in, 1048576);
        if ($chunk === false) {
            $ok = false;
            break;
        }
        if ($chunk !== '' && fwrite($out, $chunk) === false) {
            $ok = false;
            break;
        }
    }
    gzclose($in);
    fclose($out);

    if (!$ok) {
        @unlink($dest);
        return false;
    }
    return true;
}

/** 流式读取句柄：按文件头魔数自动识别 gzip，与扩展名无关 */
function zibll_child_users_reader_open($path)
{
    if (!is_readable($path)) {
        return false;
    }

    if (zibll_child_users_is_gzip($path)) {
        if (!function_exists('gzopen')) {
            return false;
        }
        $h = @gzopen($path, 'rb');
        return $h ? array('gz' => true, 'h' => $h) : false;
    }

    $h = @fopen($path, 'rb');
    return $h ? array('gz' => false, 'h' => $h) : false;
}

function zibll_child_users_reader_line($s)
{
    return $s['gz'] ? gzgets($s['h']) : fgets($s['h']);
}

function zibll_child_users_reader_tell($s)
{
    return $s['gz'] ? gztell($s['h']) : ftell($s['h']);
}

function zibll_child_users_reader_seek($s, $offset)
{
    $offset = (int) $offset;
    if ($offset <= 0) {
        return 0;
    }
    return $s['gz'] ? @gzseek($s['h'], $offset) : @fseek($s['h'], $offset);
}

function zibll_child_users_reader_close($s)
{
    return $s['gz'] ? gzclose($s['h']) : fclose($s['h']);
}

/**
 * 把一条记录编码成一行 JSON。
 * 正常情况下直接用 JSON；若数据含非法 UTF-8 导致 json_encode 失败，
 * 退化为 {"_b64":"…"}（base64(serialize(原始数组))），保证「不丢数据」。
 */
function zibll_child_users_encode_line($record)
{
    $json = function_exists('wp_json_encode')
        ? wp_json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        : json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if (is_string($json) && $json !== '') {
        return $json . "\n";
    }

    // 退化路径：整体 base64 + serialize（serialize 对二进制安全）
    $raw = @serialize($record);
    if (!is_string($raw)) {
        return '';
    }
    return '{"_b64":' . json_encode(base64_encode($raw)) . "}\n";
}

/** 解析一行；兼容 _b64 退化行 */
function zibll_child_users_decode_line($line)
{
    $line = trim((string) $line);
    if ($line === '') {
        return null;
    }
    $data = json_decode($line, true);
    if (!is_array($data)) {
        return null;
    }
    if (isset($data['_b64']) && is_string($data['_b64']) && count($data) === 1) {
        $raw = base64_decode($data['_b64'], true);
        if ($raw === false) {
            return null;
        }
        // allowed_classes=false：杜绝反序列化对象注入
        $restored = @unserialize($raw, array('allowed_classes' => false));
        return is_array($restored) ? $restored : null;
    }
    return $data;
}

/** 统计文件行数（流式，内存恒定）。行数超过 $cap 时提前返回 -1 表示「过大不统计」 */
function zibll_child_users_count_lines($path, $cap = 300000)
{
    $handle = zibll_child_users_reader_open($path);
    if (!$handle) {
        return -1;
    }
    $lines = 0;
    while (($line = zibll_child_users_reader_line($handle)) !== false) {
        $lines++;
        if ($lines > $cap) {
            zibll_child_users_reader_close($handle);
            return -1;
        }
    }
    zibll_child_users_reader_close($handle);
    return $lines;
}

/* ══════════════════════════════════════════════════════════════
 * 二、父主题（zibll）用户扩展字段清单
 * ══════════════════════════════════════════════════════════════ */

/** 永不出入的 usermeta 键（安全红线） */
function zibll_child_users_forbidden_meta_keys()
{
    return apply_filters('zibll_child_users_forbidden_meta_keys', array(
        'session_tokens',      // 会话令牌：导出=泄露，导入=会话劫持
        'default_password_nag',
    ));
}

/**
 * 子比「附加功能」用户扩展字段清单（精确键名）。
 * 用户选了「父主题用户扩展数据」方案：这些数据全部存于 usermeta，
 * 导出时随用户一起带走，导入时原样写回，即完成父主题附加功能的备份/恢复。
 */
function zibll_child_users_zib_meta_keys()
{
    return apply_filters('zibll_child_users_zib_meta_keys', array(
        // 积分 / 余额 / 免费额度
        'points', 'points_record', 'free_points_detail', 'free_points',
        'balance', 'balance_record', 'rebate_rule', 'income_rule',
        // VIP
        'vip_level', 'vip_level_expired', 'vip_setting', 'vip_type', 'vip_expire',
        // 签到 / 勋章 / 等级
        'checkin', 'checkin_date', 'continuous_checkin', 'checkin_record',
        'user_level', 'medal', 'medal_list', 'user_medal',
        // 收藏 / 关注 / 邀请
        'favorite', 'favorite_post', 'favorite_list',
        'follow', 'follow_user', 'fans', 'followed',
        'invit_code', 'invite_code', 'invited_by', 'invit_count',
        // 头像 / 封面 / 资料
        'custom_avatar', 'custom_avatar_id', 'cover_image_id',
        'auth_info', 'user_addr', 'phone', 'mobile',
        // 收款 / 打赏
        'rewards_title', 'rewards_wechat_image_id', 'rewards_alipay_image_id',
        // 下载 / 订单相关
        'pay_down_log', 'pay_down_count',
        // 封禁 / 登录
        'ban', 'user_ban', 'ban_reason', 'last_login', 'login_count',
    ));
}

/** 子比扩展字段的前缀特征（用于覆盖率统计的兜底匹配） */
function zibll_child_users_zib_meta_prefixes()
{
    return apply_filters('zibll_child_users_zib_meta_prefixes', array('oauth_', 'zib_', 'zibll_', 'zibpay_'));
}

/**
 * 统计站点内「父主题附加功能」用户数据的覆盖情况（用于面板概览）。
 * 结果缓存 10 分钟，避免每次打开设置页都扫全表。
 */
function zibll_child_users_zib_coverage($force = false)
{
    if (!$force) {
        $cached = get_transient('zibll_child_users_coverage');
        if (is_array($cached)) {
            return $cached;
        }
    }

    global $wpdb;
    $keys  = zibll_child_users_zib_meta_keys();
    $found = array();

    if (!empty($wpdb->usermeta) && !empty($keys)) {
        $holders = implode(',', array_fill(0, count($keys), '%s'));
        $sql = $wpdb->prepare(
            "SELECT meta_key, COUNT(*) AS rows_count, COUNT(DISTINCT user_id) AS users_count
             FROM {$wpdb->usermeta}
             WHERE meta_key IN ($holders)
             GROUP BY meta_key
             ORDER BY users_count DESC",
            $keys
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $found[$row['meta_key']] = array(
                    'rows'  => (int) $row['rows_count'],
                    'users' => (int) $row['users_count'],
                );
            }
        }

        // 前缀型（如 oauth_weixin_getUserInfo）合并成一个汇总条目，避免清单过长
        $like = array();
        $args = array();
        foreach (zibll_child_users_zib_meta_prefixes() as $prefix) {
            $like[] = 'meta_key LIKE %s';
            $args[] = $wpdb->esc_like($prefix) . '%';
        }
        $sql = "SELECT COUNT(*) AS rows_count, COUNT(DISTINCT user_id) AS users_count
                FROM {$wpdb->usermeta} WHERE " . implode(' OR ', $like);
        $row = $wpdb->get_row($wpdb->prepare($sql, $args), ARRAY_A);
        if ($row) {
            $found['（前缀型：oauth_* / zib_* / zibll_* / zibpay_*）'] = array(
                'rows'  => (int) $row['rows_count'],
                'users' => (int) $row['users_count'],
            );
        }
    }

    $coverage = array(
        'keys'    => $found,
        'total'   => array_sum(wp_list_pluck($found, 'rows')),
        'updated' => current_time('Y-m-d H:i:s'),
    );

    set_transient('zibll_child_users_coverage', $coverage, 10 * MINUTE_IN_SECONDS);
    return $coverage;
}

/* ══════════════════════════════════════════════════════════════
 * 三、导出：分片查询 + 逐行落盘
 * ══════════════════════════════════════════════════════════════ */

/** 按「游标 ID（主键递增）」分片取用户 ID；比 OFFSET 稳定且走主键索引 */
function zibll_child_users_query_ids($after_id, $limit, $params)
{
    global $wpdb;
    $after_id = (int) $after_id;
    $limit    = max(1, (int) $limit);
    $role     = isset($params['role']) ? (string) $params['role'] : '';

    if ($role !== '') {
        $cap_key = $wpdb->get_blog_prefix() . 'capabilities';
        $sql = $wpdb->prepare(
            "SELECT u.ID FROM {$wpdb->users} u
             INNER JOIN {$wpdb->usermeta} m ON (m.user_id = u.ID AND m.meta_key = %s)
             WHERE u.ID > %d AND m.meta_value LIKE %s
             ORDER BY u.ID ASC LIMIT %d",
            $cap_key,
            $after_id,
            '%' . $wpdb->esc_like('"' . $role . '"') . '%',
            $limit
        );
        return array_map('intval', (array) $wpdb->get_col($sql));
    }

    $sql = $wpdb->prepare(
        "SELECT ID FROM {$wpdb->users} WHERE ID > %d ORDER BY ID ASC LIMIT %d",
        $after_id,
        $limit
    );
    return array_map('intval', (array) $wpdb->get_col($sql));
}

/** 导出总量（用于进度百分比） */
function zibll_child_users_count_scope($params)
{
    global $wpdb;
    $role = isset($params['role']) ? (string) $params['role'] : '';

    if ($role !== '') {
        $cap_key = $wpdb->get_blog_prefix() . 'capabilities';
        $sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->users} u
             INNER JOIN {$wpdb->usermeta} m ON (m.user_id = u.ID AND m.meta_key = %s)
             WHERE m.meta_value LIKE %s",
            $cap_key,
            '%' . $wpdb->esc_like('"' . $role . '"') . '%'
        );
        return (int) $wpdb->get_var($sql);
    }

    return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}");
}

/** 头部行：格式标记 + 站点上下文 + 导出参数（导入前先校验，防串站/串格式） */
function zibll_child_users_header($params, $total)
{
    return array(
        '_meta' => array(
            'format'         => ZIBLL_CHILD_USERS_FORMAT,
            'format_version' => ZIBLL_CHILD_USERS_FORMAT_VERSION,
            'created'        => current_time('Y-m-d H:i:s'),
            'created_gmt'    => gmdate('c'),
            'site_url'       => home_url('/'),
            'site_name'      => get_bloginfo('name'),
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'table_prefix'   => $GLOBALS['wpdb']->prefix,
            'theme'          => function_exists('zibll_child_get_version')
                ? 'zibll-child ' . zibll_child_get_version()
                : 'zibll-child',
            'total_users'    => (int) $total,
            'batch_size'     => (int) $params['batch'],
            'scope_role'     => (string) $params['role'],
            'include_meta'   => !empty($params['meta']),
            'include_secret' => !empty($params['pass']),
            'zib_meta_keys'  => zibll_child_users_zib_meta_keys(),
            'note'           => '父主题 zibll 用户附加功能数据以原始 usermeta 行导出，导入时 1:1 写回。',
        ),
    );
}

/**
 * 一批用户的【原始】数据：users 表一行 + usermeta 原始行。
 * 刻意绕开 get_userdata / get_user_meta：
 *   ① 避免 N+1 查询（一批两次 IN 查询搞定）；
 *   ② 避免 update_user_meta 的二次序列化破坏父主题扩展数据的原始结构。
 */
function zibll_child_users_fetch_batch($ids, $include_meta, $include_pass)
{
    global $wpdb;
    if (empty($ids)) {
        return array();
    }
    $ids_in = implode(',', array_map('intval', $ids));

    $cols = 'ID,user_login,user_nicename,user_email,user_url,user_registered,user_status,display_name';
    if ($include_pass) {
        $cols .= ',user_pass';
    }
    $users = $wpdb->get_results(
        "SELECT $cols FROM {$wpdb->users} WHERE ID IN ($ids_in) ORDER BY ID ASC",
        ARRAY_A
    );
    if (!is_array($users)) {
        return array();
    }

    $meta_map = array();
    if ($include_meta) {
        $exclude = zibll_child_users_forbidden_meta_keys();
        $rows = $wpdb->get_results(
            "SELECT user_id,meta_key,meta_value FROM {$wpdb->usermeta} WHERE user_id IN ($ids_in)",
            ARRAY_A
        );
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $key = (string) $row['meta_key'];
                if (in_array($key, $exclude, true)) {
                    continue; // 安全红线：会话令牌等一律不出
                }
                $uid = (int) $row['user_id'];
                if (!isset($meta_map[$uid])) {
                    $meta_map[$uid] = array();
                }
                if (!isset($meta_map[$uid][$key])) {
                    $meta_map[$uid][$key] = array();
                }
                $meta_map[$uid][$key][] = (string) $row['meta_value'];
            }
        }
    }

    $out = array();
    foreach ($users as $u) {
        $uid = (int) $u['ID'];
        $rec = array(
            'id' => $uid,
            'u'  => $u,
            'm'  => isset($meta_map[$uid]) ? $meta_map[$uid] : array(),
        );
        $out[] = $rec;
    }
    return $out;
}

/* ══════════════════════════════════════════════════════════════
 * 四、导入：按策略写回用户 + 原样写回 usermeta
 * ══════════════════════════════════════════════════════════════ */

/** 导入策略清单（供面板下拉复用） */
function zibll_child_users_import_policies()
{
    return array(
        'update_keep_pass' => '更新资料与扩展数据，已存在用户保留其当前密码（推荐）',
        'update_all'       => '更新资料与扩展数据，并按导出文件覆盖密码哈希（完全还原）',
        'insert_only'      => '仅新增不存在的用户，已存在的一律跳过（最安全，适合合并站点）',
    );
}

/** 是否为可接受的 WordPress 密码哈希（避免把明文/脏数据直接写进 users.user_pass） */
function zibll_child_users_is_password_hash($value)
{
    $value = (string) $value;
    if (strlen($value) < 20 || strlen($value) > 255) {
        return false;
    }
    return (bool) preg_match('/^\$(P|H|wp|2[aby]|argon2)/', $value);
}

/**
 * 导入单个用户记录。
 *
 * @param array $rec    一行反序列化后的记录
 * @param array $params 导入参数（policy / meta / purge / protect_self）
 * @param array $stats  统计（引用）
 * @param array $errors 错误摘要（引用）
 * @return string created|updated|skipped|failed
 */
function zibll_child_users_import_one($rec, $params, &$stats, &$errors)
{
    global $wpdb;

    if (!is_array($rec) || empty($rec['u']) || !is_array($rec['u'])) {
        $stats['failed']++;
        if (count($errors) < ZIBLL_CHILD_USERS_MAX_ERRORS) {
            $errors[] = '跳过 1 条无法解析的记录。';
        }
        return 'failed';
    }

    $u         = $rec['u'];
    $login     = isset($u['user_login']) ? trim((string) $u['user_login']) : '';
    $email     = isset($u['user_email']) ? trim((string) $u['user_email']) : '';
    $meta      = (isset($rec['m']) && is_array($rec['m'])) ? $rec['m'] : array();
    $policy    = isset($params['policy']) ? (string) $params['policy'] : 'update_keep_pass';
    $with_meta = !empty($params['meta']);
    $purge     = !empty($params['purge']);
    $protect   = !empty($params['protect_self']);
    $self_id   = (int) get_current_user_id();

    if ($login === '' || !validate_username($login)) {
        $stats['failed']++;
        if (count($errors) < ZIBLL_CHILD_USERS_MAX_ERRORS) {
            $errors[] = '用户名为空或非法：' . ($login === '' ? '(空)' : $login);
        }
        return 'failed';
    }

    // ── 定位已存在用户：先按登录名，再按邮箱 ──
    $existing_id = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->users} WHERE user_login = %s LIMIT 1",
        $login
    ));
    if (!$existing_id && $email !== '') {
        $existing_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->users} WHERE user_email = %s LIMIT 1",
            $email
        ));
    }

    if ($existing_id && $policy === 'insert_only') {
        $stats['skipped']++;
        return 'skipped';
    }

    $is_self   = ($existing_id && $self_id && $existing_id === $self_id);
    $lock_self = ($is_self && $protect); // 保护当前管理员：不动其密码与角色

    // ── 组装 users 表字段 ──
    $core = array(
        'user_email'      => $email,
        'user_nicename'   => isset($u['user_nicename']) ? (string) $u['user_nicename'] : '',
        'user_url'        => isset($u['user_url']) ? (string) $u['user_url'] : '',
        'display_name'    => isset($u['display_name']) ? (string) $u['display_name'] : $login,
        'user_status'     => isset($u['user_status']) ? (int) $u['user_status'] : 0,
    );

    $result = 'created';

    if ($existing_id) {
        $result = 'updated';
        // 邮箱为空时不写，避免把已有邮箱清掉；邮箱冲突由 $wpdb->update 返回 false 兜底
        if ($core['user_email'] === '') {
            unset($core['user_email']);
        }
        $ok = $wpdb->update($wpdb->users, $core, array('ID' => $existing_id));
        if ($ok === false) {
            // 多为邮箱唯一索引冲突：保留其余字段与扩展数据的导入，不让整条记录失败
            unset($core['user_email']);
            $wpdb->update($wpdb->users, $core, array('ID' => $existing_id));
            if (count($errors) < ZIBLL_CHILD_USERS_MAX_ERRORS) {
                $errors[] = '#' . $existing_id . ' ' . $login . '：邮箱与其它账号冲突，已跳过邮箱更新。';
            }
        }
        $user_id = $existing_id;
    } else {
        $data = $core;
        $data['user_login']      = $login;
        // wp_insert_user 会对 user_pass 再做一次 wp_hash_password（明文→哈希）。
        // 因此这里先给一个随机强密码，稍后用 $wpdb->update 直接写入文件里的哈希，
        // 避免「哈希被二次哈希」导致用户无法登录。
        $data['user_pass']       = wp_generate_password(24, true, true);
        $data['user_registered'] = isset($u['user_registered']) ? (string) $u['user_registered'] : current_time('mysql');
        $data['role']            = ''; // 角色由 capabilities meta 原样恢复，这里不赋

        $new_id = wp_insert_user($data);
        if (is_wp_error($new_id)) {
            $stats['failed']++;
            if (count($errors) < ZIBLL_CHILD_USERS_MAX_ERRORS) {
                $errors[] = $login . '：' . $new_id->get_error_message();
            }
            return 'failed';
        }
        $user_id = (int) $new_id;
    }

    // ── 密码哈希：新建用户继承；更新用户按策略 ──
    $can_write_pass = (!$lock_self) && ($result === 'created' || $policy === 'update_all');
    if ($can_write_pass && !empty($u['user_pass']) && zibll_child_users_is_password_hash($u['user_pass'])) {
        $wpdb->update($wpdb->users, array('user_pass' => (string) $u['user_pass']), array('ID' => $user_id));
    } elseif ($lock_self && !empty($u['user_pass'])) {
        $stats['protected']++;
    }

    // ── usermeta：父主题附加功能数据的备份/恢复就在这里 ──
    if ($with_meta && !empty($meta)) {
        $forbidden  = zibll_child_users_forbidden_meta_keys();
        $cap_key    = $wpdb->get_blog_prefix() . 'capabilities';
        $skip_keys  = $forbidden;
        if ($lock_self) {
            // 保护自己：不动角色能力（否则可能把自己降权/锁死）
            $skip_keys[] = $cap_key;
        }

        $keys = array();
        foreach (array_keys($meta) as $k) {
            $k = (string) $k;
            if (in_array($k, $skip_keys, true)) {
                continue;
            }
            $keys[] = $k;
        }

        if ($purge && !$lock_self) {
            // 完全还原模式：清掉目标用户全部旧 meta（自身账号除外，避免清掉会话与角色）
            $wpdb->delete($wpdb->usermeta, array('user_id' => $user_id));
        }

        if (!empty($keys)) {
            $holders = implode(',', array_fill(0, count($keys), '%s'));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key IN ($holders)",
                array_merge(array($user_id), $keys)
            ));

            $rows = array();
            $args = array();
            foreach ($keys as $k) {
                $values = is_array($meta[$k]) ? $meta[$k] : array($meta[$k]);
                foreach ($values as $v) {
                    $rows[] = '(%d,%s,%s)';
                    $args[] = $user_id;
                    $args[] = $k;
                    $args[] = (string) $v;
                }
            }

            // 分块 INSERT，避免单条 SQL 过大触发 max_allowed_packet
            foreach (array_chunk($rows, 150) as $chunk) {
                $chunk_args = array_slice($args, 0, count($chunk) * 3);
                $args       = array_slice($args, count($chunk) * 3);
                $wpdb->query($wpdb->prepare(
                    "INSERT INTO {$wpdb->usermeta} (user_id,meta_key,meta_value) VALUES " . implode(',', $chunk),
                    $chunk_args
                ));
            }
        }
    }

    clean_user_cache($user_id);

    // 与子主题「QQ 邮箱自动头像」模块保持一致：文件里带了自定义头像时，
    // 清掉「系统自动设置」标记 —— 否则新用户注册钩子先写了 auto=1，
    // 之后用户改资料时可能被自动同步覆盖掉刚导入进来的头像。
    if ($with_meta && isset($meta['custom_avatar'])) {
        delete_user_meta($user_id, 'zibll_child_qq_avatar_auto');
    }

    // ── 兜底：扩展数据未覆盖到角色时，别让新用户变成「无角色」 ──
    if ($result === 'created') {
        $fresh = new WP_User($user_id);
        if (empty($fresh->roles)) {
            $fresh->set_role('subscriber');
        }
    }

    $stats[$result === 'created' ? 'created' : 'updated']++;
    return $result;
}

/* ══════════════════════════════════════════════════════════════
 * 五、AJAX：导出
 * ══════════════════════════════════════════════════════════════ */

/**
 * 统一守卫：nonce + 权限 + 单次请求时间预算。
 * 任一不满足直接 wp_send_json_error 并终止请求。
 */
function zibll_child_users_ajax_guard()
{
    check_ajax_referer(ZIBLL_CHILD_USERS_NONCE, 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('无权限');
    }
    if (function_exists('wp_raise_memory_limit')) {
        wp_raise_memory_limit('admin');
    }
    if (function_exists('set_time_limit')) {
        @set_time_limit(ZIBLL_CHILD_USERS_STEP_SECONDS);
    }
    if (function_exists('ignore_user_abort')) {
        @ignore_user_abort(true); // 浏览器断连也让当前这批做完，避免半批写坏
    }
}

/** 导出进度负载 */
function zibll_child_users_progress($job)
{
    $total     = (int) $job['total'];
    $processed = (int) $job['processed'];
    $percent   = $total > 0 ? (int) floor($processed * 100 / $total) : 0;
    if ($percent > 100) {
        $percent = 100;
    }

    $payload = array(
        'token'     => $job['token'],
        'type'      => $job['type'],
        'status'    => $job['status'],
        'processed' => $processed,
        'total'     => $total,
        'percent'   => $percent,
        'message'   => isset($job['message']) ? $job['message'] : '',
        'done'      => ($job['status'] === 'done'),
        'file_size' => isset($job['file_size']) ? (int) $job['file_size'] : 0,
        'file_name' => isset($job['download_name']) ? $job['download_name'] : '',
        'sha256'    => isset($job['sha256']) ? $job['sha256'] : '',
        'stats'     => isset($job['stats']) ? $job['stats'] : array(),
        'warn'      => isset($job['warn']) ? (string) $job['warn'] : '',
        'errors'    => isset($job['errors']) ? array_slice((array) $job['errors'], 0, 20) : array(),
    );
    if (!empty($payload['done']) && $job['type'] === 'export') {
        $payload['download_url'] = zibll_child_users_download_url($job['token']);
    }
    return $payload;
}

/** 带 nonce 的下载地址（不直接暴露文件路径） */
function zibll_child_users_download_url($token)
{
    return add_query_arg(
        array(
            'action'   => 'zibll_child_users_download',
            'token'    => rawurlencode($token),
            '_wpnonce' => wp_create_nonce(ZIBLL_CHILD_USERS_NONCE),
        ),
        admin_url('admin-post.php')
    );
}

/** 导出：开始 —— 建文件、写头部，返回总量 */
function zibll_child_ajax_users_export_start()
{
    zibll_child_users_ajax_guard();

    $guard = zibll_child_users_guard();
    if ($guard !== true) {
        wp_send_json_error($guard);
    }

    $dir = zibll_child_users_dir();
    if ($dir === '') {
        wp_send_json_error('无法创建导出目录（uploads 不可写），请检查目录权限。');
    }

    $batch   = isset($_POST['batch']) ? (int) $_POST['batch'] : 300;
    $batch   = max(20, min(2000, $batch));
    $role    = isset($_POST['role']) ? sanitize_key(wp_unslash($_POST['role'])) : '';
    $meta    = !isset($_POST['meta']) || $_POST['meta'] === '1';
    $pass    = isset($_POST['pass']) && $_POST['pass'] === '1';
    $gzip    = isset($_POST['gzip']) && $_POST['gzip'] === '1' && function_exists('gzopen');

    $params = array(
        'batch' => $batch,
        'role'  => $role,
        'meta'  => $meta,
        'pass'  => $pass,
        'gzip'  => $gzip,
    );

    $total = zibll_child_users_count_scope($params);
    if ($total <= 0) {
        wp_send_json_error('当前范围内没有可导出的用户。');
    }

    $token    = gmdate('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 8);
    $filename = 'zibll-child-users-' . $token . '.jsonl' . ($gzip ? '.gz' : '');
    $path     = trailingslashit($dir) . 'export-' . $token . '.jsonl' . ($gzip ? '.gz' : '');

    if (file_exists($path)) {
        @unlink($path);
    }

    $writer = zibll_child_users_writer_open($path, $gzip);
    if (!$writer) {
        wp_send_json_error('无法写入导出文件，请检查目录权限。');
    }
    zibll_child_users_writer_write($writer, zibll_child_users_encode_line(zibll_child_users_header($params, $total)));
    zibll_child_users_writer_close($writer);

    $job = array(
        'type'          => 'export',
        'status'        => 'running',
        'token'         => $token,
        'file'          => $path,
        'download_name' => $filename,
        'gzip'          => $gzip,
        'cursor'        => 0,       // 已写入的最大用户 ID
        'total'         => $total,
        'processed'     => 0,
        'params'        => $params,
        'stats'         => array('created' => 0, 'updated' => 0, 'skipped' => 0, 'failed' => 0, 'protected' => 0),
        'errors'        => array(),
        'created'       => time(),
        'message'       => '正在导出…共 ' . $total . ' 个用户。',
    );
    zibll_child_users_job_set($job);

    wp_send_json_success(zibll_child_users_progress($job));
}
add_action('wp_ajax_zibll_child_users_export_start', 'zibll_child_ajax_users_export_start');

/** 导出：单步 —— 处理一批并追加落盘；本批已到队尾则直接收尾 */
function zibll_child_ajax_users_export_step()
{
    zibll_child_users_ajax_guard();

    $job = zibll_child_users_job_get();
    if (!$job || $job['type'] !== 'export') {
        wp_send_json_error('未找到导出任务，请重新开始。');
    }
    if ($job['status'] === 'done') {
        wp_send_json_success(zibll_child_users_progress($job));
    }
    if (!empty($_POST['token']) && sanitize_text_field(wp_unslash($_POST['token'])) !== $job['token']) {
        wp_send_json_error('任务令牌不匹配，请刷新页面后重试。');
    }

    $run_id = isset($_POST['run_id']) ? sanitize_text_field(wp_unslash($_POST['run_id'])) : '';
    $lock   = zibll_child_users_step_run_guard($job, $run_id);
    if ($lock !== true) {
        wp_send_json_error($lock);
    }

    $batch = (int) $job['params']['batch'];
    $ids   = zibll_child_users_query_ids($job['cursor'], $batch, $job['params']);

    if (empty($ids)) {
        wp_send_json_success(zibll_child_users_finish_export($job));
    }

    $records = zibll_child_users_fetch_batch(
        $ids,
        !empty($job['params']['meta']),
        !empty($job['params']['pass'])
    );

    $writer = zibll_child_users_writer_open($job['file'], !empty($job['gzip']));
    if (!$writer) {
        $job['status']  = 'error';
        $job['message'] = '写入导出文件失败，任务已中止。';
        zibll_child_users_job_set($job);
        wp_send_json_error($job['message']);
    }

    $written = 0;
    foreach ($records as $rec) {
        $line = zibll_child_users_encode_line($rec);
        if ($line === '') {
            $job['stats']['failed']++;
            if (count($job['errors']) < ZIBLL_CHILD_USERS_MAX_ERRORS) {
                $job['errors'][] = '#' . $rec['id'] . ' 记录编码失败，已跳过。';
            }
            continue;
        }
        zibll_child_users_writer_write($writer, $line);
        $written++;
    }
    zibll_child_users_writer_close($writer);

    $job['cursor']    = (int) end($ids);
    $job['processed'] = (int) $job['processed'] + count($ids);
    $job['message']   = '正在导出…';

    // 本批不满 → 已到队尾（或刚好取完），直接收尾，省一次空请求
    if (count($ids) < $batch) {
        wp_send_json_success(zibll_child_users_finish_export($job));
    }

    zibll_child_users_job_set($job);
    wp_send_json_success(zibll_child_users_progress($job));
}
add_action('wp_ajax_zibll_child_users_export_step', 'zibll_child_ajax_users_export_step');

/** 导出：收尾 —— 记录体积与校验和，落定为可下载 */
function zibll_child_users_finish_export($job)
{
    $job['status'] = 'done';
    $file          = $job['file'];

    if (!is_readable($file)) {
        $job['status']  = 'error';
        $job['message'] = '导出文件已丢失，请重新执行导出。';
        zibll_child_users_job_set($job);
        return zibll_child_users_progress($job);
    }

    $job['file_size'] = (int) filesize($file);
    $job['sha256']    = (string) @hash_file('sha256', $file);
    $job['message']   = '导出完成：' . (int) $job['processed'] . ' 个用户，'
        . size_format($job['file_size'], 2) . '。';
    zibll_child_users_job_set($job);

    return zibll_child_users_progress($job);
}

/* ══════════════════════════════════════════════════════════════
 * 六、AJAX：导入
 * ══════════════════════════════════════════════════════════════ */

/** 导入：开始 —— 接收文件（上传或服务器路径）、校验头部、建立断点 */
function zibll_child_ajax_users_import_start()
{
    zibll_child_users_ajax_guard();

    // 导入期间对外置一个标记常量：供本子主题其它模块（如 QQ 头像自动同步）
    // 在批量导入这种「非真人操作」场景下做差异化处理。
    if (!defined('ZIBLL_CHILD_USERS_IMPORTING')) {
        define('ZIBLL_CHILD_USERS_IMPORTING', true);
    }

    $guard = zibll_child_users_guard();
    if ($guard !== true) {
        wp_send_json_error($guard);
    }

    $dir = zibll_child_users_dir();
    if ($dir === '') {
        wp_send_json_error('无法创建导入目录（uploads 不可写），请检查目录权限。');
    }

    $token  = gmdate('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 8);
    $source = '';
    $detach = false; // 该文件是否为本任务自己产生的临时副本（可安全删除）

    // ① 服务器路径（适合超过 upload_max_filesize 的超大文件）
    $server_path = isset($_POST['server_path']) ? trim(wp_unslash($_POST['server_path'])) : '';
    if ($server_path !== '') {
        $real = realpath($server_path);
        if ($real === false || !is_readable($real) || !is_file($real)) {
            wp_send_json_error('服务器文件不存在或不可读：' . $server_path);
        }
        $ext = strtolower(pathinfo($real, PATHINFO_EXTENSION));
        if (!in_array($ext, array('jsonl', 'json', 'gz', 'txt', 'ndjson'), true)) {
            wp_send_json_error('服务器文件扩展名不被支持（仅 jsonl/json/ndjson/txt/gz）。');
        }
        $source = $real;
    } else {
        // ② 浏览器上传
        if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
            wp_send_json_error('请选择要导入的文件，或填写服务器上的文件路径。');
        }
        $file = $_FILES['file'];
        if (!empty($file['error'])) {
            wp_send_json_error('文件上传失败（错误码 ' . (int) $file['error'] . '）。若文件超过服务器 upload_max_filesize，请改用「服务器文件路径」方式。');
        }
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            wp_send_json_error('上传文件校验失败，请重试。');
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, array('jsonl', 'json', 'gz', 'txt', 'ndjson'), true)) {
            wp_send_json_error('不支持的文件类型，请上传导出的 .jsonl 或 .jsonl.gz 文件。');
        }

        $dest = trailingslashit($dir) . 'import-' . $token . '.' . ($ext === 'gz' ? 'jsonl.gz' : 'jsonl');
        if (!@move_uploaded_file($file['tmp_name'], $dest)) {
            wp_send_json_error('无法保存上传文件到导入目录，请检查目录权限。');
        }
        $source = $dest;
        $detach = true;
    }

    $display_name = basename($source);

    // ── gzip 统一先解压成纯文本 ──────────────────────────────────
    // 之后的每一步续读都只面对纯文本文件（fseek 定位精确、O(1)），
    // 彻底规避「在压缩流上随机定位」的语义差异与性能陷阱。
    $work          = $source;
    $cleanup_files = array();
    if (zibll_child_users_is_gzip($source)) {
        $plain = trailingslashit($dir) . 'import-' . $token . '.jsonl';
        if (!zibll_child_users_decompress_to($source, $plain)) {
            if ($detach) {
                @unlink($source);
            }
            wp_send_json_error('解压失败：文件不是有效的 gzip，或服务器未启用 zlib 扩展。');
        }
        if ($detach) {
            @unlink($source); // 上传的 .gz 用完即删，只保留解压结果
        }
        $work            = $plain;
        $cleanup_files[] = $plain;
    } elseif ($detach) {
        $cleanup_files[] = $source; // 上传的纯文本副本
    }
    // 服务器路径 + 纯文本：不登记任何清理项，绝不删用户自己的文件

    // 读头部并校验格式，防止把不相干的文件导入进来
    $reader = zibll_child_users_reader_open($work);
    if (!$reader) {
        wp_send_json_error('无法读取该文件，请确认文件完整。');
    }
    $first = zibll_child_users_reader_line($reader);
    $head  = zibll_child_users_decode_line($first);
    if (!is_array($head) || empty($head['_meta']['format']) || $head['_meta']['format'] !== ZIBLL_CHILD_USERS_FORMAT) {
        zibll_child_users_reader_close($reader);
        foreach ($cleanup_files as $f) {
            @unlink($f);
        }
        wp_send_json_error('文件格式不符：不是本子主题导出的用户数据文件（缺少 ' . ZIBLL_CHILD_USERS_FORMAT . ' 标记）。');
    }
    $cursor = (int) zibll_child_users_reader_tell($reader);
    zibll_child_users_reader_close($reader);

    $lines = zibll_child_users_count_lines($work);
    $total = ($lines > 0) ? max(0, $lines - 1) : 0; // 减去头部行；-1 表示过大未统计

    // 免费的一致性校验：头部声明了多少个用户，实际就有多少条记录？
    // 不一致通常意味着文件被截断、传输损坏，或（若用了 gzip）解压不完整 —— 提前告知，避免"静默少导"。
    $declared = isset($head['_meta']['total_users']) ? (int) $head['_meta']['total_users'] : 0;
    $warn     = '';
    if ($declared > 0 && $total > 0 && $declared !== $total) {
        $warn = '注意：文件头部声明 ' . $declared . ' 个用户，实际读取到 ' . $total
            . ' 条记录，文件可能不完整或已被截断，请核对后再决定是否继续。';
    }

    $batch  = isset($_POST['batch']) ? (int) $_POST['batch'] : 200;
    $batch  = max(20, min(2000, $batch));
    $policy = isset($_POST['policy']) ? sanitize_key(wp_unslash($_POST['policy'])) : 'update_keep_pass';
    if (!array_key_exists($policy, zibll_child_users_import_policies())) {
        $policy = 'update_keep_pass';
    }

    $params = array(
        'batch'        => $batch,
        'policy'       => $policy,
        'meta'         => !isset($_POST['meta']) || $_POST['meta'] === '1',
        'purge'        => isset($_POST['purge']) && $_POST['purge'] === '1',
        'protect_self' => !isset($_POST['protect_self']) || $_POST['protect_self'] === '1',
    );

    // 导入前顺手留一份「当前设置」快照（复用已有的设置备份模块），便于察觉误操作
    if (function_exists('zibll_child_settings_backup')) {
        zibll_child_settings_backup('导入用户数据前自动备份');
    }

    $job = array(
        'type'          => 'import',
        'status'        => 'running',
        'token'         => $token,
        'file'          => $work,
        'download_name' => $display_name,
        'cleanup_files' => $cleanup_files, // 任务结束后需要删除的临时文件
        'cursor'        => $cursor,        // 纯文本字节偏移（头部行之后）
        'total'         => $total,
        'processed'     => 0,
        'params'        => $params,
        'stats'         => array('created' => 0, 'updated' => 0, 'skipped' => 0, 'failed' => 0, 'protected' => 0),
        'errors'        => array(),
        'created'       => time(),
        'message'       => ($warn !== '' ? $warn : ($total > 0 ? ('共有 ' . $total . ' 条用户记录待导入。') : '正在导入…')),
        'warn'          => $warn,
        'header'        => isset($head['_meta']) ? $head['_meta'] : array(),
    );
    zibll_child_users_job_set($job);

    wp_send_json_success(zibll_child_users_progress($job));
}
add_action('wp_ajax_zibll_child_users_import_start', 'zibll_child_ajax_users_import_start');

/** 导入：单步 —— 从断点续读一批并逐条写回 */
function zibll_child_ajax_users_import_step()
{
    zibll_child_users_ajax_guard();

    if (!defined('ZIBLL_CHILD_USERS_IMPORTING')) {
        define('ZIBLL_CHILD_USERS_IMPORTING', true);
    }

    $job = zibll_child_users_job_get();
    if (!$job || $job['type'] !== 'import') {
        wp_send_json_error('未找到导入任务，请重新开始。');
    }
    if ($job['status'] === 'done') {
        wp_send_json_success(zibll_child_users_progress($job));
    }
    if (!empty($_POST['token']) && sanitize_text_field(wp_unslash($_POST['token'])) !== $job['token']) {
        wp_send_json_error('任务令牌不匹配，请刷新页面后重试。');
    }

    $run_id = isset($_POST['run_id']) ? sanitize_text_field(wp_unslash($_POST['run_id'])) : '';
    $lock   = zibll_child_users_step_run_guard($job, $run_id);
    if ($lock !== true) {
        wp_send_json_error($lock);
    }

    $reader = zibll_child_users_reader_open($job['file']);
    if (!$reader) {
        $job['status']  = 'error';
        $job['message'] = '导入文件不可读，任务已中止。';
        zibll_child_users_job_set($job);
        wp_send_json_error($job['message']);
    }
    zibll_child_users_reader_seek($reader, $job['cursor']);

    $batch   = (int) $job['params']['batch'];
    $cursor  = (int) $job['cursor'];
    $handled = 0;
    $eof     = false;

    for ($i = 0; $i < $batch; $i++) {
        $line = zibll_child_users_reader_line($reader);
        if ($line === false || $line === '') {
            $eof = true;
            break;
        }
        // 先推进游标再处理：即使本条处理失败，下次也从下一行继续，不会卡死在同一行
        $cursor = (int) zibll_child_users_reader_tell($reader);

        if (trim($line) === '') {
            $handled++; // 空行静默跳过，不计入失败
            continue;
        }

        $rec = zibll_child_users_decode_line($line);
        if ($rec === null) {
            $job['stats']['failed']++;
            if (count($job['errors']) < ZIBLL_CHILD_USERS_MAX_ERRORS) {
                $job['errors'][] = '第 ' . ((int) $job['processed'] + $handled + 1) . ' 行无法解析，已跳过。';
            }
            $handled++;
            continue;
        }

        zibll_child_users_import_one($rec, $job['params'], $job['stats'], $job['errors']);
        $handled++;
    }

    zibll_child_users_reader_close($reader);

    $job['cursor']    = $cursor;
    $job['processed'] = (int) $job['processed'] + $handled;

    if ($eof || $handled < $batch) {
        wp_send_json_success(zibll_child_users_finish_import($job));
    }

    $job['message'] = '正在导入…';
    zibll_child_users_job_set($job);
    wp_send_json_success(zibll_child_users_progress($job));
}
add_action('wp_ajax_zibll_child_users_import_step', 'zibll_child_ajax_users_import_step');

/** 删除作业登记在案的临时文件（导入的上传副本 / 解压结果） */
function zibll_child_users_job_cleanup_files($job)
{
    if (empty($job['cleanup_files']) || !is_array($job['cleanup_files'])) {
        return;
    }
    foreach ($job['cleanup_files'] as $f) {
        if (is_string($f) && $f !== '' && is_file($f)) {
            @unlink($f);
        }
    }
}

/** 导入：收尾 —— 汇总结果，清理临时文件 */
function zibll_child_users_finish_import($job)
{
    $s = $job['stats'];
    $job['status']  = 'done';
    $job['message'] = sprintf(
        '导入完成：新增 %d，更新 %d，跳过 %d，失败 %d。',
        (int) $s['created'],
        (int) $s['updated'],
        (int) $s['skipped'],
        (int) $s['failed']
    );
    if (!empty($s['protected'])) {
        $job['message'] .= '（已保护当前管理员账号，未覆盖其密码/角色）';
    }
    if (!empty($job['warn'])) {
        $job['message'] = $job['warn'] . ' ' . $job['message'];
    }

    // 临时文件（上传副本 / 解压结果）用完即删；用户自己的服务器文件从不登记、不会被删
    zibll_child_users_job_cleanup_files($job);
    $job['cleanup_files'] = array();

    zibll_child_users_job_set($job);
    return zibll_child_users_progress($job);
}

/* ══════════════════════════════════════════════════════════════
 * 七、AJAX：任务控制与文件管理
 * ══════════════════════════════════════════════════════════════ */

/**
 * 终止任务 / 清除任务记录。
 * 注意：已完成的「导出」任务记录必须保留 —— 下载入口靠它定位文件；
 * 清除它等于让刚导出的文件无法下载。要释放磁盘空间请用「清理导出目录」。
 */
function zibll_child_ajax_users_job_reset()
{
    zibll_child_users_ajax_guard();

    $job = zibll_child_users_job_get();

    if ($job && $job['type'] === 'import') {
        zibll_child_users_job_cleanup_files($job); // 未完成导入的临时文件顺手删掉
    }

    if ($job && $job['type'] === 'export' && $job['status'] === 'done' && !empty($job['file']) && is_file($job['file'])) {
        wp_send_json_success(array(
            'msg'  => '导出文件仍可下载，任务记录已保留。若要释放磁盘空间，请使用「清理导出目录」。',
            'html' => zibll_child_users_panel_html(true),
        ));
    }

    zibll_child_users_job_clear();

    wp_send_json_success(array('msg' => '任务已终止并重置。', 'html' => zibll_child_users_panel_html(true)));
}
add_action('wp_ajax_zibll_child_users_job_reset', 'zibll_child_ajax_users_job_reset');

/** 清理导出目录：删除目录下全部文件，并同步清除指向它们的任务记录 */
function zibll_child_ajax_users_clean_files()
{
    zibll_child_users_ajax_guard();

    $dir = zibll_child_users_dir();
    if ($dir === '') {
        wp_send_json_error('导出目录不可用。');
    }

    // 任何任务在跑都不能清理：正在追加写入的导出文件被删掉会导致前序数据丢失
    $job = zibll_child_users_job_get();
    if ($job && $job['status'] === 'running') {
        wp_send_json_error('当前有任务正在运行，请先终止任务再清理。');
    }

    $deleted = 0;
    $freed   = 0;
    $items   = @scandir($dir);
    if (is_array($items)) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item === 'index.php' || $item === '.htaccess') {
                continue;
            }
            $path = $dir . '/' . $item;
            if (!is_file($path)) {
                continue;
            }
            $freed += (int) filesize($path);
            if (@unlink($path)) {
                $deleted++;
            }
        }
    }

    // 文件已全部删除，指向文件的下载入口自然失效 → 一并清掉任务记录
    zibll_child_users_job_clear();

    wp_send_json_success(array(
        'msg'  => '已清理 ' . $deleted . ' 个文件，释放 ' . size_format($freed, 2) . '。',
        'html' => zibll_child_users_panel_html(true),
    ));
}
add_action('wp_ajax_zibll_child_users_clean_files', 'zibll_child_ajax_users_clean_files');

/** 刷新面板（任务状态变化后局部更新，不整页刷新） */
function zibll_child_ajax_users_refresh_panel()
{
    zibll_child_users_ajax_guard();
    // 调用频率很低（任务结束 / 手动点击），这里强制重算统计，保证用户看到的数字是新的
    wp_send_json_success(array('html' => zibll_child_users_panel_html(true)));
}
add_action('wp_ajax_zibll_child_users_refresh_panel', 'zibll_child_ajax_users_refresh_panel');

/* ── 下载端点（admin-post）：带鉴权、流式输出，不暴露文件路径 ── */
function zibll_child_users_handle_download()
{
    check_admin_referer(ZIBLL_CHILD_USERS_NONCE);
    if (!current_user_can('manage_options')) {
        wp_die('无权限');
    }

    $token = isset($_GET['token']) ? sanitize_text_field(wp_unslash($_GET['token'])) : '';
    $job   = zibll_child_users_job_get();
    if (!$job || $token === '' || $job['token'] !== $token || $job['type'] !== 'export' || $job['status'] !== 'done') {
        wp_die('导出文件不存在或任务已失效。');
    }
    if (empty($job['file']) || !is_readable($job['file'])) {
        wp_die('导出文件已丢失，请重新执行导出。');
    }

    $size = (int) filesize($job['file']);
    nocache_headers();
    if (function_exists('wp_raise_memory_limit')) {
        wp_raise_memory_limit('admin');
    }
    if (function_exists('set_time_limit')) {
        @set_time_limit(0);
    }

    // 清空所有输出缓冲：否则 Content-Length 与实际输出量不符，大文件下载会被截断
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }

    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $job['download_name'] . '"');
    header('Content-Length: ' . $size);
    header('X-Content-Type-Options: nosniff');

    // 分块输出，避免一次性把大文件读进内存
    $handle = fopen($job['file'], 'rb');
    if (!$handle) {
        wp_die('读取导出文件失败。');
    }
    while (!feof($handle)) {
        echo fread($handle, 1048576); // 1MB/块
        if (function_exists('flush')) {
            @flush();
        }
    }
    fclose($handle);
    exit;
}
add_action('admin_post_zibll_child_users_download', 'zibll_child_users_handle_download');

/* ══════════════════════════════════════════════════════════════
 * 八、后台面板 HTML
 * ══════════════════════════════════════════════════════════════ */

/** 扫描导出目录：文件数量 / 占用空间 / 最新一个文件名与时间（只读，不创建目录） */
function zibll_child_users_scan_files()
{
    $dir = zibll_child_users_dir(false);
    if ($dir === '') {
        return array('count' => 0, 'size' => 0, 'latest' => '');
    }
    $count = 0;
    $size  = 0;
    $latest_time = 0;
    $latest_name = '';
    $items = @scandir($dir);
    if (is_array($items)) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item === 'index.php' || $item === '.htaccess') {
                continue;
            }
            $path = $dir . '/' . $item;
            if (!is_file($path)) {
                continue;
            }
            $count++;
            $size += (int) filesize($path);
            $t = (int) filemtime($path);
            if ($t > $latest_time) {
                $latest_time = $t;
                $latest_name = $item;
            }
        }
    }
    return array(
        'count'  => $count,
        'size'   => $size,
        'latest' => $latest_time ? (date_i18n('Y-m-d H:i:s', $latest_time) . ' · ' . $latest_name) : '',
    );
}

/**
 * 站点用户规模统计（总数 + 各角色人数）。
 *
 * ⚠️ 为什么要缓存：theme-options.php 里 CSF 的 content 字段是【即时求值】的
 * （`'content' => zibll_child_users_panel_html()` 在每次后台请求注册面板时就会执行），
 * 而 count_users() 会对 usermeta 做 GROUP BY 全表扫描 —— 万级用户的站点
 * 每次打开后台都要付这笔开销。这里用 10 分钟 transient 兜住，点「刷新统计」强制重算。
 */
function zibll_child_users_site_stats($force = false)
{
    if (!$force) {
        $cached = get_transient('zibll_child_users_stats');
        if (is_array($cached)) {
            return $cached;
        }
    }
    $counts = function_exists('count_users') ? count_users() : array();
    if (!is_array($counts) || !isset($counts['total_users'])) {
        $counts = array('total_users' => 0, 'avail_roles' => array());
    }
    set_transient('zibll_child_users_stats', $counts, 10 * MINUTE_IN_SECONDS);
    return $counts;
}

/**
 * 「用户数据」面板 HTML（由 theme-options.php 的 userdata 分区 content 字段承载）。
 *
 * @param bool $force_coverage 是否强制刷新统计（用户规模 + 父主题扩展字段覆盖率）
 */
if (!function_exists('zibll_child_users_panel_html')) {
    function zibll_child_users_panel_html($force_coverage = false)
    {
        if (!current_user_can('manage_options')) {
            return '<p>无权限查看用户数据管理。</p>';
        }

        $nonce  = wp_create_nonce(ZIBLL_CHILD_USERS_NONCE);
        $job    = zibll_child_users_job_get();
        $files  = zibll_child_users_scan_files();
        $cover  = zibll_child_users_zib_coverage($force_coverage);

        // ── 站点用户规模（带缓存，见 zibll_child_users_site_stats 注释） ──
        $counts = zibll_child_users_site_stats($force_coverage);
        $roles  = array();
        if (function_exists('wp_roles')) {
            $roles = wp_roles()->get_names();
        }

        $role_options = '<option value="">全部用户</option>';
        if (!empty($counts['avail_roles']) && is_array($counts['avail_roles'])) {
            foreach ($counts['avail_roles'] as $role_key => $role_num) {
                if ($role_key === 'none') {
                    continue;
                }
                $label = isset($roles[$role_key]) ? translate_user_role($roles[$role_key]) : $role_key;
                $role_options .= '<option value="' . esc_attr($role_key) . '">'
                    . esc_html($label . '（' . (int) $role_num . '）') . '</option>';
            }
        }

        // ── 父主题扩展字段覆盖率（前 12 项） ──
        $cover_rows = '';
        if (!empty($cover['keys'])) {
            $i = 0;
            foreach ($cover['keys'] as $key => $info) {
                if ($i++ >= 12) {
                    break;
                }
                $cover_rows .= '<div class="zdu-kv"><code>' . esc_html($key) . '</code>'
                    . '<span>' . (int) $info['users'] . ' 人 / ' . (int) $info['rows'] . ' 行</span></div>';
            }
            $more = count($cover['keys']) - 12;
            if ($more > 0) {
                $cover_rows .= '<div class="zdu-kv zdu-hint"><span>另有 ' . (int) $more . ' 个字段未在此列出</span></div>';
            }
        } else {
            $cover_rows = '<p class="zdu-hint">暂未检测到父主题（zibll）的用户附加功能数据。</p>';
        }

        // ── 任务状态卡 ──
        $job_html = '';
        if ($job) {
            $p = zibll_child_users_progress($job);
            $status_label = array(
                'running'   => '进行中',
                'done'      => '已完成',
                'error'     => '已中断',
                'cancelled' => '已终止',
            );
            $label = isset($status_label[$job['status']]) ? $status_label[$job['status']] : $job['status'];

            $job_html .= '<div class="zdu-job">';
            $job_html .= '<div class="zdu-kv"><span>当前任务</span><strong>'
                . esc_html(($job['type'] === 'export' ? '导出' : '导入') . ' · ' . $label) . '</strong></div>';
            $job_html .= '<div class="zdu-kv"><span>进度</span><span>' . (int) $p['processed'] . ' / '
                . ($p['total'] > 0 ? (int) $p['total'] : '?') . '（' . (int) $p['percent'] . '%）</span></div>';
            if (!empty($p['message'])) {
                $job_html .= '<div class="zdu-kv"><span>状态</span><span>' . esc_html($p['message']) . '</span></div>';
            }
            if (!empty($job['warn'])) {
                $job_html .= '<div class="zdu-warnbox">' . esc_html($job['warn']) . '</div>';
            }
            if ($job['type'] === 'export' && !empty($p['sha256'])) {
                $job_html .= '<div class="zdu-kv"><span>文件校验</span><span class="zdu-hint">SHA-256 '
                    . esc_html(substr($p['sha256'], 0, 16)) . '…（' . size_format($p['file_size'], 2) . '）</span></div>';
            }
            if (!empty($p['errors'])) {
                $job_html .= '<div class="zdu-log"><strong>异常摘要</strong><ul>';
                foreach ($p['errors'] as $err) {
                    $job_html .= '<li>' . esc_html($err) . '</li>';
                }
                $job_html .= '</ul></div>';
            }
            $job_html .= '<div class="zdu-actions">';
            if ($job['status'] === 'running') {
                $job_html .= '<button type="button" class="button zdu-job-reset" data-nonce="' . esc_attr($nonce) . '">终止任务</button>';
            } else {
                $job_html .= '<button type="button" class="button zdu-job-reset" data-nonce="' . esc_attr($nonce) . '">清除任务记录</button>';
            }
            if ($job['type'] === 'export' && $job['status'] === 'done') {
                $job_html .= ' <a class="button button-primary" href="'
                    . esc_url(zibll_child_users_download_url($job['token'])) . '">下载导出文件</a>';
            }
            $job_html .= '</div></div>';
        } else {
            $job_html = '<p class="zdu-hint">当前没有进行中的任务。</p>';
        }

        ob_start();
        ?>
<div class="zdu-wrap" id="zdu-panel"
     data-nonce="<?php echo esc_attr($nonce); ?>"
     data-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">

    <div class="zdu-block">
        <h4 class="zdu-title"><i class="fa fa-fw fa-users"></i> 站点用户规模</h4>
        <div class="zdu-kv"><span>用户总数</span><strong><?php echo (int) $counts['total_users']; ?> 个</strong></div>
        <div class="zdu-kv"><span>父主题附加功能数据</span><strong><?php echo (int) $cover['total']; ?> 行</strong>
            <span class="zdu-hint">（zibll 存在 usermeta 的积分/余额/VIP/签到/勋章/收藏/关注等）</span></div>
        <div class="zdu-kv"><span>本地导出文件</span><span><?php
            echo (int) $files['count']; ?> 个 · <?php echo esc_html(size_format($files['size'], 2)); ?></span></div>
        <?php if ($files['latest'] !== '') : ?>
            <div class="zdu-kv"><span>最新文件</span><span class="zdu-hint"><?php echo esc_html($files['latest']); ?></span></div>
        <?php endif; ?>
        <div class="zdu-actions">
            <button type="button" class="button zdu-clean" data-nonce="<?php echo esc_attr($nonce); ?>">
                <i class="fa fa-fw fa-trash-o"></i> 清理导出目录（全部文件）</button>
            <button type="button" class="button zdu-refresh" data-nonce="<?php echo esc_attr($nonce); ?>">
                <i class="fa fa-fw fa-refresh"></i> 刷新统计</button>
        </div>
    </div>

    <div class="zdu-block">
        <h4 class="zdu-title"><i class="fa fa-fw fa-cloud-download"></i> 导出用户数据</h4>
        <p class="zdu-hint">
            导出为<b>单个 JSONL 文件</b>（一行一个用户，含父主题扩展数据）。采用分批处理，
            几千至几万个用户均可稳定完成，中途可关闭页面，回来继续。
        </p>
        <div class="zdu-grid">
            <label>导出范围
                <select id="zdu-role"><?php echo $role_options; // 已在上方转义 ?></select>
            </label>
            <label>每批用户数
                <input type="number" id="zdu-exp-batch" value="300" min="20" max="2000" step="20">
            </label>
        </div>
        <div class="zdu-checks">
            <label><input type="checkbox" id="zdu-meta" checked> 包含父主题附加功能数据（扩展字段全量）</label>
            <label><input type="checkbox" id="zdu-pass" checked> 包含密码哈希（用于整站还原；文件需妥善保管）</label>
            <label><input type="checkbox" id="zdu-gzip" <?php echo function_exists('gzopen') ? 'checked' : 'disabled'; ?>>
                压缩导出（gzip，可大幅减小体积）</label>
        </div>
        <div class="zdu-actions">
            <button type="button" class="button button-primary zdu-export-start" data-nonce="<?php echo esc_attr($nonce); ?>">
                <i class="fa fa-fw fa-play"></i> 开始导出</button>
        </div>
        <p class="zdu-warn">
            提示：勾选「密码哈希」后，导出文件等同于站点账号凭据，请勿放置在公开目录或通过不安全渠道传输。
            系统已将该文件存放于不可直连的受保护目录，仅能通过带鉴权的后台入口下载。
        </p>
    </div>

    <div class="zdu-block">
        <h4 class="zdu-title"><i class="fa fa-fw fa-cloud-upload"></i> 导入用户数据</h4>
        <p class="zdu-hint">
            选择此前导出的文件即可恢复。导入同样分批执行；遇到个别脏数据只记录不中止，保证长任务不被打断。
        </p>
        <div class="zdu-grid">
            <label>选择文件
                <input type="file" id="zdu-file" accept=".jsonl,.jsonl.gz,.json,.ndjson,.txt,.gz">
            </label>
            <label>或服务器文件路径
                <input type="text" id="zdu-server-path" placeholder="适合超过 upload_max_filesize 的大文件">
            </label>
        </div>
        <div class="zdu-grid">
            <label>导入策略
                <select id="zdu-policy">
                    <?php foreach (zibll_child_users_import_policies() as $k => $v) : ?>
                        <option value="<?php echo esc_attr($k); ?>"<?php echo $k === 'update_keep_pass' ? ' selected' : ''; ?>>
                            <?php echo esc_html($v); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label>每批用户数
                <input type="number" id="zdu-imp-batch" value="200" min="20" max="2000" step="20">
            </label>
        </div>
        <div class="zdu-checks">
            <label><input type="checkbox" id="zdu-imp-meta" checked> 导入父主题附加功能数据（扩展字段）</label>
            <label><input type="checkbox" id="zdu-protect" checked> 保护当前管理员（不覆盖自己的密码与角色）</label>
            <label><input type="checkbox" id="zdu-purge"> 完全还原：先清空目标用户已有的扩展数据</label>
        </div>
        <div class="zdu-actions">
            <button type="button" class="button button-primary zdu-import-start" data-nonce="<?php echo esc_attr($nonce); ?>">
                <i class="fa fa-fw fa-play"></i> 开始导入</button>
        </div>
    </div>

    <div class="zdu-block">
        <h4 class="zdu-title"><i class="fa fa-fw fa-tasks"></i> 任务状态</h4>
        <span id="zdu-job-meta" hidden
              data-token="<?php echo esc_attr($job ? $job['token'] : ''); ?>"
              data-type="<?php echo esc_attr($job ? $job['type'] : ''); ?>"
              data-status="<?php echo esc_attr($job ? $job['status'] : ''); ?>"></span>
        <div id="zdu-job"><?php echo $job_html; ?></div>
        <div class="zdu-live" id="zdu-live"></div>
        <div class="zdu-progress" id="zdu-progress"><span id="zdu-progress-bar"></span></div>
    </div>

    <div class="zdu-block">
        <h4 class="zdu-title"><i class="fa fa-fw fa-puzzle-piece"></i> 父主题附加功能数据覆盖情况</h4>
        <p class="zdu-hint">下列字段随用户一起导出/导入，恢复时按原始行 1:1 写回，不做二次序列化。</p>
        <div class="zdu-cover"><?php echo $cover_rows; ?></div>
    </div>

    <p class="zdu-foot">
        说明：本模块只处理 WordPress 用户表与本子主题导出的文件，不修改父主题设置、不影响其它插件数据。
        文件格式 zibll-child-users v<?php echo (int) ZIBLL_CHILD_USERS_FORMAT_VERSION; ?>。
    </p>
</div>
        <?php
        return ob_get_clean();
    }
}

/* ══════════════════════════════════════════════════════════════
 * 九、面板专属样式与脚本（仅 page=zibll_child_options 时注入）
 * ══════════════════════════════════════════════════════════════ */

add_action('admin_head', 'zibll_child_users_admin_assets');
function zibll_child_users_admin_assets()
{
    if (empty($_GET['page']) || $_GET['page'] !== 'zibll_child_options') {
        return;
    }
    echo '<style id="zibll-child-users-css">
.zdu-wrap{font-size:13px;color:#23282d;}
.zdu-block{border:1px solid #e2e4e7;border-radius:4px;padding:14px 16px;margin-bottom:14px;background:#fff;}
.zdu-title{margin:0 0 10px;font-size:13px;color:#23282d;display:flex;align-items:center;gap:6px;}
.zdu-title .fa{color:#2271b1;}
.zdu-kv{display:flex;align-items:baseline;gap:10px;padding:6px 0;border-bottom:1px dashed #f0f0f1;flex-wrap:wrap;}
.zdu-kv:last-of-type{border-bottom:none;}
.zdu-kv>span:first-child{color:#646970;min-width:140px;}
.zdu-hint{color:#8c8f94;font-size:12px;line-height:1.7;}
.zdu-warn{color:#b32d2e;font-size:12px;line-height:1.7;margin:8px 0 0;}
.zdu-grid{display:flex;gap:14px;flex-wrap:wrap;margin:8px 0;}
.zdu-grid label{display:flex;flex-direction:column;gap:4px;color:#646970;font-size:12px;min-width:220px;flex:1;}
.zdu-grid input[type=number],.zdu-grid input[type=text],.zdu-grid select{width:100%;max-width:340px;}
.zdu-checks{display:flex;flex-wrap:wrap;gap:6px 20px;margin:8px 0 2px;color:#3c434a;}
.zdu-checks label{display:inline-flex;align-items:center;gap:6px;}
.zdu-actions{margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
.zdu-progress{height:10px;border-radius:6px;background:#f0f0f1;overflow:hidden;margin-top:12px;display:none;}
.zdu-progress.zdu-on{display:block;}
.zdu-progress>span{display:block;height:100%;width:0;background:#2271b1;transition:width .25s;}
/* 总量未知（文件过大未统计）时改为不定量动画，避免进度条永远停在 0 */
.zdu-progress.zdu-indet>span{width:35%;transition:none;animation:zdu-indet 1.2s ease-in-out infinite;}
@keyframes zdu-indet{0%{margin-left:-35%;}100%{margin-left:100%;}}
.zdu-live{margin-top:8px;font-size:12px;color:#3c434a;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.zdu-live:empty{display:none;}
.zdu-live .zdu-warn{margin:0;flex-basis:100%;}
.zdu-warnbox{margin-top:8px;background:#fff8e5;border:1px solid #f0d9a0;border-radius:4px;padding:8px 12px;color:#8a6116;font-size:12px;line-height:1.7;}
.zdu-job .zdu-log{margin-top:8px;background:#fff8f8;border:1px solid #f0c8c8;border-radius:4px;padding:8px 12px;color:#8a2424;font-size:12px;max-height:200px;overflow:auto;}
.zdu-job .zdu-log ul{margin:6px 0 0;padding-left:18px;list-style:disc;}
.zdu-job .zdu-log li{margin:2px 0;}
.zdu-cover{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:4px 16px;}
.zdu-cover .zdu-kv{border-bottom:none;padding:3px 0;}
.zdu-cover .zdu-kv>span:first-child{min-width:0;}
.zdu-cover code{background:#f0f0f1;padding:1px 6px;border-radius:3px;font-size:11px;}
.zdu-foot{color:#8c8f94;font-size:12px;line-height:1.7;}
.zdu-busy{opacity:.5;pointer-events:none;}
</style>';
}

add_action('admin_footer', 'zibll_child_users_admin_js');
function zibll_child_users_admin_js()
{
    if (empty($_GET['page']) || $_GET['page'] !== 'zibll_child_options') {
        return;
    }
    ?>
<script id="zibll-child-users-js">
(function ($) {
    var $panel = $('#zdu-panel');
    if (!$panel.length) { return; }

    var AJAX = $panel.data('ajax');
    var running = false;

    /* 本次页面会话标识：同一个人开两个标签页时，服务端据此拒绝并发驱动同一任务 */
    function newRunId() {
        return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    function bar(on, percent, indet) {
        var $p = $('#zdu-progress');
        if (on) { $p.addClass('zdu-on'); } else { $p.removeClass('zdu-on'); }
        if (indet) {
            $p.addClass('zdu-indet');
            return;
        }
        $p.removeClass('zdu-indet');
        $('#zdu-progress-bar').css('width', Math.max(0, Math.min(100, percent || 0)) + '%');
    }

    function say(msg) {
        $('#zdu-live').html('<span>' + $('<div>').text(msg).html() + '</span>');
    }

    /* 单次请求 + 自动重试：网络抖动 / 网关超时都不至于让长任务断掉 */
    function post(data, attempt, cb) {
        attempt = attempt || 0;
        $.ajax({ url: AJAX, type: 'POST', data: data, dataType: 'json' })
            .done(function (res) {
                if (res && res.success) { cb(null, res.data); return; }
                cb((res && res.data) ? res.data : '请求被服务器拒绝', null);
            })
            .fail(function () {
                if (attempt < 3) {
                    setTimeout(function () { post(data, attempt + 1, cb); }, 1200 * (attempt + 1));
                } else {
                    cb('网络请求失败，已自动重试 3 次。任务进度已保存在服务器，可点击「刷新统计」后继续。', null);
                }
            });
    }

    function replacePanel(html) {
        var $new = $('<div>').html(html).find('#zdu-panel');
        if ($new.length) {
            $('#zdu-panel').replaceWith($new);
            $panel = $('#zdu-panel');
        }
    }

    function renderProgress(d) {
        say(d.message || '处理中…');
        if (d.warn) {
            $('#zdu-live').append($('<span class="zdu-warn">').text(d.warn));
        }
        var unknown = (!d.total && !d.done); // 总量未知（文件过大未统计）
        bar(true, d.percent || 0, unknown);
        if (d.done) {
            bar(true, 100, false);
            post({ action: 'zibll_child_users_refresh_panel', nonce: $panel.data('nonce') }, 0, function (err, data) {
                if (!err && data && data.html) { replacePanel(data.html); }
                running = false;
            });
        }
    }

    /* ── 作业循环：导出 / 导入共用一套驱动 ── */
    function runLoop(type, token, runId) {
        var action = (type === 'export') ? 'zibll_child_users_export_step' : 'zibll_child_users_import_step';
        post({ action: action, nonce: $panel.data('nonce'), token: token, run_id: runId }, 0, function (err, d) {
            if (err) {
                bar(false, 0, false);
                running = false;
                say((type === 'export' ? '导出' : '导入') + '已暂停：' + err);
                return;
            }
            renderProgress(d);
            if (!d.done) { setTimeout(function () { runLoop(type, token, runId); }, 40); }
        });
    }

    /* 若上一个导出任务已完成但文件还没下载，开新任务会覆盖它的下载入口 —— 先提醒 */
    function confirmDiscardPendingExport() {
        var $m = $('#zdu-job-meta');
        if ($m.length && $m.data('type') === 'export' && $m.data('status') === 'done') {
            return confirm('上一次导出的文件尚未下载，开始新任务会失去它的下载入口（文件可稍后用「清理导出目录」删除）。确认继续？');
        }
        return true;
    }

    $(document).on('click', '.zdu-export-start', function () {
        if (running) { return; }
        if (!$('#zdu-pass').is(':checked')) {
            if (!confirm('未勾选「包含密码哈希」：导入到新站点后用户将无法用原密码登录。确认继续导出吗？')) { return; }
        }
        if (!confirmDiscardPendingExport()) { return; }
        running = true;
        bar(true, 0, true);
        say('正在初始化导出任务…');
        post({
            action: 'zibll_child_users_export_start',
            nonce: $(this).data('nonce'),
            role: $('#zdu-role').val() || '',
            batch: $('#zdu-exp-batch').val() || 300,
            meta: $('#zdu-meta').is(':checked') ? '1' : '0',
            pass: $('#zdu-pass').is(':checked') ? '1' : '0',
            gzip: $('#zdu-gzip').is(':checked') ? '1' : '0'
        }, 0, function (err, d) {
            if (err) { running = false; bar(false, 0, false); say('无法开始导出：' + err); return; }
            renderProgress(d);
            runLoop('export', d.token, newRunId());
        });
    });

    $(document).on('click', '.zdu-import-start', function () {
        if (running) { return; }
        var hasFile = ($('#zdu-file').get(0).files || []).length > 0;
        var hasPath = ($('#zdu-server-path').val() || '').trim() !== '';
        if (!hasFile && !hasPath) { alert('请先选择要导入的文件，或填写服务器文件路径。'); return; }
        if (!confirm('导入会写入 / 更新现有用户数据，确认继续？')) { return; }
        if (!confirmDiscardPendingExport()) { return; }

        running = true;
        bar(true, 0, true);
        say('正在校验导入文件…');

        var fd = new FormData();
        fd.append('action', 'zibll_child_users_import_start');
        fd.append('nonce', $(this).data('nonce'));
        fd.append('policy', $('#zdu-policy').val());
        fd.append('batch', $('#zdu-imp-batch').val() || 200);
        fd.append('meta', $('#zdu-imp-meta').is(':checked') ? '1' : '0');
        fd.append('protect_self', $('#zdu-protect').is(':checked') ? '1' : '0');
        fd.append('purge', $('#zdu-purge').is(':checked') ? '1' : '0');
        if (hasFile) { fd.append('file', $('#zdu-file').get(0).files[0]); }
        if (hasPath) { fd.append('server_path', $('#zdu-server-path').val()); }

        $.ajax({ url: AJAX, type: 'POST', data: fd, processData: false, contentType: false, dataType: 'json' })
            .done(function (res) {
                if (!res || !res.success) {
                    running = false; bar(false, 0, false);
                    say('无法开始导入：' + ((res && res.data) ? res.data : '未知错误'));
                    return;
                }
                renderProgress(res.data);
                runLoop('import', res.data.token, newRunId());
            })
            .fail(function () {
                running = false; bar(false, 0, false);
                say('上传 / 初始化失败，请检查文件是否超过服务器 upload_max_filesize（可改用「服务器文件路径」）。');
            });
    });

    $(document).on('click', '.zdu-job-reset', function () {
        if (!confirm('确认终止 / 清除当前任务记录？（已完成的导出文件会保留在服务器上，需用「清理导出目录」删除）')) { return; }
        post({ action: 'zibll_child_users_job_reset', nonce: $(this).data('nonce') }, 0, function (err, d) {
            running = false; bar(false, 0, false); say('');
            if (err) { alert(err); return; }
            if (d.html) { replacePanel(d.html); }
            alert(d.msg || '已重置');
        });
    });

    $(document).on('click', '.zdu-clean', function () {
        if (!confirm('确认删除导出目录下的全部文件？刚导出的文件也会被删除，下载入口随之失效。')) { return; }
        post({ action: 'zibll_child_users_clean_files', nonce: $(this).data('nonce') }, 0, function (err, d) {
            if (err) { alert(err); return; }
            if (d.html) { replacePanel(d.html); }
            alert(d.msg || '已清理');
        });
    });

    $(document).on('click', '.zdu-refresh', function () {
        post({ action: 'zibll_child_users_refresh_panel', nonce: $(this).data('nonce') }, 0, function (err, d) {
            if (err) { alert(err); return; }
            if (d.html) { replacePanel(d.html); }
        });
    });

    /* ── 断点续跑：上次关掉浏览器后，任务仍停在服务器上，这里可直接接着跑 ── */
    var $meta = $('#zdu-job-meta');
    if ($meta.length && $meta.data('status') === 'running' && $meta.data('token')) {
        var $resume = $('<button type="button" class="button zdu-resume" style="margin-top:10px;">'
            + '<i class="fa fa-fw fa-repeat"></i> 继续未完成任务</button>');
        $('#zdu-job').append($resume);
        say('检测到上次未完成的任务，可点击「继续未完成任务」接着处理（从断点恢复，不会重复处理）。');
        $resume.on('click', function () {
            $(this).remove();
            running = true;
            bar(true, 0, true);
            runLoop($meta.data('type'), $meta.data('token'), newRunId());
        });
    }
})(jQuery);
</script>
    <?php
}
