<?php
/**
 * 子比子主题 - 谷歌登录头像国内可达（墙外反代改写）
 * ─────────────────────────────────────────────────────────────
 * 解决什么问题
 *   父主题处理 Google 登录时：
 *     · oauth/google/callback.php 取 $userInfo['picture']（lh3.googleusercontent.com 原链）
 *     · oauth/oauth.php 在用户未设头像时把该原链写入 custom_avatar（zib-theme.php:310-312）
 *   全站头像渲染走 zib_get_user_avatar_url() 直接读 custom_avatar，国内拉不到
 *   googleusercontent → 头像裂图。
 *
 * 本方案（零侵入父主题，复用 QQ 头像模块范式）
 *   把 custom_avatar 里的 googleusercontent 原链改写为【子主题自带的代理端点】，
 *   该端点（子主题根目录 avatar-proxy.php，随主题分发）运行在用户的服务器上，
 *   自身即墙外出口，可直连 Google 拉图后吐给国内用户（前面有 CDN/CF 缓存）。
 *   渲染层 zib_get_user_avatar_url() 会去协议（preg_replace '/^(https:|http:)/'）
 *   变成 //<站点域名>/.../avatar-proxy.php?u=...，国内走你自家域名 → 正常显示。
 *   开关：zibll_child_module_enabled('enable_google_avatar_proxy')，默认关闭
 *   （国内服务器部署一般用不到，香港 + Google 登录场景手动开启）。
 *
 * 自愈（v1.5.11+）
 *   · 除 Google 原链外，还识别「已被代理过」的地址（任意 …avatar-proxy…?u=<google> 形态，
 *     含 1.5.10 曾写下的 https://steam.hoarfall.com/avatar-proxy 死链），取出内层 Google
 *     原链后重指向当前端点——修历史遗留；结果幂等（与现值相同则不写库）。
 *
 * 安全边界
 *   · 只改「值是 Google 原链」或「内层是 Google 原链的旧代理地址」的 custom_avatar；
 *     其余（QQ 头像 / 用户主动上传）一律不动，避免覆盖。
 *   · 代理端点（avatar-proxy.php）侧做 URL 白名单（防变开放代理），本文件只负责改写。
 *
 * 开关：zibll_child_module_enabled('enable_google_avatar_proxy')（默认关闭）
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// 墙外反代地址：指向子主题自带的端点（子主题根目录 avatar-proxy.php）。
// 该端点随主题分发、运行在用户服务器（如香港墙外出口），可直连 Google 拉图，
// 无需任何外部 Worker / 独立域名。改路径只动这一处。
if (!defined('ZIBLL_CHILD_GOOGLE_AVATAR_PROXY')) {
    $zibll_child_proxy_url = function_exists('get_stylesheet_directory_uri')
        ? trailingslashit(get_stylesheet_directory_uri()) . 'avatar-proxy.php'
        : 'avatar-proxy.php';
    define('ZIBLL_CHILD_GOOGLE_AVATAR_PROXY', $zibll_child_proxy_url);
}

/**
 * 判断一个 URL 是否为 Google 头像（googleusercontent 系 / google.com 的 +ID 头像）。
 * @param string $url
 * @return bool
 */
if (!function_exists('zibll_child_is_google_avatar')) {
    function zibll_child_is_google_avatar($url)
    {
        if (empty($url) || !is_string($url)) {
            return false;
        }
        return (bool) preg_match('#^https?://(lh\d+\.)?googleusercontent\.com/#i', $url)
            || (bool) preg_match('#^https?://[\w.-]+\.googleusercontent\.com/#i', $url)
            || (bool) preg_match('#^https?://(?:[\w.-]+\.)?google\.com/\+#i', $url);
    }
}

/**
 * 从「已被代理过的头像地址」里取出内层 Google 原链（用于修历史遗留死链）。
 * 例：https://steam.hoarfall.com/avatar-proxy?u=<google原链>（该端点已失效）
 *     → 返回内层 google 原链，供重新指向当前端点。
 * @param string $url
 * @return string 内层 Google 原链；非代理形态、或内层不是 Google 时返回 ''
 */
if (!function_exists('zibll_child_unwrap_proxied_google_avatar')) {
    function zibll_child_unwrap_proxied_google_avatar($url)
    {
        if (empty($url) || !is_string($url)) {
            return '';
        }
        // 匹配任意 "…avatar-proxy…?u=<urlencoded>" 形态（旧 steam/CF 端点或本主题旧路径）
        if (preg_match('#^https?://[^/]+/[^?]*avatar-proxy[^?]*\?u=([^&]+)#i', $url, $m)) {
            $inner = rawurldecode($m[1]);
            if (zibll_child_is_google_avatar($inner)) {
                return $inner;
            }
        }
        return '';
    }
}

/**
 * 把 Google 头像 URL 改写为当前反代端点地址。三种输入都正确、且结果幂等：
 *   1) Google 原链        → <当前端点>?u=<encoded 原链>
 *   2) 已被代理过的旧地址  → 取出内层 Google 原链后重指向 <当前端点>（修死链）
 *   3) 其它（QQ/上传等）   → 原样返回，不动
 * @param string $url
 * @return string
 */
if (!function_exists('zibll_child_proxy_google_avatar_url')) {
    function zibll_child_proxy_google_avatar_url($url)
    {
        if (empty($url) || !is_string($url)) {
            return $url;
        }
        // 已是 Google 原链
        if (zibll_child_is_google_avatar($url)) {
            return ZIBLL_CHILD_GOOGLE_AVATAR_PROXY . '?u=' . urlencode($url);
        }
        // 已是被代理过的地址（含历史死链）→ 还原后重指向当前端点
        $inner = zibll_child_unwrap_proxied_google_avatar($url);
        if ($inner !== '') {
            return ZIBLL_CHILD_GOOGLE_AVATAR_PROXY . '?u=' . urlencode($inner);
        }
        return $url;
    }
}

/**
 * 单个用户：若 custom_avatar 是 Google 头像则改写为反代地址并刷新头像缓存。
 * @param int $user_id
 */
if (!function_exists('zibll_child_proxy_user_google_avatar')) {
    function zibll_child_proxy_user_google_avatar($user_id)
    {
        $user_id = (int) $user_id;
        if (!$user_id || !function_exists('zib_get_user_meta')) {
            return;
        }
        $existing = zib_get_user_meta($user_id, 'custom_avatar', true);
        if (empty($existing) || !is_string($existing)) {
            return;
        }
        // 幂等：只有结果与现值不同才写库
        // （Google 原链、以及 1.5.10 写下的旧 steam 代理死链，都会在此被纠正）
        $new = zibll_child_proxy_google_avatar_url($existing);
        if ($new !== $existing) {
            zib_update_user_meta($user_id, 'custom_avatar', $new);
            if (function_exists('zibll_child_flush_avatar_cache')) {
                zibll_child_flush_avatar_cache($user_id);
            }
        }
    }
}

/**
 * wp_login 适配器（优先级 25，确保晚于父主题 oauth 写库 + oauth-auto-email 的 20）。
 * 回调签名为 ($user_login, $user)，首参是用户名字符串，需取出 $user->ID。
 */
if (!function_exists('zibll_child_proxy_google_avatar_on_login')) {
    function zibll_child_proxy_google_avatar_on_login($user_login, $user)
    {
        if ($user instanceof WP_User) {
            zibll_child_proxy_user_google_avatar($user->ID);
        }
    }
}

/**
 * 存量用户一次性改写：把全部 custom_avatar 是 Google 头像的用户改写为反代地址。
 *
 * ⚠️ 不能用 get_users(meta_key='custom_avatar')：父主题把 custom_avatar 注册进了
 * zibll 自有的 option_meta 机制（见 zibll dependent.php 的 user_meta option_meta_keys），
 * 真实头像并不在 wp_usermeta 表里，标准 WP_User_Query 查不到。
 * 所以改为遍历全部用户，用 zib_get_user_meta 逐个读取判断；
 * zibll_child_proxy_user_google_avatar 内部已带 is_google_avatar 守卫，天然幂等。
 */
if (!function_exists('zibll_child_proxy_all_google_avatars')) {
    function zibll_child_proxy_all_google_avatars()
    {
        $users = get_users(array('fields' => 'ID', 'number' => 0));
        foreach ($users as $uid) {
            // 幂等：Google 原链与「旧代理死链」都会被纠正为当前端点，其它头像不动
            zibll_child_proxy_user_google_avatar((int) $uid);
        }
    }
}

if (zibll_child_module_enabled('enable_google_avatar_proxy', false)) {
    // 登录时即时改写当前用户（覆盖 oauth 新建号 / 后续登录场景）
    add_action('wp_login', 'zibll_child_proxy_google_avatar_on_login', 25, 2);

    // 启用后一次性改写存量谷歌头像用户（选项标记只跑一次）
    add_action('init', 'zibll_child_google_avatar_auto_once');
}

if (!function_exists('zibll_child_google_avatar_auto_once')) {
    function zibll_child_google_avatar_auto_once()
    {
        // v2：1.5.11 起支持自愈历史死链（1.5.10 写下的 steam 旧端点），需重跑一次存量修复
        if (get_option('zibll_child_google_avatar_done_v2')) {
            return;
        }
        zibll_child_proxy_all_google_avatars();
        update_option('zibll_child_google_avatar_done_v2', 1);
    }
}
