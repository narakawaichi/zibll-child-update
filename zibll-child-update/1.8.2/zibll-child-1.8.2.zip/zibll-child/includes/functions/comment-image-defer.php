<?php
/**
 * 评论配图体验重构（子主题：zibll-child）
 *
 * 前端 assets/js/comment-image-defer.js
 *   选图 / Ctrl+V 粘贴只在本地排队，点「发送评论」时才真正上传；
 *   一次评论只带 1 张图；上传期间按钮禁用并显示「上传中」。
 *
 * 后端（本文件）
 *   只对【评论图片上传】这一个入口做「重编码洗图」：
 *     - 重新解码再编码，丢掉 EXIF / 注释 / 追加数据，杀掉图片里藏的 PHP 马、polyglot；
 *     - 洗图前先按 EXIF 方向把手机照片转正（否则洗掉方向标记后照片会躺倒）；
 *     - 动图（GIF 多帧）不洗，避免动图变成死图；
 *     - 像素过大的图不洗，避免 GD 吃满内存让上传直接失败；
 *     - 文章配图 / 头像 / 封面等其它上传完全不受影响。
 *
 * 依赖主题自带开关（注意：文章页评论框和论坛回复框用的是两套开关）：
 *   文章页评论：#commentform 里的上传入口由 主题设置 → 评论 →「允许上传图片」控制，
 *               对应选项 comment_upload_img（按钮本身由 comment_img 控制）。
 *   论坛/圈子回复：对应选项 bbs_comment_upload_img。
 * 本模块只做体验优化与洗图，不强行改这些配置；
 * 开关没开时前端会说明原因，后台也会给一条提示。
 */

if (!defined('ABSPATH')) {
    exit;
}

/* -------------------------------------------------------------------------
 * 一、前端脚本
 * ---------------------------------------------------------------------- */

add_action('wp_enqueue_scripts', 'hoarfall_comment_image_defer_enqueue', 30);
function hoarfall_comment_image_defer_enqueue()
{
    if (is_admin() || !is_singular()) {
        return;
    }

    $path = get_stylesheet_directory() . '/assets/js/comment-image-defer.js';
    if (!file_exists($path)) {
        return;
    }

    wp_enqueue_script(
        'hoarfall-comment-image-defer',
        get_stylesheet_directory_uri() . '/assets/js/comment-image-defer.js',
        array('jquery'),
        (string) filemtime($path), // 用文件时间当版本号：改完不用手动清浏览器缓存
        true
    );
}

/* -------------------------------------------------------------------------
 * 二、后台提示：评论图片上传开关没开时提醒一下
 * ---------------------------------------------------------------------- */

add_action('admin_notices', 'hoarfall_comment_image_admin_notice');
function hoarfall_comment_image_admin_notice()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    if (!function_exists('_pz')) {
        return;
    }

    // 文章页评论框：图片按钮（comment_img）+ 上传入口（comment_upload_img）
    // 论坛/圈子回复：bbs_comment_img + bbs_comment_upload_img
    $missing = array();
    if (!_pz('comment_img', true)) {
        $missing[] = '评论 - 允许插入图片';
    }
    if (!_pz('comment_upload_img', false)) {
        $missing[] = '评论 - 允许上传图片';
    }

    if (!$missing) {
        return;
    }

    echo '<div class="notice notice-warning"><p><b>评论配图</b>：主题设置里这些开关现在是关着的，'
        . '文章页评论框不会出现上传入口，Ctrl+V 粘贴图片也用不了：</p><ul style="margin-left:18px;list-style:disc;">';
    foreach ($missing as $item) {
        echo '<li>' . esc_html($item) . '</li>';
    }
    echo '</ul><p>请到 <b>子比主题设置 → 评论</b> 把对应开关打开（文章评论的上传入口由「允许上传图片」控制）。'
        . '开启后本提示自动消失。</p></div>';
}

/* -------------------------------------------------------------------------
 * 三、服务端：只给评论 / 私信的图片上传做重编码洗图
 * ---------------------------------------------------------------------- */

add_filter('wp_handle_upload_prefilter', 'hoarfall_sanitize_comment_image');
function hoarfall_sanitize_comment_image($file)
{
    if (!hoarfall_is_comment_image_upload()) {
        return $file;
    }

    $tmp = isset($file['tmp_name']) ? $file['tmp_name'] : '';
    if (!$tmp || !is_uploaded_file($tmp)) {
        return $file;
    }

    $info = @getimagesize($tmp);
    if (empty($info['mime'])) {
        return $file; // 不是真图，交给主题 / WP 的校验去拒绝
    }

    $mime = $info['mime'];
    $w    = isset($info[0]) ? (int) $info[0] : 0;
    $h    = isset($info[1]) ? (int) $info[1] : 0;

    // 只处理主题 accept 里允许的格式
    if (!in_array($mime, array('image/jpeg', 'image/png', 'image/gif', 'image/webp'), true)) {
        return $file;
    }

    // 像素太大不洗：128M 内存下 GD 处理 1200 万像素约需 48MB，再大容易把上传搞崩
    if ($w > 0 && $h > 0 && ($w * $h) > 12000000) {
        return $file;
    }

    // 动图不洗（GD 只能取第一帧，洗了动图就变死图）
    if ($mime === 'image/gif' && hoarfall_is_animated_gif($tmp)) {
        return $file;
    }

    $clean = hoarfall_reencode_image($tmp, $mime);
    if (is_string($clean) && $clean !== '') {
        @file_put_contents($tmp, $clean);
    }

    return $file;
}

/**
 * 判断当前请求是不是 zibll 的「评论 / 私信图片上传」入口。
 * 该入口由 zib_get_input_expand_but('image', ...) 生成，表单里带
 *   <input data-name="action" data-value="user_upload_image">
 *   <input data-name="upload_image_nonce" data-value="...">
 * 上传时由 mini-upload.js 一起 POST 上来。
 * 其它上传（文章配图 / 头像 / 封面 / 附件）action 不同，天然被排除。
 */
function hoarfall_is_comment_image_upload()
{
    $action = isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';
    if ('user_upload_image' !== $action) {
        return false;
    }

    $nonce = isset($_POST['upload_image_nonce']) ? wp_unslash($_POST['upload_image_nonce']) : '';
    return (bool) wp_verify_nonce($nonce, 'upload_image');
}

/**
 * 用 GD 重新解码 → 按 EXIF 方向转正 → 再编码，返回干净的二进制。
 * 失败返回 false（调用方保持原文件不动，不破坏上传）。
 */
function hoarfall_reencode_image($tmp, $mime)
{
    if (!function_exists('imagecreatefromstring')) {
        return false;
    }

    $raw = @file_get_contents($tmp);
    if (false === $raw || '' === $raw) {
        return false;
    }

    $img = @imagecreatefromstring($raw);
    if (!$img) {
        return false;
    }

    // 手机照片：先按 EXIF 方向摆正，再丢掉元数据，否则洗图后照片会躺倒
    if ('image/jpeg' === $mime && function_exists('imagerotate')) {
        $img = hoarfall_apply_exif_orientation($img, hoarfall_jpeg_orientation($tmp));
    }

    ob_start();
    $ok = true;
    switch ($mime) {
        case 'image/jpeg':
            imagejpeg($img, null, 92);
            break;
        case 'image/png':
            if (function_exists('imagealphablending')) {
                imagealphablending($img, false);
                imagesavealpha($img, true);
            }
            imagepng($img, null, 6);
            break;
        case 'image/gif':
            imagegif($img);
            break;
        case 'image/webp':
            if (function_exists('imagewebp')) {
                imagewebp($img, null, 92);
            } else {
                $ok = false;
            }
            break;
        default:
            $ok = false;
    }
    $data = ob_get_clean();

    imagedestroy($img);

    return ($ok && is_string($data) && '' !== $data) ? $data : false;
}

/**
 * 按 EXIF 方向值（1~8）把 GD 图像摆正。
 */
function hoarfall_apply_exif_orientation($img, $orientation)
{
    $orientation = (int) $orientation;
    if ($orientation < 2 || $orientation > 8) {
        return $img; // 1 = 正常，不用动
    }

    $flip = null;
    $angle = 0;

    switch ($orientation) {
        case 2: // 水平镜像
            $flip = IMG_FLIP_HORIZONTAL;
            break;
        case 3: // 旋转 180
            $angle = 180;
            break;
        case 4: // 垂直镜像
            $flip = IMG_FLIP_VERTICAL;
            break;
        case 5: // 水平镜像 + 顺时针 90
            $flip  = IMG_FLIP_HORIZONTAL;
            $angle = -90;
            break;
        case 6: // 顺时针 90（手机竖拍最常见）
            $angle = -90;
            break;
        case 7: // 水平镜像 + 逆时针 90
            $flip  = IMG_FLIP_HORIZONTAL;
            $angle = 90;
            break;
        case 8: // 逆时针 90
            $angle = 90;
            break;
    }

    if ($flip && function_exists('imageflip')) {
        imageflip($img, $flip);
    }

    if ($angle !== 0) {
        $bg  = imagecolorallocate($img, 255, 255, 255);
        $rot = @imagerotate($img, $angle, $bg);
        if ($rot) {
            imagedestroy($img);
            $img = $rot;
        }
    }

    return $img;
}

/**
 * 读 JPEG 的 EXIF 方向（1~8）。服务器没装 exif 扩展时 exif_read_data 不可用，
 * 所以这里自己解析 APP1 段里的 TIFF 头，只取 0x0112 这一个标签。
 * 读不到就返回 1（不动）。
 */
function hoarfall_jpeg_orientation($path)
{
    $fh = @fopen($path, 'rb');
    if (!$fh) {
        return 1;
    }

    if ("\xFF\xD8" !== fread($fh, 2)) { // 不是 JPEG
        fclose($fh);
        return 1;
    }

    $orientation = 1;
    $guard       = 40; // 最多看 40 个段，足够覆盖到 APP1

    while ($guard-- > 0 && !feof($fh)) {
        $marker = fread($fh, 2);
        if (strlen($marker) < 2 || "\xFF" !== $marker[0]) {
            break;
        }

        $code = ord($marker[1]);

        if (0xDA === $code) { // 进入图像数据，后面不会再有 EXIF
            break;
        }
        if (0x01 === $code || 0xD8 === $code || ($code >= 0xD0 && $code <= 0xD7)) {
            continue; // 这些段没有长度字段
        }

        $len_bytes = fread($fh, 2);
        if (strlen($len_bytes) < 2) {
            break;
        }
        $len = unpack('n', $len_bytes);
        $len = isset($len[1]) ? (int) $len[1] : 0;
        if ($len < 2) {
            break;
        }

        $body = $len > 2 ? fread($fh, $len - 2) : '';

        if (0xE1 === $code && strlen($body) > 6 && 0 === strncmp($body, "Exif\0\0", 6)) {
            $found = hoarfall_tiff_orientation(substr($body, 6));
            if ($found >= 1 && $found <= 8) {
                $orientation = $found;
            }
            break;
        }
    }

    fclose($fh);

    return $orientation;
}

/**
 * 从 TIFF 头里取 Orientation 标签（0x0112）。
 */
function hoarfall_tiff_orientation($tiff)
{
    if (strlen($tiff) < 8) {
        return 0;
    }

    $endian = substr($tiff, 0, 2);
    if ('II' === $endian) {
        $fmt_short = 'v';
        $fmt_long  = 'V';
    } elseif ('MM' === $endian) {
        $fmt_short = 'n';
        $fmt_long  = 'N';
    } else {
        return 0;
    }

    $ifd_raw = unpack($fmt_long, substr($tiff, 4, 4));
    $ifd     = isset($ifd_raw[1]) ? (int) $ifd_raw[1] : 0;
    if ($ifd < 8 || ($ifd + 2) > strlen($tiff)) {
        return 0;
    }

    $cnt_raw = unpack($fmt_short, substr($tiff, $ifd, 2));
    $count   = isset($cnt_raw[1]) ? (int) $cnt_raw[1] : 0;
    $count   = min($count, 200); // 防止损坏文件把循环拉爆

    for ($i = 0; $i < $count; $i++) {
        $off = $ifd + 2 + $i * 12;
        if (($off + 12) > strlen($tiff)) {
            return 0;
        }

        $tag_raw = unpack($fmt_short, substr($tiff, $off, 2));
        $tag     = isset($tag_raw[1]) ? (int) $tag_raw[1] : 0;

        if (0x0112 === $tag) {
            $val_raw = unpack($fmt_short, substr($tiff, $off + 8, 2));
            return isset($val_raw[1]) ? (int) $val_raw[1] : 0;
        }
    }

    return 0;
}

/**
 * GIF 是否多帧（动图）。只看前面 256KB，足够判断。
 */
function hoarfall_is_animated_gif($path)
{
    $raw = @file_get_contents($path, false, null, 0, 262144);
    if (false === $raw || '' === $raw) {
        return false;
    }

    return substr_count($raw, "\x21\xF9\x04") > 1;
}
