/**
 * 评论配图体验重构（子主题：zibll-child）
 *
 * 做法（已对照子比 9.x 源码核实）：
 *   1) 选图 / Ctrl+V 粘贴 → 只在本地排队（移除 auto-submit，隐藏"确认上传"按钮），
 *      不再"选完就传"，废图不会占服务器；
 *   2) 点「发送评论」时才真正上传：先触发主题自己的 user_upload_image 上传，
 *      等图片地址被写回评论框后，再放行评论提交；
 *   3) 一次评论只带 1 张图（主题这个上传口就是单图）；
 *   4) 上传中按钮禁用并显示"上传中"，成功/失败都有提示；
 *   5) 前端先做格式白名单软校验，服务端另有真校验与重编码。
 *
 * 关键契约（子比 9.x）：
 *   inc/functions/functions.php 的 case 'image' 生成
 *     <div class="form-upload">
 *       <input type=file zibupload="image_upload" name="image_upload">
 *       <button zibupload="submit" auto-submit="true" class="input-expand-upload">确认上传</button>
 *       <input type=hidden data-name="action" data-value="user_upload_image">
 *     </div>
 *   整段位于 <form id="commentform"> 内（textarea.grin 即 #comment）。
 *   mini-upload.js：change 末尾 form.find('[auto-submit]').click() → 去掉该属性即可不自动上传；
 *   上传成功后在按钮上 trigger('miniuploaded')
 *   → input-expand.js 用 grin() 把 [img=URL] 追加进 textarea.grin。
 *
 * 评论表单常为懒加载 / 回复时动态生成，故用 MutationObserver 在节点注入后再次处理。
 */
(function ($) {
    'use strict';

    var UPLOAD_INPUT = '[zibupload="image_upload"]';
    var SUBMIT_BTN   = '[zibupload="submit"]';
    var AUTOS        = '[auto-submit]';
    var ALLOW_EXT    = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    var sending = false; // 正在走"提交评论 → 先上传图片 → 再提交"流程
    var bypass  = false; // 图片已处理完，放行本次真正的提交

    /* ---------------------------------------------------------------- 提示 */

    function notify(msg, type) {
        type = type || 'danger';
        try {
            if (typeof notyf === 'function') {
                notyf(msg, type);
            } else if (window.notyf && typeof window.notyf[type] === 'function') {
                window.notyf[type](msg);
            } else if (type === 'danger') {
                alert(msg);
            }
        } catch (e) {
            if (type === 'danger') alert(msg);
        }
    }

    function extOf(name) {
        var m = /\.([a-z0-9]+)$/i.exec(name || '');
        return m ? m[1].toLowerCase() : '';
    }

    function isAllowedImage(file) {
        if (!file || !file.type || file.type.indexOf('image/') !== 0) return false;
        var ext = extOf(file.name);
        if (ext && ALLOW_EXT.indexOf(ext) === -1) return false;
        return true;
    }

    /* ---------------------------------------------------- 定位评论表单的各个零件 */

    // 评论框自己的上传 input（只在 #commentform / #respond 范围内找，避免抓到头像上传）
    function uploadInput() {
        var up = $('#commentform').find(UPLOAD_INPUT);
        if (!up.length) up = $('#respond').find(UPLOAD_INPUT);
        return up;
    }

    // 上传 input 所在的 .form-upload 容器（没有就退回最近的 form）
    function uploadBox() {
        var up = uploadInput();
        if (!up.length) return $();
        var box = up.closest('.form-upload');
        return box.length ? box : up.closest('form');
    }

    // 评论表单本体
    function commentForm() {
        var f = $('#commentform');
        if (f.length) return f;
        var up = uploadInput();
        return up.length ? up.closest('form') : $();
    }

    /* ------------------------------------------------------- 关掉"选图即传" */

    function neutralize() {
        var box = uploadBox();
        if (!box.length) return;

        if (!box.data('hoarfall-neutralized')) {
            // 记住主题原本的「添加图片」占位，移除已挂图片时用于还原
            var pre = box.find('.preview');
            if (pre.length && typeof pre.data('hoarfall-placeholder') === 'undefined') {
                pre.data('hoarfall-placeholder', pre.html());
            }
            box.find(AUTOS).removeAttr('auto-submit');
            box.find(SUBMIT_BTN).hide(); // 真正上传只在点"发送评论"时发生
            box.data('hoarfall-neutralized', 1);
        }
    }

    function pendingFiles() {
        var up = uploadInput();
        return up.length && up[0].files ? up[0].files.length : 0;
    }

    /* --------------------------------------- 评论框下方「已挂图片」可见提示条 */

    var CHIP_ID = 'hoarfall-image-queue';

    function escapeHtml(s) {
        return String(s || '').replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c];
        });
    }

    function humanSize(bytes) {
        if (!bytes && bytes !== 0) return '';
        if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
        return Math.max(1, Math.round(bytes / 1024)) + ' KB';
    }

    function chipEl() {
        return $('#' + CHIP_ID);
    }

    function removeChip() {
        chipEl().remove();
    }

    // 在评论框下方显示：缩略图 + 文件名 + 大小 + 移除按钮
    function renderChip(file, dataUrl) {
        var ta = $('#comment');
        if (!ta.length || !file) {
            removeChip();
            return;
        }

        var chip = chipEl();
        if (!chip.length) {
            chip = $('<div id="' + CHIP_ID + '"></div>').css({
                margin: '8px 0 4px',
                padding: '8px 10px',
                border: '1px dashed rgba(127,127,127,.45)',
                'border-radius': '8px',
                display: 'flex',
                'align-items': 'center',
                gap: '10px'
            });
            ta.after(chip);
        }

        var img = dataUrl
            ? '<img src="' + dataUrl + '" style="width:48px;height:48px;object-fit:cover;border-radius:6px;display:block;">'
            : '<div style="width:48px;height:48px;border-radius:6px;background:rgba(127,127,127,.2);"></div>';

        chip.html(
            img +
            '<div style="line-height:1.5;font-size:12px;">' +
                '<div style="font-weight:600;">已挂 1 张图</div>' +
                '<div style="opacity:.7;">' + escapeHtml(file.name) + (file.size ? ' · ' + humanSize(file.size) : '') +
                ' · 点「发送评论」时自动上传</div>' +
            '</div>' +
            '<a href="javascript:;" class="hoarfall-queue-remove" style="margin-left:auto;opacity:.65;cursor:pointer;white-space:nowrap;text-decoration:none;">✕ 移除</a>'
        );
    }

    // 按当前 input 里的文件刷新提示条
    function refreshChip() {
        var up = uploadInput();
        var file = up.length && up[0].files && up[0].files.length ? up[0].files[0] : null;

        if (!file) {
            removeChip();
            return;
        }

        // 已经有提示条就不重复读文件（避免闪烁）
        if (chipEl().length && chipEl().data('hoarfall-name') === file.name + '|' + file.size) {
            return;
        }
        chipEl().data('hoarfall-name', file.name + '|' + file.size);

        try {
            var fr = new FileReader();
            fr.onload = function () { renderChip(file, fr.result); };
            fr.readAsDataURL(file);
        } catch (e) {
            renderChip(file, '');
        }
    }

    // 清掉已挂的图片（同时让 mini-upload 里的私有队列也作废）
    function clearQueued() {
        var up = uploadInput();
        if (up.length) {
            try {
                up[0].files = new DataTransfer().files;
            } catch (e) {
                up.val('');
            }
            // 让 mini-upload 重新分配一个空的 upload_id 队列，
            // 它闭包里的旧 mini_file 旧 id 就再也取不到了
            up.removeAttr('upload_id');
            up.trigger('change');
        }

        // 还原主题自己的「添加图片」占位图
        var box = uploadBox();
        if (box.length) {
            var pre = box.find('.preview');
            var ph = pre.data('hoarfall-placeholder');
            if (pre.length && typeof ph !== 'undefined') pre.html(ph);
        }

        removeChip();
    }

    /* ------------------------------------------ 把粘贴进来的图片塞进上传 input */

    // 把图片写进上传 input；replace=true 时替换已有队列（粘贴重复=换图，而不是叠加）
    function assignFiles(inputEl, files, replace) {
        var dt;
        try {
            dt = new DataTransfer();
        } catch (e) {
            dt = null;
        }
        if (!dt) {
            notify('当前浏览器不支持粘贴上传，请手动选择图片', 'warning');
            return false;
        }

        var i;
        if (!replace) {
            var exist = inputEl.files || [];
            for (i = 0; i < exist.length; i++) dt.items.add(exist[i]);
        }
        for (i = 0; i < files.length; i++) dt.items.add(files[i]);

        try {
            inputEl.files = dt.files;
        } catch (e) {
            notify('当前浏览器不支持粘贴上传，请手动选择图片', 'warning');
            return false;
        }

        $(inputEl).trigger('change'); // 交给 mini-upload 生成预览
        return true;
    }

    /**
     * 静默切到"上传图片"分页。
     * 注意：不能用 trigger('click') —— 子比的「上传图片」标签带 data-onclick="#input_xxx"，
     * main.js 里 `[data-onclick]` 的点击会去 .click() 那个文件框，直接弹出系统选文件窗口。
     * 粘贴时弹框就是这个原因。所以这里只切 class / 调 bootstrap tab，绝不触发 click。
     */
    function showUploadTab(link) {
        if (!link || !link.length) return;

        var href = link.attr('href') || '';
        var pane = href ? $(href) : $();
        if (!pane.length) return;

        try {
            if ($.fn.tab) link.tab('show');
        } catch (e) { /* 继续走下面的兜底 */ }

        if (!pane.hasClass('active')) {
            var box = pane.parent();
            box.find('.tab-pane').removeClass('in active');
            pane.addClass('in active');
            box.find('a[data-toggle="tab"]').removeClass('active');
            link.addClass('active');
        }
    }

    // 找到评论区那个「上传图片」标签
    function uploadTabLink(scope) {
        var link = scope.find('a[data-toggle="tab"][href$="-2"]');
        return link.length ? link.first() : $();
    }

    // 切到"上传图片"分页，让用户能看到预览（不弹文件选择框）
    function switchToUploadTab(up) {
        var menu = up.closest('.dropdown-menu');
        if (!menu.length) return;
        showUploadTab(uploadTabLink(menu));
    }

    /* ------------------------------------------------------------- 粘贴图片 */

    $(document).on('paste', '#comment', function (e) {
        var cdt = (e.originalEvent && e.originalEvent.clipboardData) || window.clipboardData;
        if (!cdt) return;

        var files = [];
        var bad = [];
        var i, it, f;

        for (i = 0; i < cdt.items.length; i++) {
            it = cdt.items[i];
            if (it.kind === 'file' && it.type && it.type.indexOf('image/') === 0) {
                f = it.getAsFile();
                if (f && isAllowedImage(f)) {
                    files.push(f);
                } else if (f) {
                    bad.push(f.name);
                }
            }
        }

        if (bad.length) notify('不支持的图片格式：' + bad.join('、'), 'danger');
        if (!files.length) return; // 粘的是文字，走浏览器默认行为

        e.preventDefault();

        var up = uploadInput();
        if (!up.length) {
            notify('请先登录，并在主题设置 → 评论 里打开「允许上传图片」后再粘贴', 'warning');
            return;
        }

        // 这个上传口是单图：只取第一张，多余的明确告知，避免"以为传了其实丢了"
        if (files.length > 1) {
            notify('评论一次只能带 1 张图，已放入第一张', 'warning');
            files = [files[0]];
        }

        neutralize();
        if (assignFiles(up[0], files, true)) {
            switchToUploadTab(up);
            refreshChip();
            notify('图片已就绪，点「发送评论」后上传', 'success');
        }
    });

    /* -------------------------------------------- 选图后的前端软校验（提示用） */

    $(document).on('change', '#commentform ' + UPLOAD_INPUT + ', #respond ' + UPLOAD_INPUT, function () {
        var list = this.files || [];
        var bad = [];
        var i;
        for (i = 0; i < list.length; i++) {
            if (!isAllowedImage(list[i])) bad.push(list[i].name);
        }
        if (bad.length) {
            notify('不支持的图片格式：' + bad.join('、'), 'danger');
            return;
        }
        refreshChip(); // 手动选图也显示同样的提示条
    });

    // 点「✕ 移除」：清掉已挂的图片与提示条
    $(document).on('click', '#' + CHIP_ID + ' .hoarfall-queue-remove', function () {
        clearQueued();
        notify('已移除这张图片', 'success');
        return false;
    });

    /* --------------------------------- 点"发送评论"：先上传图，再真正提交评论 */

    // 等图片上传完成：以"评论框里是否多出了新的 [img=...]"为准（成功才放行）
    function waitImageReady(onDone) {
        var startedAt = Date.now();
        var clearedAt = 0;
        var before = $('#comment').val() || '';
        var deadline = 30000; // 30s 上限，慢网也不至于卡死

        var timer = setInterval(function () {
            var up = uploadInput();
            var left = up.length && up[0].files ? up[0].files.length : 0;
            var now = $('#comment').val() || '';

            // 成功：评论框里出现了新的图片标记
            if (/\[img=[^\]]+\]/i.test(now) && now !== before) {
                clearInterval(timer);
                onDone(true);
                return;
            }

            // 失败：上传 input 已被主题清空，但评论框没拿到图片地址
            if (left === 0) {
                if (!clearedAt) clearedAt = Date.now();
                if (Date.now() - clearedAt > 1200) {
                    clearInterval(timer);
                    onDone(false);
                    return;
                }
            }

            // 超时兜底：不把用户卡死在"上传中"
            if (Date.now() - startedAt > deadline) {
                clearInterval(timer);
                onDone(false);
            }
        }, 350);
    }

    function onSubmitClick(e) {
        var t = e.target && e.target.closest ? e.target.closest('#commentform #submit') : null;
        if (!t) return;

        // 正在上传中又点了一次：直接吞掉，避免重复提交
        if (sending) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }

        // 没有待传图片，或本次已处理完 → 交还主题正常提交
        if (bypass || !pendingFiles()) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        var $btn = $(t);
        var btnText = $btn.text();
        var box = uploadBox();
        var upBtn = box.length ? box.find(SUBMIT_BTN) : $();

        sending = true;
        $btn.prop('disabled', true).text('图片上传中…');

        // 找不到上传按钮（未登录 / 开关没开 / 结构变了）→ 放手，按纯文字评论提交
        if (!upBtn.length) {
            sending = false;
            bypass = true;
            $btn.prop('disabled', false).text(btnText);
            $('#commentform #submit').trigger('click');
            setTimeout(function () { bypass = false; }, 1500);
            return;
        }

        waitImageReady(function (ok) {
            sending = false;
            bypass = true;
            $btn.prop('disabled', false).text(btnText);
            removeChip(); // 图片已处理完（成功或放弃），提示条收起

            if (!ok) {
                notify('图片没能上传成功，本条评论先按纯文字发送（可稍后重新带图）', 'warning');
                var up = uploadInput();
                if (up.length) up.val('');
            }

            $('#commentform #submit').trigger('click');
            // 1.5s 后恢复"延后上传"能力，供下一次评论使用
            setTimeout(function () { bypass = false; }, 1500);
        });

        // 触发子比自己的上传（user_upload_image），原有校验 / 审核链路不变
        upBtn.trigger('click');
    }

    document.addEventListener('click', onSubmitClick, true);

    /* ------------------------------------------------- 评论表单懒加载 / 回复 */

    function prepare() {
        if (!$('#commentform').length) return;
        neutralize();
        refreshChip(); // 页面 / 回复框重建后，按 input 现状恢复提示条
    }

    // 点工具栏"图片"按钮时，静默切到"上传图片"那一页（不自动弹文件选择框，
    // 想让用户选文件时点那个虚线预览框即可；粘贴则完全不用点）
    $(document).on('click', '.input-image', function () {
        if (!$(this).closest('#commentform').length) return;
        var self = this;
        setTimeout(function () {
            var menu = $(self).parent().find('.dropdown-menu');
            showUploadTab(uploadTabLink(menu));
        }, 0);
    });

    var mo = null;
    function startObserve() {
        if (mo || typeof MutationObserver === 'undefined') return;
        mo = new MutationObserver(function () {
            prepare();
        });
        mo.observe(document.documentElement, { childList: true, subtree: true });
    }

    $(function () {
        prepare();
        startObserve();
    });

    // 点"回复"会重建回复框，稍后再处理一次
    $(document).on('click', '.comment-reply-link, .comment-edit-link', function () {
        setTimeout(prepare, 300);
    });

    $(document).on('comment_added zib_ajax.success', function () {
        setTimeout(prepare, 300);
    });

})(jQuery);
