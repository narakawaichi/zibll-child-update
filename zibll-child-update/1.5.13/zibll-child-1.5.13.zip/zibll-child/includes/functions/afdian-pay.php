<?php
/**
 * 子比子主题 - 爱发电（Afdian）支付渠道
 * ─────────────────────────────────────────────────────────────
 * 把爱发电作为标准支付方式「融入」父主题 zibll 的收银台（付费文章 / 会员 /
 * 余额充值 / 商城商品），零侵入、不修改父主题一行。
 *
 * 工作原理（完全复用父主题现有钩子与入口）：
 *   1. add_filter('zibpay_payment_methods', …)
 *      —— 往支付选择列表注入 afdian，所有收银台自动出现「爱发电」选项。
 *   2. add_filter('zibpay_initiate_paysdk', …)
 *      —— 识别 payment_method=afdian，转交本模块的发起处理器。
 *   3. zibll_child_afdian_initiate_pay()
 *      —— 返回 open_url，把用户带到爱发电页面付款（带 custom_order_id=本地订单号），
 *         复用前端已有的跳转逻辑，不新造 UI。
 *   4. afdian-notify.php（子主题根目录，仿父主题 zibpay/shop/<网关>/notify.php）
 *      —— 爱发电 Webhook 回调入口，用爱发电【平台固定公钥】RSA-SHA256 验签，
 *         status=2 且通过后调用 ZibPay::payment_order() 标记本地订单已付，
 *         自动触发 zibll 原有发货 / 到账流程。幂等 + 必须回 {"ec":200,"em":""}。
 *
 * 模式说明（本版 = 纯 Webhook 模式）：
 *   不依赖爱发电 user_id / api_token（那套仅用于定时回查漏单，后续可选扩展）。
 *   Webhook 验签用的是爱发电平台固定公钥，任何站点通用，无需你的任何凭证即可运行。
 *
 * 配置：后台「子比子主题设置 → 基础设置」开关「爱发电支付」+ 新增「爱发电支付」分组
 *       （爱发电页面地址、user_id、api_token）。
 *
 * @package zibll-child
 * @author  依岸归
 * @link    https://nav.hoarfall.cn/
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── 爱发电平台固定公钥（RSA-SHA256，用于 Webhook 验签；全平台通用，无需你的私钥） ───
if (!defined('ZIBLL_CHILD_AFDIANA_PUBLIC_KEY')) {
    define('ZIBLL_CHILD_AFDIANA_PUBLIC_KEY', <<<PEM
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwwdaCg1Bt+UKZKs0R54y
lYnuANma49IpgoOwNmk3a0rhg/PQuhUJ0EOZSowIC44l0K3+fqGns3Ygi4AfmEfS
4EKbdk1ahSxu7Zkp2rHMt+R9GarQFQkwSS/5x1dYiHNVMiR8oIXDgjmvxuNes2Cr
8fw9dEF0xNBKdkKgG2qAawcN1nZrdyaKWtPVT9m2Hl0ddOO9thZmVLFOb9NVzgYf
jEgI+KWX6aY19Ka/ghv/L4t1IXmz9pctablN5S0CRWpJW3Cn0k6zSXgjVdKm4uN7
jRlgSRaf/Ind46vMCm3N2sgwxu/g3bnooW+db0iLo13zzuvyn727Q3UDQ0MmZcEW
MQIDAQAB
-----END PUBLIC KEY-----
PEM
    );
}

// ─── 配置读取 ───────────────────────────────────────────────
if (!function_exists('zibll_child_afdian_config')) {
    function zibll_child_afdian_config()
    {
        return array(
            'page_url' => zibll_child_get_option('afdian_page_url', 'https://ifdian.net/p/9c65d9cc617011ed81c352540025c377'),
            'user_id'  => zibll_child_get_option('afdian_user_id', ''),
            'api_token'=> zibll_child_get_option('afdian_api_token', ''),
        );
    }
}

// 模块是否启用（开关 + 至少配置了页面地址）
if (!function_exists('zibll_child_afdian_enabled')) {
    function zibll_child_afdian_enabled()
    {
        if (!zibll_child_module_enabled('enable_afdian_pay', false)) {
            return false;
        }
        $cfg = zibll_child_afdian_config();
        return !empty($cfg['page_url']);
    }
}

// Webhook 接收地址（供后台展示 + 用户配置到爱发电开发者后台）
if (!function_exists('zibll_child_afdian_webhook_url')) {
    function zibll_child_afdian_webhook_url()
    {
        return home_url('/wp-content/themes/zibll-child/afdian-notify.php');
    }
}

// 收银台支付方式图标（爱发电品牌色：黄 #FFE411 + 闪电/心形意象，内联 SVG，避免外部文件依赖）
if (!function_exists('zibll_child_afdian_method_img')) {
    function zibll_child_afdian_method_img()
    {
        return '<svg viewBox="0 0 28 28" width="22" height="22" aria-hidden="true" style="border-radius:5px;">'
            . '<rect x="1" y="1" width="26" height="26" rx="6" fill="#FFE411"/>'
            . '<path d="M16.5 5 L9.5 15.5 H13.5 L11.5 23 L19 12 H14.8 Z" fill="#1a1a1a"/>'
            . '</svg>';
    }
}

// ─── 钩子 1：把爱发电注入收银台支付方式列表 ──────────────────
add_filter('zibpay_payment_methods', 'zibll_child_afdian_payment_methods', 20, 2);
if (!function_exists('zibll_child_afdian_payment_methods')) {
    function zibll_child_afdian_payment_methods($methods, $pay_type)
    {
        if (zibll_child_afdian_enabled()) {
            $methods['afdian'] = array(
                'name' => '爱发电',
                'img'  => zibll_child_afdian_method_img(),
            );
        }
        return $methods;
    }
}

// ─── 钩子 2：识别 afdian 支付方式，转交本模块发起处理器 ──────
add_filter('zibpay_initiate_paysdk', 'zibll_child_afdian_initiate_paysdk', 20, 2);
if (!function_exists('zibll_child_afdian_initiate_paysdk')) {
    function zibll_child_afdian_initiate_paysdk($pay_sdk, $order_data)
    {
        if (!empty($order_data['payment_method']) && 'afdian' === $order_data['payment_method']) {
            return 'afdian';
        }
        return $pay_sdk;
    }
}

// ─── 钩子 3：发起爱发电支付（返回跳转链接，复用前端 open_url 逻辑） ──
add_filter('zibpay_initiate_afdian', 'zibll_child_afdian_initiate_pay', 10, 1);
if (!function_exists('zibll_child_afdian_initiate_pay')) {
    function zibll_child_afdian_initiate_pay($order_data)
    {
        if (!zibll_child_afdian_enabled()) {
            return array('error' => 1, 'msg' => __('当前订单不支持此方式支付，请联系客服', 'zib_language'));
        }

        $cfg = zibll_child_afdian_config();
        $order_num  = !empty($order_data['order_num']) ? $order_data['order_num'] : '';
        $order_price= !empty($order_data['order_price']) ? $order_data['order_price'] : 0;

        if (!$order_num) {
            return array('error' => 1, 'msg' => __('订单创建失败', 'zib_language'));
        }

        // 跳转爱发电页面：custom_order_id 把我们本地订单号带过去，
        // 爱发电会在 Webhook 原样回传，作为回调映射回本地订单的桥；
        // amount 预填本次应付金额（用户可在爱发电侧调整）。
        $redirect = add_query_arg(array(
            'custom_order_id' => $order_num,
            'amount'          => $order_price,
        ), $cfg['page_url']);

        return array(
            'open_url' => true,
            'url'      => $redirect,
        );
    }
}

// ─── Webhook 验签（RSA-SHA256，平台固定公钥） ──────────────
if (!function_exists('zibll_child_afdian_verify_sign')) {
    function zibll_child_afdian_verify_sign($order)
    {
        if (empty($order['out_trade_no']) || empty($order['user_id'])
            || empty($order['plan_id']) || !isset($order['total_amount']) || empty($_POST['sign'])) {
            return false;
        }
        // sign_str = out_trade_no + user_id + plan_id + total_amount（顺序拼接）
        $sign_str = $order['out_trade_no'] . $order['user_id'] . $order['plan_id'] . $order['total_amount'];
        // 公钥可被过滤器覆盖（便于密钥轮换 / 测试环境注入测试密钥），默认用爱发电平台固定公钥
        $public_key = apply_filters('zibll_child_afdian_public_key', ZIBLL_CHILD_AFDIANA_PUBLIC_KEY);
        $pubkey   = openssl_get_publickey($public_key);
        if (!$pubkey) {
            return false;
        }
        $ok = openssl_verify($sign_str, base64_decode($_POST['sign']), $pubkey, OPENSSL_ALGO_SHA256);
        openssl_free_key($pubkey);
        return $ok === 1;
    }
}

// ─── Webhook 业务处理（供 afdian-notify.php 调用） ──────────
if (!function_exists('zibll_child_afdian_handle_webhook')) {
    function zibll_child_afdian_handle_webhook()
    {
        // 读取原始 JSON 体
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        if (empty($data) || empty($data['data']['order'])) {
            return array('ec' => 200, 'em' => '');
        }

        $order = $data['data']['order'];
        $sign  = isset($data['data']['sign']) ? $data['data']['sign'] : '';

        // 把 sign 暂存到 $_POST 供验签函数读取（与父主题 notify 风格一致）
        $_POST['sign'] = $sign;

        // 验签
        if (!zibll_child_afdian_verify_sign($order)) {
            zibll_child_afdian_log_unmatched($order, 'sign_failed');
            return array('ec' => 200, 'em' => '');
        }

        // 仅处理交易成功（爱发电仅推送 status=2）
        if (empty($order['status']) || (int) $order['status'] !== 2) {
            return array('ec' => 200, 'em' => '');
        }

        // 映射本地订单：优先 custom_order_id（本模块跳转时写入），其次 out_trade_no（API 模式）
        $local_order_num = '';
        if (!empty($order['custom_order_id'])) {
            $local_order_num = (string) $order['custom_order_id'];
        } elseif (!empty($order['out_trade_no'])) {
            $local_order_num = (string) $order['out_trade_no'];
        }

        if (!$local_order_num) {
            zibll_child_afdian_log_unmatched($order, 'no_order_num');
            return array('ec' => 200, 'em' => '');
        }

        // 幂等：已支付则直接返回成功
        global $wpdb;
        $already = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM {$wpdb->zibpay_order} WHERE order_num = %s",
            $local_order_num
        ));
        if ($already === '1') {
            return array('ec' => 200, 'em' => '');
        }

        // 入账（should_skip_pay_amount_check 恒为 true，不比对金额；直接写入实付金额）
        $pay = array(
            'order_num' => $local_order_num,
            'pay_type'  => 'afdian',
            'pay_price' => isset($order['total_amount']) ? (float) $order['total_amount'] : 0,
            'pay_num'   => isset($order['out_trade_no']) ? $order['out_trade_no'] : '',
        );

        $result = ZibPay::payment_order($pay);
        if (!$result) {
            zibll_child_afdian_log_unmatched($order, 'payment_order_failed');
        }

        return array('ec' => 200, 'em' => '');
    }
}

// 未匹配订单留痕（避免爱发电反复重试，同时便于站长后台核查）
if (!function_exists('zibll_child_afdian_log_unmatched')) {
    function zibll_child_afdian_log_unmatched($order, $reason)
    {
        $log = get_option('zibll_child_afdian_unmatched', array());
        $log[] = array(
            'time'    => current_time('mysql'),
            'reason'  => $reason,
            'order'   => $order,
        );
        // 最多保留最近 50 条
        if (count($log) > 50) {
            $log = array_slice($log, -50);
        }
        update_option('zibll_child_afdian_unmatched', $log);
    }
}
