<?php
/**
 * 子比子主题 - 注册邮箱后缀选择
 * ─────────────────────────────────────────────────────────────
 * 目的：在父主题原生「用户邮箱限制」之外，提供一个更友好的注册体验——
 *      用户只填写邮箱前缀（@ 前面的部分），后缀从后台配置的白名单里下拉选择。
 *
 * 为什么必须走「JS 改造 DOM + 服务端前置守卫」，而不是改模板：
 *   - 父主题注册表单由 zib_signup_form()（zibll/inc/functions/zib-user.php:311）
 *     直接拼接字符串输出，**没有任何 filter 钩子**；
 *   - 注册弹窗（zib-user.php:99）与注册页（pages/user-sign.php:183）共用同一份输出；
 *   - 因此零侵入方案只能是：前端把原输入框改成「前缀输入 + 后缀下拉」，
 *     再用一个隐藏域 name="email" 提交完整地址，父主题 JS/PHP 完全不需要改。
 *
 * 服务端拦截点（不覆写任何父主题函数）：
 *   - 父主题把 zib_ajax_user_signup / zib_ajax_signup_captcha 注册在默认优先级 10；
 *     本模块注册在同名 action 的优先级 1，因此**先于**父主题执行。
 *   - 另挂 registration_errors 作第二道保险，且严格限定在
 *     「wp_doing_ajax() + action=user_signup」，避免污染后台建用户、
 *     WooCommerce 结账注册、OAuth 建号等其它注册路径。
 *
 * 与父主题原生白名单的关系：
 *   - 父主题 is_disable_email()（zib-theme.php:1978）读 user_email_out +
 *     user_email_limit_type，依旧生效，两者是**交集**。
 *   - 父主题那栏是「关键字包含匹配」，条目可以是 123123@（某个邮箱号）、
 *     gmail（任意包含串），并不等价于「域名清单」，所以本模块单独维护一份
 *     只含域名的干净清单，并提供「从父主题白名单导入」按钮减少重复填写。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// 单次最多接受多少个后缀，防止误粘贴超长内容撑爆下拉框与页面体积。
if (!defined('ZIBLL_CHILD_EMAIL_SUFFIX_MAX')) {
    define('ZIBLL_CHILD_EMAIL_SUFFIX_MAX', 50);
}

/**
 * 规范化单个后缀：去空白、去开头 @、转小写、校验字符集。
 *
 * 只接受「域名」形态，不接受整段邮箱或通配符：
 *   qq.com  -> qq.com
 *   @163.com -> 163.com
 *   123123@ -> ''（父主题里表示某个具体邮箱号，不是后缀）
 *
 * @param string $item
 * @return string 合法返回后缀，非法返回空字符串
 */
function zibll_child_email_suffix_normalize_one($item)
{
    $item = trim((string) $item);
    if ($item === '') {
        return '';
    }

    $item = ltrim($item, '@');
    $item = strtolower($item);

    if ($item === '' || strlen($item) > 253) {
        return '';
    }
    // 域名首尾必须是字母或数字，中间允许点与连字符；不允许连续点。
    if (!preg_match('/^[a-z0-9](?:[a-z0-9.\-]*[a-z0-9])?$/', $item)) {
        return '';
    }
    if (strpos($item, '..') !== false) {
        return '';
    }

    return $item;
}

/**
 * 把后台 textarea 的内容解析成后缀数组（逗号 / 中文逗号 / 空白均可分隔）。
 *
 * @param string $raw
 * @return array
 */
function zibll_child_email_suffix_parse($raw)
{
    $raw = (string) $raw;
    if ($raw === '') {
        return array();
    }

    $parts = preg_split('/[,，\s]+/u', $raw);
    if (!is_array($parts)) {
        return array();
    }

    $out = array();
    foreach ($parts as $part) {
        $suffix = zibll_child_email_suffix_normalize_one($part);
        if ($suffix !== '' && !in_array($suffix, $out, true)) {
            $out[] = $suffix;
        }
        if (count($out) >= ZIBLL_CHILD_EMAIL_SUFFIX_MAX) {
            break;
        }
    }

    return $out;
}

/**
 * 当前配置的后缀清单（整个请求只解析一次）。
 *
 * @return array
 */
function zibll_child_email_suffix_list()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cache = zibll_child_email_suffix_parse(zibll_child_get_option('email_suffix_list', ''));

    return $cache;
}

/**
 * 读取本模块的开关型配置。
 *
 * ⚠️ 为什么不用现成的 zibll_child_option_enabled()：
 *    CSF 的 switcher 关闭时保存的是**空字符串**，而 zibll_child_option_enabled()
 *    在「未设置」和「设为空」两种情况下都会回落到 $default，
 *    对 default=true 的开关会导致「关了又自动变回开启」。
 *    这里用 array_key_exists 区分「从未设置」与「明确设为空」。
 *
 * @param string $key
 * @param bool   $default
 * @return bool
 */
function zibll_child_email_suffix_flag($key, $default)
{
    $options = get_option('zibll_child_options', array());
    if (!is_array($options) || !array_key_exists($key, $options)) {
        return (bool) $default;
    }

    $v = $options[$key];
    if ($v === true || $v === 1 || $v === '1') {
        return true;
    }
    if ($v === false || $v === 0 || $v === '0' || $v === '' || $v === null) {
        return false;
    }

    return (bool) $default;
}

/**
 * 功能是否真正可用：开关开启 **且** 至少配置了一个合法后缀。
 *
 * 名称为空时视为「未配置」而不是「全部允许」——否则一次配置失误会把
 * 全站注册锁死，或让下拉框变成空壳。这是本模块最重要的兜底。
 *
 * @return bool
 */
function zibll_child_email_suffix_enabled()
{
    if (!zibll_child_email_suffix_flag('email_suffix_enable', false)) {
        return false;
    }

    return count(zibll_child_email_suffix_list()) > 0;
}

/**
 * 默认选中的后缀；未配置或不在清单内时返回空串（即默认不预选）。
 *
 * @return string
 */
function zibll_child_email_suffix_default()
{
    $default = zibll_child_email_suffix_normalize_one(zibll_child_get_option('email_suffix_default', ''));
    if ($default === '') {
        return '';
    }

    return in_array($default, zibll_child_email_suffix_list(), true) ? $default : '';
}

/**
 * 从当前请求里取出「待校验的邮箱」。
 *
 * 父主题的邮箱字段名随 captch_type 变化：
 *   email       -> name="email"
 *   email_phone -> name="email_phone"（可能是手机号）
 *   phone       -> 没有邮箱字段
 * 因此这里做兼容，并明确返回 null 表示「本次请求与邮箱无关，放行」。
 *
 * @return string|null 返回 null 表示跳过校验；返回字符串（可能为空）表示需要校验
 */
function zibll_child_email_suffix_request_email()
{
    // 父主题未开启注册验证码时，注册表单里根本没有邮箱字段，直接放行。
    if (function_exists('_pz') && !_pz('user_signup_captch')) {
        return null;
    }

    $email = isset($_REQUEST['email']) ? trim((string) wp_unslash($_REQUEST['email'])) : '';
    if ($email === '') {
        $alt = isset($_REQUEST['email_phone']) ? trim((string) wp_unslash($_REQUEST['email_phone'])) : '';
        // email_phone 模式下可能是手机号：不含 @ 且形如 11 位手机号则视为手机注册。
        if ($alt !== '' && strpos($alt, '@') === false && preg_match('/^1\d{10}$/', $alt)) {
            return null;
        }
        if ($alt !== '') {
            $email = $alt;
        }
    }

    $type = isset($_REQUEST['captcha_type']) ? sanitize_key(wp_unslash($_REQUEST['captcha_type'])) : '';
    if ($type === 'phone') {
        return null;
    }

    return $email;
}

/**
 * 校验一个完整邮箱是否符合后缀白名单。
 *
 * 注意：域名必须与白名单**严格全等**，绝不能用 strpos/stristr 做包含判断，
 *      否则 qq.com.evil.com 会被误判为合法（父主题原生实现就是包含匹配，
 *      这里不能照抄）。
 *
 * @param string $email
 * @return true|string 通过返回 true，失败返回可直接展示的中文提示
 */
function zibll_child_email_suffix_check($email)
{
    $email = trim((string) $email);

    if ($email === '') {
        return '请输入邮箱前缀';
    }
    if (strpos($email, '@') === false) {
        return '请选择邮箱后缀';
    }
    if (!is_email($email)) {
        return '邮箱格式错误';
    }

    $at     = strrpos($email, '@');
    $prefix = substr($email, 0, $at);
    $domain = strtolower(substr($email, $at + 1));

    if ($prefix === '') {
        return '请输入邮箱前缀';
    }
    if (!preg_match('/^[A-Za-z0-9._%+\-]+$/', $prefix)) {
        return '邮箱前缀只能包含字母、数字和 . _ - +';
    }

    if (!in_array($domain, zibll_child_email_suffix_list(), true)) {
        return '该邮箱后缀不在允许范围内';
    }

    return true;
}

/**
 * AJAX 前置守卫：注册与发送验证码都先过这一关。
 *
 * 优先级 1 是关键——父主题同名回调在默认优先级 10，
 * 因此这里能抢在它之前拒绝请求，且不需要覆写任何父主题函数。
 *
 * @return void
 */
function zibll_child_email_suffix_guard()
{
    if (!zibll_child_email_suffix_enabled()) {
        return;
    }

    $email = zibll_child_email_suffix_request_email();
    if ($email === null) {
        return;
    }

    $result = zibll_child_email_suffix_check($email);
    if ($result === true) {
        return;
    }

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    // 与父主题回调保持完全一致的结构，前端 zib_ajax 的 notyf 可直接弹出。
    echo wp_json_encode(array('error' => 1, 'msg' => $result, 'ys' => 'danger'));
    exit;
}
add_action('wp_ajax_nopriv_user_signup', 'zibll_child_email_suffix_guard', 1);
add_action('wp_ajax_user_signup', 'zibll_child_email_suffix_guard', 1);
add_action('wp_ajax_nopriv_signup_captcha', 'zibll_child_email_suffix_guard', 1);
add_action('wp_ajax_signup_captcha', 'zibll_child_email_suffix_guard', 1);

/**
 * 第二道保险：即使前置守卫被其它插件覆盖，也能在建号前拦下。
 *
 * ⚠️ 必须严格限定作用域。registration_errors 是 WordPress 核心过滤器，
 *    后台建用户、WooCommerce 结账注册、OAuth 建号都会经过它；
 *    不加限定会把「Google 登录用户的邮箱」等非本流程地址全部误拦。
 *
 * @param WP_Error $errors
 * @param string   $sanitized_user_login
 * @param string   $email
 * @return WP_Error
 */
function zibll_child_email_suffix_registration_errors($errors, $sanitized_user_login = '', $email = '')
{
    if (!zibll_child_email_suffix_enabled() || !is_wp_error($errors)) {
        return $errors;
    }
    if (!wp_doing_ajax()) {
        return $errors;
    }

    $action = isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '';
    if ($action !== 'user_signup') {
        return $errors;
    }

    // 手机号注册时父主题传进来的 $email 是空串（字段名是 email_phone），
    // 这种情况交给父主题自己的逻辑，不能在这里判成「未填邮箱前缀」。
    $email = is_string($email) ? trim($email) : '';
    if ($email === '') {
        return $errors;
    }
    if (strpos($email, '@') === false && preg_match('/^1\d{10}$/', $email)) {
        return $errors;
    }

    $result = zibll_child_email_suffix_check($email);
    if ($result !== true) {
        $errors->add('zibll_child_email_suffix', $result);
    }

    return $errors;
}
add_filter('registration_errors', 'zibll_child_email_suffix_registration_errors', 10, 3);

/**
 * 登记前台资源。
 *
 * 只在功能真正可用时加载；依赖父主题样式里的 CSS 变量做配色，
 * 不额外引入任何框架。
 *
 * @return void
 */
function zibll_child_email_suffix_assets()
{
    if (!zibll_child_email_suffix_enabled()) {
        return;
    }

    $uri  = get_stylesheet_directory_uri() . '/assets/';
    $dir  = get_stylesheet_directory() . '/assets/';
    $ver  = wp_get_theme()->get('Version');

    // ⚠️ 这两个资源可能在不升主题版本的情况下单独更新（热修复/试用），
    //    若沿用主题版本号做 ver，浏览器与 CDN 会继续命中旧缓存。
    //    这里用文件修改时间做版本号，改一次就自动换 URL。
    // 下拉组件的样式与登录模块共用 suffix-picker.css，避免两套视觉各自漂移。
    $css_file = $dir . 'css/suffix-picker.css';
    $js_file  = $dir . 'js/email-suffix.js';
    $css_ver  = file_exists($css_file) ? $ver . '.' . filemtime($css_file) : $ver;
    $js_ver   = file_exists($js_file) ? $ver . '.' . filemtime($js_file) : $ver;

    wp_enqueue_style('zc-suffix-picker', $uri . 'css/suffix-picker.css', array(), $css_ver);
    wp_enqueue_script('zc-email-suffix', $uri . 'js/email-suffix.js', array(), $js_ver, true);

    wp_localize_script('zc-email-suffix', 'ZC_EMAIL_SUFFIX', array(
        'suffixes' => zibll_child_email_suffix_list(),
        'default'  => zibll_child_email_suffix_default(),
        'i18n'     => array(
            'choose'      => '选择后缀',
            'prefix'      => '邮箱前缀',
            'needPrefix'  => '请输入邮箱前缀',
            'needSuffix'  => '请选择邮箱后缀',
            'badPrefix'   => '邮箱前缀只能包含字母、数字和 . _ - +',
            'badSuffix'   => '该邮箱后缀不在允许范围内',
        ),
    ));
}
add_action('wp_enqueue_scripts', 'zibll_child_email_suffix_assets', 30);

/**
 * 读取父主题已配置的邮箱白名单，筛出其中「形如域名」的条目。
 *
 * 父主题字段：
 *   zibll_options['user_email_limit_type'] = 'allow' | 'not'
 *   zibll_options['user_email_out']        = 逗号/换行分隔的关键字
 *
 * 只提取 @qq.com、qq.com 这类条目；123123@（具体邮箱号）、
 * gmail（任意包含串）不是后缀，跳过。
 *
 * @return array{type:string,list:array}
 */
function zibll_child_email_suffix_parent_suffixes()
{
    $options = get_option('zibll_options', array());
    if (!is_array($options)) {
        return array('type' => 'not', 'list' => array());
    }

    $type = isset($options['user_email_limit_type']) ? (string) $options['user_email_limit_type'] : 'not';
    $raw  = isset($options['user_email_out']) ? (string) $options['user_email_out'] : '';

    $list = array();
    if ($raw !== '') {
        $parts = preg_split('/[,，\s]+/u', $raw);
        if (is_array($parts)) {
            foreach ($parts as $part) {
                $part = trim($part);
                if ($part === '') {
                    continue;
                }
                if (strpos($part, '@') === 0) {
                    $part = substr($part, 1);
                } elseif (strpos($part, '@') !== false) {
                    continue;
                }

                $suffix = zibll_child_email_suffix_normalize_one($part);
                if ($suffix !== '' && !in_array($suffix, $list, true)) {
                    $list[] = $suffix;
                }
            }
        }
    }

    return array('type' => $type, 'list' => $list);
}

/**
 * 后台「从父主题白名单导入」区块的 HTML（供 CSF content 字段使用）。
 *
 * @return string
 */
function zibll_child_email_suffix_import_html()
{
    $parent   = zibll_child_email_suffix_parent_suffixes();
    $is_allow = $parent['type'] === 'allow';
    $list     = $parent['list'];

    $html  = '<div class="zic-es-import" style="margin-top:4px;padding:12px 14px;border:1px solid #e5e5e5;border-radius:6px;background:#fafafa;">';
    $html .= '<p style="margin:0 0 8px;font-weight:500;">从父主题导入（可选，一次操作）</p>';

    if ($is_allow && $list) {
        $preview = array();
        foreach ($list as $suffix) {
            $preview[] = '@' . $suffix;
        }
        $html .= '<p style="margin:0 0 8px;color:#646970;font-size:12px;">'
            . '检测到父主题（zibll主题设置 → 用户 → 用户邮箱限制）已开启白名单模式，'
            . '其中可识别的邮箱后缀共 <b>' . count($list) . '</b> 个：</p>';
        $html .= '<p style="margin:0 0 10px;font-size:12px;word-break:break-all;">'
            . '<code>' . esc_html(implode('  ', $preview)) . '</code></p>';
        $html .= '<button type="button" class="button button-secondary" id="zic-es-import">'
            . '把这些后缀填入上方清单</button>';
    } elseif ($is_allow) {
        $html .= '<p style="margin:0;color:#646970;font-size:12px;">'
            . '父主题已开启白名单模式，但其中没有形如 <code>@qq.com</code> 的后缀条目，暂无可导入内容。</p>';
    } else {
        $html .= '<p style="margin:0;color:#646970;font-size:12px;">'
            . '父主题当前是「黑名单模式」（或未设置），没有可直接导入的后缀。'
            . '如需导入，请先在父主题里把限制方式改为「白名单模式」并填写 <code>@qq.com</code> 这类条目。</p>';
    }

    $html .= '<p style="margin:10px 0 0;color:#8c8f94;font-size:12px;">'
        . '两者是<b>交集</b>关系：本清单只决定下拉框里能选什么，父主题白名单仍会在提交时再校验一次。'
        . '若本清单比父主题更宽，用户会被父主题拦下并提示「邮箱非法或为禁止的邮箱格式」。</p>';
    $html .= '</div>';

    return $html;
}

/**
 * 后台导入按钮的脚本。
 *
 * ⚠️ 不写在 CSF 的 content 字段里：CSF 会丢弃其中的 <script> 标签。
 *    统一挂到 admin_print_footer_scripts，并限定只在子主题设置页输出。
 *
 * @return void
 */
function zibll_child_email_suffix_admin_script()
{
    $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
    if ($page !== 'zibll_child_options') {
        return;
    }

    $parent = zibll_child_email_suffix_parent_suffixes();
    if ($parent['type'] !== 'allow' || !$parent['list']) {
        return;
    }
    ?>
    <script>
    (function () {
        var btn = document.getElementById('zic-es-import');
        if (!btn) { return; }

        var incoming = <?php echo wp_json_encode(array_values($parent['list'])); ?>;

        btn.addEventListener('click', function () {
            var area = document.querySelector('textarea[name*="email_suffix_list"]');
            if (!area) {
                window.alert('未找到后缀输入框，请刷新页面后重试。');
                return;
            }

            var current = area.value.split(/[\s,，]+/).filter(function (s) { return s !== ''; });
            var added = 0;

            incoming.forEach(function (suffix) {
                if (current.indexOf(suffix) === -1) {
                    current.push(suffix);
                    added++;
                }
            });

            area.value = current.join('\n');
            area.dispatchEvent(new Event('input', { bubbles: true }));
            area.dispatchEvent(new Event('change', { bubbles: true }));
            btn.disabled = true;
            btn.textContent = added > 0 ? ('已导入 ' + added + ' 个后缀，请点击页面底部「保存」') : '没有新增内容';
        });
    })();
    </script>
    <?php
}
add_action('admin_print_footer_scripts', 'zibll_child_email_suffix_admin_script');
