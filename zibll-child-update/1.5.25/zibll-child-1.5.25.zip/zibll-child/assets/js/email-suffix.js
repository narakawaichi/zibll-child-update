/**
 * 子比子主题 - 注册邮箱后缀选择（前端）
 *
 * 做的事：
 *   1. 把父主题注册表单里的邮箱输入框改成「前缀输入 + 后缀下拉」；
 *   2. 用一个隐藏域 name="email" 实时同步完整地址 —— 父主题
 *      zib_ajax() 走 form.serializeObject()，因此父主题 JS / PHP 都不用改；
 *   3. 点击「注册」或「发送验证码」前做一次前端校验，给出明确提示。
 *
 * 为什么不用原生 <select>：
 *   原生下拉弹层由浏览器绘制，无法改样式（白底方框 + 系统蓝高亮），
 *   在注册弹窗里会盖住密码框、与主题完全割裂。这里改为挂在 body 上的
 *   自定义面板（position:fixed），既能跟随主题配色，也不会被弹窗容器裁剪。
 *
 * 不改父主题任何文件；不依赖 jQuery（有则复用其动画能力）。
 *
 * @package zibll-child
 */
(function () {
    'use strict';

    var CFG = window.ZC_EMAIL_SUFFIX;
    if (!CFG || !CFG.suffixes || !CFG.suffixes.length) {
        return;
    }

    var I18N = CFG.i18n || {};

    // 只处理注册表单。找回密码表单（#tab-resetpassword）用的是同一个
    // zib_get_sign_captch()，也会出现 input[name="email"]，绝不能误伤。
    var FORM_SELECTOR = '#tab-sign-up form, #tab-signup-signup form, form#sign-up';
    // ⚠️ 必须限定 type="text"：本模块自己会插入 <input type="hidden" name="email">，
    //    若用 input[name="email"] 会把隐藏域也当成邮箱框再次改造，
    //    MutationObserver 与改造互相触发 → 下拉框被无限复制。
    var FIELD_SELECTOR = 'input[type="text"][name="email"], input[type="text"][name="email_phone"]';

    // '@qq.com' -> 'qq.com'，用于识别浏览器自动填充的完整邮箱。
    var SUFFIX_MAP = Object.create(null);
    CFG.suffixes.forEach(function (suffix) {
        SUFFIX_MAP['@' + suffix] = suffix;
    });

    var opened = null; // 当前展开的 { trigger, menu }

    function tip(message) {
        if (typeof window.notyf === 'function') {
            window.notyf(message, 'danger');
        } else {
            window.alert(message);
        }
    }

    /**
     * 父主题靠 input[change-show] 的「值长度 > 5」来滑出验证码区域。
     * 用户只填前缀时长度可能不足 5，导致验证码框永远不出现，
     * 所以这里按「完整地址长度」主动兜一次。
     */
    function revealCaptcha(form) {
        var panel = form.querySelector('.change-show');
        if (!panel) {
            return;
        }

        if (window.jQuery && window.jQuery.fn && window.jQuery.fn.slideDown) {
            var $panel = window.jQuery(panel);
            if ($panel.is(':hidden')) {
                $panel.slideDown();
            }
            return;
        }

        if (!panel.style.display || panel.style.display === 'none') {
            panel.style.display = 'block';
        }
    }

    function closeMenu() {
        if (!opened) {
            return;
        }
        opened.menu.style.display = 'none';
        opened.trigger.setAttribute('aria-expanded', 'false');
        opened.wrap.classList.remove('is-open');
        opened = null;
    }

    function placeMenu(trigger, menu) {
        var rect = trigger.getBoundingClientRect();
        var width = Math.max(rect.width, 132);

        menu.style.display = 'block';
        menu.style.visibility = 'hidden';
        menu.style.width = width + 'px';

        var height = menu.offsetHeight;
        var left = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 8));
        var top = rect.bottom + 6;

        // 下方放不下且上方有空间 → 向上展开
        if (top + height > window.innerHeight - 8 && rect.top - height - 6 > 8) {
            top = rect.top - height - 6;
        }

        menu.style.left = left + 'px';
        menu.style.top = top + 'px';
        menu.style.visibility = '';
    }

    function selectSuffix(zic, value) {
        zic.suffix = value;
        zic.valueEl.textContent = value || (I18N.choose || '选择后缀');
        zic.valueEl.classList.toggle('is-placeholder', !value);
        zic.trigger.title = value || '';

        var items = zic.menu.querySelectorAll('.zic-es-item');
        for (var i = 0; i < items.length; i++) {
            var active = items[i].getAttribute('data-value') === value;
            items[i].classList.toggle('is-active', active);
            items[i].setAttribute('aria-selected', active ? 'true' : 'false');
        }

        zic.sync();
    }

    function bindMenu(zic) {
        var item = zic.menu.querySelector('.zic-es-item[data-value="' + zic.suffix + '"]');
        if (item) {
            zic.menu.scrollTop = Math.max(0, item.offsetTop - zic.menu.clientHeight / 2);
        }
    }

    function buildMenu(zic) {
        var menu = document.createElement('div');
        menu.className = 'zic-es-menu';
        menu.setAttribute('role', 'listbox');

        CFG.suffixes.forEach(function (suffix) {
            var value = '@' + suffix;
            var item = document.createElement('button');
            item.type = 'button';
            item.className = 'zic-es-item';
            item.setAttribute('role', 'option');
            item.setAttribute('data-value', value);
            item.textContent = value;

            item.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                selectSuffix(zic, value);
                closeMenu();
            });

            menu.appendChild(item);
        });

        document.body.appendChild(menu);
        return menu;
    }

    function toggleMenu(zic) {
        if (opened && opened.trigger === zic.trigger) {
            closeMenu();
            return;
        }
        closeMenu();

        zic.menu = zic.menu || buildMenu(zic);
        placeMenu(zic.trigger, zic.menu);

        zic.trigger.setAttribute('aria-expanded', 'true');
        zic.wrap.classList.add('is-open');
        bindMenu(zic);
        opened = { trigger: zic.trigger, menu: zic.menu, wrap: zic.wrap };
    }

    function enhance(input) {
        if (!input || input.dataset.zicEmail === '1' || !input.parentNode) {
            return;
        }
        if (input.type === 'hidden') {
            return;
        }

        var form = input.form || input.closest('form');
        if (!form) {
            return;
        }

        input.dataset.zicEmail = '1';
        input.dataset.zicOrigName = input.getAttribute('name') || 'email';

        // 移除 name：避免把「半截前缀」也当成 email 提交上去。
        input.removeAttribute('name');
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('spellcheck', 'false');
        input.setAttribute('maxlength', '64');
        input.classList.add('zic-email-prefix');

        var holder = input.parentNode;
        var placeholder = holder.querySelector('.scale-placeholder');
        if (placeholder) {
            placeholder.textContent = I18N.prefix || '邮箱前缀';
        }

        var hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'email';

        var wrap = document.createElement('span');
        wrap.className = 'zic-es';

        var trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'zic-es-trigger';
        trigger.setAttribute('aria-haspopup', 'listbox');
        trigger.setAttribute('aria-expanded', 'false');

        var valueEl = document.createElement('span');
        valueEl.className = 'zic-es-value is-placeholder';
        valueEl.textContent = I18N.choose || '选择后缀';

        var caret = document.createElement('i');
        caret.className = 'zic-es-caret';
        caret.setAttribute('aria-hidden', 'true');

        trigger.appendChild(valueEl);
        trigger.appendChild(caret);
        wrap.appendChild(trigger);

        holder.insertBefore(hidden, input.nextSibling);
        holder.insertBefore(wrap, hidden.nextSibling);

        var zic = {
            input: input,
            hidden: hidden,
            wrap: wrap,
            trigger: trigger,
            valueEl: valueEl,
            menu: null,
            suffix: CFG.default ? '@' + CFG.default : ''
        };

        trigger.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            toggleMenu(zic);
        });

        // 键盘可达性：Esc 关闭，上下箭头在面板内移动焦点
        trigger.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                closeMenu();
            }
        });

        zic.sync = function () {
            var raw = input.value.trim();

            // 浏览器密码管理器常把完整邮箱灌进来：能匹配白名单后缀就自动拆分。
            if (raw.indexOf('@') > -1) {
                var at = raw.lastIndexOf('@');
                var suffix = raw.slice(at).toLowerCase();
                if (SUFFIX_MAP[suffix]) {
                    input.value = raw.slice(0, at);
                    if (zic.suffix !== suffix) {
                        zic.suffix = suffix;
                        zic.valueEl.textContent = suffix;
                        zic.valueEl.classList.remove('is-placeholder');
                        var items = zic.menu ? zic.menu.querySelectorAll('.zic-es-item') : [];
                        for (var i = 0; i < items.length; i++) {
                            items[i].classList.toggle('is-active', items[i].getAttribute('data-value') === suffix);
                        }
                    }
                }
            }

            var rawNow = input.value.trim();
            if (rawNow === '') {
                hidden.value = '';
            } else if (zic.suffix) {
                var pos = rawNow.lastIndexOf('@');
                hidden.value = (pos > -1 ? rawNow.slice(0, pos) : rawNow) + zic.suffix;
            } else {
                hidden.value = rawNow;
            }

            if (hidden.value.length > 5) {
                revealCaptcha(form);
            }
        };

        // 初始化显示
        if (zic.suffix) {
            valueEl.textContent = zic.suffix;
            valueEl.classList.remove('is-placeholder');
            trigger.title = zic.suffix;
        }

        input.__zicES = zic;

        input.addEventListener('input', zic.sync);
        input.addEventListener('change', zic.sync);
        input.addEventListener('blur', zic.sync);

        zic.sync();
    }

    /**
     * 校验一个已改造的表单；返回 {ok:boolean, msg?:string}。
     */
    function validate(form) {
        var input = form.querySelector('input.zic-email-prefix');
        if (!input) {
            return { ok: true };
        }

        var zic = input.__zicES;
        if (!zic) {
            return { ok: true };
        }

        var raw = input.value.trim();
        var full = zic.hidden.value;

        if (raw === '') {
            return { ok: false, msg: I18N.needPrefix || '请输入邮箱前缀' };
        }
        if (!zic.suffix && full.indexOf('@') === -1) {
            return { ok: false, msg: I18N.needSuffix || '请选择邮箱后缀' };
        }

        var at = full.lastIndexOf('@');
        if (at === -1) {
            return { ok: false, msg: I18N.needSuffix || '请选择邮箱后缀' };
        }

        var local = full.slice(0, at);
        var domain = full.slice(at + 1).toLowerCase();

        if (local === '') {
            return { ok: false, msg: I18N.needPrefix || '请输入邮箱前缀' };
        }
        if (!/^[A-Za-z0-9._%+\-]+$/.test(local)) {
            return { ok: false, msg: I18N.badPrefix || '邮箱前缀只能包含字母、数字和 . _ - +' };
        }
        if (CFG.suffixes.indexOf(domain) === -1) {
            return { ok: false, msg: I18N.badSuffix || '该邮箱后缀不在允许范围内' };
        }

        return { ok: true };
    }

    /**
     * 提交前拦截。
     *
     * 必须用「捕获阶段」：父主题的 .signsubmit-loader / .captchsubmit
     * 是 jQuery 委托在 body 上的冒泡处理器，捕获阶段先执行，
     * 这样 preventDefault + stopPropagation 才能真正阻止它发出请求。
     */
    document.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.closest) {
            return;
        }

        // 点面板外部关闭
        if (opened && !target.closest('.zic-es') && !target.closest('.zic-es-menu')) {
            closeMenu();
        }

        var button = target.closest('.signsubmit-loader, .captchsubmit');
        if (!button) {
            return;
        }

        var form = button.closest('form');
        if (!form || !form.querySelector('input.zic-email-prefix')) {
            return;
        }

        var result = validate(form);
        if (!result.ok) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) {
                event.stopImmediatePropagation();
            }
            tip(result.msg);
        }
    }, true);

    // 弹窗滚动/窗口尺寸变化时，面板位置会失效，直接收起。
    // ⚠️ 面板自身的滚动要放行，否则列表稍长就滚不动（一滚就关）。
    window.addEventListener('scroll', function (event) {
        var target = event.target;
        if (target && target.closest && target.closest('.zic-es-menu')) {
            return;
        }
        closeMenu();
    }, true);
    window.addEventListener('resize', closeMenu);
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closeMenu();
        }
    });

    function scan() {
        var forms = document.querySelectorAll(FORM_SELECTOR);
        for (var i = 0; i < forms.length; i++) {
            var fields = forms[i].querySelectorAll(FIELD_SELECTOR);
            for (var j = 0; j < fields.length; j++) {
                enhance(fields[j]);
            }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', scan);
    } else {
        scan();
    }

    // 兜底：第三方插件或主题异步插入注册表单时，重新扫描一次。
    if (window.MutationObserver) {
        var scheduled = false;
        var observer = new MutationObserver(function () {
            if (scheduled) {
                return;
            }
            scheduled = true;
            window.setTimeout(function () {
                scheduled = false;
                scan();
            }, 60);
        });

        observer.observe(document.body || document.documentElement, {
            childList: true,
            subtree: true
        });
    }
})();
