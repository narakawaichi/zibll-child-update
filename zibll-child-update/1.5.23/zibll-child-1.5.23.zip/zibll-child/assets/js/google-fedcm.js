/**
 * 子比子主题 - Google 一键登录（FedCM）前端
 * ─────────────────────────────────────────────────────────────
 * 目标体验：用户在登录框点「Google 登录」→ Chrome / Edge 顶部弹出【浏览器原生】
 * 的 Google 账号选择器 → 亲手选一个账号 → 直接登录本站。
 * 不跳 Google 授权页、不跳本站绑定页、也不静默自动登录。
 *
 * ★★ 坑一：FedCM 的开关不在 renderButton() 里 ★★
 *   官方 JS 参考（js-reference / fedcm-migration 原文）：
 *     「set use_fedcm_for_button to true in the **IdConfiguration** object
 *       to enable FedCM Button flow.」
 *   即 use_fedcm_for_button / button_auto_select 都是 google.accounts.id.initialize()
 *   的配置项。renderButton() 只吃视觉与行为参数（type / theme / size / text /
 *   shape / logo_alignment / width / locale / click_listener / state），
 *   多塞的字段会被 GIS **静默忽略、不报错**。
 *   → v1.5.22 把这两个参数写进了 renderButton()，等于没写：按钮回退到旧的
 *     非 FedCM 流程，那条流程对已授权用户会直接放行，所以点了就登录、没有弹窗。
 *
 * ★★ 坑二：父主题原生 Google 按钮是 302 跳转，本身就会静默登录 ★★
 *   父主题 zib_social_login()（inc/functions/functions.php:1363）输出的 Google 按钮是
 *   <a href="/oauth/google">，走 OAuth2 授权码流程；其授权 URL 由
 *   oauth/sdk/google/OAuth2.php::getAuthUrl() 拼装，**没有 prompt=select_account**。
 *   Google 对「已授权过」的应用会静默自动批准 → 回访用户点一下直接进站，
 *   没有任何账号选择器。这正是共享电脑 / 误触 / 纠纷场景下最危险的行为。
 *   → 故 FedCM 可用时，本模块把 FedCM 按钮**原位替换**掉那个图标：
 *     外观、尺寸、位置与父主题一致，用户点击手感不变，但点击行为变成
 *     「弹浏览器原生账号选择器」。父主题图标只在 FedCM 不可用时保留。
 *
 * ★★ 账号选择器：两道自动登录开关都显式关掉 ★★
 *   Google 有两个互相独立的「自动选择」，都在 initialize() 里：
 *     · auto_select        —— One Tap 自动登录。官方原文：开启后系统「会自动返回
 *                            用户的 ID 令牌凭据，而无需用户进行任何互动」。
 *     · button_auto_select —— FedCM 按钮流自动登录。官方原文：开启后「具有有效
 *                            Google 会话的回访用户将自动登录，略过账号选择器提示」。
 *   两道都显式写 false（而不是依赖默认值）：① 语义自解释，后人看到「默认 false」
 *   不会随手删掉；② Google 万一变更默认值，这两行仍能锁住行为。
 *   → 效果：任何情况下都必须用户亲手在账号选择器里点一次。
 *
 * 降级链路（Firefox / Safari / iOS —— window.FedCM 不存在）：
 *   ① 页面里有父主题原生 Google 图标 → **完全不动 DOM**，让图标继续走 302。
 *      浏览器不具备这个能力时不该硬凑，但功能不缺失。
 *   ② 页面里没有任何 Google 入口（例如社交登录栏被第三方插件接管）→ 输出一个
 *      指向父主题 302 的文字链接，绝不让用户遇到「点了没反应」。
 */
(function () {
    'use strict';

    var cfg = window.zibllChildFedcm;
    if (!cfg || !cfg.clientId || !cfg.endpoint) { return; }

    // 模板容器（PHP 输出）。FedCM 可用时它的内容会被克隆到社交登录栏里；
    // 不可用且页面无 Google 入口时，它自己就是那个降级链接。
    var tpl = document.getElementById('zibll-fedcm-wrap');
    if (!tpl) { return; }

    var fallbackUrl = cfg.fallbackUrl || '';
    var fedcmVersion = cfg.version || '';

    function log() {
        if (cfg.debug && window.console && console.log) {
            console.log.apply(console, ['[zibll-child fedcm]'].concat([].slice.call(arguments)));
        }
    }

    // ── 1. 提交 ID Token ─────────────────────────────────────
    var submitting = false;

    function submit(credential) {
        if (!credential || submitting) { return; }
        submitting = true;
        log('got credential');

        // 端点字段名必须是 token（不是 GIS 回调里的 credential）
        var body = new URLSearchParams();
        body.set('token', credential);
        body.set('nonce', cfg.nonce || '');

        fetch(cfg.endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: body.toString()
        }).then(function (res) {
            // 端点成功时是 302 跳转，fetch 会跟随并拿到最终页面 HTML。
            // 失败时输出的是带说明的 wp_die 页面（非 JSON），故不解析 body，
            // 直接按状态码决定去留。
            log('endpoint status', res.status, res.url);
            if (res.redirected || res.ok) {
                window.location.href = res.url || cfg.endpoint;
                return;
            }
            submitting = false;
            showFallback();
        }).catch(function (err) {
            log('submit failed', err);
            submitting = false;
            showFallback();
        });
    }

    // ── 2. 部署：把 FedCM 按钮注入父主题的社交登录栏 ─────────
    // 父主题登录框/弹窗/评论区的社交登录都用 .social_loginbar 包裹，
    // 其中原生 Google 图标类名为 .social-login-item.google。
    var NATIVE_GOOGLE = '.social-login-item.google';

    function findBars() {
        var list = document.querySelectorAll('.social_loginbar');
        return Array.prototype.slice.call(list);
    }

    function findNativeGoogle(bar) {
        return bar.querySelector(NATIVE_GOOGLE);
    }

    function hasAnyNativeGoogle() {
        return document.querySelectorAll(NATIVE_GOOGLE).length > 0;
    }

    /**
     * 把模板克隆一份塞进社交登录栏，替换掉原生 Google 图标。
     * 返回 {box, slot, fallback}；该栏已处理过则返回 null。
     */
    function injectIntoBar(bar) {
        if (bar.getAttribute('data-fedcm-done') === '1') { return null; }

        var native = findNativeGoogle(bar);
        if (!native) { return null; }

        bar.setAttribute('data-fedcm-done', '1');

        var box = tpl.cloneNode(true);
        box.removeAttribute('id');
        box.hidden = false;
        box.className += ' zibll-fedcm-inline';
        box.setAttribute('data-fedcm-ver', fedcmVersion);

        var slot = box.querySelector('.zibll-fedcm-slot');
        var fb = box.querySelector('.zibll-fedcm-fallback');
        var fbLink = box.querySelector('.zibll-fedcm-fallback-link');

        if (fb) { fb.hidden = true; }
        if (fbLink && fallbackUrl) { fbLink.setAttribute('href', fallbackUrl); }

        // 插到原生图标之后（保留社交栏的排列顺序），并把原生图标收起来，
        // 免得用户点到那个「点了就静默登录」的 302 入口。
        if (native.parentNode) {
            native.parentNode.insertBefore(box, native.nextSibling);
        } else {
            bar.appendChild(box);
        }
        native.setAttribute('data-fedcm-shadow', '1');
        if (native.style) { native.style.display = 'none'; }

        return { box: box, slot: slot, fallback: fb };
    }

    /**
     * FedCM 不可用且页面上没有任何 Google 入口时的兜底：
     * 把模板里的 302 链接插到登录框里（找不到就留在页脚原位）。
     */
    function showFallback() {
        var fb = tpl.querySelector('.zibll-fedcm-fallback');
        var fbLink = tpl.querySelector('.zibll-fedcm-fallback-link');
        if (fbLink && fallbackUrl) { fbLink.setAttribute('href', fallbackUrl); }

        if (!hasAnyNativeGoogle()) {
            var signBox = document.getElementById('sign-in');
            if (signBox && !tpl.parentNode) {
                signBox.appendChild(tpl);
            }
            tpl.hidden = false;
            if (fb) { fb.hidden = false; }
        } else {
            // 已有原生图标承担降级职责，本模块不重复输出，避免同一处两个入口
            tpl.hidden = true;
        }
    }

    // ── 3. 初始化 GIS ────────────────────────────────────────
    function init(google) {
        if (!google || !google.accounts || !google.accounts.id) {
            showFallback();
            return;
        }

        // 浏览器不支持 FedCM → 交回父主题原生 302 入口，不做无谓渲染
        if (typeof window.FedCM === 'undefined') {
            log('FedCM unsupported by this browser');
            showFallback();
            return;
        }

        var initCfg = {
            client_id: cfg.clientId,
            callback: submit,

            // ★ 开启 FedCM 按钮流：账号选择器交由浏览器代管，不依赖第三方 Cookie。
            //   不需要任何 Google 白名单（GIS 已于 2024-04 全量迁移，新应用一律开启）。
            //   ⚠️ 必须在 initialize() 里，写进 renderButton() 会被静默忽略。
            use_fedcm_for_button: true,

            // ★★ 关键：显式关掉「按钮流自动选择」★★
            //   官方原文：「启用后，具有有效 Google 会话的回访用户将自动登录，
            //   略过账号选择器提示。」即回访用户点按钮会直接进站。
            //   本站要求「必须用户亲手确认是哪个账号」，故锁死 false。
            button_auto_select: false,

            // ★ 关闭 One Tap「自动登录」：开启后系统会自动返回 ID 令牌凭据，
            //   而无需用户进行任何互动。同样锁死。
            auto_select: false,

            // 一次性 nonce，服务端校验后即作废，防重放
            nonce: cfg.nonce || undefined,

            // 点弹窗外关闭 One Tap
            cancel_on_tap_outside: true
        };
        if (cfg.hd) {
            // 限定 Google Workspace 域名（服务端会再校验一次，前端只提前筛选）
            initCfg.hd = cfg.hd;
        }

        try {
            google.accounts.id.initialize(initCfg);
        } catch (e) {
            log('initialize failed', e);
            showFallback();
            return;
        }

        // ── 4. 渲染按钮 ──
        // 用 icon 形态替换父主题那个图标：尺寸/形状与原生一致，视觉无变化，
        // 但点击走 FedCM 账号选择器而非 302 静默登录。
        var deployed = 0;
        var bars = findBars();
        for (var i = 0; i < bars.length; i++) {
            var target = injectIntoBar(bars[i]);
            if (!target || !target.slot) { continue; }
            if (target.box.getAttribute('data-fedcm-rendered') === '1') { continue; }
            try {
                google.accounts.id.renderButton(target.slot, {
                    type: 'icon',
                    theme: document.body.classList.contains('dark-theme') ? 'filled_black' : 'outline',
                    size: 'large',
                    shape: 'circle',
                    text: cfg.text || '使用 Google 账号登录'
                });
                target.box.setAttribute('data-fedcm-rendered', '1');
                deployed++;
            } catch (e2) {
                log('renderButton failed', e2);
                // 渲染失败就把原生图标放回去，宁可走 302 也不能让用户没得用
                var shadow = bars[i].querySelector('[data-fedcm-shadow]');
                if (shadow && shadow.style) { shadow.style.display = ''; }
                var bad = target.box;
                if (bad.parentNode) { bad.parentNode.removeChild(bad); }
                bars[i].removeAttribute('data-fedcm-done');
            }
        }

        if (deployed === 0) {
            // 页面里没有社交登录栏（例如只有默认登录框）→ 用模板自身的容器
            var self = { slot: tpl.querySelector('.zibll-fedcm-slot') };
            var selfSlot = self.slot;
            if (selfSlot) {
                try {
                    google.accounts.id.renderButton(selfSlot, {
                        type: 'standard',
                        theme: document.body.classList.contains('dark-theme') ? 'filled_black' : 'outline',
                        size: 'large',
                        text: cfg.text || '使用 Google 账号登录',
                        width: Math.min(320, Math.max(200, tpl.offsetWidth || 280))
                    });
                    tpl.hidden = false;
                    var tplFb = tpl.querySelector('.zibll-fedcm-fallback');
                    if (tplFb) { tplFb.hidden = true; }
                    deployed = 1;
                } catch (e3) {
                    log('standalone renderButton failed', e3);
                }
            }
        }

        if (deployed === 0) {
            showFallback();
            return;
        }
        log('button rendered via fedcm, count=' + deployed + ', auto_select disabled');

        // ── 5. 可选：自动弹窗 ──
        // 首次访问常因 Chrome 手势策略不弹，属官方已知行为，不影响按钮可用。
        if (cfg.autoPrompt) {
            try {
                google.accounts.id.prompt(function () {
                    // FedCM 下 moment 通知已精简，这里只做日志，不承载任何逻辑
                    log('prompt moment');
                });
            } catch (e4) {
                log('prompt failed', e4);
            }
        }
    }

    // ── 6. 加载 GIS + 观察动态插入的登录框 ───────────────────
    function load() {
        if (window.google && window.google.accounts && window.google.accounts.id) {
            init(window.google);
            watch();
            return;
        }
        if (typeof window.FedCM === 'undefined') {
            log('FedCM unsupported by this browser');
            showFallback();
            watch();
            return;
        }

        var s = document.createElement('script');
        s.src = 'https://accounts.google.com/gsi/client';
        s.async = true;
        s.defer = true;
        s.onload = function () {
            init(window.google);
            watch();
        };
        s.onerror = function () {
            log('GIS script failed to load');
            showFallback();
        };
        document.head.appendChild(s);
    }

    /**
     * 子主题的登录框是 AJAX 弹窗、评论区的登录框也是动态插入的，
     * 首次 load() 时页面上往往还没有 .social_loginbar。
     * 故监听后续插入，把 FedCM 按钮补进新出现的社交登录栏。
     */
    var watching = false;
    function watch() {
        if (watching || typeof window.MutationObserver === 'undefined') { return; }
        watching = true;

        var pending = false;
        var mo = new MutationObserver(function () {
            if (pending) { return; }
            pending = true;
            // 合并同一批 DOM 变更，避免频繁重排
            window.requestAnimationFrame(function () {
                pending = false;
                if (typeof window.FedCM === 'undefined') { return; }
                if (!window.google || !window.google.accounts || !window.google.accounts.id) { return; }

                var bars = findBars();
                for (var i = 0; i < bars.length; i++) {
                    if (bars[i].getAttribute('data-fedcm-done') === '1') { continue; }
                    var target = injectIntoBar(bars[i]);
                    if (!target || !target.slot) { continue; }
                    try {
                        window.google.accounts.id.renderButton(target.slot, {
                            type: 'icon',
                            theme: document.body.classList.contains('dark-theme') ? 'filled_black' : 'outline',
                            size: 'large',
                            shape: 'circle',
                            text: cfg.text || '使用 Google 账号登录'
                        });
                        target.box.setAttribute('data-fedcm-rendered', '1');
                        log('button injected into late social bar');
                    } catch (e) {
                        log('late renderButton failed', e);
                    }
                }
            });
        });

        mo.observe(document.body, { childList: true, subtree: true });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', load);
    } else {
        load();
    }
})();