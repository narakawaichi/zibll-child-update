/**
 * 子比子主题 - 悬停面板快捷按钮替换（用户区 / 管理员区 双区域）
 *
 * ── v1.5.20 修复的根因 ──────────────────────────────────────────────
 * 父主题 zib_header_user_box() 登录态下输出的是**两行** .header-user-href：
 *   第 1 行（zib-header.php:238-249）用户区：用户中心 / 我的订单 / 发布文章 / 退出登录
 *   第 2 行（zib-header.php:251-258）仅 is_super_admin()：主题设置 / 模块布局 / 商城中心 / 后台管理
 * v1.5.9~1.5.19 用 $('.sub-user-box .header-user-href') 选中**全部**匹配
 * （桌面盒 + 移动盒，各 2 行 = 4 个）后逐个 box.html(newHtml) 整块覆盖，
 * 于是「改用户区」把管理员原生那四个按钮一起覆盖掉了 —— 用户报的「污染」。
 *
 * ── v1.5.20 做法 ────────────────────────────────────────────────────
 * 改为**按区域定向替换**：遍历每个 .sub-user-box，盒内
 *   第 1 个 .header-user-href（.eq(0)）→ 用户区，用 userHtml 替换
 *   第 2 个 .header-user-href（.eq(1)）→ 管理员区，用 adminHtml 替换；不存在就跳过
 * 对应内容为空串（该区开关关闭）时**跳过不动**，完整保留父主题原生按钮。
 * 退出登录兜底只作用于用户区，且只在**该盒自己的第 1 行**里取原始节点，避免跨盒取值。
 */
(function ($) {
    'use strict';

    function zcReplaceUserBox() {
        var cfg = window.ZIBLL_CHILD_USER_BOX;
        if (!cfg) {
            return;
        }

        var hasUser  = typeof cfg.userHtml === 'string' && cfg.userHtml !== '';
        var hasAdmin = typeof cfg.adminHtml === 'string' && cfg.adminHtml !== '';
        if (!hasUser && !hasAdmin) {
            return;
        }

        // ⚠️ 保留 v1.5.16 的修复：父主题 zib_header_user_box() 带 static $html 缓存，
        //    会在【桌面导航与移动导航各输出一次】同一个用户盒，所以必须遍历全部 .sub-user-box。
        var boxes = $('.sub-user-box');
        if (!boxes.length) {
            return;
        }

        boxes.each(function () {
            var rows = $(this).find('.header-user-href');

            // ── 用户区：盒内第 1 行 ──
            if (hasUser && rows.length >= 1) {
                var userRow = rows.eq(0);
                var userHtml = cfg.userHtml;

                // 配置里没有退出登录时，把**本行**原始的退出登录按钮补回来（永不丢失）
                if (userHtml.indexOf('data-zib-logout') === -1) {
                    var origLogout = userRow.find('a[data-target="#modal_signout"]').first();
                    if (origLogout.length) {
                        userHtml += origLogout[0].outerHTML;
                    }
                }

                // 仅替换内部，保留 .header-user-href 自身的 flex 布局类
                userRow.html(userHtml);
            }

            // ── 管理员区：盒内第 2 行（父主题仅超管渲染，普通账号压根没有这一行）──
            if (hasAdmin && rows.length >= 2) {
                rows.eq(1).html(cfg.adminHtml);
            }
        });
    }

    $(function () {
        zcReplaceUserBox();
    });

    // 登录弹窗完成后，头部用户卡片可能被刷新，重跑一次（幂等）
    $(document).ajaxComplete(function () {
        zcReplaceUserBox();
    });
})(jQuery);
