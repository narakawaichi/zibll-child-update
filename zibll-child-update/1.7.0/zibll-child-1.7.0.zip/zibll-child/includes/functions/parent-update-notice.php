<?php
/**
 * 子比子主题 - 父主题「文档&更新」分区的版本误报修正
 *
 * ── 现象 ────────────────────────────────────────────────
 * 子主题启用后，父主题设置页（zibll主题设置 → 文档&更新）恒显示：
 *   「当前主题版本：V1.6.2，可更新到最新版本：V9.1」
 * 对买家来说等于「装了子主题就永远提示父主题有新版本」，既误导也伤观感。
 *
 * ── 根因（2026-10-25 双向实证）────────────────────────────
 *   父主题 inc/options/options-module.php:2045
 *       $theme_version = wp_get_theme()['Version'];
 *   父主题 ZibAut::is_update()（inc/options/zib-code.php，加密）同样拿
 *   wp_get_theme() 的版本与官方最新版比较。
 *   子主题启用时 wp_get_theme() 返回的是【子主题】（1.6.2），
 *   于是 1.6.2 < 9.1 恒判「有更新」。
 *
 *   实测对照（同一测试站、同一时刻）：
 *     子主题身份 → wp_get_theme()=1.6.2，is_update()=true，version=9.1
 *     临时切回父主题身份 → wp_get_theme()=9.1，is_update()=false
 *
 * ── 处理方式 ─────────────────────────────────────────────
 * 不改父主题任何文件，只在【子主题】环境下用 Codestar Framework 自带的
 * `csf_zibll_options_sections` 过滤器（CSF_Options::__construct 内触发）
 * 把这一条 notice 换成按父主题真实版本（THEME_VERSION）重新得出的结论。
 *
 * 三点设计约束：
 *   1. 只认父主题更新通知：用 `admin_skip_update` / `admin_detect_update`
 *      这两个只有父主题更新框才有的隐藏 action 作识别标记，不依赖中文文案，
 *      站点换语言也不会失配。
 *   2. 父主题升级后若改了这段结构，识别不到就原样返回 —— 自动退回父主题行为，
 *      不会因为父主题改版而报错或丢内容。
 *   3. 不给「在线更新」按钮：子主题启用下父主题的在线更新会按子主题身份
 *      安装父主题包，风险远高于收益，改为指引先切回 zibll 再更新。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 判断某个 CSF 字段是否为父主题的更新通知框。
 *
 * @param mixed $field CSF 字段定义。
 * @return bool
 */
function zibll_child_parent_update_is_notice($field)
{
    if (!is_array($field) || empty($field['type']) || $field['type'] !== 'notice') {
        return false;
    }

    $content = isset($field['content']) ? (string) $field['content'] : '';

    return strpos($content, 'admin_skip_update') !== false
        || strpos($content, 'admin_detect_update') !== false;
}

/**
 * 从父主题更新通知里取出「官方最新版本」。
 *
 * 父主题把它包在 <code>V9.1</code> 里（esc_html 之后仍是纯版本串），
 * 取不到就返回空串，由调用方走保守文案。
 *
 * @param string $content 原 notice HTML。
 * @return string
 */
function zibll_child_parent_update_remote_version($content)
{
    if (preg_match('/<code[^>]*>\s*V?([0-9]+(?:\.[0-9]+){1,3})\s*<\/code>/i', (string) $content, $m)) {
        return $m[1];
    }

    return '';
}

/**
 * 生成替换用的说明 HTML。
 *
 * @param string $remote 官方最新版本，空串表示未取到。
 * @return string
 */
function zibll_child_parent_update_notice_html($remote = '')
{
    $parent = defined('ZIBLL_CHILD_PARENT_VERSION')
        ? (string) ZIBLL_CHILD_PARENT_VERSION
        : (defined('THEME_VERSION') ? (string) THEME_VERSION : '');

    $child = function_exists('zibll_child_get_version')
        ? zibll_child_get_version()
        : (string) wp_get_theme()->get('Version');

    $updates  = esc_url(admin_url('update-core.php'));
    $settings = esc_url(admin_url('admin.php?page=zibll_child_options'));
    $themes   = esc_url(admin_url('themes.php'));

    // 父主题真的有新版吗：只有拿到官方版本且确实高于本地父主题版本才算。
    $parent_outdated = $remote !== '' && $parent !== '' && version_compare($remote, $parent, '>');

    $html  = '<div>';
    $html .= '<h3 class="c-red"><i class="fa fa-info-circle fa-fw"></i> 当前启用的是子比子主题 v'
        . esc_html($child) . '</h3>';

    $html .= '<p>本栏是<b>父主题（子比）</b>的版本检测。它的「当前主题版本」取的是正在启用的主题，'
        . '也就是子主题的 v' . esc_html($child) . '；'
        . ($remote !== '' ? '而官方版本是 v' . esc_html($remote) . '，两者一比就恒判「有更新」。' : '因此这里的版本对比不代表子主题有新版本。')
        . '这是父主题的取数方式造成的，<b>与子主题版本无关</b>。</p>';

    if ($parent_outdated) {
        $html .= '<p class="c-yellow"><b>子比（父主题）确有新版：v' . esc_html($parent)
            . ' → v' . esc_html($remote) . '</b>。请先在 <a href="' . $themes
            . '">外观 → 主题</a> 切换回 zibll 再更新；子主题启用时不要点父主题原本的'
            . '「在线更新」，它会按子主题身份安装父主题包。</p>';
    } elseif ($parent !== '') {
        $html .= '<p><b>当前父主题 zibll 为 v' . esc_html($parent) . '，已是最新版</b>，此处无需处理。</p>';
    }

    $html .= '<p><b>子主题更新</b>：前往 <a href="' . $updates . '">仪表盘 → 更新</a>，'
        . '或在 <a href="' . $settings . '">子比子主题设置</a> 里点击「检查更新」。</p>';
    $html .= '</div>';

    return $html;
}

/**
 * 替换父面板「文档&更新」分区里的误报 notice。
 *
 * 同时摘掉分区图标上的 `c-red` —— 父主题在检测到「有更新」时会把图标标红，
 * 子主题环境下这个红点是恒定误报，留着只会让人一直以为有问题。
 *
 * @param array $sections CSF 分区数组。
 * @return array
 */
function zibll_child_filter_parent_update_notice($sections)
{
    if (!is_array($sections) || empty($sections)) {
        return $sections;
    }

    // 本过滤器只在「父主题已加载」时有意义；缺父主题时 compat-check 会给出提示。
    if (!defined('ZIBLL_CHILD_PARENT_VERSION') && !defined('THEME_VERSION')) {
        return $sections;
    }

    foreach ($sections as $index => $section) {
        if (empty($section['fields']) || !is_array($section['fields'])) {
            continue;
        }

        $replaced = false;

        foreach ($section['fields'] as $field_index => $field) {
            if (!zibll_child_parent_update_is_notice($field)) {
                continue;
            }

            $remote = zibll_child_parent_update_remote_version($field['content']);

            $sections[$index]['fields'][$field_index]['content'] = zibll_child_parent_update_notice_html($remote);
            $sections[$index]['fields'][$field_index]['style']   = 'info';
            $replaced = true;
        }

        if ($replaced && !empty($section['icon']) && is_string($section['icon'])) {
            $sections[$index]['icon'] = trim(preg_replace('/\s*c-red\b/', '', $section['icon']));
        }
    }

    return $sections;
}
add_filter('csf_zibll_options_sections', 'zibll_child_filter_parent_update_notice', 20);

/* =========================================================================
 * 二、后台顶部「Zibll子比主题：检测到主题更新」提示
 *
 * 用户实际看到的「后台顶部提示」就是这一条：由父主题的
 *    add_action('admin_notices', array('ZibAut', 'noaut_update'));
 * 在【全部后台页】输出，与上面 CSF 面板那条同源 —— 同样是拿子主题版本
 * 1.6.2 去比父主题的 9.1。
 *
 * ⚠️ ZibAut 是加密类（inc/options/zib-code.php 的 payload 经 eval 执行），
 *    方法内容不可读、也无法 filter，只能截获它的输出来改写。
 *    这里用输出缓冲包住 admin_notices 这一段（父主题默认 priority 10）：
 *    只替换含「检测到主题更新」的那一个 div，其他提示（含未授权提醒）
 *    一律原样输出，不碰父主题的授权逻辑。
 *
 *    父主题真有新版本时给出正确提示；父主题已是最新时整块移除，
 *    避免每个后台页面顶部都挂着一条假的「有更新」。
 * ========================================================================= */

function zibll_child_parent_update_notice_buffer_start()
{
    ob_start();
}
add_action('admin_notices', 'zibll_child_parent_update_notice_buffer_start', -1000);

function zibll_child_parent_update_notice_buffer_end()
{
    $html = ob_get_clean();

    if (!is_string($html) || $html === '') {
        return;
    }

    echo zibll_child_filter_admin_update_notice($html);
}
add_action('admin_notices', 'zibll_child_parent_update_notice_buffer_end', 1000);

/**
 * 父主题后台顶部更新提示的替换文案（仅在父主题确实落后于官方版本时使用）。
 *
 * @param string $remote 官方最新版本。
 * @return string
 */
function zibll_child_parent_update_admin_notice_html($remote)
{
    $parent = defined('ZIBLL_CHILD_PARENT_VERSION')
        ? (string) ZIBLL_CHILD_PARENT_VERSION
        : (defined('THEME_VERSION') ? (string) THEME_VERSION : '');

    $child  = function_exists('zibll_child_get_version')
        ? zibll_child_get_version()
        : (string) wp_get_theme()->get('Version');

    $themes = esc_url(admin_url('themes.php'));

    $html  = '<div class="notice notice-warning is-dismissible"><p>';
    $html .= '<b>子比（父主题）有新版本：v' . esc_html($parent) . ' → v' . esc_html($remote) . '</b><br>';
    $html .= '当前启用的是子比子主题 v' . esc_html($child) . '，这个版本号与父主题无关。';
    $html .= '请先到 <a href="' . $themes . '">外观 → 主题</a> 切换回 zibll 再更新；'
        . '子主题启用时不要用父主题的「在线更新」，它会按子主题身份安装父主题包。';
    $html .= '</p></div>';

    return $html;
}

/**
 * 从 admin_notices 的整段 HTML 里摘出父主题的「检测到主题更新」提示并改写。
 *
 * 识别依据是提示文案本身（这段由加密方法直接拼接输出，没有可用的类名或
 * 钩子标记）。父主题改版后识别不到时原样返回，退回父主题默认行为。
 *
 * @param string $html admin_notices 输出的 HTML。
 * @return string
 */
function zibll_child_filter_admin_update_notice($html)
{
    if (strpos($html, '检测到主题更新') === false) {
        return $html;
    }

    // 只匹配到最近的 </div>，不会吞掉后面紧邻的其他 notice（该块内部无嵌套 div）。
    $pattern = '#<div class="notice[^"]*">(?:(?!</div>).)*?检测到主题更新(?:(?!</div>).)*?</div>#s';

    if (!preg_match($pattern, $html, $match)) {
        return $html;
    }

    $notice = $match[0];
    $remote = '';

    // ⚠️ 不能用字符类 [：:] —— 非 UTF-8 模式下字符类一次只消耗「：」的 1 个字节，
    //    剩下的字节会让后面的 \s*V?[0-9]+ 全部错位而匹配失败（2026-10-25 实测踩过）。
    //    改成 (?:：|:) 分组，字面量按多字节序列整段匹配。
    if (preg_match('/可更新到最新版本(?:：|:)\s*V?([0-9]+(?:\.[0-9]+){1,3})/', $notice, $version)) {
        $remote = $version[1];
    } elseif (preg_match('/Update available[^0-9]{0,6}V?([0-9]+(?:\.[0-9]+){1,3})/i', $notice, $version)) {
        $remote = $version[1];
    }

    $parent = defined('ZIBLL_CHILD_PARENT_VERSION')
        ? (string) ZIBLL_CHILD_PARENT_VERSION
        : (defined('THEME_VERSION') ? (string) THEME_VERSION : '');

    $outdated = $remote !== '' && $parent !== '' && version_compare($remote, $parent, '>');

    $replacement = $outdated ? zibll_child_parent_update_admin_notice_html($remote) : '';

    return str_replace($notice, $replacement, $html);
}
