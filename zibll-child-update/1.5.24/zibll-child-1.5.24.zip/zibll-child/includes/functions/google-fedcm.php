<?php
/**
 * 子比子主题 - Google 一键登录（FedCM / One Tap）  v1.5.21
 * ─────────────────────────────────────────────────────────────
 * 让访客点一下「Google 登录」，Chrome 顶部直接弹出浏览器原生的账号选择器
 * （就是你平时看到的那一排已登录的 Google 账号），点完即登录本站，
 * 中间不跳 Google 授权页、不跳本站绑定页。
 *
 * ★ 为什么不用 prompt=none 静默续登 ★
 *   静默续登在合规上是灰色地带——用户没有明确动作就被登录，出了纠纷说不清。
 *   本模块走 FedCM：弹窗是浏览器原生 UI + 用户主动点选，授权关系清晰可举证。
 *   这也是用户明确提出的要求（「不然静默的话会产生纠纷」）。
 *
 * ★ FedCM 不需要向 Google 申请白名单 ★
 *   网上（含我本人一度）流传「FedCM 需要 fedcm.support 白名单」的说法是错的。
 *   Google 官方迁移指南原文：新 Web 应用「始终启用 FedCM」；GIS 已于 2024-04
 *   把所有站点迁到 FedCM。
 *   ⚠️ 开关必须写在 google.accounts.id.initialize() 的 IdConfiguration 里
 *      （use_fedcm_for_button），**写进 renderButton() 会被 GIS 静默忽略**。
 *      v1.5.22 曾踩这个坑：参数放错对象 → 按钮回退旧流程 → 回访用户点了直接登录、
 *      不弹账号选择器。用户实测反馈「点对应的谷歌登录直接就是登陆状态了」。
 *   浏览器支持：Chrome / Edge（桌面 M125+ / Android M128+）。
 *   Firefox / Safari / iOS 不支持 → 本模块在这些浏览器上**完全不改动页面**，
 *   继续使用父主题原有的 302 跳转按钮（功能不缺失，只是少个弹窗）。
 *
 * ★ 为什么必须「原位替换」父主题的 Google 图标 ★
 *   父主题 zib_social_login()（inc/functions/functions.php:1363）输出的 Google 按钮是
 *   <a href="/oauth/google">，其授权 URL 由 oauth/sdk/google/OAuth2.php::getAuthUrl()
 *   拼装，**没有 prompt=select_account**。Google 对「已授权过」的应用会
 *   静默自动批准 → 回访用户点一下直接进站，没有任何账号选择器。
 *   这在共享电脑 / 误触 / 纠纷场景下就是「不打招呼就换了账号」，
 *   正是用户明确反对的（「不然静默的话会产生纠纷」）。
 *   故本模块在 FedCM 可用时把 GIS 按钮**注入到该图标的位置**（icon + circle，
 *   外观尺寸与父主题一致），并把原生图标隐藏，让用户点击的唯一 Google 入口
 *   一定是浏览器原生账号选择器。
 *
 * ★ 与父主题 302 登录的关系（共存在线，不互相取代）★
 *   父主题 oauth/google/login.php 走 OAuth2 授权码流程，拿 access_token
 *   再去 googleapis.com/oauth2/v2/userinfo 换资料。而 FedCM 拿到的是
 *   ID Token（JWT），Google【不提供】用 ID Token 换 access_token 的接口，
 *   所以两条路凭证结构不同，无法直接互换。本模块因此：
 *     · 自己完成 ID Token 的本地验签与 claim 校验（不请求 Google）；
 *     · 提取身份字段后，组装成父主题格式的 $oauth_data，
 *       调用父主题现成的 zib_oauth_update_user() 完成建号/绑定/登录。
 *   父主题的 openid meta key 是 'oauth_' . $type . '_openid' 字符串拼接，
 *   本模块统一传 type='google'，且 openid 取 ID Token 的 sub
 *   （父主题 SDK 取 id 并回退 sub，指向同一个 Google 账号），
 *   因此【存量 Google 用户可正常登录】，与父主题按钮共用同一套绑定数据。
 *
 * ★ 安全边界（务必读完再改）★
 *   P0-1 验签是强制的。ID Token 无法与 Google 换 token，绕不开本地验签。
 *      不验签 = 任何人都能手搓一个 JWT 冒充任意 Google 账号登录本站。
 *      实现：拉 Google JWKS（https://www.googleapis.com/oauth2/v3/certs），
 *      按 JWT 头里的 kid 选公钥，用 openssl_verify 以 RS256 验证签名。
 *      无 openssl 扩展 → 直接判定未授权，绝不降级为「不验签」。
 *   P0-2 匹配主键必须用 sub，不能用 email。
 *      email 可被 Google 侧变更、可被冒用；sub 是 OIDC 里永久唯一的
 *      账号主体标识。这与 v1.5.5 处理 Apple 伪造邮箱时踩过的坑是同一个道理。
 *   P0-3 必须校验 email_verified。
 *      未验证的邮箱不得写入 WordPress 身份字段 user_email。
 *      （写入动作本身由 oauth-auto-email 模块负责，本模块只保证不喂脏数据给它。）
 *   P0-4 claim 全套校验：aud（等于本站 Client ID）、iss（须为 accounts.google.com）、
 *      exp（未过期）、iat（防极端未来时间）、nonce（防重放）。
 *   P0-5 nonce 一次性：用后即删（transient 存哈希），同一 token 不可重放。
 *   P1-6 JWKS 按 kid 缓存 6 小时；拉取失败时回退到过期缓存，再失败回退到
 *      后台手工导入的 JWKS。三级兜底应对国内服务器访问 Google 不畅。
 *   P1-7 端点不是 REST，而是普通前端地址。
 *      父主题 zib_oauth_new_is_to_page() 为真时（oauth_bind_type=page 或
 *      邀请码注册），zib_oauth_update_user() 会 header('location:…'); exit;
 *      在 REST 里调它会导致响应被截断成白屏。故本模块走 template_redirect。
 *   P1-8 端点仅在模块启用 + 已配置 Client ID 时挂载，且只接受 POST。
 *
 * ★ 服务器必须能访问 googleapis.com ★
 *   没有墙外出口 → 拉不到 JWKS → 验签无法完成。
 *   快速判别：父主题的 302 Google 登录要访问 oauth2.googleapis.com/token，
 *   与本模块所需域名同批；【现在 Google 登录能用 = 出口正常】。
 *
 * 开关：zibll_child_option_enabled('google_fedcm_enable')
 * 配置：后台「子比子主题设置 → Google 一键登录」分组
 *
 * @package zibll-child
 * @author  依岸归
 * @link    https://nav.hoarfall.cn/
 * @license GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ═══════════════════════════════════════════════════════════
 * 1. 配置读取
 * ═══════════════════════════════════════════════════════════ */

if (!defined('ZIBLL_CHILD_FEDCM_JWKS_URL')) {
    define('ZIBLL_CHILD_FEDCM_JWKS_URL', 'https://www.googleapis.com/oauth2/v3/certs');
}
if (!defined('ZIBLL_CHILD_FEDCM_JWKS_TTL')) {
    define('ZIBLL_CHILD_FEDCM_JWKS_TTL', 6 * HOUR_IN_SECONDS);
}
if (!defined('ZIBLL_CHILD_FEDCM_NONCE_TTL')) {
    define('ZIBLL_CHILD_FEDCM_NONCE_TTL', 10 * MINUTE_IN_SECONDS);
}
if (!defined('ZIBLL_CHILD_FEDCM_VER')) {
    define('ZIBLL_CHILD_FEDCM_VER', '1.5.24');
}

if (!function_exists('zibll_child_fedcm_settings')) {
    /**
     * 本模块全部配置。Client ID 缺省回落到父主题 zibll_options 的
     * oauth_google_option.appid —— 即「父主题已配好的 Google 凭证直接复用」，
     * 不需要在子主题重复填一遍。
     *
     * @return array
     */
    function zibll_child_fedcm_settings()
    {
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }

        $parent = function_exists('_pz') ? _pz('oauth_google_option') : array();
        if (!is_array($parent)) {
            $parent = array();
        }

        $parent_client_id = isset($parent['appid']) ? trim((string) $parent['appid']) : '';
        $client_id       = trim((string) zibll_child_get_option('google_fedcm_client_id', ''));
        if ($client_id === '') {
            $client_id = $parent_client_id;
        }

        // 父主题「社交登录」总开关 + Google 登录开关都开，才认为父主题侧就绪。
        $parent_ready = function_exists('_pz')
            && !empty(_pz('social'))
            && !empty(_pz('oauth_google_s'))
            && $parent_client_id !== '';

        $cache = array(
            'enable'          => zibll_child_option_enabled('google_fedcm_enable', false),
            'client_id'       => $client_id,
            'parent_client_id'=> $parent_client_id,
            'parent_ready'    => $parent_ready,
            'text'            => (string) zibll_child_get_option('google_fedcm_text', '使用 Google 账号登录'),
            'auto_prompt'     => zibll_child_option_enabled('google_fedcm_auto_prompt', false),
            'hd'              => trim((string) zibll_child_get_option('google_fedcm_hd', '')),
            'jwks_manual'     => trim((string) zibll_child_get_option('google_fedcm_jwks', '')),
            'only_logged_out' => zibll_child_option_enabled('google_fedcm_only_logged_out', true),
        );

        return $cache;
    }
}

if (!function_exists('zibll_child_fedcm_enabled')) {
    /**
     * 模块是否真正可用：开关开 + 有 Client ID + 已登录用户按配置挡掉。
     *
     * @return bool
     */
    function zibll_child_fedcm_enabled()
    {
        $s = zibll_child_fedcm_settings();
        if (empty($s['enable']) || empty($s['client_id'])) {
            return false;
        }
        if (!empty($s['only_logged_out']) && is_user_logged_in()) {
            return false;
        }
        if (!function_exists('zib_oauth_update_user')) {
            return false; // 父主题 OAuth 层未就绪，寧可不显示
        }
        return true;
    }
}

if (!function_exists('zibll_child_fedcm_endpoint_url')) {
    /**
     * 端点地址。挂 query var 而非物理文件，避免多一个公开入口文件被打到。
     * 之所以必须是「普通前端地址」而不是 REST，见文件头 P1-7。
     *
     * @return string
     */
    function zibll_child_fedcm_endpoint_url()
    {
        return add_query_arg('zibll_child_fedcm', '1', home_url('/'));
    }
}

/* ═══════════════════════════════════════════════════════════
 * 2. JWKS 获取与验签
 * ═══════════════════════════════════════════════════════════ */

/**
 * 纯 PHP 的 RS256 验签回退实现（不依赖 openssl 扩展）。
 *
 * 为什么需要它 —— 一个只有实测才会暴露的坑：
 *   部分服务器（实测宝塔面板 PHP 8.4 / 7.4 均如此）**没有随附 openssl.cnf**，
 *   且 php.ini 里 openssl.cafile / openssl.config 都为空。此时 OpenSSL 库因
 *   找不到默认配置文件而报 error:07000072，于是：
 *     · openssl_pkey_new() 直接失败（无法生成密钥做自测）
 *     · openssl_pkey_get_public() 返回 false → 【每一枚合法 ID Token 都会被
 *       误判为「Google 公钥不可用」而拒绝】，功能整体不可用且极难自查。
 *   修复它需要 OPENSSL_CONF 这个**进程启动前的环境变量**，而 PHP 的 putenv()
 *   要么被禁用（宝塔默认 disable_functions 常见项）、要么对已加载的 OpenSSL
 *   无效 —— 也就是说 PHP 层面根本救不回来。
 *   与其让站长去改 php.ini / 加环境变量（超出本模块该做的事），不如自带一条
 *   不依赖 OpenSSL 的验签路径。
 *
 * 实现：RSASSA-PKCS1-v1_5 验签 = 用 GMP 大整数算 s^e mod n，
 * 与 EMSA-PKCS1-v1_5 编码后的期望值比对。gmp 缺失时用 bcmath 兜底。
 * 安全性等价：同样做完整的签名校验，不存在「跳过验签」的分支。
 *
 * 依赖：ext-gmp（优选）或 ext-bcmath。两者都没有时返回 null，
 *       调用方回落到「判未授权」，绝不降级为不验签。
 */

/** 把二进制大端字节串转成 gmp 大整数 */
if (!function_exists('zibll_child_fedcm_bigint_from_bytes')) {
    function zibll_child_fedcm_bigint_from_bytes($bytes)
    {
        if (function_exists('gmp_import')) {
            return gmp_import($bytes);
        }
        if (function_exists('gmp_init')) {
            $r = gmp_init(0);
            for ($i = 0, $len = strlen($bytes); $i < $len; $i++) {
                $r = gmp_add(gmp_mul($r, 256), gmp_init(ord($bytes[$i])));
            }
            return $r;
        }
        if (function_exists('bcadd')) {
            $hex = bin2hex($bytes);
            $r = '0';
            for ($i = 0, $len = strlen($hex); $i < $len; $i++) {
                $r = bcadd(bcmul($r, '16', 0), (string) hexdec($hex[$i]), 0);
            }
            return $r;
        }
        return null;
    }
}

/** 大整数模幂 a^e mod m */
if (!function_exists('zibll_child_fedcm_bigint_powmod')) {
    function zibll_child_fedcm_bigint_powmod($base, $exp, $mod)
    {
        if (function_exists('gmp_powm') && function_exists('gmp_cmp')) {
            return gmp_powm($base, $exp, $mod);
        }
        if (function_exists('bcpowmod')) {
            return bcpowmod($base, $exp, $mod, 0);
        }
        return null;
    }
}

/** 大整数比较 */
if (!function_exists('zibll_child_fedcm_bigint_cmp')) {
    function zibll_child_fedcm_bigint_cmp($a, $b)
    {
        if (function_exists('gmp_cmp')) {
            return gmp_cmp($a, $b);
        }
        return bccomp($a, $b, 0);
    }
}

/**
 * 纯 PHP RS256 验签。
 *
 * @param string $signing_input  "header.payload" 原文
 * @param string $signature      原始签名二进制
 * @param string $jwk_n          JWK 的 n（base64url）
 * @param string $jwk_e          JWK 的 e（base64url）
 * @return bool|null true=验签通过；false=验签失败；null=环境不支持
 */
if (!function_exists('zibll_child_fedcm_pure_rs256_verify')) {
    function zibll_child_fedcm_pure_rs256_verify($signing_input, $signature, $jwk_n, $jwk_e)
    {
        $n_bytes = zibll_child_fedcm_b64url_decode($jwk_n);
        $e_bytes = zibll_child_fedcm_b64url_decode($jwk_e);
        if (empty($n_bytes) || empty($e_bytes)) {
            return false;
        }
        // Google 的 RSA 密钥为 2048/2560 位，签名字节数必须与模数长度一致
        $k = strlen($n_bytes);
        if ($k < 256 || $k > 512 || strlen($signature) !== $k) {
            return false;
        }

        $s = zibll_child_fedcm_bigint_from_bytes($signature);
        $n = zibll_child_fedcm_bigint_from_bytes($n_bytes);
        $e = zibll_child_fedcm_bigint_from_bytes($e_bytes);
        if (null === $s || null === $n || null === $e) {
            return null; // 没有可用的大整数库
        }
        // s 必须落在 [0, n)，否则是非规范签名，直接拒
        if (zibll_child_fedcm_bigint_cmp($s, $n) >= 0) {
            return false;
        }

        // EMSA-PKCS1-v1_5 + SHA-256 的 DigestInfo 前缀
        $digest_info = "\x30\x31\x30\x0d\x06\x09\x60\x86\x48\x01\x65\x03\x04\x02\x01\x05\x00\x04\x20"
            . hash('sha256', $signing_input, true);
        if ($k < strlen($digest_info) + 11) {
            return false;
        }
        $em = "\x00\x01" . str_repeat("\xff", $k - strlen($digest_info) - 3) . "\x00" . $digest_info;
        $em_int = zibll_child_fedcm_bigint_from_bytes($em);
        if (null === $em_int) {
            return null;
        }

        $m = zibll_child_fedcm_bigint_powmod($s, $e, $n);
        if (null === $m) {
            return null;
        }

        return 0 === zibll_child_fedcm_bigint_cmp($m, $em_int);
    }
}

if (!function_exists('zibll_child_fedcm_b64url_decode')) {
    /**
     * JWT 用的 base64url 解码（标准 base64 去掉 = 填充并把 -_ 换回 +/）。
     *
     * @param string $s
     * @return string|false
     */
    function zibll_child_fedcm_b64url_decode($s)
    {
        $s = strtr((string) $s, '-_', '+/');
        $pad = strlen($s) % 4;
        if ($pad) {
            $s .= str_repeat('=', 4 - $pad);
        }
        return base64_decode($s, true);
    }
}

if (!function_exists('zibll_child_fedcm_fetch_jwks')) {
    /**
     * 取 JWKS 公钥集合，三级兜底（见文件头 P1-6）：
     *   ① 实时拉 Google（成功即写缓存）
     *   ② 拉取失败 → 回退到过期缓存
     *   ③ 也没有 → 回退到后台手工导入的 JWKS
     *
     * @return array kid => array{key:resource,alg:string}|false
     */
    function zibll_child_fedcm_fetch_jwks()
    {
        $cache_key = 'zibll_child_fedcm_jwks';
        $cached    = get_transient($cache_key);
        if (!empty($cached) && is_array($cached)) {
            return $cached;
        }

        $keys = array();

        $response = wp_remote_get(ZIBLL_CHILD_FEDCM_JWKS_URL, array(
            'timeout'    => 8,
            'redirection'=> 2,
            'headers'    => array('Accept' => 'application/json'),
        ));

        if (!is_wp_error($response) && 200 === (int) wp_remote_retrieve_response_code($response)) {
            $raw = json_decode(wp_remote_retrieve_body($response), true);
            if (!empty($raw['keys']) && is_array($raw['keys'])) {
                foreach ($raw['keys'] as $jwk) {
                    if (empty($jwk['kid']) || empty($jwk['n']) || empty($jwk['e'])) {
                        continue;
                    }
                    // 仅接受 RSA 家族；alg 缺省时按 Google 现行惯例视为 RS256
                    $alg = !empty($jwk['alg']) ? $jwk['alg'] : 'RS256';
                    if (0 !== strpos($alg, 'RS')) {
                        continue;
                    }
                    $pem = zibll_child_fedcm_jwk_to_pem($jwk['n'], $jwk['e']);
                    if ($pem) {
                        $keys[$jwk['kid']] = array('pem' => $pem, 'alg' => $alg, 'n' => $jwk['n'], 'e' => $jwk['e']);
                    }
                }
            }
        }

        if (!empty($keys)) {
            set_transient($cache_key, $keys, ZIBLL_CHILD_FEDCM_JWKS_TTL);
            return $keys;
        }

        // ② 过期缓存兜底
        if (!empty($cached) && is_array($cached)) {
            return $cached;
        }

        // ③ 手工导入兜底
        $manual = zibll_child_fedcm_settings();
        if (!empty($manual['jwks_manual'])) {
            $parsed = json_decode($manual['jwks_manual'], true);
            if (!empty($parsed['keys']) && is_array($parsed['keys'])) {
                foreach ($parsed['keys'] as $jwk) {
                    if (empty($jwk['kid']) || empty($jwk['n']) || empty($jwk['e'])) {
                        continue;
                    }
                    $pem = zibll_child_fedcm_jwk_to_pem($jwk['n'], $jwk['e']);
                    if ($pem) {
                        $keys[$jwk['kid']] = array('pem' => $pem, 'alg' => !empty($jwk['alg']) ? $jwk['alg'] : 'RS256', 'n' => $jwk['n'], 'e' => $jwk['e']);
                    }
                }
            }
        }

        return !empty($keys) ? $keys : false;
    }
}

if (!function_exists('zibll_child_fedcm_jwk_to_pem')) {
    /**
     * JWK(n,e) → PEM 公钥。
     *
     * 不用 openssl_pkey_get_details() 反推（各家 OpenSSL 对「只给 n/e」的
     * 支持并不一致），而是手工拼 PKCS#1 RSA 公钥 DER 再 base64 编码，
     * 这条路径不依赖 OpenSSL 版本行为，最稳。
     *
     * @param string $n base64url 模数
     * @param string $e base64url 指数
     * @return string PEM
     */
    function zibll_child_fedcm_jwk_to_pem($n, $e)
    {
        $n_raw = zibll_child_fedcm_b64url_decode($n);
        $e_raw = zibll_child_fedcm_b64url_decode($e);
        if (empty($n_raw) || empty($e_raw)) {
            return '';
        }

        // 把大整数编码成 DER 的 INTEGER：正数补 0x00 前导
        $encode_int = function ($bytes) {
            $bytes = ltrim($bytes, "\x00");
            if ($bytes === '') {
                $bytes = "\x00";
            }
            if (ord($bytes[0]) & 0x80) {
                $bytes = "\x00" . $bytes;
            }
            return "\x02" . chr(strlen($bytes)) . $bytes;
        };

        $rsa_pub = $encode_int($n_raw) . $encode_int($e_raw);
        // RSAPublicKey ::= SEQUENCE { modulus INTEGER, publicExponent INTEGER }
        $rsa_der = "\x30" . chr(strlen($rsa_pub)) . $rsa_pub;

        // 包装成 X.509 SubjectPublicKeyInfo
        $algo_id = "\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00";
        $bitstr  = "\x03" . chr(strlen($rsa_der) + 1) . "\x00" . $rsa_der;
        $spki    = $algo_id . $bitstr;
        $spki_der = "\x30" . chr(strlen($spki)) . $spki;

        $pem = "-----BEGIN PUBLIC KEY-----\n";
        $pem .= chunk_split(base64_encode($spki_der), 64, "\n");
        $pem .= "-----END PUBLIC KEY-----\n";

        return $pem;
    }
}

if (!function_exists('zibll_child_fedcm_verify_token')) {
    /**
     * 校验 ID Token：签名 + 全套 claim。返回 array|WP_Error。
     *
     * @param string $jwt 原始 ID Token
     * @return array|WP_Error 成功返回 claims 数组
     */
    function zibll_child_fedcm_verify_token($jwt)
    {
        $jwt = trim((string) $jwt);
        if ($jwt === '') {
            return new WP_Error('empty_token', '凭证为空');
        }

        $parts = explode('.', $jwt);
        if (count($parts) !== 3) {
            return new WP_Error('bad_token', '凭证格式错误');
        }

        list($h_b64, $p_b64, $s_b64) = $parts;

        $header_raw = zibll_child_fedcm_b64url_decode($h_b64);
        $payload_raw = zibll_child_fedcm_b64url_decode($p_b64);
        $sig_raw = zibll_child_fedcm_b64url_decode($s_b64);
        if (empty($header_raw) || empty($payload_raw) || empty($sig_raw)) {
            return new WP_Error('bad_token', '凭证解析失败');
        }

        $header = json_decode($header_raw, true);
        $claims = json_decode($payload_raw, true);
        if (!is_array($header) || !is_array($claims)) {
            return new WP_Error('bad_token', '凭证结构错误');
        }

        // ── 签名算法必须是 RS256 ──
        // 关键安全点：JWT 的 alg 由 token 自带，若不锁死，攻击者可把 alg 改成
        // HS256 并用「公钥当 HMAC 密钥」伪造签名。这里显式只收 RS256/RS384/RS512。
        $alg = isset($header['alg']) ? strtoupper($header['alg']) : '';
        if (!in_array($alg, array('RS256', 'RS384', 'RS512'), true)) {
            return new WP_Error('bad_alg', '签名算法不被接受');
        }

        // ── 取公钥 ──
        $kid = isset($header['kid']) ? (string) $header['kid'] : '';
        $keys = zibll_child_fedcm_fetch_jwks();

        // kid 未命中时清缓存重取一次（应对 Google 轮换密钥）。
        // ⚠️ 安全（v1.5.21 实测修复）：这里【不能】无条件 delete_transient。
        //    未命中最常见的原因是「攻击者随手编了个不存在的 kid」，
        //    若照旧清缓存，在服务器访问 Google 不畅的站点上
        //    （拉取失败 → 无缓存可回退）会造成：一次伪造请求即可清空公钥缓存，
        //    之后【所有正常用户的登录全部失败】—— 即可被利用的拒绝服务。
        //    故只有「重取后确实拿到了新公钥」才作废旧缓存；
        //    重取失败（离线/超时）时保留原缓存，不让它被无效请求打空。
        if (empty($keys) || empty($keys[$kid]) || empty($keys[$kid]['n'])) {
            $stale = $keys; // 可能是旧缓存，留个底
            delete_transient('zibll_child_fedcm_jwks');
            $keys = zibll_child_fedcm_fetch_jwks();
            if (empty($keys)) {
                // 重取失败：把原缓存写回去，避免被无效请求打空
                if (!empty($stale) && is_array($stale)) {
                    set_transient('zibll_child_fedcm_jwks', $stale, ZIBLL_CHILD_FEDCM_JWKS_TTL);
                }
            }
        }
        if (empty($keys) || empty($keys[$kid])) {
            return new WP_Error('no_jwks', '无法获取 Google 公钥');
        }
        if (empty($keys[$kid]['n']) || empty($keys[$kid]['e'])) {
            return new WP_Error('jwks_incomplete', 'Google 公钥数据不完整');
        }

        $pub = null;
        $signed = $h_b64 . '.' . $p_b64;
        $verified = false;

        // ── 验签主路径：OpenSSL ──
        // 注意：不能因为 openssl_verify 不存在就直接判失败（那是 P0-1 要求的），
        // 但「有 openssl 扩展却读不出公钥」（典型即缺 openssl.cnf 的服务器）
        // 不等于凭证有问题，此时走下面的纯 PHP 路径重新完整校验一次。
        if (function_exists('openssl_verify')) {
            $pub = @openssl_pkey_get_public($keys[$kid]['pem']);
            if ($pub) {
                $algo = 'RS256' === $alg ? OPENSSL_ALGO_SHA256 : ('RS384' === $alg ? OPENSSL_ALGO_SHA384 : OPENSSL_ALGO_SHA512);
                if (1 === openssl_verify($signed, $sig_raw, $pub, $algo)) {
                    $verified = true;
                }
            }
        }

        // ── 验签回退路径：纯 PHP 大整数 ──
        // 覆盖两种情形：① 没有 openssl 扩展；② 有扩展但读不出公钥（缺 openssl.cnf）。
        // 纯 PHP 路径只实现 RS256；RS384/512 在该情形下判未授权（Google 现网只发 RS256）。
        if (!$verified && 'RS256' === $alg) {
            $pure = zibll_child_fedcm_pure_rs256_verify(
                $signed,
                $sig_raw,
                $keys[$kid]['n'],
                $keys[$kid]['e']
            );
            if (true === $pure) {
                $verified = true;
            } elseif (null === $pure) {
                // 既无 openssl 可用、也没有 gmp/bcmath → 无法完成任何验签
                return new WP_Error('no_verify_backend', '服务器缺少可用的凭证校验组件（OpenSSL 或 GMP/BCMath）');
            }
        }

        if (!$verified) {
            return new WP_Error('bad_signature', '凭证签名无效');
        }

        // ── claim 校验（P0-4）──
        $s = zibll_child_fedcm_settings();

        $now = time();

        // exp：允许 60s 时钟偏移
        if (empty($claims['exp']) || !is_numeric($claims['exp']) || (int) $claims['exp'] < ($now - 60)) {
            return new WP_Error('token_expired', '凭证已过期');
        }
        // iat：不允许来自未来（超过 5 分钟视为异常）
        if (!empty($claims['iat']) && is_numeric($claims['iat']) && (int) $claims['iat'] > ($now + 300)) {
            return new WP_Error('token_future', '凭证时间异常');
        }

        // iss：Google 两种历史写法都接受，但绝不容忍其它域
        $iss = isset($claims['iss']) ? $claims['iss'] : '';
        if (!in_array($iss, array('https://accounts.google.com', 'accounts.google.com'), true)) {
            return new WP_Error('bad_issuer', '凭证来源不可信');
        }

        // aud：必须等于本站 Client ID（数组时取其一命中即可）
        $aud = isset($claims['aud']) ? $claims['aud'] : '';
        $aud_ok = false;
        if (is_array($aud)) {
            foreach ($aud as $a) {
                if ((string) $a === (string) $s['client_id']) {
                    $aud_ok = true;
                    break;
                }
            }
        } else {
            $aud_ok = ((string) $aud === (string) $s['client_id']);
        }
        if (!$aud_ok) {
            return new WP_Error('bad_audience', '凭证受众不匹配');
        }

        // azp：aud 为数组时 Google 要求 azp 也等于 client_id
        if (is_array($aud) && !empty($claims['azp']) && (string) $claims['azp'] !== (string) $s['client_id']) {
            return new WP_Error('bad_azp', '凭证授权方不匹配');
        }

        // sub 必填，且是本模块唯一的账号匹配主键（P0-2）
        if (empty($claims['sub']) || !is_string($claims['sub'])) {
            return new WP_Error('no_sub', '凭证缺少账号标识');
        }

        // hd：配置了 Workspace 域名则必须命中
        if (!empty($s['hd'])) {
            $hd = isset($claims['hd']) ? (string) $claims['hd'] : '';
            $allowed = array_filter(array_map('trim', explode('|', $s['hd'])));
            if ($hd === '' || !in_array(strtolower($hd), array_map('strtolower', $allowed), true)) {
                return new WP_Error('hd_not_allowed', '该 Google 账号不在允许的域名内');
            }
        }

        return $claims;
    }
}

/* ═══════════════════════════════════════════════════════════
 * 3. nonce（防重放）
 * ═══════════════════════════════════════════════════════════ */

if (!function_exists('zibll_child_fedcm_issue_nonce')) {
    /**
     * 页面渲染时签发一次性 nonce，存 transient（存哈希，不存明文）。
     *
     * @return string
     */
    function zibll_child_fedcm_issue_nonce()
    {
        $nonce = wp_generate_password(32, false, false);
        set_transient('zibll_child_fedcm_nonce_' . hash('sha256', $nonce), 1, ZIBLL_CHILD_FEDCM_NONCE_TTL);
        return $nonce;
    }
}

if (!function_exists('zibll_child_fedcm_consume_nonce')) {
    /**
     * 校验并销毁 nonce。用后即删 → 同一 token 无法重放（P0-5）。
     *
     * @param string $nonce
     * @return bool
     */
    function zibll_child_fedcm_consume_nonce($nonce)
    {
        $nonce = (string) $nonce;
        if ($nonce === '') {
            return false;
        }
        $key = 'zibll_child_fedcm_nonce_' . hash('sha256', $nonce);
        if (get_transient($key) === false) {
            return false;
        }
        // 先验后删：即便校验后续失败，这次 nonce 也已经作废
        delete_transient($key);
        return true;
    }
}

/* ═══════════════════════════════════════════════════════════
 * 4. 端点：接收 ID Token 并完成登录
 * ═══════════════════════════════════════════════════════════ */

if (!function_exists('zibll_child_fedcm_handle_request')) {
    /**
     * 处理端点请求。用法：加 nonce 前缀的完整 nonce 字符串。
     * 返回值 = 给用户看的提示文案（已 wp_die / 跳转）。
     */
    function zibll_child_fedcm_handle_request()
    {
        // 只接受 POST
        if (!isset($_SERVER['REQUEST_METHOD']) || 'POST' !== $_SERVER['REQUEST_METHOD']) {
            wp_die(esc_html__('请求方式不正确', 'zibll_child'), esc_html__('Google 登录', 'zibll_child'), array('response' => 405));
        }

        $s = zibll_child_fedcm_settings();
        if (empty($s['enable']) || empty($s['client_id'])) {
            wp_die(esc_html__('Google 一键登录未启用', 'zibll_child'), esc_html__('Google 登录', 'zibll_child'), array('response' => 403));
        }

        // nonce 校验：必须在验签之前 —— 它防的是「拿一个自己伪造的 token 反复打端点」
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!zibll_child_fedcm_consume_nonce($nonce)) {
            wp_die(esc_html__('会话已过期，请返回重试', 'zibll_child'), esc_html__('Google 登录', 'zibll_child'), array('response' => 403));
        }

        $token = isset($_POST['token']) ? trim((string) wp_unslash($_POST['token'])) : '';
        if ($token === '') {
            wp_die(esc_html__('未收到凭证', 'zibll_child'), esc_html__('Google 登录', 'zibll_child'), array('response' => 400));
        }

        $claims = zibll_child_fedcm_verify_token($token);
        if (is_wp_error($claims)) {
            // 不把内部错误码暴露给访客，避免探测；写入 debug.log 供站长排查
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[zibll-child fedcm] verify failed: ' . $claims->get_error_code() . ' / ' . $claims->get_error_message());
            }
            wp_die(esc_html__('登录凭证校验失败，请重试。若持续失败请改用下方「使用 Google 账号登录」按钮。', 'zibll_child'), esc_html__('Google 登录', 'zibll_child'), array('response' => 403));
        }

        // nonce 也应体现在 token 里（Google 会把 initialize 的 nonce 原样放进 claim）
        if (!empty($claims['nonce']) && !hash_equals((string) $nonce, (string) $claims['nonce'])) {
            wp_die(esc_html__('凭证与本次会话不匹配，请重试', 'zibll_child'), esc_html__('Google 登录', 'zibll_child'), array('response' => 403));
        }

        // ── 组装父主题格式的 oauth_data ──
        // openid 用 sub（永久唯一），绝不用 email（P0-2）
        $sub = (string) $claims['sub'];

        // 昵称：与父主题 SDK 的 parseDisplayName 规则对齐（16 字上限）
        $name = '';
        foreach (array('name', 'given_name') as $k) {
            if (!empty($claims[$k]) && is_string($claims[$k])) {
                $name = trim($claims[$k]);
                break;
            }
        }
        if ($name === '' && !empty($claims['email']) && is_string($claims['email'])) {
            $name = strstr($claims['email'], '@', true);
        }
        if (function_exists('zib_new_strlen')) {
            while ($name !== '' && zib_new_strlen($name) > 16) {
                $name = function_exists('mb_substr') ? mb_substr($name, 0, -1, 'UTF-8') : substr($name, 0, -1);
            }
        }
        $name = trim($name);

        // 头像：ID Token 的 picture 与父主题 userinfo 的 picture 同源
        $avatar = !empty($claims['picture']) && is_string($claims['picture']) ? $claims['picture'] : '';

        // getUserInfo：父主题会整份存进 oauth_google_getUserInfo。
        // 带上 email_verified 字段，oauth-auto-email 模块据此决定能否写入 user_email
        // （该模块的 google 验证字段列表是 'verified_email|email_verified'，正好命中）。
        $get_user_info = array(
            'sub'            => $sub,
            'email'          => isset($claims['email']) ? $claims['email'] : '',
            'email_verified' => !empty($claims['email_verified']),
            'name'           => $name,
            'picture'        => $avatar,
            'hd'             => isset($claims['hd']) ? $claims['hd'] : '',
            'source'         => 'fedcm',
        );

        $oauth_data = array(
            'type'        => 'google',
            'openid'      => $sub,
            'name'        => $name,
            'avatar'      => $avatar,
            'description' => '',
            'getUserInfo' => $get_user_info,
        );

        // ── 交回父主题：建号 / 绑定 / 登录三合一 ──
        // ⚠️ 这里可能触发 zib_oauth_update_user() 内部的 header()+exit（跳绑定页），
        //    这正是本端点必须做成普通前端地址的原因（P1-7）。不要试图改成 REST。
        $result = zib_oauth_update_user($oauth_data);

        if (!empty($result['error'])) {
            $msg = !empty($result['msg']) ? $result['msg'] : '登录失败，请重试';
            wp_die(esc_html($msg), esc_html__('Google 登录', 'zibll_child'), array('response' => 400));
        }

        // 登录成功
        $redirect = !empty($result['redirect_url']) ? $result['redirect_url'] : home_url('/');
        wp_safe_redirect($redirect);
        exit;
    }
}

if (!function_exists('zibll_child_fedcm_maybe_handle')) {
    /**
     * template_redirect 守卫：命中 ?zibll_child_fedcm=1 即接管本请求。
     * 优先级 5 —— 早于父主题 zib_oauth_page_template()（同为 5 但先注册先执行，
     * 本模块在子主题加载、注册更晚，故用 4 明确抢在前面，避免与 /oauth/* 路由混淆）。
     */
    function zibll_child_fedcm_maybe_handle()
    {
        if (!isset($_GET['zibll_child_fedcm'])) {
            return;
        }
        zibll_child_fedcm_handle_request();
    }
}

/* ═══════════════════════════════════════════════════════════
 * 5. 前端注入
 * ═══════════════════════════════════════════════════════════ */

if (!function_exists('zibll_child_fedcm_render')) {
    /**
     * 输出 Google 登录按钮容器。挂 login_footer（登录页）与 wp_footer（前台弹窗登录），
     * 只在模块可用时输出。已登录用户按配置不输出。
     */
    function zibll_child_fedcm_render()
    {
        if (!zibll_child_fedcm_enabled()) {
            return;
        }
        if (did_action('zibll_child_fedcm_rendered')) {
            return; // 一个请求只输出一次
        }
        do_action('zibll_child_fedcm_rendered');

        $s   = zibll_child_fedcm_settings();

        // 降级按钮走父主题原有的 302 登录地址（会自动带 rurl 回跳参数）
        $fallback_url = '';
        if (function_exists('zib_get_oauth_login_url')) {
            $fallback_url = zib_get_oauth_login_url('google');
        }
        if (empty($fallback_url)) {
            $fallback_url = home_url('/oauth/google');
        }

        $config = array(
            'clientId'   => $s['client_id'],
            'text'       => $s['text'] !== '' ? $s['text'] : __('使用 Google 账号登录', 'zibll_child'),
            'autoPrompt' => !empty($s['auto_prompt']),
            'hd'         => $s['hd'],
            'endpoint'   => zibll_child_fedcm_endpoint_url(),
            'nonce'      => zibll_child_fedcm_issue_nonce(),
            'fallbackUrl'=> $fallback_url,
            'version'    => ZIBLL_CHILD_FEDCM_VER,
            'debug'      => defined('WP_DEBUG') && WP_DEBUG,
        );

        // JSON_HEX_* 防 XSS：配置里的文案含中文/引号时不能裸进 <script>
        $json = wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

        ?>
        <div class="zibll-fedcm-wrap" id="zibll-fedcm-wrap" hidden data-fedcm-ver="<?php echo esc_attr(ZIBLL_CHILD_FEDCM_VER); ?>">
            <div class="zibll-fedcm-slot" id="zibll-fedcm-slot"></div>
            <noscript><?php echo esc_html__('请启用 JavaScript 以使用 Google 一键登录', 'zibll_child'); ?></noscript>
            <p class="zibll-fedcm-fallback" hidden>
                <a class="zibll-fedcm-fallback-link" href="<?php echo esc_url($config['fallbackUrl']); ?>"><?php echo esc_html($config['text']); ?></a>
            </p>
        </div>
        <script>
        window.zibllChildFedcm = <?php echo $json; // phpcs:ignore WordPress.Security.EscapeOutput -- 已 JSON_HEX_* 转义 ?>;
        </script>
        <?php
    }
}

if (!function_exists('zibll_child_fedcm_assets')) {
    /**
     * 前端资源。用 theme 的目录 URI，随主题分发升级。
     */
    function zibll_child_fedcm_assets()
    {
        if (!zibll_child_fedcm_enabled()) {
            return;
        }
        $uri = get_stylesheet_directory_uri();
        // 用 filemtime 做缓存戳，保证改动后浏览器必定重取（与 afdian-pay 一致）
        $js  = get_stylesheet_directory() . '/assets/js/google-fedcm.js';
        $css = get_stylesheet_directory() . '/assets/css/google-fedcm.css';
        $vjs = file_exists($js) ? filemtime($js) : '1.0.0';
        $css = file_exists($css) ? filemtime($css) : '1.0.0';

        wp_enqueue_script(
            'zibll-child-fedcm',
            $uri . '/assets/js/google-fedcm.js',
            array(),
            $vjs,
            true
        );
        wp_enqueue_style(
            'zibll-child-fedcm',
            $uri . '/assets/css/google-fedcm.css',
            array(),
            $css
        );
    }
}

/* ═══════════════════════════════════════════════════════════
 * 6. 挂载
 * ═══════════════════════════════════════════════════════════ */

if (zibll_child_option_enabled('google_fedcm_enable', false)) {
    add_action('template_redirect', 'zibll_child_fedcm_maybe_handle', 4);
    add_action('wp_enqueue_scripts', 'zibll_child_fedcm_assets', 40);
    add_action('wp_footer', 'zibll_child_fedcm_render', 20);
    add_action('login_footer', 'zibll_child_fedcm_render', 20);
}
