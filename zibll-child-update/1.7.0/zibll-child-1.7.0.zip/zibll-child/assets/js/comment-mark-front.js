/**
 * 子比子主题 - 留言标记（前台「更多操作」菜单）
 *
 * 只在管理员访问时加载（见 comment-mark.php 的 wp_enqueue_scripts 判断）。
 * 留言右下角「三个点」菜单里多一项「标记」，点开是一个标记选择面板，
 * 选完即时保存，并把这条留言下方的标签就地换成新的（不刷新页面）。
 */

(function ($) {
  'use strict';

  var cfg = window.ZC_COMMENT_MARK_FRONT;

  if (!cfg) {
    return;
  }

  var $picker = null;
  var currentId = 0;

  /**
   * 生成标记选择面板（只在第一次点击时构建，之后复用）。
   */
  function buildPicker() {
    var $panel = $('<div class="zcm-picker" role="dialog" aria-label="设置留言标记"></div>');

    $('<div class="zcm-picker-head"></div>').text(cfg.i18n.title).appendTo($panel);

    (cfg.marks || []).forEach(function (mark) {
      var $item = $('<a href="javascript:;" class="zcm-pick"></a>').attr('data-mark', mark.name);

      $('<span class="zcm-pick-dot"></span>').css('background-color', mark.color).appendTo($item);

      if (mark.icon) {
        $item.append(mark.icon);
      }

      $item.append(document.createTextNode(mark.name));
      $item.appendTo($panel);
    });

    $('<a href="javascript:;" class="zcm-pick zcm-pick-clear"></a>')
      .attr('data-mark', '')
      .text(cfg.i18n.clear)
      .appendTo($panel);

    return $panel;
  }

  function hidePicker() {
    if ($picker) {
      $picker.hide();
    }
    currentId = 0;
  }

  /**
   * 把面板定位到触发按钮下方；空间不够时自动翻到上方、左右也不越界。
   */
  function placePicker($button) {
    $picker.show();

    var rect = $button[0].getBoundingClientRect();
    var width = $picker.outerWidth();
    var height = $picker.outerHeight();

    var left = rect.left;
    if (left + width > window.innerWidth - 8) {
      left = Math.max(8, window.innerWidth - width - 8);
    }

    var top = rect.bottom + 6;
    if (top + height > window.innerHeight - 8) {
      top = Math.max(8, rect.top - height - 6);
    }

    $picker.css({ top: top, left: left });
  }

  /**
   * 就地替换某条留言的标签（badgeHtml 为空表示清除标记）。
   *
   * 父主题的标签容器是 li#div-comment-<id> 里的 .comt-meta，
   * 我们的标签始终插在这一行的最前面。
   */
  function applyBadge(commentId, badgeHtml) {
    var $meta = $('#div-comment-' + commentId).find('.comt-meta').first();

    if (!$meta.length) {
      return;
    }

    $meta.find('.zcm-badge').remove();

    if (badgeHtml) {
      $meta.prepend(badgeHtml);
    }
  }

  // 打开面板
  $(document).on('click', '.zcm-front-mark', function (e) {
    e.preventDefault();
    e.stopPropagation();

    var $button = $(this);
    var commentId = parseInt($button.attr('data-comment'), 10) || 0;

    if (!commentId) {
      return;
    }

    // 再点同一个按钮就收起
    if (currentId === commentId && $picker && $picker.is(':visible')) {
      hidePicker();
      return;
    }

    currentId = commentId;

    if (!$picker) {
      $picker = buildPicker().appendTo(document.body);
      // ⚠️ 这里不能再给面板绑 stopPropagation：.zcm-pick 的点击是委托在 document 上的，
      //    一旦在面板上截断冒泡，选择动作根本不会触发（面板打开了却点不动）。
      //    关闭逻辑已经用「closest('.zcm-picker')」判断，不会误关。
    }

    placePicker($button);
  });

  // 选择某个标记
  $(document).on('click', '.zcm-pick', function () {
    if (!currentId || ($picker && $picker.data('busy'))) {
      return;
    }

    var mark = $(this).attr('data-mark') || '';
    var commentId = currentId;

    $picker.data('busy', true).addClass('zcm-picker-busy');

    $.post(cfg.ajax, {
      action: 'zibll_child_comment_mark_save',
      nonce: cfg.nonce,
      comment_id: commentId,
      mark: mark
    })
      .done(function (res) {
        if (!res || !res.success) {
          window.alert((res && res.data && res.data.message) || cfg.i18n.failed);
          return;
        }

        applyBadge(commentId, res.data && res.data.badge ? res.data.badge : '');
        hidePicker();
      })
      .fail(function () {
        window.alert(cfg.i18n.failed);
      })
      .always(function () {
        if ($picker) {
          $picker.data('busy', false).removeClass('zcm-picker-busy');
        }
      });
  });

  // 点面板外面 / 按 ESC 收起
  $(document).on('click', function (e) {
    if (!$picker || !$picker.is(':visible')) {
      return;
    }

    if ($(e.target).closest('.zcm-picker').length) {
      return;
    }

    hidePicker();
  });

  $(document).on('keydown', function (e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
      hidePicker();
    }
  });

  // 窗口尺寸变化时收起，避免面板浮在错位置
  $(window).on('resize', hidePicker);
})(jQuery);
