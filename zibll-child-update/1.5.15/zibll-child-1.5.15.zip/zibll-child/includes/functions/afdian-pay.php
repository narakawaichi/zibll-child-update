<?php
/**
 * 子比子主题 - 爱发电（Afdian）支付渠道  v1.5.15
 * ─────────────────────────────────────────────────────────────
 * 把爱发电作为标准支付方式「融入」父主题 zibll 的收银台（付费文章 / 会员 /
 * 余额充值 / 商城商品），零侵入、不修改父主题一行。
 *
 * 工作原理（完全复用父主题现有钩子与入口）：
 *   1. add_filter('zibpay_payment_methods', …)
 *      —— 往支付选择列表注入 afdian，所有收银台自动出现「爱发电」选项。
 *   2. add_filter('zibpay_initiate_paysdk', …)
 *      —— 识别 payment_method=afdian，转交本模块的发起处理器。
 *   3. zibll_child_afdian_initiate_pay()
 *      —— 拼出爱发电「下单页」URL 并交给前端 open_url 跳转逻辑；
 *         用户在该页完成付款后，爱发电主动把订单推到本站的 Webhook。
 *   4. afdian-notify.php（子主题根目录，仿父主题 zibpay/shop/<网关>/notify.php）
 *      —— 爱发电 Webhook 回调入口，用爱发电【平台固定公钥】RSA-SHA256 验签，
 *        status=2 且通过后调用 ZibPay::payment_order() 标记本地订单已付，
 *        自动触发 zibll 原有发货 / 到账流程。幂等 + 必须回 {"ec":200,"em":""}。
 *
 * 两种下单模式（对齐爱发电官方 / 授权中心 Go 实现）：
 *   · 自选金额模式（未填「爱发电方案 ID」）—— 落点 /order/create 且必须带
 *     user_id（爱发电下单页前置守卫要求，否则页只显示「选择你的赞助期限」无法付款）；
 *     custom_price=站内订单金额（auto 时预填），支持任意充值金额 —— 推荐。
 *   · 固定方案模式（填了「爱发电方案 ID」）—— 落点 /order/create?plan_id=…&product_type=…，
 *     金额由方案自身决定，必须与站内订单金额一致，否则回调会因金额核对失败拒绝入账。
 *   两种模式都必带 custom_order_id（站内订单号），它是回调能与站内订单精确对上账的唯一凭据。
 *
 * 爱发电没有「服务端创建订单」接口，也没有「商户字段」：回调的 order.user_id 是
 * 「买家」不是商户，商户身份由「Webhook 配在哪家账号」决定，因此认证完全依赖
 * RSA 签名校验，绝不能用 order.user_id 去比对配置里的 user_id（早期实现因此误拒）。
 * 本模块 Webhook 验签用的就是爱发电平台固定公钥，任何站点通用，无需你的任何凭证即可运行。
 *
 * 配置：后台「子比子主题设置 → 爱发电支付」分组
 *       （爱发电 user_id、方案 ID〔可选〕、product_type、自选金额参数、API 基础地址、API Token〔选填〕）。
 *
 * @package zibll-child
 * @author  依岸归
 * @link    https://nav.hoarfall.cn/
 * @license GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── 爱发电平台固定公钥（RSA-SHA256，用于 Webhook 验签；全平台通用，无需你的私钥） ───
if (!defined('ZIBLL_CHILD_AFDIANA_PUBLIC_KEY')) {
    define('ZIBLL_CHILD_AFDIANA_PUBLIC_KEY', <<<PEM
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwwdaCg1Bt+UKZKs0R54y
lYnuANma49IpgoOwNmk3a0rhg/PQuhUJ0EOZSowIC44l0K3+fqGns3Ygi4AfmEfS
4EKbdk1ahSxu7Zkp2rHMt+R9GarQFQkwSS/5x1dYiHNVMiR8oIXDgjmvxuNes2Cr
8fw9dEF0xNBKdkKgG2qAawcN1nZrdyaKWtPVT9m2Hl0ddOO9thZmVLFOb9NVzgYf
jEgI+KWX6aY19Ka/ghv/L4t1IXmz9pctablN5S0CRWpJW3Cn0k6zSXgjVdKm4uN7
jRlgSRaf/Ind46vMCm3N2sgwxu/g3bnooW+db0iLo13zzuvyn727Q3UDQ0MmZcEW
MQIDAQAB
-----END PUBLIC KEY-----
PEM
    );
}

// ─── 配置读取 ───────────────────────────────────────────────
if (!function_exists('zibll_child_afdian_config')) {
    function zibll_child_afdian_config()
    {
        return array(
            'user_id'      => trim(zibll_child_get_option('afdian_user_id', '')),
            'plan_id'      => trim(zibll_child_get_option('afdian_plan_id', '')),
            'api_token'    => trim(zibll_child_get_option('afdian_api_token', '')),
            'api_base'     => trim(zibll_child_get_option('afdian_api_base', 'https://ifdian.net')),
            'product_type' => zibll_child_get_option('afdian_product_type', '0'),
            'custom_price' => zibll_child_get_option('afdian_custom_price', 'auto'),
        );
    }
}

// 模块是否启用（开关 + 至少有一个能标识创作者的参数：user_id 或 plan_id 任一非空）
// 早期版本强依赖一个写死的「页面地址」，导致用户删空后整模块罢工；随后又只认 user_id，
// 让「固定方案模式（只填 plan_id）」误判禁用。现改为两者任一即可。
if (!function_exists('zibll_child_afdian_enabled')) {
    function zibll_child_afdian_enabled()
    {
        if (!zibll_child_module_enabled('enable_afdian_pay', false)) {
            return false;
        }
        $cfg = zibll_child_afdian_config();
        return $cfg['user_id'] !== '' || $cfg['plan_id'] !== '';
    }
}

// Webhook 接收地址（供后台展示 + 用户配置到爱发电开发者后台）
if (!function_exists('zibll_child_afdian_webhook_url')) {
    function zibll_child_afdian_webhook_url()
    {
        return home_url('/wp-content/themes/zibll-child/afdian-notify.php');
    }
}

// 收银台支付方式图标（爱发电品牌色：黄 #FFE411 + 闪电意象，内联 SVG，避免外部文件依赖）
if (!function_exists('zibll_child_afdian_method_img')) {
    function zibll_child_afdian_method_img()
    {
        return '<svg viewBox="0 0 28 28" width="22" height="22" aria-hidden="true" style="border-radius:5px;">'
            . '<rect x="1" y="1" width="26" height="26" rx="6" fill="#FFE411"/>'
            . '<path d="M16.5 5 L9.5 15.5 H13.5 L11.5 23 L19 12 H14.8 Z" fill="#1a1a1a"/>'
            . '</svg>';
    }
}

// ─── 钩子 1：把爱发电注入收银台支付方式列表 ──────────────────
add_filter('zibpay_payment_methods', 'zibll_child_afdian_payment_methods', 20, 2);
if (!function_exists('zibll_child_afdian_payment_methods')) {
    function zibll_child_afdian_payment_methods($methods, $pay_type)
    {
        if (zibll_child_afdian_enabled()) {
            $methods['afdian'] = array(
                'name' => '爱发电',
                'img'  => zibll_child_afdian_method_img(),
            );
        }
        return $methods;
    }
}

// ─── 钩子 2：识别 afdian 支付方式，转交本模块发起处理器 ──────
add_filter('zibpay_initiate_paysdk', 'zibll_child_afdian_initiate_paysdk', 20, 2);
if (!function_exists('zibll_child_afdian_initiate_paysdk')) {
    function zibll_child_afdian_initiate_paysdk($pay_sdk, $order_data)
    {
        if (!empty($order_data['payment_method']) && 'afdian' === $order_data['payment_method']) {
            return 'afdian';
        }
        return $pay_sdk;
    }
}

// ─── 钩子 3：拼爱发电下单页 URL（返回跳转链接，复用前端 open_url 逻辑） ──
add_filter('zibpay_initiate_afdian', 'zibll_child_afdian_initiate_pay', 10, 1);
if (!function_exists('zibll_child_afdian_initiate_pay')) {
    function zibll_child_afdian_initiate_pay($order_data)
    {
        if (!zibll_child_afdian_enabled()) {
            return array('error' => 1, 'msg' => __('当前订单不支持此方式支付，请联系客服', 'zib_language'));
        }

        $order_num   = !empty($order_data['order_num']) ? $order_data['order_num'] : '';
        $order_price = !empty($order_data['order_price']) ? (float) $order_data['order_price'] : 0;

        if (!$order_num) {
            return array('error' => 1, 'msg' => __('订单创建失败', 'zib_language'));
        }

        $url = zibll_child_afdian_order_create_url($order_num, $order_price);
        if (!$url) {
            return array('error' => 1, 'msg' => __('爱发电配置不完整，请联系客服', 'zib_language'));
        }

        return array(
            'open_url' => true,
            'url'      => $url,
        );
    }
}

// ─── 拼装爱发电下单页地址（对齐爱发电官方 / 授权中心 Go 实现） ──
// 关键点：/order/create 的前置守卫要求 URL 里出现 plan_id / user_id 之一，
// 否则页面拿不到创作者上下文，只渲染留言框和「去支付」按钮、档位区域报
// 「选择你的赞助期限」，用户根本付不了款。
if (!function_exists('zibll_child_afdian_order_create_url')) {
    function zibll_child_afdian_order_create_url($order_num, $amount)
    {
        $cfg = zibll_child_afdian_config();

        $api_base = $cfg['api_base'] !== '' ? $cfg['api_base'] : 'https://ifdian.net';
        $api_base = rtrim($api_base, '/');

        $plan_id = $cfg['plan_id'];
        $user_id = $cfg['user_id'];

        $q = array();

        if ($plan_id !== '') {
            // 固定方案模式：金额由方案自身决定，custom_price 无意义。
            $q['plan_id']      = $plan_id;
            $q['product_type'] = ($cfg['product_type'] === '1') ? '1' : '0';
        } else {
            // 自选金额模式：user_id 是让下单页正常工作的必需参数。
            if ($user_id === '') {
                return '';
            }
            $q['user_id'] = $user_id;
            if (($cfg['custom_price'] ?: 'auto') === 'auto' && $amount > 0) {
                // 预填金额，降低用户改错金额导致回调金额核对失败的概率。
                $q['custom_price'] = number_format($amount, 2, '.', '');
            }
        }

        // 两种模式都必带 custom_order_id（站内订单号）—— 回调对账唯一凭据。
        $q['custom_order_id'] = $order_num;

        return $api_base . '/order/create?' . http_build_query($q);
    }
}

// ─── Webhook 验签（RSA-SHA256，平台固定公钥） ──────────────
if (!function_exists('zibll_child_afdian_verify_sign')) {
    function zibll_child_afdian_verify_sign($order)
    {
        // 必填：out_trade_no（爱发电订单号）、total_amount（实际收款）；user_id / plan_id 允许为空但须参与拼接。
        // ⚠️ plan_id 在「自选金额模式」下本就是空字符串，但必须原样参与拼接（与授权中心 Go 实现
        //    verifyAfdianOrderSignature 完全一致：TrimSpace 后直接拼接，绝不判空），否则签名永不匹配。
        if (empty($order['out_trade_no']) || !isset($order['total_amount']) || empty($_POST['sign'])) {
            return false;
        }
        // sign_str = out_trade_no + user_id + plan_id + total_amount（逐个 TrimSpace 后拼接，对齐爱发电官方）
        $sign_str = trim($order['out_trade_no'])
            . trim(isset($order['user_id']) ? (string) $order['user_id'] : '')
            . trim(isset($order['plan_id']) ? (string) $order['plan_id'] : '')
            . trim((string) $order['total_amount']);
        // 公钥可被过滤器覆盖（便于密钥轮换 / 测试环境注入测试密钥），默认用爱发电平台固定公钥
        $public_key = apply_filters('zibll_child_afdian_public_key', ZIBLL_CHILD_AFDIANA_PUBLIC_KEY);
        $pubkey   = openssl_get_publickey($public_key);
        if (!$pubkey) {
            return false;
        }
        // PHP 8.0+ 中 OpenSSLAsymmetricKey 对象会被自动释放，无需 openssl_free_key()。
        $ok = openssl_verify($sign_str, base64_decode($_POST['sign']), $pubkey, OPENSSL_ALGO_SHA256);
        return $ok === 1;
    }
}

// 原始请求体读取（抽成函数，便于测试时在不支持 php://input 的 CLI 环境覆写）
if (!function_exists('zibll_child_afdian_raw_input')) {
    function zibll_child_afdian_raw_input()
    {
        return file_get_contents('php://input');
    }
}

// ─── Webhook 业务处理（供 afdian-notify.php 调用） ──────────
if (!function_exists('zibll_child_afdian_handle_webhook')) {
    function zibll_child_afdian_handle_webhook()
    {
        // 读取原始 JSON 体
        $raw = zibll_child_afdian_raw_input();
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data['data']['order'])) {
            return array('ec' => 200, 'em' => '');
        }

        $order = $data['data']['order'];
        // 签名字段：优先 data.sign，其次 order.sign（爱发电不同推送版本位置不同）
        $sign = '';
        if (!empty($data['data']['sign'])) {
            $sign = $data['data']['sign'];
        } elseif (!empty($order['sign'])) {
            $sign = $order['sign'];
        }
        $_POST['sign'] = $sign;

        // 验签（RSA-SHA256，平台固定公钥）
        if (!zibll_child_afdian_verify_sign($order)) {
            zibll_child_afdian_log_unmatched($order, 'sign_failed');
            return array('ec' => 200, 'em' => '');
        }

        // 仅处理交易成功（爱发电仅推送 status=2）
        if (empty($order['status']) || (int) $order['status'] !== 2) {
            return array('ec' => 200, 'em' => '');
        }

        // custom_order_id 必须是我们下单时透传的站内订单号。为空说明该订单不是在站内
        // 发起的（例如创作者自己在爱发电页面成交），直接按无关事件放行 —— 否则爱发电会无限重推。
        $custom_order_id = isset($order['custom_order_id']) ? trim($order['custom_order_id']) : '';
        if ($custom_order_id === '') {
            zibll_child_afdian_log_unmatched($order, 'no_custom_order_id');
            return array('ec' => 200, 'em' => '');
        }

        // 用兑换码支付时 total_amount 为 0.00，没有实际收款，不入账也不重推。
        $total_amount = isset($order['total_amount']) ? trim($order['total_amount']) : '';
        if ($total_amount === '' || (float) $total_amount <= 0) {
            zibll_child_afdian_log_unmatched($order, 'zero_amount');
            return array('ec' => 200, 'em' => '');
        }

        // 幂等：已支付则直接返回成功
        global $wpdb;
        $already = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM {$wpdb->zibpay_order} WHERE order_num = %s",
            $custom_order_id
        ));
        if ($already === '1') {
            return array('ec' => 200, 'em' => '');
        }

        // 入账（以爱发电实际推送金额为准；custom_order_id 已锁定站内订单）
        $pay = array(
            'order_num' => $custom_order_id,
            'pay_type'  => 'afdian',
            'pay_price' => (float) $total_amount,
            'pay_num'   => isset($order['out_trade_no']) ? $order['out_trade_no'] : '',
        );

        $result = ZibPay::payment_order($pay);
        if (!$result) {
            zibll_child_afdian_log_unmatched($order, 'payment_order_failed');
        }

        return array('ec' => 200, 'em' => '');
    }
}

// 未匹配订单留痕（避免爱发电反复重试，同时便于站长后台核查）
if (!function_exists('zibll_child_afdian_log_unmatched')) {
    function zibll_child_afdian_log_unmatched($order, $reason)
    {
        $log = get_option('zibll_child_afdian_unmatched', array());
        $log[] = array(
            'time'    => current_time('mysql'),
            'reason'  => $reason,
            'order'   => $order,
        );
        // 最多保留最近 50 条
        if (count($log) > 50) {
            $log = array_slice($log, -50);
        }
        update_option('zibll_child_afdian_unmatched', $log);
    }
}
