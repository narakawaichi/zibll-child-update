/**
 * 子比子主题 - 消息通知悬浮弹窗行为层
 *
 * 职责很窄：只做「形态切换 + 全部已读 + 收起记忆」三件事，
 * 消息内容的取数与渲染全部在 PHP 端完成（首屏即有内容，无额外请求）。
 *
 * 与父主题的关系：
 *   - 「全部已读」复用父主题自己的 admin-ajax 动作 msg_all_readed，
 *     nonce 由 PHP 用 wp_create_nonce('msg_readed') 生成后传入，
 *     不自建接口、不直接改库。
 *   - 不拦截、不修改父主题原有的顶部铃铛与消息中心。
 *
 * @package zibll-child
 */
(function () {
    'use strict';

    var CFG = window.ZC_MSGPOPUP || {};
    var KEY_DISMISS = 'zcMsgPopupDismissed';
    var KEY_LAST = 'zcMsgPopupLastUnread';

    /* ── 极简 localStorage 包装（隐私模式下会抛错，必须兜住） ── */
    function store(key, value) {
        try {
            if (value === undefined) {
                return window.localStorage.getItem(key);
            }
            if (value === null) {
                window.localStorage.removeItem(key);
            } else {
                window.localStorage.setItem(key, value);
            }
        } catch (e) {
            /* 忽略：无痕模式 / 禁用存储 */
        }
        return null;
    }

    function setOpen(el, open) {
        if (open) {
            el.classList.add('is-open');
        } else {
            el.classList.remove('is-open');
        }
    }

    /**
     * 全部标记已读：调用父主题 msg_all_readed。
     * 成功后只做前端清理（去角标 / 收起面板），不改本地数据真实值——
     * 下次刷新页面时由 PHP 重新取数，保持单一数据源。
     */
    function markAllRead(el) {
        if (!CFG.ajax) {
            return;
        }

        var body = [
            'action=msg_all_readed',
            'user_id=' + encodeURIComponent(CFG.userId || ''),
            '_wpnonce=' + encodeURIComponent(CFG.nonce || '')
        ].join('&');

        var req = new XMLHttpRequest();
        req.open('POST', CFG.ajax, true);
        req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        req.onload = function () {
            var badge = el.querySelector('.zc-mp-badge');
            if (badge && badge.parentNode) {
                badge.parentNode.removeChild(badge);
            }

            var miniList = el.querySelector('.zc-mp-mini-list');
            if (miniList) {
                miniList.innerHTML = '<span class="zc-mp-mini-row">'
                    + '<em class="zc-mp-mini-txt zc-mp-mute">暂无新消息</em></span>';
            }

            var miniFoot = el.querySelector('.zc-mp-mini .zc-mp-cfoot');
            if (miniFoot) {
                miniFoot.textContent = '展开全部消息';
            }

            var pill = el.querySelector('.zc-mp-pill span');
            if (pill) {
                pill.textContent = '消息通知';
            }

            Array.prototype.forEach.call(el.querySelectorAll('.zc-mp-item.is-unread'), function (item) {
                item.classList.remove('is-unread');
            });

            el.setAttribute('data-unread', '0');
            store(KEY_LAST, '0');
            setOpen(el, false);
        };
        req.send(body);
    }

    function handle(el, act) {
        switch (act) {
            case 'expand':
                setOpen(el, true);
                break;
            case 'fold':
                setOpen(el, false);
                break;
            case 'close':
                // 用户主动关闭：记住，之后不再自动展开，直到出现新消息
                store(KEY_DISMISS, '1');
                setOpen(el, false);
                break;
            case 'mark':
                markAllRead(el);
                break;
        }
    }

    function initOne(el) {
        var unread = parseInt(el.getAttribute('data-unread') || '0', 10) || 0;
        var lastSeen = parseInt(store(KEY_LAST) || '0', 10) || 0;

        // 未读变多 = 期间来了新消息 → 解除「不再自动展开」的标记
        if (unread > lastSeen) {
            store(KEY_DISMISS, null);
        }
        store(KEY_LAST, String(unread));

        // 用户曾主动关闭，且没有新消息 → 强制收起（PHP 已按 auto_expand 展开过）
        if (store(KEY_DISMISS) === '1') {
            setOpen(el, false);
        }

        el.addEventListener('click', function (e) {
            var trigger = e.target.closest ? e.target.closest('[data-act]') : null;

            if (trigger && el.contains(trigger)) {
                handle(el, trigger.getAttribute('data-act'));
                return;
            }

            // 点到容器空白处（移动端展开时容器铺满视口，等价于点遮罩）→ 收起
            if (e.target === el && el.classList.contains('is-open') && el.getAttribute('data-scope') === 'ph') {
                setOpen(el, false);
            }
        });

        // 键盘可达：焦点在收起态元素上时回车/空格等同点击
        el.addEventListener('keydown', function (e) {
            if (e.key !== 'Enter' && e.key !== ' ') {
                return;
            }
            var trigger = e.target.closest ? e.target.closest('[data-act="expand"]') : null;
            if (trigger && el.contains(trigger)) {
                e.preventDefault();
                setOpen(el, true);
            }
        });
    }

    function boot() {
        var roots = document.querySelectorAll('.zc-mp');
        if (!roots.length) {
            return;
        }

        Array.prototype.forEach.call(roots, initOne);

        // 桌面端：点击面板外任意位置收起（移动端由容器的遮罩区负责）
        document.addEventListener('click', function (e) {
            var pc = document.getElementById('zc-mp-pc');
            if (pc && pc.classList.contains('is-open') && !pc.contains(e.target)) {
                setOpen(pc, false);
            }
        });

        // Esc 收起所有展开的实例
        document.addEventListener('keydown', function (e) {
            if (e.key !== 'Escape') {
                return;
            }
            Array.prototype.forEach.call(document.querySelectorAll('.zc-mp.is-open'), function (el) {
                setOpen(el, false);
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
