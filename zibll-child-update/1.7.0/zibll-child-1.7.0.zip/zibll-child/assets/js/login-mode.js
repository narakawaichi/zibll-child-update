/**
 * 子比子主题 - 登录方式切换（前端）
 *
 * 在父主题登录表单顶部插入「邮箱登录 / 用户名登录（/ 手机号登录）」切换：
 *   · 邮箱登录：输入框变成「邮箱前缀 + 后缀下拉」，后缀白名单与注册页共用；
 *   · 用户名登录：普通用户名输入；
 *   · 手机号登录：父主题开启手机号登录时自动出现。
 *
 * 只改变输入引导与提交前提示，不改变后端判定 —— 父主题本来就会
 * 按内容自动识别邮箱、手机号、用户名。
 *
 * 登录的 username 字段不能拆成隐藏域，所以完整邮箱是在**点击登录的捕获阶段**
 * 补全的；父主题随后的 form.serializeObject() 拿到的就是完整地址。
 *
 * @package zibll-child
 */
(function () {
    'use strict';

    var CFG = window.ZC_LOGIN_MODE;
    if (!CFG) {
        return;
    }

    var I18N = CFG.i18n || {};
    var SUFFIXES = CFG.suffixes || [];
    var HAS_SUFFIX = SUFFIXES.length > 0;
    var MODES = CFG.phone ? ['email', 'username', 'phone'] : ['email', 'username'];
    var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

    var SUFFIX_MAP = Object.create(null);
    SUFFIXES.forEach(function (suffix) {
        SUFFIX_MAP['@' + suffix] = suffix;
    });

    var TAB_LABEL = {
        email: I18N.emailTab || '邮箱登录',
        username: I18N.usernameTab || '用户名登录',
        phone: I18N.phoneTab || '手机号登录'
    };

    var AUTOCOMPLETE = { email: 'email', username: 'username', phone: 'tel' };
    var INPUTMODE = { email: 'email', username: 'text', phone: 'tel' };

    var opened = null;

    function tip(message) {
        if (typeof window.notyf === 'function') {
            window.notyf(message, 'danger');
        } else {
            window.alert(message);
        }
    }

    function closeMenu() {
        if (!opened) {
            return;
        }
        opened.menu.style.display = 'none';
        opened.trigger.setAttribute('aria-expanded', 'false');
        opened.wrap.classList.remove('is-open');
        opened = null;
    }

    /**
     * 与 email-suffix.js 的 fitTrigger 同款：按后缀文本实测宽度动态给输入框让位，
     * 让触发器完整显示后缀（旧版写死 132px 会把长域名截成省略号）。
     */
    function fitTrigger(state) {
        var input = state.input;
        if (!input || !input.offsetWidth) {
            return;
        }

        var cs = window.getComputedStyle(state.valueEl);
        var probe = document.createElement('span');
        probe.style.position = 'absolute';
        probe.style.visibility = 'hidden';
        probe.style.whiteSpace = 'nowrap';
        probe.style.fontSize = cs.fontSize;
        probe.style.fontFamily = cs.fontFamily;
        probe.style.fontWeight = cs.fontWeight;
        probe.style.fontStyle = cs.fontStyle;
        probe.style.letterSpacing = cs.letterSpacing;
        probe.textContent = state.valueEl.textContent || '';
        document.body.appendChild(probe);
        var textW = probe.offsetWidth;
        document.body.removeChild(probe);

        var need = textW + 30;
        var maxW = Math.max(96, Math.floor(input.offsetWidth * 0.62));
        var w = Math.min(need, maxW);

        state.wrap.style.maxWidth = maxW + 'px';
        input.style.paddingRight = (w + 10) + 'px';
    }

    function placeMenu(trigger, menu) {
        var rect = trigger.getBoundingClientRect();

        menu.style.display = 'block';
        menu.style.visibility = 'hidden';
        // 与 email-suffix.js 同步：面板宽度 = 触发器宽度，
        // 超长选项由 CSS ellipsis 省略，不撑宽、不出横向滚动条。
        var width = Math.max(rect.width, 132);
        menu.style.width = width + 'px';

        var height = menu.offsetHeight;
        var left = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 8));
        var top = rect.bottom + 6;

        if (top + height > window.innerHeight - 8 && rect.top - height - 6 > 8) {
            top = rect.top - height - 6;
        }

        menu.style.left = left + 'px';
        menu.style.top = top + 'px';
        menu.style.visibility = '';
    }

    function updateActive(state) {
        if (!state.menu) {
            return;
        }
        var items = state.menu.querySelectorAll('.zic-es-item');
        for (var i = 0; i < items.length; i++) {
            var on = items[i].getAttribute('data-value') === state.suffix;
            items[i].classList.toggle('is-active', on);
            items[i].setAttribute('aria-selected', on ? 'true' : 'false');
        }
    }

    function setSuffix(state, value) {
        state.suffix = value;
        state.valueEl.textContent = value || (I18N.chooseSuffix || '选择后缀');
        state.valueEl.classList.toggle('is-placeholder', !value);
        state.trigger.title = value || '';

        // 输入框里若是完整邮箱，只保留 @ 前的部分（下拉负责后缀）
        var raw = state.input.value.trim();
        var at = raw.lastIndexOf('@');
        if (at > -1 && value) {
            state.input.value = raw.slice(0, at);
        }

        updateActive(state);
        fitTrigger(state);
    }

    function buildMenu(state) {
        var menu = document.createElement('div');
        menu.className = 'zic-es-menu';
        menu.setAttribute('role', 'listbox');

        SUFFIXES.forEach(function (suffix) {
            var value = '@' + suffix;
            var item = document.createElement('button');
            item.type = 'button';
            item.className = 'zic-es-item';
            item.setAttribute('role', 'option');
            item.setAttribute('data-value', value);
            item.textContent = value;

            item.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                setSuffix(state, value);
                closeMenu();
            });

            menu.appendChild(item);
        });

        document.body.appendChild(menu);
        return menu;
    }

    function toggleMenu(state) {
        if (opened && opened.trigger === state.trigger) {
            closeMenu();
            return;
        }
        closeMenu();

        state.menu = state.menu || buildMenu(state);
        placeMenu(state.trigger, state.menu);

        state.trigger.setAttribute('aria-expanded', 'true');
        state.wrap.classList.add('is-open');
        updateActive(state);
        opened = { trigger: state.trigger, menu: state.menu, wrap: state.wrap };
    }

    function createPicker(input, state) {
        var holder = input.parentNode;

        var wrap = document.createElement('span');
        wrap.className = 'zic-es';

        var trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'zic-es-trigger';
        trigger.setAttribute('aria-haspopup', 'listbox');
        trigger.setAttribute('aria-expanded', 'false');

        var valueEl = document.createElement('span');
        valueEl.className = 'zic-es-value is-placeholder';

        // 与后台「默认选中的后缀」配套：配置了就预选，留空才显示「选择后缀」
        var defaultSuffix = CFG.default ? '@' + CFG.default : '';
        if (defaultSuffix) {
            valueEl.classList.remove('is-placeholder');
            valueEl.textContent = defaultSuffix;
            trigger.title = defaultSuffix;
        } else {
            valueEl.textContent = I18N.chooseSuffix || '选择后缀';
        }

        var caret = document.createElement('i');
        caret.className = 'zic-es-caret';
        caret.setAttribute('aria-hidden', 'true');

        trigger.appendChild(valueEl);
        trigger.appendChild(caret);
        wrap.appendChild(trigger);
        holder.insertBefore(wrap, input.nextSibling);

        state.wrap = wrap;
        state.trigger = trigger;
        state.valueEl = valueEl;
        state.menu = null;
        state.suffix = defaultSuffix;
        fitTrigger(state);

        trigger.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            toggleMenu(state);
        });

        trigger.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                closeMenu();
            }
        });
    }

    function syncFromInput(state) {
        if (state.mode !== 'email' || !HAS_SUFFIX) {
            return;
        }

        var raw = state.input.value.trim();
        if (raw.indexOf('@') === -1) {
            return;
        }

        var at = raw.lastIndexOf('@');
        var suffix = raw.slice(at).toLowerCase();
        if (SUFFIX_MAP[suffix]) {
            state.input.value = raw.slice(0, at);
            setSuffix(state, suffix);
        }
    }

    function applyMode(form, mode) {
        var state = form.__zicLogin;
        if (!state || MODES.indexOf(mode) === -1) {
            return;
        }

        state.mode = mode;
        form.dataset.zicLoginMode = mode;

        var buttons = form.querySelectorAll('.zic-login-mode__item');
        for (var i = 0; i < buttons.length; i++) {
            var on = buttons[i].getAttribute('data-mode') === mode;
            buttons[i].classList.toggle('is-active', on);
            buttons[i].setAttribute('aria-selected', on ? 'true' : 'false');
        }

        var input = state.input;

        if (mode === 'email') {
            input.classList.toggle('zic-email-prefix', HAS_SUFFIX);
            if (state.wrap) {
                state.wrap.style.display = '';
            }
        } else {
            input.classList.remove('zic-email-prefix');
            if (state.wrap) {
                state.wrap.style.display = 'none';
            }
            closeMenu();
        }

        var placeholder = input.parentNode.querySelector('.scale-placeholder');
        if (placeholder) {
            if (mode === 'email') {
                placeholder.textContent = HAS_SUFFIX
                    ? (I18N.emailPrefixPlaceholder || '邮箱前缀')
                    : (I18N.emailPlaceholder || '邮箱地址');
            } else if (mode === 'phone') {
                placeholder.textContent = I18N.phonePlaceholder || '手机号';
            } else {
                placeholder.textContent = I18N.usernamePlaceholder || '用户名';
            }
        }

        input.setAttribute('autocomplete', AUTOCOMPLETE[mode]);
        input.setAttribute('inputmode', INPUTMODE[mode]);
        input.setAttribute('aria-label', placeholder ? placeholder.textContent : '');
    }

    function buildSwitch(form) {
        var input = form.querySelector('input[name="username"]');
        var row = input ? input.closest('.line-form') : null;
        if (!row) {
            return;
        }

        var state = { form: form, input: input, mode: 'email', suffix: '', wrap: null, trigger: null, valueEl: null, menu: null };
        form.__zicLogin = state;

        if (HAS_SUFFIX) {
            createPicker(input, state);
        }

        var switchBox = document.createElement('div');
        switchBox.className = 'zic-login-mode';
        switchBox.setAttribute('role', 'tablist');
        switchBox.setAttribute('aria-label', '登录方式');

        MODES.forEach(function (mode) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'zic-login-mode__item';
            btn.setAttribute('role', 'tab');
            btn.setAttribute('data-mode', mode);
            btn.textContent = TAB_LABEL[mode];

            btn.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                applyMode(form, mode);
            });

            switchBox.appendChild(btn);
        });

        form.insertBefore(switchBox, row);
        applyMode(form, 'email');

        input.addEventListener('input', function () {
            syncFromInput(state);
        });
        input.addEventListener('change', function () {
            syncFromInput(state);
        });
    }

    function enhance(form) {
        if (!form || form.dataset.zicLoginModeReady === '1') {
            return;
        }
        if (!form.querySelector('input[name="username"]') || !form.querySelector('input[name="password"]')) {
            return;
        }

        form.dataset.zicLoginModeReady = '1';
        buildSwitch(form);
    }

    /**
     * 提交前处理：按模式补全/提示。
     *
     * 必须挂在捕获阶段：父主题的 .signsubmit-loader 是 body 上的 jQuery 委托，
     * 捕获阶段先执行才能先补全 username、并在明显填错时拦住请求。
     */
    document.addEventListener('click', function (event) {
        var target = event.target;
        if (!target || !target.closest) {
            return;
        }

        if (opened && !target.closest('.zic-es') && !target.closest('.zic-es-menu')) {
            closeMenu();
        }

        var button = target.closest('.signsubmit-loader');
        if (!button) {
            return;
        }

        var form = button.closest('form');
        var state = form ? form.__zicLogin : null;
        if (!state) {
            return;
        }

        var input = state.input;
        var value = (input.value || '').trim();
        var mode = state.mode;
        var message = '';

        if (mode === 'email') {
            if (value !== '') {
                if (value.indexOf('@') === -1) {
                    if (state.suffix) {
                        // 把「前缀 + 后缀」补成完整邮箱，父主题随后的序列化即可拿到完整地址
                        input.value = value + state.suffix;
                    } else if (HAS_SUFFIX) {
                        message = I18N.needSuffix || '请选择邮箱后缀';
                    } else {
                        message = I18N.needEmail || '请输入完整的邮箱地址';
                    }
                } else if (!EMAIL_RE.test(value)) {
                    message = I18N.needEmail || '请输入完整的邮箱地址';
                }
            }
        } else if (mode === 'username') {
            if (value !== '' && value.indexOf('@') > -1) {
                message = I18N.needUsername || '用户名登录请填写用户名，不要带 @';
            }
        } else if (mode === 'phone') {
            if (value !== '' && !/^1\d{10}$/.test(value)) {
                message = '请输入 11 位手机号';
            }
        }

        if (message) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) {
                event.stopImmediatePropagation();
            }
            tip(message);
        }
    }, true);

    window.addEventListener('scroll', function (event) {
        var t = event.target;
        if (t && t.closest && t.closest('.zic-es-menu')) {
            return;
        }
        closeMenu();
    }, true);
    window.addEventListener('resize', closeMenu);
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            closeMenu();
        }
    });

    function scan() {
        // 只处理 #sign-in 内的登录表单：
        //   - 找回密码表单不在 #sign-in 内；
        //   - 注册表单在 #tab-sign-up，也不在范围内。
        var forms = document.querySelectorAll('#sign-in form');
        for (var i = 0; i < forms.length; i++) {
            enhance(forms[i]);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', scan);
    } else {
        scan();
    }

    if (window.MutationObserver) {
        var scheduled = false;
        var observer = new MutationObserver(function () {
            if (scheduled) {
                return;
            }
            scheduled = true;
            window.setTimeout(function () {
                scheduled = false;
                scan();
            }, 60);
        });

        observer.observe(document.body || document.documentElement, {
            childList: true,
            subtree: true
        });
    }
})();
