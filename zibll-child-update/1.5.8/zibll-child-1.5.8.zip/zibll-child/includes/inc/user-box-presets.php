<?php
/**
 * 子比子主题 - 悬停面板「快捷按钮」预设动作池
 *
 * 每条预设对应 zibll 已有的一个真实可打开的目标（用户中心子页 / 投稿页 / 退出登录等）。
 * 添加按钮时选「预设动作」即可一键带出 文字 + 图标 + 链接 + 默认可见权限，
 * 管理员只需决定它的「可见权限」与「排序」即可。
 *
 * 字段说明：
 *   title      默认显示文字
 *   icon_type  svg | fa
 *   icon       图标名（svg 名取自 zibll/js/svg-icon.js；fa 名取自 font-awesome）
 *   color      按钮配色（zibll 的 c-* 颜色类）
 *   link_mode  preset（走下方 preset_key 解析）| logout（退出登录弹窗）
 *   preset_key 解析链接时用的 token（见 includes/functions/user-box.php 的 switch）
 *   cap        默认可见权限：all / logged / vip / level / auth
 *   requires   依赖的主题开关（_pz 键）；为空表示无依赖。开关关闭时该预设自动不显示。
 *              —— 例：我的订单依赖 shop_s；发布文章依赖 nav_user_newposts_btn。
 *   desc       后台选择器里的说明
 *
 * 注意：图标名只作默认值，管理员在设置面板里可任意改成全部 902 个图标中的任意一个。
 */
if (!defined('ABSPATH')) {
    exit;
}

return array(
    'user_center' => array(
        'title'     => '用户中心',
        'icon_type' => 'svg',
        'icon'      => 'user',
        'color'     => 'c-blue',
        'link_mode' => 'preset',
        'preset_key' => 'user_center',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '个人主页 / 资料',
    ),
    'my_order' => array(
        'title'     => '我的订单',
        'icon_type' => 'svg',
        'icon'      => 'handbag',
        'color'     => 'c-purple',
        'link_mode' => 'preset',
        'preset_key' => 'order',
        'cap'       => 'logged',
        'requires'  => 'shop_s',
        'desc'      => '需开启商城（shop_s）；关闭商城后自动隐藏',
    ),
    'new_post' => array(
        'title'     => '发布文章',
        'icon_type' => 'fa',
        'icon'      => 'pencil-square-o',
        'color'     => 'c-green',
        'link_mode' => 'preset',
        'preset_key' => 'new_post',
        'cap'       => 'logged',
        'requires'  => 'nav_user_newposts_btn',
        'desc'      => '前台投稿；依赖「导航栏用户卡片-投稿按钮」开启',
    ),
    'my_vip' => array(
        'title'     => '我的会员',
        'icon_type' => 'svg',
        'icon'      => 'vip_1',
        'color'     => 'c-yellow',
        'link_mode' => 'preset',
        'preset_key' => 'vip',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '会员中心',
    ),
    'my_balance' => array(
        'title'     => '我的余额',
        'icon_type' => 'fa',
        'icon'      => 'credit-card',
        'color'     => 'c-yellow',
        'link_mode' => 'preset',
        'preset_key' => 'balance',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '余额 / 积分',
    ),
    'my_income' => array(
        'title'     => '创作分成',
        'icon_type' => 'fa',
        'icon'      => 'pie-chart',
        'color'     => 'c-yellow',
        'link_mode' => 'preset',
        'preset_key' => 'income',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '创作收益',
    ),
    'my_rebate' => array(
        'title'     => '我的推广',
        'icon_type' => 'fa',
        'icon'      => 'share-alt',
        'color'     => 'c-yellow',
        'link_mode' => 'preset',
        'preset_key' => 'rebate',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '推广佣金',
    ),
    'my_account' => array(
        'title'     => '账号设置',
        'icon_type' => 'fa',
        'icon'      => 'cog',
        'color'     => 'c-blue',
        'link_mode' => 'preset',
        'preset_key' => 'account',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '账号 / 绑定',
    ),
    'my_level' => array(
        'title'     => '我的等级',
        'icon_type' => 'fa',
        'icon'      => 'level-up',
        'color'     => 'c-blue',
        'link_mode' => 'preset',
        'preset_key' => 'level',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '成长等级',
    ),
    'my_auth' => array(
        'title'     => '我的认证',
        'icon_type' => 'svg',
        'icon'      => 'user-auth',
        'color'     => 'c-blue',
        'link_mode' => 'preset',
        'preset_key' => 'auth',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '实名 / 认证',
    ),
    'logout' => array(
        'title'     => '退出登录',
        'icon_type' => 'svg',
        'icon'      => 'signout',
        'color'     => 'c-red',
        'link_mode' => 'logout',
        'preset_key' => 'logout',
        'cap'       => 'logged',
        'requires'  => '',
        'desc'      => '弹窗确认退出（兜底始终保留，不会因删除而丢失）',
    ),
);
