<?php
/**
 * 私信实时推送（WebSocket）
 *
 * 整合自独立插件 zib-private-push，按子主题规范并入 includes/functions/。
 *
 * ─── 做什么 ─────────────────────────────────────────────────
 *   给父主题的私信加 WebSocket 实时推送：
 *     · 对方发来的消息，气泡当场出现，不用刷新
 *     · 左侧会话列表的红点 / 最新一句 / 时间 / 新联系人，实时刷新
 *     · 自己消息上的「未读」字样，对方看过之后实时消失
 *
 * ─── 怎么做（零侵入父主题）─────────────────────────────────
 *   只挂父主题已有的两个钩子，不修改任何父主题文件：
 *     · zib_add_message          —— 私信落库后「摇铃」通知推送服务
 *     · zib_message_all_readed   —— 有人把私信标为已读时，反向通知发消息的人
 *   气泡与列表的 HTML 全部复用父主题自己的渲染函数：
 *     · Zib_Private::get_msg_box()     （单条气泡）
 *     · Zib_Private::get_chat_lists()  （左侧会话列表）
 *   因此样式、头像、红点、分页与父主题原生完全一致，父主题升级也不会变形。
 *
 * ─── 为什么不会绕开父主题的安全逻辑 ────────────────────────
 *   发送仍然走父主题原有的 admin-ajax 接口，内容审核、黑名单、封号、
 *   私信邮件通知全部照旧生效；本模块只在「消息已经存进数据库之后」做事。
 *
 * ─── 依赖 ───────────────────────────────────────────────────
 *   · 推送服务（Node.js + ws，部署在 api.hoarfall.cn）
 *   · 设置项见「子比子主题设置 → 私信实时推送」
 *   · 未开启 / 未填地址 / 未填密钥时：不注册任何前台脚本，零开销
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ─────────────────────────────────────────────────────────────
 * 0. 配置读取
 * ───────────────────────────────────────────────────────────── */

/**
 * 模块总开关
 *
 * ⚠️ 不用 zibll_child_option_enabled()：CSF 的 switcher 关闭时保存的是
 *    **空字符串**，而 zibll_child_option_enabled() 会把空字符串落回默认值。
 *    与本主题 email-suffix / login-mode / comment-mark 的处理方式保持一致：
 *    只有明确是 true / 1 / '1' 才算开启，其余一律视为关闭。
 */
function zibll_child_pp_enabled()
{
    if (!function_exists('zibll_child_get_option')) {
        return false;
    }
    $v = zibll_child_get_option('private_push_enable', false);
    return ($v === true || $v === 1 || $v === '1');
}

/** 推送服务基址（去掉结尾斜杠） */
function zibll_child_pp_base()
{
    $base = (string) zibll_child_get_option('private_push_base', '');
    return rtrim(trim($base), '/');
}

/** 共享密钥 */
function zibll_child_pp_secret()
{
    return (string) zibll_child_get_option('private_push_secret', '');
}

/** 兜底轮询间隔（秒） */
function zibll_child_pp_fallback()
{
    $n = (int) zibll_child_get_option('private_push_fallback', 5);
    return $n >= 3 && $n <= 60 ? $n : 5;
}

/** 配置是否完整可用 */
function zibll_child_pp_ready()
{
    return zibll_child_pp_enabled() && '' !== zibll_child_pp_base() && '' !== zibll_child_pp_secret();
}

/** https://push.x.com  =>  wss://push.x.com/ws */
function zibll_child_pp_ws_url()
{
    $base = zibll_child_pp_base();
    if ('' === $base) {
        return '';
    }
    $base = preg_replace('#^https://#i', 'wss://', $base);
    $base = preg_replace('#^http://#i', 'ws://', $base);
    return $base . '/ws';
}

/**
 * 「摇铃」地址：发消息后通知推送服务用
 *
 * 默认走公网域名，但如果填了「内网投递地址」，就改走本机直连。
 *
 * 为什么要这个开关（实测数据）：
 *   走公网 https://api.hoarfall.cn/notify  →  34.2 ms
 *   走本机 http://127.0.0.1:8787/notify    →   0.92 ms
 * 那 33 毫秒全是「从服务器出门绕公网、再进同一台机器」的 DNS + TLS 加密握手开销。
 * 服务器和推送服务装在同一台机器时，这段路完全没必要走。
 *
 * 注意：这里只影响「发消息的人等多久」，不影响消息送达速度；
 *      签名校验照旧，不会因为走内网就降低安全性（内网地址外人也访问不到）。
 */
function zibll_child_pp_notify_url()
{
    $internal = rtrim(trim((string) zibll_child_get_option('private_push_notify', '')), '/');

    if ('' !== $internal) {
        // 允许偷懒只填 127.0.0.1:8787，自动补上 http://
        if (!preg_match('#^https?://#i', $internal)) {
            $internal = 'http://' . $internal;
        }
        return $internal . '/notify';
    }

    return zibll_child_pp_base() . '/notify';
}

/**
 * 体检地址
 *
 * 推送服务对 /health 分两档返回：
 *   · 不签名 → 只回 {"ok":true}（外人只能知道服务活着）
 *   · 带 ts+sig → 回完整信息（在线人数等），签名算法 sig = hmac("health|ts")
 * 这里默认带签名，所以后台「测试连接」能看到在线人数。
 *
 * @param bool $signed 是否附带签名
 */
function zibll_child_pp_health_url($signed = true)
{
    $url = zibll_child_pp_base() . '/health';

    if (!$signed) {
        return $url;
    }

    $ts = time();
    return $url . '?ts=' . $ts . '&sig=' . zibll_child_pp_sign('health|' . $ts);
}

/**
 * 统一签名算法，必须与推送服务 server.js 完全一致
 */
function zibll_child_pp_sign($str)
{
    return hash_hmac('sha256', (string) $str, zibll_child_pp_secret());
}

/**
 * 调试日志：只记录元数据，永远不记录消息正文
 */
function zibll_child_pp_log($msg)
{
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('[ZC-PP] ' . $msg);
    }
}

/**
 * 保存设置时，保护共享密钥不被误清空
 *
 * 背景：设置面板每次保存都会用「表单里提交的字段」重建整个选项数组，
 *      没出现在表单里的键会被丢掉。如果哪天密钥字段被改成隐藏、
 *      或者被浏览器密码管理器清空，密钥就会凭空消失，推送直接罢工。
 * 做法：保存前若发现提交数据里没有密钥（或为空），就把数据库里的旧值补回去。
 *      想真正更换密钥，就在面板里填一个新的，仍然生效。
 */
add_filter('csf_zibll_child_options_save', 'zibll_child_pp_keep_secret', 10, 1);

function zibll_child_pp_keep_secret($data)
{
    if (!is_array($data)) {
        return $data;
    }

    if (!empty($data['private_push_secret'])) {
        return $data;   // 用户填了新密钥，尊重用户
    }

    $old = (array) get_option('zibll_child_options', array());
    if (!empty($old['private_push_secret'])) {
        $data['private_push_secret'] = $old['private_push_secret'];
    }

    return $data;
}

/* ─────────────────────────────────────────────────────────────
 * 1. 新私信落库后「摇铃」
 * ───────────────────────────────────────────────────────────── */

add_action('zib_add_message', 'zibll_child_pp_on_new_message', 20);

/**
 * @param array $values 父主题写入数据库的消息字段
 */
function zibll_child_pp_on_new_message($values)
{
    if (!zibll_child_pp_ready()) {
        return;
    }

    $values = (array) $values;

    // 只处理私信，其余消息类型（评论/订单/系统通知…）一律放行
    if (empty($values['type']) || 'private' !== $values['type']) {
        return;
    }

    $to   = isset($values['receive_user']) ? (int) $values['receive_user'] : 0;
    $from = isset($values['send_user']) ? (int) $values['send_user'] : 0;

    if (!$to || !$from || $to === $from) {
        return;
    }
    if (empty($values['content'])) {
        return;
    }

    // 钩子在 $wpdb->insert() 之后触发，insert_id 就是这条消息的 ID
    global $wpdb;
    $msg_id = (int) $wpdb->insert_id;
    if (!$msg_id) {
        return;
    }

    // 复用父主题渲染，保证气泡与原生完全一致
    $html = '';
    if (class_exists('Zib_Private') && method_exists('Zib_Private', 'get_msg_box')) {
        $html = Zib_Private::get_msg_box($values, $to);
    }
    if (!$html) {
        zibll_child_pp_log('render failed, msg#' . $msg_id);
        return;
    }

    $ts   = time();
    $body = array(
        'to'     => $to,
        'from'   => $from,
        'msg_id' => $msg_id,
        'html'   => $html,
        'ts'     => $ts,
        'sig'    => zibll_child_pp_sign($to . '|' . $msg_id . '|' . $ts),
    );

    // 非阻塞：把信扔进邮筒就走，推送服务再慢也拖不慢发信人
    wp_remote_post(
        zibll_child_pp_notify_url(),
        array(
            'timeout'  => 0.5,
            'blocking' => false,
            'headers'  => array('Content-Type' => 'application/json'),
            'body'     => wp_json_encode($body),
        )
    );

    zibll_child_pp_log('notify to=' . $to . ' msg#' . $msg_id . ' bytes=' . strlen($html));
}

/* ─────────────────────────────────────────────────────────────
 * 2. 已读回执：告诉发消息的人「对方已经看了」
 * ───────────────────────────────────────────────────────────── */

/**
 * @param int $to     回执推给谁（原来发消息的人）
 * @param int $reader 谁读的
 */
function zibll_child_pp_push_read($to, $reader)
{
    if (!zibll_child_pp_ready() || !$to || !$reader) {
        return;
    }

    $ts   = time();
    $body = array(
        'to'   => (int) $to,
        'from' => (int) $reader,
        'read' => 1,
        'ts'   => $ts,
        'sig'  => zibll_child_pp_sign($to . '|read|' . $ts),
    );

    wp_remote_post(
        zibll_child_pp_notify_url(),
        array(
            'timeout'  => 0.5,
            'blocking' => false,
            'headers'  => array('Content-Type' => 'application/json'),
            'body'     => wp_json_encode($body),
        )
    );

    zibll_child_pp_log('read-ack reader=' . $reader . ' to=' . $to);
}

/**
 * 父主题把私信标记为已读时触发。
 * 「打开聊天窗口」和「收到新消息」都会走到这里，所以只挂一处即可全覆盖。
 */
add_action('zib_message_all_readed', 'zibll_child_pp_on_all_readed', 20, 2);

function zibll_child_pp_on_all_readed($where, $user_id)
{
    if (!zibll_child_pp_ready()) {
        return;
    }

    $where = (array) $where;

    if (empty($where['type']) || 'private' !== $where['type']) {
        return;
    }

    $reader = (int) $user_id;
    if (!$reader) {
        return;
    }

    // send_user 即「原发消息的人」，也就是要通知回执的对象
    $peer = 0;
    if (!empty($where['send_user'])) {
        if (is_array($where['send_user'])) {
            foreach ($where['send_user'] as $u) {
                if (is_numeric($u)) {
                    $peer = (int) $u;
                    break;
                }
            }
        } elseif (is_numeric($where['send_user'])) {
            $peer = (int) $where['send_user'];
        }
    }

    if (!$peer || $peer === $reader) {
        return;
    }

    zibll_child_pp_push_read($peer, $reader);
}

/* ─────────────────────────────────────────────────────────────
 * 3. 前台接口（全部要求登录 + nonce）
 * ───────────────────────────────────────────────────────────── */

/** 统一的安全校验，失败直接返回 JSON 错误 */
function zibll_child_pp_verify($require_ready = true)
{
    if ($require_ready && !zibll_child_pp_ready()) {
        wp_send_json_error(array('message' => '实时推送未启用'));
    }
    if (!check_ajax_referer('zibll_child_pp', 'nonce', false)) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面'));
    }

    $uid = get_current_user_id();
    if (!$uid) {
        wp_send_json_error(array('message' => '请先登录'));
    }
    return $uid;
}

/**
 * 3.1 通行证：浏览器拿着它去连 WebSocket
 *     格式 base64url( 用户ID . 过期时间 . 签名 )，60 秒有效
 */
add_action('wp_ajax_zibll_child_pp_ticket', 'zibll_child_pp_ajax_ticket');

function zibll_child_pp_ajax_ticket()
{
    $uid = zibll_child_pp_verify();

    $exp    = time() + 60;
    $sig    = zibll_child_pp_sign($uid . '.' . $exp);
    $ticket = rtrim(strtr(base64_encode($uid . '.' . $exp . '.' . $sig), '+/', '-_'), '=');

    wp_send_json_success(array(
        'ticket' => $ticket,
        'ws'     => zibll_child_pp_ws_url(),
        'uid'    => $uid,
    ));
}

/**
 * 3.2 兜底轮询：只在 WebSocket 连不上时使用
 */
add_action('wp_ajax_zibll_child_pp_poll', 'zibll_child_pp_ajax_poll');

function zibll_child_pp_ajax_poll()
{
    $me = zibll_child_pp_verify();

    $peer    = isset($_POST['peer']) ? (int) $_POST['peer'] : 0;
    $last_id = isset($_POST['last_id']) ? (int) $_POST['last_id'] : 0;

    if (!$peer || $peer === $me) {
        wp_send_json_error(array('message' => '参数错误'));
    }
    if (!class_exists('Zib_Private')) {
        wp_send_json_error(array('message' => '父主题未就绪'));
    }

    $rows = Zib_Private::get_msg($me, $peer, 0, 30, 'id', 'DESC');
    $rows = array_reverse((array) $rows);

    $out = array();
    $max = $last_id;

    foreach ($rows as $row) {
        $row = (array) $row;
        $id  = isset($row['id']) ? (int) $row['id'] : 0;
        if (!$id || $id <= $last_id) {
            continue;
        }
        $out[] = array(
            'id'   => $id,
            'from' => isset($row['send_user']) ? (int) $row['send_user'] : 0,
            'html' => Zib_Private::get_msg_box($row, $me),
        );
        if ($id > $max) {
            $max = $id;
        }
    }

    wp_send_json_success(array(
        'messages' => $out,
        'last_id'  => $max,
    ));
}

/**
 * 3.3 回执：把对方发来的消息标记为已读
 */
add_action('wp_ajax_zibll_child_pp_ack', 'zibll_child_pp_ajax_ack');

function zibll_child_pp_ajax_ack()
{
    $me = zibll_child_pp_verify(false);

    $peer = isset($_POST['peer']) ? (int) $_POST['peer'] : 0;
    if (!$peer || !class_exists('ZibMsg')) {
        wp_send_json_error(array('message' => '参数错误'));
    }

    ZibMsg::user_all_readed(array(
        'send_user'      => $peer,
        'receive_user'   => $me,
        'status'         => 0,
        'no_readed_user' => $me,
        'type'           => 'private',
    ), $me);

    wp_send_json_success();
}

/**
 * 3.4 左侧会话列表：重新渲染一份最新的
 *     复用父主题 Zib_Private::get_chat_lists()，红点/头像/最新一句/分页全一致
 */
add_action('wp_ajax_zibll_child_pp_chatlist', 'zibll_child_pp_ajax_chatlist');

function zibll_child_pp_ajax_chatlist()
{
    $me = zibll_child_pp_verify();

    if (!class_exists('Zib_Private')) {
        wp_send_json_error(array('message' => '父主题未就绪'));
    }

    // 前端把「当前已显示多少条」传上来，保证刷新后条数不变，不会把翻出来的记录弄丢
    $limit = isset($_POST['limit']) ? (int) $_POST['limit'] : 10;
    $limit = max(10, min(200, $limit));

    // get_chat_lists 内部会读这两个参数
    $_REQUEST['paged']       = 1;
    $_REQUEST['ice_perpage'] = $limit;

    $html = Zib_Private::get_chat_lists($me, $limit, 1);

    wp_send_json_success(array('html' => (string) $html));
}

/**
 * 3.5 后台「测试连接」：由服务端访问 /health，避开浏览器跨域
 */
add_action('wp_ajax_zibll_child_pp_test', 'zibll_child_pp_ajax_test');

function zibll_child_pp_ajax_test()
{
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => '权限不足'));
    }
    if (!check_ajax_referer('zibll_child_pp', 'nonce', false)) {
        wp_send_json_error(array('message' => '安全验证失败，请刷新页面'));
    }
    if ('' === zibll_child_pp_base()) {
        wp_send_json_error(array('message' => '还没填推送服务地址'));
    }

    $res = wp_remote_get(zibll_child_pp_health_url(), array('timeout' => 5));

    if (is_wp_error($res)) {
        wp_send_json_error(array('message' => '连不上推送服务：' . $res->get_error_message()));
    }

    $code = (int) wp_remote_retrieve_response_code($res);
    $data = json_decode(wp_remote_retrieve_body($res), true);

    if (200 !== $code || !is_array($data)) {
        wp_send_json_error(array('message' => '返回异常（HTTP ' . $code . '），确认地址指向推送服务根路径'));
    }

    // 只有签名对得上才会返回在线人数；只拿到 ok 说明密钥不一致或服务端是旧版
    if (!isset($data['users'])) {
        wp_send_json_error(array(
            'message' => '服务是通的，但没拿到在线人数 —— 多半是「共享密钥」和推送服务对不上，请核对',
        ));
    }

    wp_send_json_success(array(
        'message' => sprintf(
            '推送服务正常，当前在线用户 %s 人，连接数 %s',
            (int) $data['users'],
            isset($data['online']) ? (int) $data['online'] : 0
        ),
    ));
}

/* ─────────────────────────────────────────────────────────────
 * 4. 前台脚本
 * ───────────────────────────────────────────────────────────── */

add_action('wp_enqueue_scripts', 'zibll_child_pp_assets', 30);

function zibll_child_pp_assets()
{
    // 未登录、未配置：一概不加载，页面上一个字节都不多
    if (!is_user_logged_in() || !zibll_child_pp_ready()) {
        return;
    }

    $uri = get_stylesheet_directory_uri() . '/assets/js/private-push.js';
    $ver = wp_get_theme()->get('Version');

    // 缓存戳：追加文件 mtime，单文件更新即自动失效，无需 bump 主题版本
    // （与同目录 msg-popup 模块的做法保持一致）
    $mtime = @filemtime(get_stylesheet_directory() . '/assets/js/private-push.js');
    if ($mtime) {
        $ver .= '.' . $mtime;
    }

    wp_enqueue_script('zc-private-push', $uri, array('jquery'), $ver, true);

    wp_localize_script('zc-private-push', 'ZC_PRIVATE_PUSH', array(
        'ajax'     => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('zibll_child_pp'),
        'fallback' => zibll_child_pp_fallback(),
    ));
}

/* ─────────────────────────────────────────────────────────────
 * 5. 后台：设置页里的「测试连接」按钮
 * ───────────────────────────────────────────────────────────── */

add_action('admin_footer', 'zibll_child_pp_admin_footer_script');

function zibll_child_pp_admin_footer_script()
{
    if (!isset($_GET['page']) || 'zibll_child_options' !== $_GET['page']) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }

    $nonce = wp_create_nonce('zibll_child_pp');
    ?>
    <script>
    (function () {
        var ajax = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
        var nonce = <?php echo wp_json_encode($nonce); ?>;

        document.addEventListener('click', function (e) {
            var btn = e.target.closest && e.target.closest('#zc-pp-test');
            if (!btn) {
                return;
            }
            e.preventDefault();

            var out = document.getElementById('zc-pp-test-result');
            if (out) {
                out.textContent = '检测中…';
                out.style.color = '#8c8f94';
            }

            var body = new URLSearchParams();
            body.append('action', 'zibll_child_pp_test');
            body.append('nonce', nonce);

            fetch(ajax, { method: 'POST', credentials: 'same-origin', body: body })
                .then(function (r) { return r.json(); })
                .then(function (r) {
                    if (!out) { return; }
                    if (r && r.success) {
                        out.textContent = '✅ ' + r.data.message;
                        out.style.color = '#00a32a';
                    } else {
                        out.textContent = '❌ ' + ((r && r.data && r.data.message) || '连接失败');
                        out.style.color = '#d63638';
                    }
                })
                .catch(function () {
                    if (!out) { return; }
                    out.textContent = '❌ 请求失败，检查地址是否正确';
                    out.style.color = '#d63638';
                });
        });
    })();
    </script>
    <?php
}

