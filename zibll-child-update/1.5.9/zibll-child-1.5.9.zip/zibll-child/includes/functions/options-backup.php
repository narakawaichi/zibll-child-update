<?php
/**
 * 子比子主题 - 主题设置备份 / 恢复 / 导入 / 导出
 * ─────────────────────────────────────────────────────────────
 * 功能来源：参考第三方子主题框架 Vela（DearLicy/zibll_child）同款能力，
 *           改用本子主题前缀与存储键重新实现，并补齐 nonce 校验。
 *
 * 设计要点：
 *   1. 备份快照同时含两个 option：
 *        - zibll_child_options  （CSF 设置面板，含各功能配置）
 *        - zibll_child_modules  （模块全量开关，独立存储）
 *      恢复时两个一起写回，保证"开关 + 配置"回到同一点。
 *   2. 自动备份时机（复用父主题 9.1 完整版 CSF 的动作钩子）：
 *        csf_zibll_child_options_saved            → 保存后自动备份
 *        csf_zibll_child_options_reset_before     → 重置前自动备份
 *        csf_zibll_child_options_reset_section_before → 重置分区前自动备份
 *   3. 上限 20 份，超出自动淘汰最旧（与 Vela 一致）。
 *   4. 所有 AJAX 均要求 manage_options + nonce（Vela 原版只有角色校验，无 nonce）。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('ZIBLL_CHILD_BACKUP_OPT')) {
    define('ZIBLL_CHILD_BACKUP_OPT', 'zibll_child_options_backup');
}
if (!defined('ZIBLL_CHILD_BACKUP_MAX')) {
    define('ZIBLL_CHILD_BACKUP_MAX', 20);
}
if (!defined('ZIBLL_CHILD_BACKUP_NONCE')) {
    define('ZIBLL_CHILD_BACKUP_NONCE', 'zibll_child_backup_action');
}

/**
 * 创建一份设置快照（同时含设置面板 + 模块开关）。
 *
 * @param string $type 备份类型说明（手动/自动）
 * @return bool|array 成功返回整份备份数组，失败 false
 */
function zibll_child_settings_backup($type = '手动备份')
{
    $snapshot = array(
        'options' => get_option('zibll_child_options', array()),
        'modules' => get_option('zibll_child_modules', array()),
    );

    $backup = get_option(ZIBLL_CHILD_BACKUP_OPT, array());
    if (!is_array($backup)) {
        $backup = array();
    }

    $time = current_time('Y-m-d H:i:s');
    // 同一秒内多份会互相覆盖，附加毫秒位避免（如连续自动备份）
    $key = $time;
    while (isset($backup[$key])) {
        $key .= '.1';
    }

    $backup[$key] = array(
        'time' => $time,
        'type' => $type,
        'data' => $snapshot,
    );

    // 保留最近 ZIBLL_CHILD_BACKUP_MAX 份
    if (count($backup) > ZIBLL_CHILD_BACKUP_MAX) {
        $backup = array_slice($backup, -ZIBLL_CHILD_BACKUP_MAX, null, true);
    }

    update_option(ZIBLL_CHILD_BACKUP_OPT, $backup);
    return $backup;
}

/**
 * 从指定备份恢复（设置 + 模块开关一并写回）。
 *
 * @param string $key 备份的时间戳键
 * @return bool
 */
function zibll_child_settings_restore($key)
{
    $backup = get_option(ZIBLL_CHILD_BACKUP_OPT, array());
    if (!is_array($backup) || empty($backup[$key]['data']) || !is_array($backup[$key]['data'])) {
        return false;
    }
    $snapshot = $backup[$key]['data'];

    $options = isset($snapshot['options']) && is_array($snapshot['options']) ? $snapshot['options'] : array();
    $modules = isset($snapshot['modules']) && is_array($snapshot['modules']) ? $snapshot['modules'] : array();

    update_option('zibll_child_options', $options);
    update_option('zibll_child_modules', $modules);
    return true;
}

/**
 * 设置面板内「备份 & 导入」UI 的 HTML（由 theme-options.php 的 content 字段承载）。
 */
if (!function_exists('zibll_child_settings_backup_html')) {
    function zibll_child_settings_backup_html()
    {
        $backup = get_option(ZIBLL_CHILD_BACKUP_OPT, array());
        if (!is_array($backup)) {
            $backup = array();
        }
        $nonce     = wp_create_nonce(ZIBLL_CHILD_BACKUP_NONCE);
        $admin_url = admin_url('admin.php?page=zibll_child_options');

        // 备份列表
        $extra = '';
        if (empty($backup)) {
            $list = '<p class="zibllc-hint" style="margin:0;">暂无备份数据。系统会在保存设置、重置设置等关键操作前自动创建备份。</p>';
        } else {
            $list = '';
            $backup_desc = array_reverse($backup, true);
            $count = count($backup_desc);
            foreach ($backup_desc as $key => $val) {
                $label = isset($val['type']) ? $val['type'] : '备份';
                $time  = isset($val['time']) ? $val['time'] : $key;
                $list .= '<div class="zibllc-backup-row" data-key="' . esc_attr($key) . '">'
                    . '<span class="zibllc-backup-meta"><code>' . esc_html($time) . '</code>'
                    . '<span class="zibllc-hint">[' . esc_html($label) . ']</span></span>'
                    . '<span class="zibllc-backup-actions">'
                    . '<button type="button" class="button button-small zibllc-bk-restore" data-nonce="' . esc_attr($nonce) . '">恢复</button> '
                    . '<button type="button" class="button button-small zibllc-bk-delete" data-nonce="' . esc_attr($nonce) . '">删除</button>'
                    . '</span></div>';
            }
            if ($count > 3) {
                $extra .= '<button type="button" class="button zibllc-bk-surplus" data-nonce="' . esc_attr($nonce) . '">仅保留最新 3 份</button> ';
            }
            $extra .= '<button type="button" class="button zibllc-bk-delete-all" data-nonce="' . esc_attr($nonce) . '">删除全部备份</button>';
        }

        $export_url = add_query_arg(
            array(
                'action' => 'zibll_child_settings_export',
                'nonce'  => wp_create_nonce(ZIBLL_CHILD_BACKUP_NONCE),
            ),
            admin_url('admin-ajax.php')
        );

        $html  = '<div class="zibllc-update">';

        // —— 备份 & 恢复 ——
        $html .= '<h4 class="zibllc-sub">备份 & 恢复</h4>';
        $html .= '<p class="zibllc-hint">系统最多保留 ' . ZIBLL_CHILD_BACKUP_MAX . ' 份，保存/重置设置前会自动创建备份。恢复后请刷新页面确认。</p>';
        $html .= '<div class="zibllc-backup-list">' . $list . '</div>';
        $html .= '<div class="zibllc-actions" style="margin-top:10px;">'
            . '<button type="button" class="button button-primary zibllc-bk-now" data-nonce="' . esc_attr($nonce) . '">备份当前配置</button> '
            . (isset($extra) ? $extra : '')
            . '</div>';

        // —— 导入 & 导出 ——
        $html .= '<h4 class="zibllc-sub" style="margin-top:18px;">导入 & 导出</h4>';
        $html .= '<p class="zibllc-hint">导出会下载当前面板全部配置（含模块开关）。导入请粘贴导出的 JSON；导入前会自动备份当前配置。</p>';
        $html .= '<textarea id="zibllc-import-data" class="large-text code" rows="6" style="font-family:monospace;" placeholder="粘贴导出的 JSON 配置…"></textarea>';
        $html .= '<div class="zibllc-actions" style="margin-top:8px;">'
            . '<button type="button" class="button button-primary zibllc-bk-import" data-nonce="' . esc_attr($nonce) . '">导入配置</button> '
            . '<a class="button" href="' . esc_url($export_url) . '" target="_blank">导出当前配置</a>'
            . '</div>';

        $html .= '<p class="zibllc-foot">注意：恢复/导入的是「子比子主题」自身设置（zibll_child_options + 模块开关），不影响父主题与其它插件数据。</p>';
        $html .= '</div>';
        return $html;
    }
}

/* ── AJAX 处理器 ────────────────────────────────────────────── */

/**
 * 备份模块 AJAX 统一入口：action 参数区分操作。
 */
function zibll_child_ajax_settings_backup()
{
    check_ajax_referer(ZIBLL_CHILD_BACKUP_NONCE, 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('无权限');
    }

    $action = isset($_POST['do']) ? sanitize_key($_POST['do']) : '';
    $key    = isset($_POST['key']) ? (string) wp_unslash($_POST['key']) : '';

    switch ($action) {
        case 'backup_now':
            $result = zibll_child_settings_backup('手动备份');
            if (!$result) {
                wp_send_json_error('备份失败');
            }
            wp_send_json_success(array('msg' => '已备份当前配置', 'html' => zibll_child_settings_backup_html()));

        case 'restore':
            if ($key === '' || !zibll_child_settings_restore($key)) {
                wp_send_json_error('未找到对应备份');
            }
            wp_send_json_success(array('msg' => '已恢复到所选备份，正在刷新…', 'reload' => 1));

        case 'delete':
            $backup = get_option(ZIBLL_CHILD_BACKUP_OPT, array());
            if (is_array($backup) && isset($backup[$key])) {
                unset($backup[$key]);
                update_option(ZIBLL_CHILD_BACKUP_OPT, $backup);
            }
            wp_send_json_success(array('msg' => '备份已删除', 'html' => zibll_child_settings_backup_html()));

        case 'delete_all':
            update_option(ZIBLL_CHILD_BACKUP_OPT, array());
            wp_send_json_success(array('msg' => '已删除全部备份', 'html' => zibll_child_settings_backup_html()));

        case 'delete_surplus':
            $backup = get_option(ZIBLL_CHILD_BACKUP_OPT, array());
            if (is_array($backup) && count($backup) > 3) {
                update_option(ZIBLL_CHILD_BACKUP_OPT, array_slice($backup, -3, null, true));
            }
            wp_send_json_success(array('msg' => '已仅保留最新 3 份', 'html' => zibll_child_settings_backup_html()));

        case 'import':
            $raw = isset($_POST['data']) ? (string) wp_unslash($_POST['data']) : '';
            $data = json_decode(trim($raw), true);
            if (!is_array($data) || !isset($data['options'])) {
                wp_send_json_error('JSON 格式错误：需为「导出当前配置」产生的完整结构');
            }
            zibll_child_settings_backup('导入前自动备份');
            update_option('zibll_child_options', is_array($data['options']) ? $data['options'] : array());
            if (isset($data['modules']) && is_array($data['modules'])) {
                update_option('zibll_child_modules', $data['modules']);
            }
            wp_send_json_success(array('msg' => '配置已导入，正在刷新…', 'reload' => 1));

        default:
            wp_send_json_error('未知操作');
    }
}
add_action('wp_ajax_zibll_child_settings_backup', 'zibll_child_ajax_settings_backup');

/* 配置导出：与导入格式一致（面板 + 模块开关完整打包） */
function zibll_child_ajax_settings_export()
{
    check_ajax_referer(ZIBLL_CHILD_BACKUP_NONCE, 'nonce');
    if (!current_user_can('manage_options')) {
        wp_die('无权限');
    }
    $payload = array(
        '_meta'   => array(
            'exported' => current_time('Y-m-d H:i:s'),
            'source'   => 'zibll-child v' . (function_exists('zibll_child_get_version')
                ? zibll_child_get_version()
                : wp_get_theme('zibll-child')->get('Version')),
        ),
        'options' => get_option('zibll_child_options', array()),
        'modules' => get_option('zibll_child_modules', array()),
    );
    nocache_headers();
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename=zibll-child-settings-' . gmdate('Ymd-His') . '.json');
    echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}
add_action('wp_ajax_zibll_child_settings_export', 'zibll_child_ajax_settings_export');

/* ── 自动备份钩子（完整版 CSF：保存 / 重置前） ──────────────── */
if (!function_exists('zibll_child_backup_auto')) {
    function zibll_child_backup_auto($type)
    {
        // 仅在面板真实保存/重置时触发，后台其它页面不创建噪音备份
        if (defined('DOING_AJAX') && DOING_AJAX && empty($_POST['action'])) {
            return;
        }
        zibll_child_settings_backup($type);
    }
}
add_action('csf_zibll_child_options_saved', function () {
    zibll_child_backup_auto('保存设置 自动备份');
});
add_action('csf_zibll_child_options_reset_before', function () {
    zibll_child_backup_auto('重置全部 自动备份');
});
add_action('csf_zibll_child_options_reset_section_before', function () {
    zibll_child_backup_auto('重置分区 自动备份');
});

/* ── 面板专属脚本（仅备份 & 导入 section 用） ───────────────── */
add_action('admin_footer', 'zibll_child_backup_admin_js');
function zibll_child_backup_admin_js()
{
    if (empty($_GET['page']) || $_GET['page'] !== 'zibll_child_options') {
        return;
    }
    ?>
<script id="zibll-child-backup-js">
(function($) {
    function zibllcPost(btn, doAction, key, extra, cb) {
        var data = { action: 'zibll_child_settings_backup', do: doAction, nonce: btn.data('nonce') };
        if (key) { data.key = key; }
        if (extra) { $.extend(data, extra); }
        btn.prop('disabled', true);
        $.post(ajaxurl, data, function(res) {
            btn.prop('disabled', false);
            if (res && res.success) {
                if (res.data.reload) { location.reload(); return; }
                if (res.data.html) {
                    var box = $('#zibllc-backup-section').length ? $('#zibllc-backup-section') : $('.zibllc-update').first();
                    box.html(res.data.html);
                }
                if (cb) { cb(); } else { alert(res.data.msg || '完成'); }
            } else {
                alert((res && res.data) ? res.data : '操作失败');
            }
        }, 'json').fail(function() { btn.prop('disabled', false); alert('请求失败'); });
    }
    $(document).on('click', '.zibllc-bk-now', function() {
        zibllcPost($(this), 'backup_now', '', {}, function() { location.reload(); });
    });
    $(document).on('click', '.zibllc-bk-restore', function() {
        if (!confirm('确认恢复到所选备份？当前配置会被覆盖。')) { return; }
        zibllcPost($(this), 'restore', $(this).closest('.zibllc-backup-row').data('key'));
    });
    $(document).on('click', '.zibllc-bk-delete', function() {
        if (!confirm('确认删除该备份？不可恢复。')) { return; }
        zibllcPost($(this), 'delete', $(this).closest('.zibllc-backup-row').data('key'));
    });
    $(document).on('click', '.zibllc-bk-surplus', function() {
        if (!confirm('确认删除多余备份，仅保留最新 3 份？')) { return; }
        zibllcPost($(this), 'delete_surplus', '');
    });
    $(document).on('click', '.zibllc-bk-delete-all', function() {
        if (!confirm('确认删除全部备份？不可恢复。')) { return; }
        zibllcPost($(this), 'delete_all', '');
    });
    $(document).on('click', '.zibllc-bk-import', function() {
        var data = $('#zibllc-import-data').val();
        if (!data || !data.trim()) { alert('请先粘贴 JSON 配置'); return; }
        zibllcPost($(this), 'import', '', { data: data });
    });
})(jQuery);
</script>
    <?php
}
