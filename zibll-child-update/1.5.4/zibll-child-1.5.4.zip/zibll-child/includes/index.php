<?php
/**
 * 子比子主题 - 模块加载入口
 *
 * 使用父主题提供的 zib_require() 批量加载子主题模块文件
 * 父主题 inc/inc.php 已在此之前加载完毕，所有父主题函数均可安全调用
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// 使用父主题的 zib_require() 加载子主题模块（保持与父主题一致的加载风格）
// 顺序要点：theme-updater 必须在 theme-options 之前加载，
// 因为 theme-options 注册面板时会调用 theme-updater 的 zibll_child_get_version() 等函数渲染「主题更新」区。
// rating-plugin-loader 需靠前加载：它会在 WP 插件加载之后、父主题 zib_require_end 触发之前，
// 视情况 require 内置评分插件主文件（独立插件已激活则跳过重载，避免重定义 fatal）。
// 依岸归品牌层：统一后台菜单（Hoarfall 工具）+ 后台视觉（CSF 横幅 / 原生页横幅 / 页内分级导航）
require_once get_stylesheet_directory() . '/includes/brand-menu.php';

zib_require(array(
    'includes/functions/modules-switch', // 模块全量开关：提供 zibll_child_module_enabled()，须早于各插件 loader 以完成早退判断
    'includes/functions/compat-check',  // 运行环境自检：PHP/WP/父主题版本失配时于后台给出明确提示（子比 9.1 + WP 7.1 基线）
    'includes/functions/theme-uninstall', // 卸载数据清理：切换/删除主题时询问并清除本子主题整合插件数据（挂 switch_theme + 后台弹窗 JS）
    'includes/xiazhi-qz-loader',        // 夏稚文章前缀插件「一体化」加载器（条件加载，数据存 post_meta，修复 ajax 懒加载列表前缀不显示）
    'includes/rating-plugin-loader',   // 文章评分插件「一体化」加载器（条件加载，数据兼容独立插件）
    'includes/zibll-comment-emoji-loader', // 评论表情包插件「一体化」加载器（整合 zibll-comment-emoji，替换原月薪喵表情包）
    'includes/functions/functions',
    'includes/functions/options-backup', // 主题设置备份/恢复/导入：提供 zibll_child_settings_backup_html() 等（供 theme-options 面板引用）
    'includes/functions/user-export-import', // 用户数据导入/导出：流式 JSONL + 分批异步作业，含父主题 zibll 用户扩展数据的备份与恢复（须先于 theme-options 加载）
    'includes/functions/bing-push',      // 必应 URL 推送：提供 zibll_child_bing_panel_html() / zibll_child_bing_ready()（供 theme-options 面板引用）
    'includes/functions/theme-updater', // WordPress 原生主题更新适配器（Achen/GitHub 双源）
    'includes/functions/theme-options', // 子主题独立设置页（CSF）+ 原生更新检查入口
), true);
