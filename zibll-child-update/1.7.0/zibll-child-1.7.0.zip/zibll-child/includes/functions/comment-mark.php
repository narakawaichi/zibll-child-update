<?php
/**
 * 子比子主题 - 留言标记
 *
 * 用途：给某篇文章 / 页面下的留言打一个状态标记（例如「已收录」「排期中」「无法找到」），
 * 方便站长按标记检查哪些留言已处理、哪些还没处理；标记同时可显示在前台留言下方。
 *
 * 典型场景：站点的「留言板」页面（如 /help）收到大量「求收录 XX 游戏」的留言，
 * 逐条看过之后标记为「已收录」或「无法找到」，下次只看「未标记」即可。
 *
 * ── 设计要点 ────────────────────────────────────────────
 * 1. 标记是「预设一组、站长自己维护」：在主题设置里一行一个「名称|颜色」，
 *    评论只能从中选一个，避免每条例外都要现编文字。参考内置的夏稚文章前缀。
 * 2. 数据存 comment meta（key `zibll_child_comment_mark`，值是标记名称）。
 *    存名称而不是内部 ID：后台改名 / 删掉某个标记时，历史留言仍能显示原来的标记文字，
 *    不会变成空白或错位。颜色则随时按当前预设取，改色即时生效。
 * 3. 后台操作全在 WordPress 原生「评论」列表里完成：
 *    新增「标记」列（行内下拉即时保存）、新增按标记筛选（含「未标记」）。
 *    按页面看留言用 WordPress 自带的「全部文章」下拉筛选即可。
 * 4. 默认关闭。未开启时后台不加列、不加筛选、前台不输出任何东西、不加载任何资源。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/** comment meta key：存标记名称。 */
function zibll_child_comment_mark_meta_key()
{
    return 'zibll_child_comment_mark';
}

/**
 * 功能是否开启。
 *
 * 默认 false：CSF 的 switcher 关闭时会存空字符串，这里用带默认值的
 * zibll_child_option_enabled() 判定，空字符串会落回默认值 false。
 *
 * @return bool
 */
function zibll_child_comment_mark_enabled()
{
    if (!function_exists('zibll_child_option_enabled')) {
        return false;
    }

    return zibll_child_option_enabled('comment_mark_enable', false);
}

/**
 * 读取预设的标记列表。
 *
 * 配置格式（一行一个，名称与颜色用半角或全角竖线分隔）：
 *     已收录|#16a34a|fa-check
 *     排期中|#f59e0b|fa-clock-o
 *     无法找到
 * 第二段（颜色）与第三段（图标）都可省略。
 *
 * @return array 形如 array( array('name' => '已收录', 'color' => '#16a34a', 'icon' => 'fa-check'), ... )
 */
function zibll_child_comment_marks()
{
    static $marks = null;

    if ($marks !== null) {
        return $marks;
    }

    $raw = function_exists('zibll_child_get_option')
        ? (string) zibll_child_get_option('comment_mark_list', '')
        : '';

    $lines = preg_split('/\r\n|\r|\n/', $raw);
    $list  = array();

    foreach ((array) $lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        // ⚠️ 不能把全角「｜」放进正则字符类：非 UTF-8 模式下字符类一次只吃掉它 1 个字节，
        //    剩下的字节会让后面的解析整体错位。这里直接按字符串切。
        if (strpos($line, '｜') !== false) {
            $parts = explode('｜', $line);
        } else {
            $parts = explode('|', $line);
        }

        $name = trim($parts[0]);
        if ($name === '') {
            continue;
        }

        $color = isset($parts[1]) ? trim($parts[1]) : '';
        if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color)) {
            $color = '#6b7280';
        }

        // 第三段：图标。写 FA 类名（如 fa-check）走 Font Awesome；
        // 其它任意短字符（如 ✅ ★ 🔥）直接当文字输出，方便用 emoji。
        $icon = isset($parts[2]) ? trim($parts[2]) : '';

        $list[] = array('name' => $name, 'color' => $color, 'icon' => $icon);
    }

    // 一项都没配好时给一组默认值，开启开关即可直接用，不用先去填表单。
    if (empty($list)) {
        $list = array(
            array('name' => '已收录', 'color' => '#16a34a', 'icon' => 'fa-check'),
            array('name' => '已更新', 'color' => '#2563eb', 'icon' => 'fa-refresh'),
            array('name' => '排期中', 'color' => '#f59e0b', 'icon' => 'fa-clock-o'),
            array('name' => '无法找到', 'color' => '#94a3b8', 'icon' => 'fa-times'),
        );
    }

    $marks = $list;

    return $marks;
}

/**
 * 把图标配置转成 HTML。
 *
 * @param string $icon 图标配置（FA 类名 / emoji / 空）。
 * @return string
 */
function zibll_child_comment_mark_icon_html($icon)
{
    $icon = trim((string) $icon);

    if ($icon === '') {
        return '';
    }

    // 间距写成内联样式：前台只输出标签 HTML、不额外加载 CSS 文件，
    // 若依赖 .zcm-badge-icon 的样式，图标会紧贴文字。
    if (preg_match('/^fa-[a-z0-9-]+$/i', $icon)) {
        return '<i class="fa fa-fw ' . esc_attr($icon) . ' zcm-badge-icon"'
            . ' style="margin-right:3px;" aria-hidden="true"></i>';
    }

    return '<span class="zcm-badge-emoji" style="margin-right:3px;">' . esc_html($icon) . '</span>';
}

/**
 * 取某条留言的标记名称（未标记返回空串）。
 *
 * @param int $comment_id 评论 ID。
 * @return string
 */
function zibll_child_comment_get_mark($comment_id)
{
    $mark = get_comment_meta((int) $comment_id, zibll_child_comment_mark_meta_key(), true);

    return is_string($mark) ? trim($mark) : '';
}

/**
 * 取标记的完整定义（标记已被删除时给出灰色、无图标的降级项）。
 *
 * @param string $mark 标记名称。
 * @return array 形如 array('name' => ..., 'color' => ..., 'icon' => ...)
 */
function zibll_child_comment_mark_data($mark)
{
    foreach (zibll_child_comment_marks() as $item) {
        if ($item['name'] === $mark) {
            return $item;
        }
    }

    return array('name' => (string) $mark, 'color' => '#94a3b8', 'icon' => '');
}

/**
 * 取标记对应的颜色（标记已被删除时用中性灰）。
 *
 * @param string $mark 标记名称。
 * @return string
 */
function zibll_child_comment_mark_color($mark)
{
    $data = zibll_child_comment_mark_data($mark);

    return $data['color'];
}

/**
 * 生成前台用的标记标签。
 *
 * @param int $comment_id 评论 ID。
 * @return string HTML，未标记时返回空串。
 */
function zibll_child_comment_mark_badge($comment_id)
{
    $mark = zibll_child_comment_get_mark($comment_id);
    if ($mark === '') {
        return '';
    }

    $data = zibll_child_comment_mark_data($mark);

    // 用父主题的 badg / badg-sm 类保持与「作者」「待审核」等标签同一套尺寸，
    // 颜色用内联样式（预设色由站长在设置里自定义，没有对应的 CSS 类可用）。
    return '<span class="badg badg-sm zcm-badge" style="background-color:' . esc_attr($data['color'])
        . ';border-color:' . esc_attr($data['color']) . ';color:#fff;margin-right:6px;">'
        . zibll_child_comment_mark_icon_html($data['icon'])
        . esc_html($mark) . '</span>';
}

/* =========================================================================
 * 一、后台：评论列表的「标记」列
 * ========================================================================= */

/** 在评论列表里插入「标记」列（放在「评论」列之后）。 */
function zibll_child_comment_mark_columns($columns)
{
    if (!zibll_child_comment_mark_enabled() || !is_array($columns)) {
        return $columns;
    }

    $new = array();
    foreach ($columns as $key => $label) {
        $new[$key] = $label;
        if ($key === 'comment') {
            $new['zcm_mark'] = '标记';
        }
    }

    if (!isset($new['zcm_mark'])) {
        $new['zcm_mark'] = '标记';
    }

    return $new;
}
add_filter('manage_edit-comments_columns', 'zibll_child_comment_mark_columns', 20);

/** 输出该列的单元格内容：一个即时保存的下拉。 */
function zibll_child_comment_mark_column_content($column, $comment_id)
{
    if ($column !== 'zcm_mark' || !zibll_child_comment_mark_enabled()) {
        return;
    }

    $current = zibll_child_comment_get_mark($comment_id);

    $html  = '<select class="zcm-select" data-comment="' . (int) $comment_id . '"';
    $html .= ' title="选择标记后立即保存">';
    $html .= '<option value="">未标记</option>';

    foreach (zibll_child_comment_marks() as $item) {
        $html .= '<option value="' . esc_attr($item['name']) . '"' . selected($current, $item['name'], false) . '>'
            . esc_html($item['name']) . '</option>';
    }

    $html .= '</select>';

    if ($current !== '') {
        $html .= '<span class="zcm-dot" style="background-color:' . esc_attr(zibll_child_comment_mark_color($current)) . '"></span>';
    }

    echo $html;
}
add_action('manage_comments_custom_column', 'zibll_child_comment_mark_column_content', 10, 2);

/** 后台样式与脚本：只在评论列表页加载。 */
function zibll_child_comment_mark_admin_assets($hook)
{
    if ($hook !== 'edit-comments.php' || !zibll_child_comment_mark_enabled()) {
        return;
    }

    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();

    $css = $dir . '/assets/css/comment-mark.css';
    $js  = $dir . '/assets/js/comment-mark-admin.js';

    wp_enqueue_style(
        'zcm-admin',
        $uri . '/assets/css/comment-mark.css',
        array(),
        file_exists($css) ? (string) filemtime($css) : '1.0.0'
    );

    wp_enqueue_script(
        'zcm-admin',
        $uri . '/assets/js/comment-mark-admin.js',
        array('jquery'),
        file_exists($js) ? (string) filemtime($js) : '1.0.0',
        true
    );

    wp_localize_script('zcm-admin', 'ZC_COMMENT_MARK', array(
        'ajax'  => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('zibll_child_comment_mark'),
        'i18n'  => array(
            'saved'  => '已保存',
            'failed' => '保存失败，请重试',
        ),
    ));
}
add_action('admin_enqueue_scripts', 'zibll_child_comment_mark_admin_assets');

/* =========================================================================
 * 二、后台：按标记筛选
 * ========================================================================= */

/** 评论列表顶部的「标记」筛选下拉（与 WordPress 自带的「全部文章」下拉并列）。 */
function zibll_child_comment_mark_filter_dropdown()
{
    if (!zibll_child_comment_mark_enabled()) {
        return;
    }

    $current = isset($_GET['zcm_mark']) ? sanitize_text_field(wp_unslash($_GET['zcm_mark'])) : '';

    echo '<select name="zcm_mark" id="zcm-mark-filter">';
    echo '<option value="">全部标记</option>';
    echo '<option value="__none__"' . selected($current, '__none__', false) . '>未标记</option>';

    foreach (zibll_child_comment_marks() as $item) {
        echo '<option value="' . esc_attr($item['name']) . '"' . selected($current, $item['name'], false) . '>'
            . esc_html($item['name']) . '</option>';
    }

    echo '</select>';
}
add_action('restrict_manage_comments', 'zibll_child_comment_mark_filter_dropdown');

/** 把上面的筛选条件接到评论查询上。 */
function zibll_child_comment_mark_filter_query($query)
{
    if (!zibll_child_comment_mark_enabled() || !is_admin()) {
        return;
    }

    if (empty($_GET['zcm_mark'])) {
        return;
    }

    $value = sanitize_text_field(wp_unslash($_GET['zcm_mark']));
    $key   = zibll_child_comment_mark_meta_key();

    if ($value === '__none__') {
        // 未标记：没有这条 meta，或 meta 值为空串。
        $query->query_vars['meta_query'] = array(
            'relation' => 'OR',
            array(
                'key'     => $key,
                'compare' => 'NOT EXISTS',
            ),
            array(
                'key'     => $key,
                'value'   => '',
                'compare' => '=',
            ),
        );
        return;
    }

    $query->query_vars['meta_query'] = array(
        array(
            'key'   => $key,
            'value' => $value,
        ),
    );
}
add_action('pre_get_comments', 'zibll_child_comment_mark_filter_query');

/* =========================================================================
 * 三、后台：批量标记（勾选多条一起设）
 * ========================================================================= */

/**
 * 在评论列表的「批量操作」下拉里追加「标记为：xxx」和「清除标记」。
 *
 * 每个预设标记生成一个独立选项，值里带它在列表里的索引。
 * 这样不用额外弹窗、不用第二个下拉，也不需要 JS 拦截表单提交，
 * 直接复用 WordPress 原生的批量操作流程。
 */
function zibll_child_comment_mark_bulk_actions($actions)
{
    if (!zibll_child_comment_mark_enabled() || !is_array($actions)) {
        return $actions;
    }

    foreach (zibll_child_comment_marks() as $index => $item) {
        $actions['zcm_set_' . $index] = '标记为：' . $item['name'];
    }

    $actions['zcm_clear'] = '清除标记';

    return $actions;
}
add_filter('bulk_actions-edit-comments', 'zibll_child_comment_mark_bulk_actions');

/**
 * 执行批量标记 / 批量清除。
 *
 * @param string $redirect_to 处理完跳回的地址（WordPress 已带上原筛选参数）。
 * @param string $action      批量动作名。
 * @param array  $comment_ids 勾选的留言 ID。
 * @return string
 */
function zibll_child_comment_mark_handle_bulk($redirect_to, $action, $comment_ids)
{
    if (!zibll_child_comment_mark_enabled()) {
        return $redirect_to;
    }

    $is_set   = strpos($action, 'zcm_set_') === 0;
    $is_clear = ($action === 'zcm_clear');

    if (!$is_set && !$is_clear) {
        return $redirect_to;
    }

    if (!current_user_can('moderate_comments')) {
        return $redirect_to;
    }

    $comment_ids = array_filter(array_map('absint', (array) $comment_ids));

    if (empty($comment_ids)) {
        return $redirect_to;
    }

    $changed = 0;

    if ($is_clear) {
        foreach ($comment_ids as $comment_id) {
            if (zibll_child_comment_get_mark($comment_id) !== '') {
                delete_comment_meta($comment_id, zibll_child_comment_mark_meta_key());
                $changed++;
            }
        }

        return add_query_arg('zcm_bulk', $changed, $redirect_to);
    }

    // 索引在「打开列表」和「点批量操作」之间若恰好改了预设，可能指向别的项，
    // 这里按当前列表重新取一次，取不到就当没改动。
    $index = (int) substr($action, strlen('zcm_set_'));
    $marks = zibll_child_comment_marks();

    if (!isset($marks[$index])) {
        return add_query_arg('zcm_bulk', 0, $redirect_to);
    }

    $mark = $marks[$index]['name'];

    foreach ($comment_ids as $comment_id) {
        update_comment_meta($comment_id, zibll_child_comment_mark_meta_key(), $mark);
        $changed++;
    }

    return add_query_arg('zcm_bulk', $changed, $redirect_to);
}
add_filter('handle_bulk_actions-edit-comments', 'zibll_child_comment_mark_handle_bulk', 10, 3);

/** 批量操作完成后在列表顶部给一句结果提示。 */
function zibll_child_comment_mark_bulk_notice()
{
    if (!zibll_child_comment_mark_enabled() || !isset($_GET['zcm_bulk'])) {
        return;
    }

    $count = absint($_GET['zcm_bulk']);

    if ($count < 1) {
        echo '<div class="notice notice-warning is-dismissible"><p>没有留言被修改（可能勾选的那些本来就没有标记）。</p></div>';
        return;
    }

    echo '<div class="notice notice-success is-dismissible"><p>已更新 <strong>' . (int) $count . '</strong> 条留言的标记。</p></div>';
}
add_action('admin_notices', 'zibll_child_comment_mark_bulk_notice');

/* =========================================================================
 * 四、保存（行内下拉的 AJAX）
 * ========================================================================= */

function zibll_child_comment_mark_ajax_save()
{
    check_ajax_referer('zibll_child_comment_mark', 'nonce');

    if (!current_user_can('moderate_comments')) {
        wp_send_json_error(array('message' => '没有审核评论的权限。'), 403);
    }

    $comment_id = isset($_POST['comment_id']) ? absint($_POST['comment_id']) : 0;

    if (!$comment_id || !get_comment($comment_id)) {
        wp_send_json_error(array('message' => '找不到这条留言。'), 404);
    }

    // ⚠️ 先按原样比对预设列表，再决定是否清洗。
    //    若先 sanitize_text_field() 再比对，含标签的脏值会被清成空串，
    //    结果「非法值」被静默当成「清空标记」——看起来保存成功，实际把原来
    //    的标记删掉了。这里改成：不是预设里的值一律报错，不做降级写入。
    $mark = isset($_POST['mark']) ? trim((string) wp_unslash($_POST['mark'])) : '';

    if ($mark !== '') {
        $matched = '';

        foreach (zibll_child_comment_marks() as $item) {
            if ($item['name'] === $mark) {
                $matched = $item['name'];
                break;
            }
        }

        if ($matched === '') {
            wp_send_json_error(array('message' => '这个标记不在预设列表里，请先在设置里添加。'), 400);
        }

        $mark = $matched;
    }

    if ($mark === '') {
        delete_comment_meta($comment_id, zibll_child_comment_mark_meta_key());
    } else {
        update_comment_meta($comment_id, zibll_child_comment_mark_meta_key(), $mark);
    }

    wp_send_json_success(array(
        'mark'  => $mark,
        'color' => $mark === '' ? '' : zibll_child_comment_mark_color($mark),
        // 前台「三个点」菜单保存后要就地替换标签，由服务端把 HTML 渲染好一起返回，
        // 避免前端自己拼图标 / 转义 / 降级色（标记被删掉时的那套逻辑都在 PHP 里）。
        'badge' => zibll_child_comment_mark_badge($comment_id),
    ));
}
add_action('wp_ajax_zibll_child_comment_mark_save', 'zibll_child_comment_mark_ajax_save');

/* =========================================================================
 * 五、前台：在留言正文下方显示标记
 * ========================================================================= */

/**
 * 插入位置是父主题 zib_get_comment_footer() 的 `comment_footer_info` 过滤器，
 * 也就是留言正文下面那一行（时间 / IP 归属地 / 回复 所在的 comt-meta），
 * 效果与父主题自带的「待审核」标签同排，不改模板、不动正文。
 *
 * @param string    $info    原有的底部信息 HTML。
 * @param WP_Comment $comment 评论对象。
 * @param int       $depth   层级。
 * @return string
 */
function zibll_child_comment_mark_footer_badge($info, $comment, $depth = 0)
{
    if (!zibll_child_comment_mark_enabled()) {
        return $info;
    }

    if (empty($comment->comment_ID)) {
        return $info;
    }

    return zibll_child_comment_mark_badge($comment->comment_ID) . $info;
}
add_filter('comment_footer_info', 'zibll_child_comment_mark_footer_badge', 10, 3);

/* =========================================================================
 * 六、前台：留言「更多操作」菜单里的标记按钮（仅管理员可见）
 *
 * 父主题每条留言右下角的「三个点」菜单由 zib_get_comments_action_list() 生成，
 * 内容通过 `comments_action_lists` 过滤器交给扩展，每项是一个 <li>。
 * 这里追加一项「标记」：点开后弹出标记选择面板，选完即时保存并就地替换前台标签。
 *
 * ⚠️ 只对具备 moderate_comments 能力的账号输出按钮与资源：
 *    普通访客和普通用户的页面里不会出现这个按钮，也不会加载对应 JS/CSS。
 * ========================================================================= */

/**
 * 往留言的「更多操作」菜单里追加「标记」项。
 *
 * @param string    $lists   已有的 <li> 列表。
 * @param WP_Comment $comment 当前留言。
 * @return string
 */
function zibll_child_comment_mark_front_action($lists, $comment)
{
    if (!zibll_child_comment_mark_enabled()) {
        return $lists;
    }

    if (!is_user_logged_in() || !current_user_can('moderate_comments')) {
        return $lists;
    }

    if (empty($comment->comment_ID)) {
        return $lists;
    }

    $lists .= '<li><a class="zcm-front-mark" data-comment="' . (int) $comment->comment_ID . '" href="javascript:;">'
        . '<i class="fa fa-tags mr10 fa-fw" aria-hidden="true"></i>' . '标记' . '</a></li>';

    return $lists;
}
add_filter('comments_action_lists', 'zibll_child_comment_mark_front_action', 10, 2);

/**
 * 前台标记面板的资源：只在管理员访问时加载。
 */
function zibll_child_comment_mark_front_assets()
{
    if (!zibll_child_comment_mark_enabled()) {
        return;
    }

    if (!is_user_logged_in() || !current_user_can('moderate_comments')) {
        return;
    }

    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();

    $css = $dir . '/assets/css/comment-mark-front.css';
    $js  = $dir . '/assets/js/comment-mark-front.js';

    wp_enqueue_style(
        'zcm-front',
        $uri . '/assets/css/comment-mark-front.css',
        array(),
        file_exists($css) ? (string) filemtime($css) : '1.0.0'
    );

    wp_enqueue_script(
        'zcm-front',
        $uri . '/assets/js/comment-mark-front.js',
        array('jquery'),
        file_exists($js) ? (string) filemtime($js) : '1.0.0',
        true
    );

    $marks = array();
    foreach (zibll_child_comment_marks() as $item) {
        $marks[] = array(
            'name'  => $item['name'],
            'color' => $item['color'],
            // 图标 HTML 在服务端生成（FA / emoji / 无），前端只负责插进面板。
            'icon'  => zibll_child_comment_mark_icon_html($item['icon']),
        );
    }

    wp_localize_script('zcm-front', 'ZC_COMMENT_MARK_FRONT', array(
        'ajax'  => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('zibll_child_comment_mark'),
        'marks' => $marks,
        'i18n'  => array(
            'title'  => '设置标记',
            'clear'  => '清除标记',
            'failed' => '保存失败，请重试',
            'saving' => '保存中…',
        ),
    ));
}
add_action('wp_enqueue_scripts', 'zibll_child_comment_mark_front_assets', 30);
