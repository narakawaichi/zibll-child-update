<?php
/**
 * 子比子主题 - 必应站长 URL 推送
 * ─────────────────────────────────────────────────────────────
 * 功能来源：参考第三方子主题框架 Vela（DearLicy/zibll_child）同款能力，
 *           修正其两处缺陷后重新实现：
 *           1. 原版「启用开关」守卫条件写反（&& 应为 ||），导致未启用时也空跑并写空 meta；
 *           2. 原版 AJAX 无 nonce，仅靠角色校验。
 *
 * 工作方式：
 *   - 配置项存于 zibll_child_options：bing_push_on（开关）/ bing_api_token（API 密钥）；
 *   - save_post（publish 的文章/页面）与 saved_term（分类/标签）后自动推送，
 *     成功/失败结果写入对应 post/term 的 meta（bing_tui_back），避免重复推送；
 *   - 设置面板提供手动批量提交（每行一个链接）；
 *   - 文章编辑页显示最近一次推送状态 + 「重新提交」勾选。
 *
 * 默认关闭（未在面板开启或未填密钥时零外发请求，不影响发布速度）。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 必应推送是否就绪（开关开启且有密钥）。
 */
function zibll_child_bing_ready()
{
    if (!function_exists('zibll_child_get_option')) {
        return false;
    }
    // 严格判定：CSF switcher 关闭时可能存 '0'/false/不存，'0' 在 PHP 中为真，必须显式排除。
    $on = zibll_child_get_option('bing_push_on', false);
    if (!($on === true || $on === 1 || $on === '1')) {
        return false;
    }
    $token = (string) zibll_child_get_option('bing_api_token', '');
    return $token !== '';
}

/**
 * 提交 URL 列表到必应站长工具。
 *
 * @param string|array $urls 单个 URL 或 URL 数组
 * @return array 结果数组（success / message / update_time ...）
 */
function zibll_child_bing_submit($urls)
{
    $token = (string) zibll_child_get_option('bing_api_token', '');
    if ($token === '') {
        return array('success' => false, 'message' => '未配置必应 API 密钥');
    }

    if (!is_array($urls)) {
        $urls = array($urls);
    }
    $urls = array_values(array_filter(array_map('trim', $urls)));
    if (empty($urls)) {
        return array('success' => false, 'message' => '没有可提交的链接');
    }

    $api_url = 'https://ssl.bing.com/webmaster/api.svc/json/SubmitUrlbatch?apikey=' . rawurlencode($token);
    $response = wp_remote_post($api_url, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => wp_json_encode(array('siteUrl' => home_url(), 'urlList' => $urls)),
        'timeout' => 30,
    ));

    $result = array('update_time' => current_time('Y-m-d H:i:s'));

    if (is_wp_error($response)) {
        $result['success'] = false;
        $result['message'] = $response->get_error_message();
        return $result;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);

    if ($code === 200) {
        $result['success'] = true;
        $result['message'] = 'URL 提交成功（' . count($urls) . ' 条）';
        return $result;
    }

    $result['success'] = false;
    $result['message'] = '提交失败 HTTP ' . $code;
    $info = json_decode($body, true);
    if (is_array($info) && isset($info['ErrorCode'], $info['Message'])) {
        $result['message'] .= '：' . $info['ErrorCode'] . ' ' . $info['Message'];
    }
    return $result;
}

/**
 * 判断某条推送记录是否已成功，避免重复提交。
 */
function zibll_child_bing_done($meta)
{
    return is_array($meta) && !empty($meta['success']);
}

/**
 * 文章保存后推送（仅发布状态；自动保存/草稿不推送）。
 */
function zibll_child_bing_push_on_save($post_id)
{
    if (!zibll_child_bing_ready()) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id)) {
        return;
    }
    $post = get_post($post_id);
    if (!$post || $post->post_status !== 'publish') {
        return;
    }
    // 重新提交勾选：清除旧结果强制再推
    if (!empty($_POST['zibllc_bing_resubmit'])) {
        delete_post_meta($post_id, 'bing_tui_back');
    }
    $old = get_post_meta($post_id, 'bing_tui_back', true);
    if (zibll_child_bing_done($old)) {
        return;
    }
    $url = get_permalink($post_id);
    if (!$url) {
        return;
    }
    update_post_meta($post_id, 'bing_tui_back', zibll_child_bing_submit($url));
}
add_action('save_post', 'zibll_child_bing_push_on_save');

/**
 * 分类/标签保存后推送。
 */
function zibll_child_bing_push_on_term($term_id)
{
    if (!zibll_child_bing_ready()) {
        return;
    }
    $term = get_term((int) $term_id);
    if (!$term || is_wp_error($term)) {
        return;
    }
    $old = get_term_meta($term_id, 'bing_tui_back', true);
    if (zibll_child_bing_done($old)) {
        return;
    }
    $url = get_term_link($term);
    if (is_wp_error($url)) {
        return;
    }
    update_term_meta($term_id, 'bing_tui_back', zibll_child_bing_submit($url));
}
add_action('saved_term', 'zibll_child_bing_push_on_term');

/* ── 文章编辑页：推送状态 metabox ────────────────────────────── */
function zibll_child_bing_add_post_box()
{
    if (!zibll_child_bing_ready()) {
        return;
    }
    add_meta_box(
        'zibllc_bing_box',
        '必应推送',
        'zibll_child_bing_post_box_html',
        array('post', 'page'),
        'side',
        'high'
    );
}
add_action('add_meta_boxes', 'zibll_child_bing_add_post_box');

function zibll_child_bing_post_box_html($post)
{
    $meta = get_post_meta($post->ID, 'bing_tui_back', true);
    $html = '';

    if (is_array($meta) && isset($meta['update_time'])) {
        $status = !empty($meta['success'])
            ? '<span style="color:#1a7f37;font-weight:600;">已提交成功</span>'
            : '<span style="color:#d63638;font-weight:600;">提交失败</span>';
        $html .= '<p style="margin:6px 0;">状态：' . $status . '<br>'
            . '<span style="color:#8c8f94;">' . esc_html($meta['update_time']) . '</span></p>';
        if (!empty($meta['message'])) {
            $html .= '<p style="margin:6px 0;color:#50575e;">' . esc_html($meta['message']) . '</p>';
        }
        $html .= '<p style="margin:8px 0;"><label><input type="checkbox" name="zibllc_bing_resubmit" value="1"> 保存时重新提交</label></p>';
    } else {
        $html .= '<p style="margin:4px 0;">该文章发布/更新后将自动提交到必应站长。</p>';
    }
    echo '<div class="zibllc-bing-box">' . $html . '</div>';
}

/* ── 设置面板内「批量提交」UI（由 theme-options.php 的 submessage 承载） ── */
if (!function_exists('zibll_child_bing_panel_html')) {
    function zibll_child_bing_panel_html()
    {
        $nonce = wp_create_nonce(ZIBLL_CHILD_BACKUP_NONCE);
        $html  = '<p>粘贴要推送的链接，每行一个（支持文章页 / 分类页 / 任意可访问 URL）：</p>';
        $html .= '<textarea id="zibllc-bing-urls" class="large-text code" rows="6" style="font-family:monospace;" placeholder="https://example.com/xxx/&#10;https://example.com/yyy/"></textarea>';
        $html .= '<p style="margin-top:8px;"><button type="button" class="button button-primary zibllc-bing-submit" data-nonce="' . esc_attr($nonce) . '">批量提交</button>'
            . ' <span id="zibllc-bing-msg" class="zibllc-hint" style="display:none;"></span></p>';
        $html .= '<p class="zibllc-hint">开启自动推送后，文章发布/更新与分类保存时会自动提交，结果记录在对应内容上（无需重复手动提交）。</p>';
        return $html;
    }
}

/* ── AJAX：批量提交 ─────────────────────────────────────────── */
function zibll_child_ajax_bing_bulk()
{
    check_ajax_referer(ZIBLL_CHILD_BACKUP_NONCE, 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('无权限');
    }
    if (!zibll_child_bing_ready()) {
        wp_send_json_error('请先在「启用必应推送 + 必应 API 密钥」填写后保存再试');
    }
    $raw = isset($_POST['urls']) ? (string) wp_unslash($_POST['urls']) : '';
    $urls = array_values(array_filter(array_map('trim', explode("\n", $raw))));
    if (empty($urls)) {
        wp_send_json_error('请至少输入一个链接');
    }
    wp_send_json_success(zibll_child_bing_submit($urls));
}
add_action('wp_ajax_zibll_child_bing_bulk', 'zibll_child_ajax_bing_bulk');

/* ── 面板专属脚本（批量提交按钮） ───────────────────────────── */
add_action('admin_footer', 'zibll_child_bing_admin_js');
function zibll_child_bing_admin_js()
{
    if (empty($_GET['page']) || $_GET['page'] !== 'zibll_child_options') {
        return;
    }
    ?>
<script id="zibll-child-bing-js">
(function($) {
    $(document).on('click', '.zibllc-bing-submit', function() {
        var $btn = $(this), urls = $('#zibllc-bing-urls').val();
        if (!urls || !urls.trim()) { alert('请先输入要推送的链接'); return; }
        $btn.prop('disabled', true).text('提交中…');
        $.post(ajaxurl, { action: 'zibll_child_bing_bulk', urls: urls, nonce: $btn.data('nonce') }, function(res) {
            $btn.prop('disabled', false).text('批量提交');
            var $msg = $('#zibllc-bing-msg').css('display', 'inline');
            if (res && res.success) {
                $msg.css('color', '#1a7f37').text(res.data.message || '提交成功');
            } else {
                $msg.css('color', '#d63638').text((res && res.data) ? res.data : '提交失败');
            }
        }, 'json').fail(function() {
            $btn.prop('disabled', false).text('批量提交');
            alert('请求失败，请重试');
        });
    });
})(jQuery);
</script>
    <?php
}
