<?php
/**
 * 子比子主题 - WordPress 原生主题更新适配器
 *
 * 更新检查和安装交给 WordPress 核心：
 * - WordPress 6.1+ 使用 Update URI 动态钩子；
 * - 旧版本通过 pre_set_site_transient_update_themes 兼容注入；
 * - 依岸归 CDN 与 GitHub 同时检查，版本较新者优先，同版本 CDN 优先；
 * - package 是完整主题 ZIP，由 Theme_Upgrader 负责替换目录。
 *
 * 过渡期仍保护旧站点的 func.php 和 style.css。站点自定义 PHP 的长期存储
 * 由 zibll-site-code 插件负责，主题目录不再是自定义代码的唯一来源。
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('ZIBLL_CHILD_UPDATE_THEME')) {
    define('ZIBLL_CHILD_UPDATE_THEME', 'zibll-child');
}

if (!defined('ZIBLL_CHILD_UPDATE_URI')) {
    define('ZIBLL_CHILD_UPDATE_URI', 'https://download.hoarfall.cn/zibll-child-update/');
}

if (!defined('ZIBLL_CHILD_UPDATE_API')) {
    define('ZIBLL_CHILD_UPDATE_API', rtrim(ZIBLL_CHILD_UPDATE_URI, '/') . '/update.json');
}

if (!defined('ZIBLL_CHILD_UPDATE_GITHUB_BASE')) {
    // 2026-09：更新仓库已由 yuananchen44-prog 迁移至 narakawaichi 账号，此处同步新地址
    define(
        'ZIBLL_CHILD_UPDATE_GITHUB_BASE',
        'https://raw.githubusercontent.com/narakawaichi/zibll-child-update/main/zibll-child-update'
    );
}

if (!defined('ZIBLL_CHILD_UPDATE_API_GITHUB')) {
    define('ZIBLL_CHILD_UPDATE_API_GITHUB', rtrim(ZIBLL_CHILD_UPDATE_GITHUB_BASE, '/') . '/update.json');
}

if (!defined('ZIBLL_CHILD_UPDATE_META_CACHE')) {
    define('ZIBLL_CHILD_UPDATE_META_CACHE', 'zibll_child_native_update_bundle');
}

function zibll_child_get_version()
{
    if (!function_exists('wp_get_theme')) {
        return '0.0.0';
    }

    $theme = wp_get_theme(ZIBLL_CHILD_UPDATE_THEME);
    $version = $theme->get('Version');
    return $version ? trim($version) : '0.0.0';
}

function zibll_child_github_headers()
{
    if (defined('ZIBLL_CHILD_GITHUB_TOKEN') && ZIBLL_CHILD_GITHUB_TOKEN !== '') {
        return array('Authorization' => 'Bearer ' . ZIBLL_CHILD_GITHUB_TOKEN);
    }

    return array();
}

function zibll_child_update_source_definitions()
{
    return array(
        'achen' => array(
            // v1.5.16：label 是后台可见文案，改为现行品牌「依岸归 CDN」；
            // 内部键 'achen' 保持不变（它参与更新元数据匹配，改动会破坏兼容）
            'label'   => '依岸归 CDN',
            'api'     => ZIBLL_CHILD_UPDATE_API,
            'base'    => rtrim(ZIBLL_CHILD_UPDATE_URI, '/'),
            'headers' => array(),
        ),
        'github' => array(
            'label'   => 'GitHub',
            'api'     => ZIBLL_CHILD_UPDATE_API_GITHUB,
            'base'    => rtrim(ZIBLL_CHILD_UPDATE_GITHUB_BASE, '/'),
            'headers' => zibll_child_github_headers(),
        ),
    );
}

function zibll_child_update_resolve_url($base, $url)
{
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }
    if (preg_match('/^https?:\/\//i', $url)) {
        return esc_url_raw($url);
    }

    return trailingslashit($base) . ltrim($url, '/');
}

function zibll_child_update_valid_version($version)
{
    if (!is_string($version) || $version === '') {
        return false;
    }

    // WordPress-compatible versions: 1.3.32, 1.3.32.1, optional -rc1/-beta2 suffix.
    return (bool) preg_match('/^[0-9]+(?:\.[0-9]+){1,3}(?:-[0-9A-Za-z.]+)?$/', $version);
}

function zibll_child_fetch_update_source($key, $source)
{
    $response = wp_remote_get($source['api'], array(
        'timeout'     => 15,
        'redirection' => 3,
        'sslverify'   => true,
        'headers'     => array_merge(
            array('Accept' => 'application/json', 'User-Agent' => 'zibll-child-updater'),
            $source['headers']
        ),
    ));

    if (is_wp_error($response)) {
        return array('ok' => false, 'error' => $response->get_error_message());
    }

    $status = (int) wp_remote_retrieve_response_code($response);
    if ($status !== 200) {
        return array('ok' => false, 'error' => 'HTTP ' . $status);
    }

    $data = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($data)) {
        return array('ok' => false, 'error' => '返回内容不是有效 JSON');
    }

    $version = isset($data['version']) ? trim((string) $data['version']) : '';
    if (!zibll_child_update_valid_version($version)) {
        return array('ok' => false, 'error' => '元数据缺少有效 version');
    }

    $package = '';
    foreach (array('package', 'package_url', 'zip') as $field) {
        if (!empty($data[$field])) {
            $package = (string) $data[$field];
            break;
        }
    }
    if ($package === '') {
        $package = $version . '/zibll-child-' . $version . '.zip';
    }
    $package = zibll_child_update_resolve_url($source['base'], $package);

    if (!preg_match('/^https:\/\//i', $package)) {
        return array('ok' => false, 'error' => 'package 必须使用 HTTPS 地址');
    }

    $package_host = wp_parse_url($package, PHP_URL_HOST);
    $source_host = wp_parse_url($source['base'], PHP_URL_HOST);
    if (!$package_host || !$source_host || strtolower($package_host) !== strtolower($source_host)) {
        return array('ok' => false, 'error' => 'package 主机名与更新源不一致');
    }

    $declared_theme = !empty($data['theme']) ? sanitize_key($data['theme']) : ZIBLL_CHILD_UPDATE_THEME;
    if ($declared_theme !== ZIBLL_CHILD_UPDATE_THEME) {
        return array('ok' => false, 'error' => '元数据 theme 与当前子主题不一致');
    }

    $meta = $data;
    $meta['theme']         = ZIBLL_CHILD_UPDATE_THEME;
    $meta['version']       = $version;
    $meta['new_version']   = $version;
    $meta['package']       = $package;
    $meta['requires']      = !empty($data['requires']) ? (string) $data['requires'] : (!empty($data['requires_wp']) ? (string) $data['requires_wp'] : '5.0');
    $meta['requires_php']  = !empty($data['requires_php']) ? (string) $data['requires_php'] : '7.0';
    $meta['url']           = !empty($data['url']) ? esc_url_raw($data['url']) : (!empty($data['homepage']) ? esc_url_raw($data['homepage']) : '');
    $meta['_source']       = $key;
    $meta['_source_label'] = $source['label'];
    $meta['_api']          = $source['api'];

    return array('ok' => true, 'meta' => $meta);
}

function zibll_child_fetch_update_bundle($force = false)
{
    if (!$force) {
        $cached = get_transient(ZIBLL_CHILD_UPDATE_META_CACHE);
        if (is_array($cached) && isset($cached['sources'])) {
            return $cached;
        }
    }

    $statuses = array();
    $valid = array();
    foreach (zibll_child_update_source_definitions() as $key => $source) {
        $result = zibll_child_fetch_update_source($key, $source);
        $meta = !empty($result['ok']) ? $result['meta'] : false;
        $statuses[$key] = array(
            'key'     => $key,
            'label'   => $source['label'],
            'api'     => $source['api'],
            'ok'      => false !== $meta,
            'version' => $meta ? $meta['version'] : '',
            'error'   => $meta ? '' : (!empty($result['error']) ? $result['error'] : '未知错误'),
        );
        if ($meta) {
            $valid[$key] = $meta;
        }
    }

    $selected = false;
    // Source definitions are ordered CDN then GitHub; equal versions keep CDN.
    foreach ($valid as $meta) {
        if ($selected === false || version_compare($meta['version'], $selected['version'], '>')) {
            $selected = $meta;
        }
    }

    $bundle = array(
        'selected'   => $selected,
        'sources'    => $statuses,
        'checked_at' => time(),
    );
    set_transient(ZIBLL_CHILD_UPDATE_META_CACHE, $bundle, HOUR_IN_SECONDS);
    return $bundle;
}

function zibll_child_fetch_update_meta($force = false)
{
    $bundle = zibll_child_fetch_update_bundle($force);
    return !empty($bundle['selected']) && is_array($bundle['selected']) ? $bundle['selected'] : false;
}

/**
 * ★ 更新包完整性校验（v1.5.16 安全修复）★
 *
 * update.json 里本来就提供了 package_sha256，但此前从未被读取，
 * 导致更新流程的全部防线只有「HTTPS + 主机名相同 + theme 字段匹配」——
 * 这三条都只是【同一控制平面内的一致性检查】。一旦更新源服务器
 * （download.hoarfall.cn）或 GitHub 账号被入侵，攻击者同时控制
 * update.json 与 ZIP，这些检查会全部通过，任意 PHP 被 Theme_Upgrader
 * 写入站点。这是典型的供应链风险。
 *
 * 现挂在 WP 标准的 upgrader_pre_download 上：主题更新包【下载完成后、
 * 解压安装之前】校验 SHA256，不匹配即中止安装。
 */
function zibll_child_verify_package_hash($upgrader, $hook_extra)
{
    if (empty($hook_extra['theme']) || $hook_extra['theme'] !== ZIBLL_CHILD_UPDATE_THEME) {
        return $upgrader; // 只管本子主题的更新
    }

    $meta = zibll_child_fetch_update_meta();
    $expected = (!empty($meta['package_sha256'])) ? strtolower(trim((string) $meta['package_sha256'])) : '';

    if ($expected === '' || !preg_match('/^[a-f0-9]{64}$/', $expected)) {
        // 元数据里没有可用哈希：不停装（避免旧版元数据把正常更新卡死），
        // 但留下告警日志，让站长知道这条防线是失效的。
        error_log('[zibll-child] update 元数据缺少有效的 package_sha256，已跳过完整性校验');
        return $upgrader;
    }

    // 取出即将安装的包路径：优先用 $upgrader->skin 已下载好的本地文件
    $package_file = '';
    if (!empty($upgrader->skin->plugin_info) && is_callable(array($upgrader->skin, 'plugin_info'))) {
        $info = $upgrader->skin->plugin_info();
        if (!empty($info['package']) && file_exists($info['package'])) {
            $package_file = $info['package'];
        }
    }
    if ($package_file === '') {
        return new WP_Error(
            'zibll_child_hash_unavailable',
            '无法定位已下载的更新包，已中止安装（无法校验完整性）。'
        );
    }

    $actual = strtolower((string) hash_file('sha256', $package_file));
    if (!hash_equals($expected, $actual)) {
        // 校验失败：删掉可疑包并中止，绝不安装
        if (function_exists('wp_delete_file')) {
            wp_delete_file($package_file);
        } else {
            @unlink($package_file);
        }
        return new WP_Error(
            'zibll_child_hash_mismatch',
            '更新包完整性校验失败（SHA256 不匹配），已中止安装。可能是下载被篡改或中途损坏，请重试。'
        );
    }

    return $upgrader;
}
add_filter('upgrader_pre_download', 'zibll_child_verify_package_hash', 10, 2);

function zibll_child_get_update_source_status($force = false)
{
    $bundle = zibll_child_fetch_update_bundle($force);
    return !empty($bundle['sources']) && is_array($bundle['sources']) ? $bundle['sources'] : array();
}

function zibll_child_has_update()
{
    $meta = zibll_child_fetch_update_meta();
    return $meta !== false && version_compare($meta['version'], zibll_child_get_version(), '>');
}

function zibll_child_build_native_update($meta)
{
    $update = array(
        'id'           => ZIBLL_CHILD_UPDATE_URI,
        'theme'        => ZIBLL_CHILD_UPDATE_THEME,
        'version'      => $meta['version'],
        'new_version'  => $meta['version'],
        'url'          => !empty($meta['url']) ? $meta['url'] : home_url('/'),
        'package'      => $meta['package'],
        'requires'     => !empty($meta['requires']) ? $meta['requires'] : '5.0',
        'requires_php' => !empty($meta['requires_php']) ? $meta['requires_php'] : '7.0',
        'autoupdate'   => false,
    );

    foreach (array('tested', 'icons', 'banners', 'banners_rtl') as $field) {
        if (!empty($meta[$field])) {
            $update[$field] = $meta[$field];
        }
    }

    return $update;
}

function zibll_child_existing_update_version($update)
{
    if (is_object($update)) {
        if (isset($update->new_version)) {
            return (string) $update->new_version;
        }
        if (isset($update->version)) {
            return (string) $update->version;
        }
    }
    if (is_array($update)) {
        if (isset($update['new_version'])) {
            return (string) $update['new_version'];
        }
        if (isset($update['version'])) {
            return (string) $update['version'];
        }
    }

    return '0.0.0';
}

/** Compatibility path for WordPress versions before the Update URI hook. */
function zibll_child_inject_native_update($value)
{
    static $running = false;
    if ($running || !is_object($value) || !isset($value->response) || !is_array($value->response)) {
        return $value;
    }

    $running = true;
    $meta = zibll_child_fetch_update_meta();
    if ($meta !== false) {
        $slug = ZIBLL_CHILD_UPDATE_THEME;
        $candidate = zibll_child_build_native_update($meta);
        $current = zibll_child_get_version();
        $existing = isset($value->response[$slug]) ? $value->response[$slug] : false;

        if (version_compare($meta['version'], $current, '>')
            && (!$existing || version_compare($meta['version'], zibll_child_existing_update_version($existing), '>='))) {
            $value->response[$slug] = $candidate;
            if (isset($value->no_update) && is_array($value->no_update)) {
                unset($value->no_update[$slug]);
            }
        } elseif (!$existing && isset($value->no_update) && is_array($value->no_update)) {
            $value->no_update[$slug] = $candidate;
        }
    }
    $running = false;
    return $value;
}
// v1.5.16（对应 P2-04）：原实现无条件同时注册两条注入路径——
//   ① pre_set_site_transient_update_themes（任意 WP 版本都会跑）
//   ② update_themes_download.hoarfall.cn（WP 6.1+ 的标准 Update URI 路径）
// 在 WP ≥ 6.1（本子主题 Requires at least: 6.1，即所有受支持版本）上
// 两者都会执行并写同一个 $value->response['zibll-child']，造成重复注入；
// 且 zibll_child_inject_native_update() 里的 static $running 重入守卫
// 可能在钩子重入时静默跳过更新信息、掩盖真实故障。
// 现按版本门控：6.1+ 只走标准路径，仅更老的版本才启用兼容回退。
if (version_compare(get_bloginfo('version'), '6.1', '<')) {
    add_filter('pre_set_site_transient_update_themes', 'zibll_child_inject_native_update', 20);
}

/** WordPress 6.1+ Update URI callback. */
function zibll_child_update_themes_from_source($update, $theme_data, $theme_stylesheet, $locales)
{
    if ($theme_stylesheet !== ZIBLL_CHILD_UPDATE_THEME) {
        return $update;
    }

    $meta = zibll_child_fetch_update_meta();
    if ($meta === false || !version_compare($meta['version'], zibll_child_get_version(), '>')) {
        return $update;
    }

    return zibll_child_build_native_update($meta);
}
add_filter('update_themes_download.hoarfall.cn', 'zibll_child_update_themes_from_source', 10, 4);

function zibll_child_get_native_update()
{
    $updates = get_site_transient('update_themes');
    if (is_object($updates) && isset($updates->response[ZIBLL_CHILD_UPDATE_THEME])) {
        return $updates->response[ZIBLL_CHILD_UPDATE_THEME];
    }
    if (is_array($updates) && isset($updates['response'][ZIBLL_CHILD_UPDATE_THEME])) {
        return $updates['response'][ZIBLL_CHILD_UPDATE_THEME];
    }

    return false;
}

/** Force a real WordPress update check from the settings page. */
function zibll_child_refresh_native_updates()
{
    delete_site_transient('update_themes');
    delete_transient(ZIBLL_CHILD_UPDATE_META_CACHE);
    delete_transient('zibll_child_update_meta');

    if (!function_exists('wp_update_themes')) {
        require_once ABSPATH . WPINC . '/update.php';
    }
    if (!function_exists('wp_update_themes')) {
        return array('ok' => false, 'message' => '当前 WordPress 无法加载主题更新接口。');
    }

    wp_update_themes();
    $update = zibll_child_get_native_update();
    return array(
        'ok'      => true,
        'update'  => $update,
        'meta'    => zibll_child_fetch_update_meta(),
        'sources' => zibll_child_get_update_source_status(),
        'message' => $update ? '已完成检查，发现新版本。' : '已完成检查，当前没有可用更新。',
    );
}

function zibll_child_native_update_notice()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    $update = zibll_child_get_native_update();
    if (!$update || version_compare(zibll_child_existing_update_version($update), zibll_child_get_version(), '<=')) {
        return;
    }

    echo '<div class="notice notice-warning is-dismissible"><p>'
        . '<strong>子比子主题有新版本：v' . esc_html(zibll_child_existing_update_version($update)) . '</strong>'
        . '（当前 v' . esc_html(zibll_child_get_version()) . '）。'
        . ' 请前往 <a href="' . esc_url(admin_url('update-core.php')) . '">仪表盘 → 更新</a> 使用 WordPress 原生主题更新。'
        . '</p></div>';
}
add_action('admin_notices', 'zibll_child_native_update_notice');

/**
 * Preserve legacy func.php/style.css during the first native upgrade.
 * upgrader_post_install receives ($response, $hook_extra, $result).
 */
$GLOBALS['zibll_child_legacy_upgrade_backup'] = false;

function zibll_child_legacy_upgrade_is_target($hook_extra)
{
    return is_array($hook_extra)
        && !empty($hook_extra['theme'])
        && $hook_extra['theme'] === ZIBLL_CHILD_UPDATE_THEME;
}

function zibll_child_theme_directory()
{
    $theme = wp_get_theme(ZIBLL_CHILD_UPDATE_THEME);
    if (is_object($theme) && method_exists($theme, 'get_stylesheet_directory')) {
        return trailingslashit($theme->get_stylesheet_directory());
    }

    return trailingslashit(get_theme_root()) . ZIBLL_CHILD_UPDATE_THEME . '/';
}

function zibll_child_backup_legacy_files($response, $hook_extra)
{
    // The independent plugin loads earlier and owns migration protection when active.
    if (defined('ZIBLL_SITE_CODE_PLUGIN_ACTIVE')
        || is_wp_error($response)
        || !zibll_child_legacy_upgrade_is_target($hook_extra)) {
        return $response;
    }

    // Do not derive the path from a hard-coded themes root: the theme may use a
    // custom theme root or a historical directory location.
    $theme_dir = zibll_child_theme_directory();
    if (!is_dir($theme_dir)) {
        return new WP_Error('zibll_child_backup_missing_theme', '找不到现有子主题目录，已中止更新以保护站点代码。');
    }

    $backup_dir = trailingslashit(get_temp_dir()) . 'zibll-child-legacy-' . md5(uniqid('', true));
    if (!wp_mkdir_p($backup_dir)) {
        return new WP_Error('zibll_child_backup_directory', '无法创建子主题迁移备份目录，已中止更新。');
    }

    $backup = array('dir' => $backup_dir, 'files' => array());
    foreach (array('func.php', 'style.css') as $file) {
        $source = $theme_dir . $file;
        $target = trailingslashit($backup_dir) . $file;
        if (!is_readable($source)) {
            continue;
        }
        if (!@copy($source, $target)) {
            @rmdir($backup_dir);
            return new WP_Error('zibll_child_backup_copy', '无法备份子主题 ' . $file . '，已中止更新。');
        }
        $backup['files'][$file] = true;
    }

    if (!empty($backup['files'])) {
        $GLOBALS['zibll_child_legacy_upgrade_backup'] = $backup;
        register_shutdown_function('zibll_child_cleanup_legacy_upgrade_backup');
    } else {
        @rmdir($backup_dir);
    }

    return $response;
}
add_filter('upgrader_pre_install', 'zibll_child_backup_legacy_files', 10, 2);

function zibll_child_css_body($css)
{
    $css = (string) $css;
    if (preg_match('/\A\s*(\/\*[\s\S]*?\*\/)\s*/', $css, $match)
        && preg_match('/Theme\s+Name\s*:/i', $match[1])) {
        return substr($css, strlen($match[0]));
    }

    return $css;
}

function zibll_child_restore_legacy_files($response, $hook_extra, $result)
{
    if (is_wp_error($response) || !zibll_child_legacy_upgrade_is_target($hook_extra)) {
        return $response;
    }

    $backup = $GLOBALS['zibll_child_legacy_upgrade_backup'];
    if (empty($backup['dir']) || empty($backup['files'])) {
        return $response;
    }

    $destination = is_array($result) && !empty($result['destination'])
        ? trailingslashit($result['destination'])
        : zibll_child_theme_directory();
    if (!is_readable($destination . 'style.css')) {
        error_log('[zibll-child] 原生主题更新后找不到新的 style.css，跳过旧文件恢复。');
        return new WP_Error('zibll_child_invalid_destination', '主题更新包结构无效，找不到新的 style.css。');
    }

    foreach ($backup['files'] as $file => $unused) {
        $old_file = trailingslashit($backup['dir']) . $file;
        $new_file = $destination . $file;
        if (!is_readable($old_file)) {
            continue;
        }

        if ($file === 'style.css' && is_readable($new_file)) {
            $old_body = zibll_child_css_body(file_get_contents($old_file));
            $new_css  = file_get_contents($new_file);
            $marker   = '/* Preserved site CSS */';
            if (is_string($old_body) && is_string($new_css) && trim($old_body) !== ''
                && strpos($new_css, $marker) === false) {
                if (false === @file_put_contents(
                    $new_file,
                    rtrim($new_css) . "\n\n" . $marker . "\n" . ltrim($old_body)
                )) {
                    error_log('[zibll-child] 站点 CSS 恢复写入失败。');
                }
            }
        } else {
            @copy($old_file, $new_file);
        }
    }

    zibll_child_cleanup_legacy_upgrade_backup();
    return $response;
}
add_filter('upgrader_post_install', 'zibll_child_restore_legacy_files', 10, 3);

function zibll_child_cleanup_legacy_upgrade_backup()
{
    $backup = $GLOBALS['zibll_child_legacy_upgrade_backup'];
    if (empty($backup['dir']) || !is_dir($backup['dir'])) {
        return;
    }

    if (!empty($backup['files'])) {
        foreach ($backup['files'] as $file => $unused) {
            @unlink(trailingslashit($backup['dir']) . $file);
        }
    }
    @rmdir($backup['dir']);
    $GLOBALS['zibll_child_legacy_upgrade_backup'] = false;
}

/**
 * Remove options left by the old incremental updater once per site.
 */
function zibll_child_cleanup_legacy_options()
{
    if (get_option('zibll_child_native_cleanup_done')) {
        return;
    }

    delete_option('zibll_child_version');
    delete_option('zibll_child_bak_cleanup_version');
    delete_transient('zibll_child_update_meta');
    update_option('zibll_child_native_cleanup_done', 1, false);
}
add_action('init', 'zibll_child_cleanup_legacy_options', 5);
