<?php
/**
 * 站点自定义 PHP 代码（安全草稿区）
 *
 * 本文件用于放置少量站点级、临时或一次性的自定义代码。
 * 说明：子主题在线更新采用【增量模式】——只下载覆盖更新清单内的核心代码文件，
 * 本文件（func.php）不在清单内、且被强制保护，因此更新时不会被覆盖，可放心存放自定义。
 *
 * 注意：
 *   - 长期、可复用的功能请改为 includes/ 下的模块文件，结构更清晰、易维护。
 *   - 以下示例默认均为「注释状态」，不会改动任何运行时行为；
 *     按需取消注释即可生效。请务必保证 PHP 语法正确，错误代码会导致白屏。
 *
 * 子主题三种标准扩展方式（详见 includes/functions/functions.php 第 4 节）：
 *   (a) 模板覆盖：在子主题根目录放同名模板文件（footer.php / single.php …）
 *   (b) 钩子扩展：add_action / add_filter 挂接父主题暴露的钩子
 *   (c) 样式覆盖：在 style.css 中书写更高优先级规则
 *
 * @package zibll-child
 */

// ─── 示例 (b)：钩子扩展 ───────────────────────────────────────
// 给 <body> 追加一个子主题专属 class，便于在 style.css 中做定向覆盖
// （父主题 inc/functions/zib-theme.php 通过 apply_filters('zib_add_bodyclass', ...)
//  输出 body class，可直接挂接）
// add_filter('zib_add_bodyclass', function ($class) {
//     return trim($class . ' zibll-child-active');
// });

// ─── 示例 (b)：移除父主题的某个前端钩子 ───────────────────────
// 父主题函数均已就绪，可直接 remove_action / remove_filter
// （以下为示意，按需替换钩子名与优先级）
// remove_action('wp_footer', 'zib_xxx_function', 10);

// ─── 示例 (b)：调用父主题函数 ────────────────────────────────
// 父主题的所有函数/类在本文件加载时早已可用，可直接调用
// add_action('init', function () {
//     // if (function_exists('_pz')) { $opt = _pz('some_option'); }
// });

// ─── 示例 (a) 提示 ───────────────────────────────────────────
// 若需覆盖某个模板，直接在子主题根目录新建同名 .php 文件即可，
// 例如新建 zibll-child/footer.php 即可覆盖父主题 footer.php，
// 父主题原文件作为回退。无需在此处写任何代码。

// ─── 全屏画廊页排除站点级 NSFW 提示 ─────────────────────────
// 「二次元画廊」插件开启「全屏画廊页」(acag_fullscreen_home) 后，/gallery 与
// /gallery-cat 使用自建纯净模板。此时移除 post-hide 模块的 NSFW 通知栏与弹窗，
// 避免站点级浮层破坏全屏画廊的纯净观感（仅全屏模式 + 画廊页生效，不影响其他页面）。
add_action('wp_footer', function () {
    if (get_option('acag_fullscreen_home', 0)
        && (is_post_type_archive('ac_gallery') || is_tax('gallery_cat'))) {
        remove_action('wp_footer', 'zibph_render_notice_bar', 50);
        remove_action('wp_footer', 'zibph_render_display_modal', 40);
    }
}, 1);

// ─── 放行"作者/编辑/管理员"进入后台（覆盖父主题"非管理员禁止进入后台"） ──
// 父主题 zib-theme.php 默认用 is_super_admin() 拦截所有非管理员（含作者/编辑），
// 重定向回首页，导致作者角色无法用后台古德堡编辑器发文章。
// 此处移除父主题的全局拦截，改为仅放行具备 publish_posts 能力的角色
// （作者/编辑/管理员），其余角色（投稿者/订阅者）仍退回首页，保留原安全意图。
// 注意保留对 admin-ajax.php 的放行，避免前台 AJAX 被误拦。
add_action('admin_init', function () {
    // 移除父主题默认优先级 10 的全局拦截（本回调优先级 1，先执行可成功移除）
    remove_action('admin_init', 'zib_no_entry_backstage', 10);

    // 仅放行能发布文章的角色；其余退回首页
    if (!current_user_can('publish_posts') && !stristr($_SERVER['PHP_SELF'] ?? '', 'admin-ajax.php')) {
        wp_redirect(home_url());
        exit;
    }
}, 1);
