<?php
/**
 * 子比子主题 - 谷歌登录头像国内可达（墙外反代改写）
 * ─────────────────────────────────────────────────────────────
 * 解决什么问题
 *   父主题处理 Google 登录时：
 *     · oauth/google/callback.php 取 $userInfo['picture']（lh3.googleusercontent.com 原链）
 *     · oauth/oauth.php 在用户未设头像时把该原链写入 custom_avatar（zib-theme.php:310-312）
 *   全站头像渲染走 zib_get_user_avatar_url() 直接读 custom_avatar，国内拉不到
 *   googleusercontent → 头像裂图。
 *
 * 本方案（零侵入父主题，复用 QQ 头像模块范式）
 *   把 custom_avatar 里的 googleusercontent 原链改写为【子主题自带的代理端点】，
 *   该端点（子主题根目录 avatar-proxy.php，随主题分发）运行在用户的服务器上，
 *   自身即墙外出口，可直连 Google 拉图后吐给国内用户（前面有 CDN/CF 缓存）。
 *   渲染层 zib_get_user_avatar_url() 会去协议（preg_replace '/^(https:|http:)/'）
 *   变成 //<站点域名>/.../avatar-proxy.php?u=...，国内走你自家域名 → 正常显示。
 *   开关：zibll_child_module_enabled('enable_google_avatar_proxy')，默认关闭
 *   （国内服务器部署一般用不到，香港 + Google 登录场景手动开启）。
 *
 * 安全边界
 *   · 只改「值是 Google 头像」的 custom_avatar；用户已主动上传/绑定的头像
 *     （custom_avatar 非 googleusercontent）一律不动，避免覆盖。
 *   · 代理端点（avatar-proxy.php）侧做 URL 白名单（防变开放代理），本文件只负责改写。
 *
 * 开关：zibll_child_module_enabled('enable_google_avatar_proxy')（默认关闭）
 *
 * @package zibll-child
 */

if (!defined('ABSPATH')) {
    exit;
}

// 墙外反代地址：指向子主题自带的端点（子主题根目录 avatar-proxy.php）。
// 该端点随主题分发、运行在用户服务器（如香港墙外出口），可直连 Google 拉图，
// 无需任何外部 Worker / 独立域名。改路径只动这一处。
if (!defined('ZIBLL_CHILD_GOOGLE_AVATAR_PROXY')) {
    $zibll_child_proxy_url = function_exists('get_stylesheet_directory_uri')
        ? trailingslashit(get_stylesheet_directory_uri()) . 'avatar-proxy.php'
        : 'avatar-proxy.php';
    define('ZIBLL_CHILD_GOOGLE_AVATAR_PROXY', $zibll_child_proxy_url);
}

/**
 * 判断一个 URL 是否为 Google 头像（googleusercontent 系 / google.com 的 +ID 头像）。
 * @param string $url
 * @return bool
 */
if (!function_exists('zibll_child_is_google_avatar')) {
    function zibll_child_is_google_avatar($url)
    {
        if (empty($url) || !is_string($url)) {
            return false;
        }
        return (bool) preg_match('#^https?://(lh\d+\.)?googleusercontent\.com/#i', $url)
            || (bool) preg_match('#^https?://[\w.-]+\.googleusercontent\.com/#i', $url)
            || (bool) preg_match('#^https?://(?:[\w.-]+\.)?google\.com/\+#i', $url);
    }
}

/**
 * 把 Google 头像 URL 改写为墙外反代地址（仅对 Google 头像生效）。
 * @param string $url
 * @return string
 */
if (!function_exists('zibll_child_proxy_google_avatar_url')) {
    function zibll_child_proxy_google_avatar_url($url)
    {
        if (!zibll_child_is_google_avatar($url)) {
            return $url;
        }
        return ZIBLL_CHILD_GOOGLE_AVATAR_PROXY . '?u=' . urlencode($url);
    }
}

/**
 * 单个用户：若 custom_avatar 是 Google 头像则改写为反代地址并刷新头像缓存。
 * @param int $user_id
 */
if (!function_exists('zibll_child_proxy_user_google_avatar')) {
    function zibll_child_proxy_user_google_avatar($user_id)
    {
        $user_id = (int) $user_id;
        if (!$user_id || !function_exists('zib_get_user_meta')) {
            return;
        }
        $existing = zib_get_user_meta($user_id, 'custom_avatar', true);
        if ($existing && zibll_child_is_google_avatar($existing)) {
            zib_update_user_meta($user_id, 'custom_avatar', zibll_child_proxy_google_avatar_url($existing));
            if (function_exists('zibll_child_flush_avatar_cache')) {
                zibll_child_flush_avatar_cache($user_id);
            }
        }
    }
}

/**
 * wp_login 适配器（优先级 25，确保晚于父主题 oauth 写库 + oauth-auto-email 的 20）。
 * 回调签名为 ($user_login, $user)，首参是用户名字符串，需取出 $user->ID。
 */
if (!function_exists('zibll_child_proxy_google_avatar_on_login')) {
    function zibll_child_proxy_google_avatar_on_login($user_login, $user)
    {
        if ($user instanceof WP_User) {
            zibll_child_proxy_user_google_avatar($user->ID);
        }
    }
}

/**
 * 存量用户一次性改写：把全部 custom_avatar 是 Google 头像的用户改写为反代地址。
 *
 * ⚠️ 不能用 get_users(meta_key='custom_avatar')：父主题把 custom_avatar 注册进了
 * zibll 自有的 option_meta 机制（见 zibll dependent.php 的 user_meta option_meta_keys），
 * 真实头像并不在 wp_usermeta 表里，标准 WP_User_Query 查不到。
 * 所以改为遍历全部用户，用 zib_get_user_meta 逐个读取判断；
 * zibll_child_proxy_user_google_avatar 内部已带 is_google_avatar 守卫，天然幂等。
 */
if (!function_exists('zibll_child_proxy_all_google_avatars')) {
    function zibll_child_proxy_all_google_avatars()
    {
        // 用 zibll 的读取辅助（若存在），否则退回标准 get_user_meta
        $reader = function_exists('zib_get_user_meta')
            ? 'zib_get_user_meta'
            : 'get_user_meta';
        $users = get_users(array('fields' => 'ID', 'number' => 0));
        foreach ($users as $uid) {
            $uid     = (int) $uid;
            $existing = $reader($uid, 'custom_avatar', true);
            if ($existing && zibll_child_is_google_avatar($existing)) {
                zibll_child_proxy_user_google_avatar($uid);
            }
        }
    }
}

if (zibll_child_module_enabled('enable_google_avatar_proxy', false)) {
    // 登录时即时改写当前用户（覆盖 oauth 新建号 / 后续登录场景）
    add_action('wp_login', 'zibll_child_proxy_google_avatar_on_login', 25, 2);

    // 启用后一次性改写存量谷歌头像用户（选项标记只跑一次）
    add_action('init', 'zibll_child_google_avatar_auto_once');
}

if (!function_exists('zibll_child_google_avatar_auto_once')) {
    function zibll_child_google_avatar_auto_once()
    {
        if (get_option('zibll_child_google_avatar_done')) {
            return;
        }
        zibll_child_proxy_all_google_avatars();
        update_option('zibll_child_google_avatar_done', 1);
    }
}
