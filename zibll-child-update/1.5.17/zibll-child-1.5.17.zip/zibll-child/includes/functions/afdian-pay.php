<?php
/**
 * 子比子主题 - 爱发电（Afdian）支付渠道  v1.5.15
 * ─────────────────────────────────────────────────────────────
 * 把爱发电作为标准支付方式「融入」父主题 zibll 的收银台（付费文章 / 会员 /
 * 余额充值 / 商城商品），零侵入、不修改父主题一行。
 *
 * 工作原理（完全复用父主题现有钩子与入口）：
 *   1. add_filter('zibpay_payment_methods', …)
 *      —— 往支付选择列表注入 afdian，所有收银台自动出现「爱发电」选项。
 *   2. add_filter('zibpay_initiate_paysdk', …)
 *      —— 识别 payment_method=afdian，转交本模块的发起处理器。
 *   3. zibll_child_afdian_initiate_pay()
 *      —— 拼出爱发电「下单页」URL 并交给前端 open_url 跳转逻辑；
 *         用户在该页完成付款后，爱发电主动把订单推到本站的 Webhook。
 *   4. afdian-notify.php（子主题根目录，仿父主题 zibpay/shop/<网关>/notify.php）
 *      —— 爱发电 Webhook 回调入口，用爱发电【平台固定公钥】RSA-SHA256 验签，
 *        status=2 且通过后调用 ZibPay::payment_order() 标记本地订单已付，
 *        自动触发 zibll 原有发货 / 到账流程。必须回 {"ec":200,"em":""}。
 *
 * ★ 安全边界（v1.5.16 修复后，此处描述才与实现一致）★
 *   1. 金额：入账金额一律取【站内订单表的应收金额】
 *      （zibll_child_afdian_local_order_price()），绝不用回调里的 total_amount。
 *      原因：父主题 ZibPay::should_skip_pay_amount_check() 在 order-class.php:837
 *      被硬编码 `return true`，其金额核对运行时从不执行；而爱发电下单页允许
 *      用户改写 custom_price。若信任回调金额，付 0.01 元即可解锁任意高价商品。
 *   2. 幂等：先按单号类型查站内状态（payment 单号查 zibpay_payment、order 单号查
 *      zibpay_order），再用带 60s TTL 的 transient 锁挡住并发重复回调；
 *      父主题 payment_order() 内的 status 条件 UPDATE 是第二道防线。
 *   3. 验签失败 / 状态非 2 / 金额不符 一律 ack {"ec":200}（爱发电协议要求，
 *      否则会无限重推），但都会写 zibll_child_afdian_unmatched 留痕供排查。
 *
 * 两种下单模式（对齐爱发电官方 / 授权中心 Go 实现）：
 *   · 自选金额模式（未填「爱发电方案 ID」）—— 落点 /order/create 且必须带
 *     user_id（爱发电下单页前置守卫要求，否则页只显示「选择你的赞助期限」无法付款）；
 *     custom_price=站内订单金额（auto 时预填），支持任意充值金额 —— 推荐。
 *   · 固定方案模式（填了「爱发电方案 ID」）—— 落点 /order/create?plan_id=…&product_type=…，
 *     金额由方案自身决定，同样必须与站内订单金额一致，否则回调会被本模块的对账拒绝入账。
 *   两种模式都必带 custom_order_id（站内订单号），它是回调能与站内订单精确对上账的唯一凭据。
 *
 * 爱发电没有「服务端创建订单」接口，也没有「商户字段」：回调的 order.user_id 是
 * 「买家」不是商户，商户身份由「Webhook 配在哪家账号」决定，因此认证完全依赖
 * RSA 签名校验，绝不能用 order.user_id 去比对配置里的 user_id（早期实现因此误拒）。
 * 本模块 Webhook 验签用的就是爱发电平台固定公钥，任何站点通用，无需你的任何凭证即可运行。
 *
 * 配置：后台「子比子主题设置 → 爱发电支付」分组
 *       （爱发电 user_id、方案 ID〔可选〕、product_type、自选金额参数、API 基础地址、API Token〔选填〕）。
 *
 * @package zibll-child
 * @author  依岸归
 * @link    https://nav.hoarfall.cn/
 * @license GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─── 爱发电平台固定公钥（RSA-SHA256，用于 Webhook 验签；全平台通用，无需你的私钥） ───
if (!defined('ZIBLL_CHILD_AFDIANA_PUBLIC_KEY')) {
    define('ZIBLL_CHILD_AFDIANA_PUBLIC_KEY', <<<PEM
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAwwdaCg1Bt+UKZKs0R54y
lYnuANma49IpgoOwNmk3a0rhg/PQuhUJ0EOZSowIC44l0K3+fqGns3Ygi4AfmEfS
4EKbdk1ahSxu7Zkp2rHMt+R9GarQFQkwSS/5x1dYiHNVMiR8oIXDgjmvxuNes2Cr
8fw9dEF0xNBKdkKgG2qAawcN1nZrdyaKWtPVT9m2Hl0ddOO9thZmVLFOb9NVzgYf
jEgI+KWX6aY19Ka/ghv/L4t1IXmz9pctablN5S0CRWpJW3Cn0k6zSXgjVdKm4uN7
jRlgSRaf/Ind46vMCm3N2sgwxu/g3bnooW+db0iLo13zzuvyn727Q3UDQ0MmZcEW
MQIDAQAB
-----END PUBLIC KEY-----
PEM
    );
}

// ─── 配置读取 ───────────────────────────────────────────────
if (!function_exists('zibll_child_afdian_config')) {
    /**
     * 爱发电配置读取（带格式归一化）。
     *
     * v1.5.16 起对 user_id / plan_id 做十六进制白名单校验、对 api_base 做归一化：
     * 原实现只做 trim()，配置里误填空格/漏写 https:// 会生成畸形跳转 URL，
     * 表现为「收银台能看见爱发电、点下去却跳错页面」，且 user_id 若被填成
     * 带路径的脏值还会被拼进 query 串造成参数注入。
     *
     * 不合规的 user_id / plan_id 视为「未配置」（返回空串），
     * 由 order_create_url() 走「配置不完整」友好报错分支。
     */
    function zibll_child_afdian_config()
    {
        $user_id = trim((string) zibll_child_get_option('afdian_user_id', ''));
        $plan_id = trim((string) zibll_child_get_option('afdian_plan_id', ''));

        // 爱发电的 user_id / plan_id 均为十六进制字符串，长度 16-64
        if ($user_id !== '' && !preg_match('/^[A-Fa-f0-9]{16,64}$/', $user_id)) {
            $user_id = '';
        }
        if ($plan_id !== '' && !preg_match('/^[A-Fa-f0-9]{16,64}$/', $plan_id)) {
            $plan_id = '';
        }

        // api_base 归一化：去掉可能重复书写的协议前缀与结尾斜杠，下游再补 https://
        $api_base = trim((string) zibll_child_get_option('afdian_api_base', 'https://ifdian.net'));
        $api_base = preg_replace('#^https?://#i', '', $api_base);
        $api_base = untrailingslashit(trim((string) $api_base));
        if ($api_base === '' || !preg_match('#^[A-Za-z0-9.\-]+(?::\d+)?(?:/[A-Za-z0-9._\-/]*)?$#', $api_base)) {
            $api_base = 'ifdian.net';
        }

        return array(
            'user_id'      => $user_id,
            'plan_id'      => $plan_id,
            'api_token'    => trim((string) zibll_child_get_option('afdian_api_token', '')),
            'api_base'     => $api_base,
            'product_type' => zibll_child_get_option('afdian_product_type', '0'),
            'custom_price' => zibll_child_get_option('afdian_custom_price', 'auto'),
        );
    }
}

// 模块是否启用（开关 + 至少有一个能标识创作者的参数：user_id 或 plan_id 任一非空）
// 早期版本强依赖一个写死的「页面地址」，导致用户删空后整模块罢工；随后又只认 user_id，
// 让「固定方案模式（只填 plan_id）」误判禁用。现改为两者任一即可。
if (!function_exists('zibll_child_afdian_enabled')) {
    function zibll_child_afdian_enabled()
    {
        if (!zibll_child_module_enabled('enable_afdian_pay', false)) {
            return false;
        }
        $cfg = zibll_child_afdian_config();
        return $cfg['user_id'] !== '' || $cfg['plan_id'] !== '';
    }
}

// Webhook 接收地址（供后台展示 + 用户配置到爱发电开发者后台）
if (!function_exists('zibll_child_afdian_webhook_url')) {
    function zibll_child_afdian_webhook_url()
    {
        return home_url('/wp-content/themes/zibll-child/afdian-notify.php');
    }
}

// 收银台支付方式图标（爱发电品牌色：黄 #FFE411 + 闪电意象，内联 SVG，避免外部文件依赖）
if (!function_exists('zibll_child_afdian_method_img')) {
    function zibll_child_afdian_method_img()
    {
        return '<svg viewBox="0 0 28 28" width="22" height="22" aria-hidden="true" style="border-radius:5px;">'
            . '<rect x="1" y="1" width="26" height="26" rx="6" fill="#FFE411"/>'
            . '<path d="M16.5 5 L9.5 15.5 H13.5 L11.5 23 L19 12 H14.8 Z" fill="#1a1a1a"/>'
            . '</svg>';
    }
}

// ─── 钩子 1：把爱发电注入收银台支付方式列表 ──────────────────
add_filter('zibpay_payment_methods', 'zibll_child_afdian_payment_methods', 20, 2);
if (!function_exists('zibll_child_afdian_payment_methods')) {
    function zibll_child_afdian_payment_methods($methods, $pay_type)
    {
        if (zibll_child_afdian_enabled()) {
            $methods['afdian'] = array(
                'name' => '爱发电',
                'img'  => zibll_child_afdian_method_img(),
            );
        }
        return $methods;
    }
}

// ─── 钩子 2：识别 afdian 支付方式，转交本模块发起处理器 ──────
add_filter('zibpay_initiate_paysdk', 'zibll_child_afdian_initiate_paysdk', 20, 2);
if (!function_exists('zibll_child_afdian_initiate_paysdk')) {
    function zibll_child_afdian_initiate_paysdk($pay_sdk, $order_data)
    {
        if (!empty($order_data['payment_method']) && 'afdian' === $order_data['payment_method']) {
            return 'afdian';
        }
        return $pay_sdk;
    }
}

// ─── 钩子 3：拼爱发电下单页 URL（返回跳转链接，复用前端 open_url 逻辑） ──
add_filter('zibpay_initiate_afdian', 'zibll_child_afdian_initiate_pay', 10, 1);
if (!function_exists('zibll_child_afdian_initiate_pay')) {
    function zibll_child_afdian_initiate_pay($order_data)
    {
        if (!zibll_child_afdian_enabled()) {
            return array('error' => 1, 'msg' => __('当前订单不支持此方式支付，请联系客服', 'zib_language'));
        }

        $order_num   = !empty($order_data['order_num']) ? $order_data['order_num'] : '';
        $order_price = !empty($order_data['order_price']) ? (float) $order_data['order_price'] : 0;

        if (!$order_num) {
            return array('error' => 1, 'msg' => __('订单创建失败', 'zib_language'));
        }

        $url = zibll_child_afdian_order_create_url($order_num, $order_price);
        if (!$url) {
            return array('error' => 1, 'msg' => __('爱发电配置不完整，请联系客服', 'zib_language'));
        }

        return array(
            'open_url' => true,
            'url'      => $url,
        );
    }
}

// ─── 拼装爱发电下单页地址（对齐爱发电官方 / 授权中心 Go 实现） ──
// 关键点：/order/create 的前置守卫要求 URL 里出现 plan_id / user_id 之一，
// 否则页面拿不到创作者上下文，只渲染留言框和「去支付」按钮、档位区域报
// 「选择你的赞助期限」，用户根本付不了款。
if (!function_exists('zibll_child_afdian_order_create_url')) {
    function zibll_child_afdian_order_create_url($order_num, $amount)
    {
        $cfg = zibll_child_afdian_config();

        // api_base 在 zibll_child_afdian_config() 中已归一为「裸域名（无协议、无尾斜杠）」，
        // 此处补回 https:// —— 支付跳转必须是 https，避免明文传输与混合内容拦截。
        $api_base = $cfg['api_base'] !== '' ? $cfg['api_base'] : 'ifdian.net';
        $api_base = 'https://' . ltrim($api_base, '/');

        $plan_id = $cfg['plan_id'];
        $user_id = $cfg['user_id'];

        $q = array();

        if ($plan_id !== '') {
            // 固定方案模式：金额由方案自身决定，custom_price 无意义。
            $q['plan_id']      = $plan_id;
            $q['product_type'] = ($cfg['product_type'] === '1') ? '1' : '0';
        } else {
            // 自选金额模式：user_id 是让下单页正常工作的必需参数。
            if ($user_id === '') {
                return '';
            }
            $q['user_id'] = $user_id;
            // ⚠️ 依赖父主题约定：zibpay_order.order_price / zibpay_payment.price
            //    均为「元」为单位的 double(10,2)。若父主题未来改为「分」存储，
            //    此处的 2 位小数必须同步去掉，否则会生成 100 倍的金额。
            // ⚠️ 安全提示：custom_price 只是【预填】，爱发电下单页允许用户改写；
            //    因此本模块【不】信任回调里的 total_amount，而是在
            //    zibll_child_afdian_handle_webhook() 中以站内订单表金额做强制对账。
            if (($cfg['custom_price'] ?: 'auto') === 'auto' && $amount > 0) {
                $q['custom_price'] = number_format($amount, 2, '.', '');
            }
        }

        // 两种模式都必带 custom_order_id（站内订单号）—— 回调对账唯一凭据。
        $q['custom_order_id'] = $order_num;

        return esc_url_raw($api_base . '/order/create?' . http_build_query($q));
    }
}

// ─── Webhook 验签（RSA-SHA256，平台固定公钥） ──────────────
if (!function_exists('zibll_child_afdian_verify_sign')) {
    function zibll_child_afdian_verify_sign($order)
    {
        // 必填：out_trade_no（爱发电订单号）、total_amount（实际收款）；user_id / plan_id 允许为空但须参与拼接。
        // ⚠️ plan_id 在「自选金额模式」下本就是空字符串，但必须原样参与拼接（与授权中心 Go 实现
        //    verifyAfdianOrderSignature 完全一致：TrimSpace 后直接拼接，绝不判空），否则签名永不匹配。
        if (empty($order['out_trade_no']) || !isset($order['total_amount']) || empty($_POST['sign'])) {
            return false;
        }
        // sign_str = out_trade_no + user_id + plan_id + total_amount（逐个 TrimSpace 后拼接，对齐爱发电官方）
        $sign_str = trim($order['out_trade_no'])
            . trim(isset($order['user_id']) ? (string) $order['user_id'] : '')
            . trim(isset($order['plan_id']) ? (string) $order['plan_id'] : '')
            . trim((string) $order['total_amount']);
        // 公钥默认用爱发电平台固定公钥。
        // ⚠️ 安全（v1.5.16）：原实现无条件允许任意插件通过过滤器替换公钥。
        // 一旦站点上存在恶意/被入侵的第三方插件调用该过滤器换上自己的公钥，
        // 攻击者即可自签任意 custom_order_id + total_amount 的伪造回调。
        // 现仅在 WP_DEBUG 开启时允许覆盖（供开发调试），生产环境锁定平台公钥。
        $public_key = ZIBLL_CHILD_AFDIANA_PUBLIC_KEY;
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $public_key = apply_filters('zibll_child_afdian_public_key', $public_key);
        }
        $pubkey   = openssl_get_publickey($public_key);
        if (!$pubkey) {
            return false;
        }
        // PHP 8.0+ 中 OpenSSLAsymmetricKey 对象会被自动释放，无需 openssl_free_key()。
        $ok = openssl_verify($sign_str, base64_decode($_POST['sign']), $pubkey, OPENSSL_ALGO_SHA256);
        return $ok === 1;
    }
}

// ─── 服务端权威金额解析（安全关键）────────────────────────────
// ⚠️ 背景（v1.5.16 安全修复）：入账金额绝不能采信 Webhook 推送的 total_amount。
//    爱发电下单页允许用户自由修改 custom_price（自选金额模式下 0.01 元即可付款），
//    而父主题 ZibPay::should_skip_pay_amount_check() 在
//    zibpay/class/order-class.php:837 被硬编码 `return true`（注释：「考虑到汇率问题，暂不启用」），
//    导致 ZibPay::verify_notify_pay_amount() 恒返回 true —— 父主题的金额核对
//    在运行时【完全不会执行】。若直接用 $total_amount 入账，攻击者付 0.01 元
//    即可解锁任意高价商品/会员，同时 pay_price 被写成 0.01 掩盖对账痕迹。
//    因此本函数一律以【站内订单表的应收金额】为唯一权威来源。
if (!function_exists('zibll_child_afdian_local_order_price')) {
    /**
     * 按站内订单号解析出应收金额（元）。
     *
     * @param string $order_num 站内订单号（payment 单号或 order 单号）
     * @return float  解析失败或金额非法时返回 0.0
     */
    function zibll_child_afdian_local_order_price($order_num)
    {
        $order_num = trim((string) $order_num);
        if ($order_num === '' || !class_exists('ZibPay')) {
            return 0.0;
        }

        // payment 单号（父主题 generate_payment_order_num() 生成，520 前缀）落在 zibpay_payment 表
        if (ZibPay::is_payment_order($order_num)) {
            $payment = ZibPay::get_payment($order_num);
            if (!empty($payment) && isset($payment['price'])) {
                return round((float) $payment['price'], 2);
            }
            return 0.0;
        }

        // order 单号落在 zibpay_order 表
        global $wpdb;
        $price = $wpdb->get_var($wpdb->prepare(
            "SELECT order_price FROM {$wpdb->zibpay_order} WHERE order_num = %s",
            $order_num
        ));
        if ($price === null || $price === '') {
            return 0.0;
        }
        return round((float) $price, 2);
    }
}

// 原始请求体读取（抽成函数，便于测试时在不支持 php://input 的 CLI 环境覆写）
if (!function_exists('zibll_child_afdian_raw_input')) {
    function zibll_child_afdian_raw_input()
    {
        return file_get_contents('php://input');
    }
}

// ─── Webhook 业务处理（供 afdian-notify.php 调用） ──────────
if (!function_exists('zibll_child_afdian_handle_webhook')) {
    function zibll_child_afdian_handle_webhook()
    {
        // 读取原始 JSON 体
        $raw = zibll_child_afdian_raw_input();
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data['data']['order'])) {
            return array('ec' => 200, 'em' => '');
        }

        $order = $data['data']['order'];
        // 签名字段：优先 data.sign，其次 order.sign（爱发电不同推送版本位置不同）
        $sign = '';
        if (!empty($data['data']['sign'])) {
            $sign = $data['data']['sign'];
        } elseif (!empty($order['sign'])) {
            $sign = $order['sign'];
        }
        $_POST['sign'] = $sign;

        // 验签（RSA-SHA256，平台固定公钥）
        if (!zibll_child_afdian_verify_sign($order)) {
            zibll_child_afdian_log_unmatched($order, 'sign_failed');
            return array('ec' => 200, 'em' => '');
        }

        // 仅处理交易成功（爱发电仅推送 status=2）
        if (empty($order['status']) || (int) $order['status'] !== 2) {
            return array('ec' => 200, 'em' => '');
        }

        // custom_order_id 必须是我们下单时透传的站内订单号。为空说明该订单不是在站内
        // 发起的（例如创作者自己在爱发电页面成交），直接按无关事件放行 —— 否则爱发电会无限重推。
        $custom_order_id = isset($order['custom_order_id']) ? trim($order['custom_order_id']) : '';
        if ($custom_order_id === '') {
            zibll_child_afdian_log_unmatched($order, 'no_custom_order_id');
            return array('ec' => 200, 'em' => '');
        }

        // 用兑换码支付时 total_amount 为 0.00，没有实际收款，不入账也不重推。
        $total_amount = isset($order['total_amount']) ? trim($order['total_amount']) : '';
        if ($total_amount === '' || (float) $total_amount <= 0) {
            zibll_child_afdian_log_unmatched($order, 'zero_amount');
            return array('ec' => 200, 'em' => '');
        }

        // ── 并发锁：把父主题「status 条件 UPDATE」这一隐式幂等契约显式化 ──
        // 官方文档明确提示「不排除重复请求」，父主题 payment_order() 内部虽带
        // status IN ('0','-1') 条件更新可挡住并发重复发放，但子主题侧不应
        // 只依赖父主题实现细节，故此处加一个带 TTL 的 transient 锁兜底。
        $lock_key = 'zibllc_afdian_' . md5($custom_order_id);
        if (get_transient($lock_key)) {
            // 同一订单正在处理中，直接 ack 让爱发电稍后重推，避免并发重复入账
            return array('ec' => 200, 'em' => '');
        }
        set_transient($lock_key, time(), 60); // 60s TTL，异常退出也不会永久卡死

        try {
            // ── 幂等：已支付则直接返回成功 ──
            // ⚠️ 修复（v1.5.16）：原实现固定查 zibpay_order 表，但 custom_order_id
            // 传入的是父主题 zibpay_ajax_initiate_pay() 用
            // generate_payment_order_num() 生成的【payment 单号】（520 前缀），
            // 实际落在 zibpay_payment 表 —— 查 zibpay_order 永远查不到，
            // 该「已支付则跳过」分支是永不执行的死代码。现按单号类型分别查。
            $paid = false;
            if (ZibPay::is_payment_order($custom_order_id)) {
                $payment = ZibPay::get_payment($custom_order_id);
                if (!empty($payment['id']) && (string) $payment['status'] === '1') {
                    $paid = true;
                }
            } else {
                global $wpdb;
                $already = $wpdb->get_var($wpdb->prepare(
                    "SELECT status FROM {$wpdb->zibpay_order} WHERE order_num = %s",
                    $custom_order_id
                ));
                if ($already === '1') {
                    $paid = true;
                }
            }
            if ($paid) {
                return array('ec' => 200, 'em' => '');
            }

            // ── ★ 金额对账（安全关键，v1.5.16 新增）──────────────────
            // 父主题的金额核对因 should_skip_pay_amount_check() 硬编码 return true
            // 而从不执行，必须在此自行以【站内订单表应收金额】为权威做校验。
            // 差额阈值 0.01 元：容忍 double(10,2) 的浮点表示尾差（如 19.99 存成 19.989999）。
            $local_price = zibll_child_afdian_local_order_price($custom_order_id);
            if ($local_price <= 0) {
                // 站内查不到这笔订单 → 拒绝入账（也可能是伪造的 custom_order_id）
                zibll_child_afdian_log_unmatched($order, 'local_order_not_found');
                return array('ec' => 200, 'em' => '');
            }
            if (abs((float) $total_amount - $local_price) > 0.01) {
                // 用户改了爱发电下单页金额（自选金额模式漏洞）→ 拒绝入账
                zibll_child_afdian_log_unmatched($order, 'amount_mismatch');
                return array('ec' => 200, 'em' => '');
            }

            // 入账：pay_price 一律使用【服务端权威金额】，绝不用 Webhook 回传值，
            // 否则后台对账会显示「已支付 0.01 元」却已发货，掩盖资损痕迹。
            $pay = array(
                'order_num' => $custom_order_id,
                'pay_type'  => 'afdian',
                'pay_price' => $local_price,
                'pay_num'   => isset($order['out_trade_no']) ? $order['out_trade_no'] : '',
            );

            $result = ZibPay::payment_order($pay);
            if (!$result) {
                zibll_child_afdian_log_unmatched($order, 'payment_order_failed');
            }

            return array('ec' => 200, 'em' => '');
        } finally {
            delete_transient($lock_key);
        }
    }
}

// 未匹配订单留痕（避免爱发电反复重试，同时便于站长后台核查）
if (!function_exists('zibll_child_afdian_log_unmatched')) {
    function zibll_child_afdian_log_unmatched($order, $reason)
    {
        $order = is_array($order) ? $order : array();

        // 字段白名单裁剪：爱发电订单报文含收货人姓名/电话/地址等个人信息
        // （address_person / address_phone / address_address）与体积很大的
        // sku_detail。此处只保留对账必需的字段，避免个人信息明文落库
        // （隐私合规），同时大幅压缩单条记录体积。
        $keep = array('out_trade_no', 'custom_order_id', 'plan_id', 'user_id', 'total_amount', 'status');
        $safe = array();
        foreach ($keep as $k) {
            if (isset($order[$k])) {
                $safe[$k] = is_scalar($order[$k]) ? (string) $order[$k] : wp_json_encode($order[$k]);
            }
        }

        $log = get_option('zibll_child_afdian_unmatched', array());
        if (!is_array($log)) {
            $log = array();
        }
        $log[] = array(
            'time'    => current_time('mysql'),
            'reason'  => (string) $reason,
            'ip'      => isset($_SERVER['REMOTE_ADDR']) ? substr((string) $_SERVER['REMOTE_ADDR'], 0, 45) : '',
            'sign'    => isset($_POST['sign']) ? substr((string) $_POST['sign'], 0, 16) : '',
            'order'   => $safe,
        );
        // 最多保留最近 50 条
        if (count($log) > 50) {
            $log = array_slice($log, -50);
        }
        // ⚠️ 第三个参数 false = 不 autoload。此 option 仅供后台排障查看，
        // 若默认 autoload=yes 会被加载进【每一次前台请求】，属无谓性能损耗。
        update_option('zibll_child_afdian_unmatched', $log, false);
    }
}
