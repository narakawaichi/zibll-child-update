<?php
/**
 * 爱发电（Afdian）Webhook 接收入口
 * ─────────────────────────────────────────────────────────────
 * 放置于子主题根目录，公开访问地址即后台展示的「Webhook 接收地址」：
 *   https://<站点域名>/wp-content/themes/zibll-child/afdian-notify.php
 * 需在爱发电开发者后台（https://ifdian.net/dashboard/dev）将「通知地址」
 * 配置为上述地址。
 *
 * 业务逻辑全部在 includes/functions/afdian-pay.php，本文件仅做：
 *   加载 WordPress（从而加载子主题与父主题 ZibPay）→ 调用处理 → 输出 JSON。
 *
 * 爱发电要求：接口必须返回 {"ec":200,"em":""} 才视为成功，否则会重试。
 *
 * @package zibll-child
 * @author  依岸归
 */

header('Content-type: application/json; Charset=utf-8');

// ── 入口最小防护（v1.5.16）─────────────────────────────────
// 本文件是公开可访问的独立入口，任何人 GET/POST 都会触发完整 WP 引导。
// 以下校验放在【加载 WordPress 之前】，保证非法请求不消耗任何服务器资源。
// 真正的身份认证由 afdian-pay.php 的 RSA 验签负责（爱发电未公开稳定推送 IP 段，
// 故不做 IP 白名单，避免误拒）。

// 1) 仅接受 POST：GET 必然不是爱发电推送
if (!isset($_SERVER['REQUEST_METHOD']) || 'POST' !== $_SERVER['REQUEST_METHOD']) {
    header('Allow: POST');
    http_response_code(405);
    echo json_encode(array('ec' => 405, 'em' => 'method not allowed'));
    exit;
}

// 2) 请求体大小上限：爱发电订单报文远小于 64KB，超限直接拒
if (isset($_SERVER['CONTENT_LENGTH']) && (int) $_SERVER['CONTENT_LENGTH'] > 65535) {
    http_response_code(413);
    echo json_encode(array('ec' => 413, 'em' => 'payload too large'));
    exit;
}

// 3) Content-Type 必须是 JSON（爱发电推送为 application/json）
$zibll_child_ct = isset($_SERVER['CONTENT_TYPE']) ? strtolower((string) $_SERVER['CONTENT_TYPE']) : '';
if ($zibll_child_ct !== '' && strpos($zibll_child_ct, 'application/json') === false) {
    http_response_code(415);
    echo json_encode(array('ec' => 415, 'em' => 'unsupported media type'));
    exit;
}

// 加载 WordPress（路径：zibll-child → themes → wp-content → 站点根）
$wp_load = dirname(__FILE__) . '/../../../wp-load.php';
if (!file_exists($wp_load)) {
    // ⚠️ 必须返回失败码而非 ack：此处说明子主题被移动/改名，WordPress 根本没起来，
    //    若回 200 爱发电会认为投递成功并【不再重试】，用户已付的订单将永久无法入账
    //    （直接资损，且无法自愈）。回 500 让对方按其重试策略补投。
    error_log('[zibll-child] afdian-notify: wp-load.php not found at ' . $wp_load);
    http_response_code(500);
    echo json_encode(array('ec' => 500, 'em' => 'wp-load not found'));
    exit;
}

require_once $wp_load;

// 主题函数（含 zibll_child_afdian_handle_webhook）与父主题 ZibPay 均已就绪
if (!function_exists('zibll_child_afdian_handle_webhook')) {
    // ⚠️ 同上：处理函数缺失说明子主题未正确加载，必须让爱发电重试而非 ack
    error_log('[zibll-child] afdian-notify: handler function missing (子主题模块未加载)');
    http_response_code(500);
    echo json_encode(array('ec' => 500, 'em' => 'handler unavailable'));
    exit;
}

$resp = zibll_child_afdian_handle_webhook();
echo json_encode($resp);
exit;
