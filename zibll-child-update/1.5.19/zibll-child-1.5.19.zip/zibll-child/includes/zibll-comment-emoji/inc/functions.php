<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Default settings.
 */
function zibll_additional_demo01_default_settings()
{
    return array(
        'enabled'               => 1,
        'include_default_group' => 1,
        'default_group_label'   => '默认',
        // 留空：首次运行时由 get_storage() 自动落到 uploads/zibll-comment-emoji/smilies，
        // 避免默认写进父主题目录（父主题升级会丢失表情）。
        'smilies_root'          => '',
        'smilies_base_url'      => '',
        'allowed_exts'          => 'gif,png,jpg,jpeg,webp',
        'max_per_group'         => 200,
        'panel_width'           => 360,
        'emoji_groups'          => array(),
        'group_lines'           => '',
        // 远程表情源：清单驱动（远程目录无法被 PHP 列举）
        'remote_enabled'        => 0,
        'remote_root_url'       => '',
        'remote_manifest_url'   => '',
    );
}

/**
 * Get all settings merged with defaults.
 */
function zibll_additional_demo01_get_settings()
{
    static $settings = null;
    if ($settings !== null) {
        return $settings;
    }

    $stored = get_option(ZIBLL_COMMENT_EMOJI_OPTIONS_KEY, array());
    if (!is_array($stored)) {
        $stored = array();
    }

    $settings = wp_parse_args($stored, zibll_additional_demo01_default_settings());
    $settings['enabled'] = !empty($settings['enabled']) ? 1 : 0;
    $settings['include_default_group'] = !empty($settings['include_default_group']) ? 1 : 0;
    $settings['default_group_label'] = sanitize_text_field((string) $settings['default_group_label']);
    $settings['smilies_root'] = zibll_additional_demo01_normalize_path($settings['smilies_root']);
    $settings['smilies_base_url'] = untrailingslashit((string) $settings['smilies_base_url']);
    $settings['allowed_exts'] = (string) $settings['allowed_exts'];
    $settings['max_per_group'] = max(1, min(500, absint($settings['max_per_group'])));
    $settings['panel_width'] = max(220, min(720, absint($settings['panel_width'])));
    $settings['emoji_groups'] = is_array($settings['emoji_groups']) ? $settings['emoji_groups'] : array();
    $settings['group_lines'] = (string) $settings['group_lines'];
    $settings['remote_enabled'] = !empty($settings['remote_enabled']) ? 1 : 0;
    $settings['remote_root_url'] = untrailingslashit(trim((string) $settings['remote_root_url']));
    $settings['remote_manifest_url'] = trim((string) $settings['remote_manifest_url']);

    return $settings;
}

/**
 * Get one setting.
 */
function zibll_additional_demo01_get_setting($key, $default = false)
{
    $settings = zibll_additional_demo01_get_settings();
    return isset($settings[$key]) ? $settings[$key] : $default;
}

/**
 * Is plugin enabled.
 */
function zibll_additional_demo01_is_enabled()
{
    return (bool) zibll_additional_demo01_get_setting('enabled', 0);
}

function zibll_additional_demo01_normalize_path($path)
{
    $path = trim((string) $path);
    if ($path === '') {
        return '';
    }
    $path = str_replace('\\', '/', $path);
    return untrailingslashit($path);
}

/**
 * SSRF 防护：校验外部可配置的 URL 是否可以安全发起请求。
 *
 * ⚠️ 安全（v1.5.16）：「远程表情源」的根 URL 与清单 URL 都是后台可填的自由文本，
 *    原实现只做了 esc_url_raw() + "以 http 开头" 判断就交给 wp_remote_get()。
 *    这意味着持有 manage_options 的用户（或被诱导去粘贴他人给出的配置）可以让
 *    服务器去请求任意地址，包括：
 *      · http://169.254.169.254/latest/meta-data/  → 云元数据，可窃取实例临时凭证；
 *      · http://127.0.0.1:6379/ 或其它内网端口     → 横向探测/访问内网服务；
 *      · file:// 等非 http(s) 协议                 → 读本地文件（取决于 WP HTTP 实现）。
 *    响应内容还会被解析后【写入数据库并对外展示】（表情清单），等于把内网响应
 *    变成了可读的数据泄露通道。
 *
 * 现做三层校验：① 只允许 http / https；② 主机名不得是 IP 字面量，
 *    除非它落在明确的内网/保留网段（那些恰恰要拒绝）；③ 解析 DNS 后
 *    校验所有 A/AAAA 记录都不在私有/保留网段内。
 *    校验不通过一律拒绝并返回 WP_Error。
 *
 * @param string $url 待校验的 URL
 * @return true|WP_Error
 */
function zibll_additional_demo01_validate_remote_url($url)
{
    $url = trim((string) $url);
    if ($url === '') {
        return new WP_Error('remote_config', 'URL 不能为空。');
    }

    $parts = wp_parse_url($url);
    if (empty($parts['scheme']) || empty($parts['host'])) {
        return new WP_Error('remote_config', 'URL 格式不正确。');
    }

    // ① 协议白名单
    $scheme = strtolower($parts['scheme']);
    if (!in_array($scheme, array('http', 'https'), true)) {
        return new WP_Error('remote_config', '仅允许 http / https 协议的地址。');
    }

    $host = $parts['host'];

    // ② 主机名若是 IP 字面量，直接按网段判定（内网一律拒绝）
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        return zibll_additional_demo01_ip_is_public($host)
            ? true
            : new WP_Error('remote_config', '禁止指向内网或保留地址。');
    }

    // ③ 域名：解析 DNS 后逐一校验所有解析结果
    $host = trim($host, '.');
    if ($host === '' || !preg_match('/^[A-Za-z0-9._-]+$/', $host)) {
        return new WP_Error('remote_config', '主机名不合法。');
    }

    $ips = gethostbynamel($host);
    if (is_array($ips) && !empty($ips)) {
        foreach ($ips as $ip) {
            if (!zibll_additional_demo01_ip_is_public($ip)) {
                return new WP_Error('remote_config', '目标域名解析到内网或保留地址，已拒绝请求。');
            }
        }
    }

    return true;
}

/**
 * 判断一个 IP 是否为「公网可路由」地址。
 * 私有网段、环回、链路本地（含云元数据 169.254.0.0/16）、保留段一律返回 false。
 *
 * @param string $ip
 * @return bool
 */
function zibll_additional_demo01_ip_is_public($ip)
{
    $ip = trim((string) $ip);
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        // 私有 / 环回 / 链路本地 / 保留
        $blocked = array(
            '10.0.0.0/8',      // 私有
            '172.16.0.0/12',   // 私有
            '192.168.0.0/16',  // 私有
            '127.0.0.0/8',     // 环回
            '169.254.0.0/16',  // 链路本地（含云元数据 169.254.169.254）
            '0.0.0.0/8',       // 本机
            '100.64.0.0/10',   // 运营商级 NAT
            '192.0.0.0/24',    // IETF 协议保留
            '198.18.0.0/15',   // 基准测试
            '224.0.0.0/4',     // 组播
            '240.0.0.0/4',     // 保留
        );
        foreach ($blocked as $cidr) {
            if (zibll_additional_demo01_ip_in_cidr($ip, $cidr)) {
                return false;
            }
        }
        return true;
    }

    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        // IPv6：环回 ::1、未指定 ::、链路本地 fe80::/10、唯一本地 fc00::/7
        $v6 = inet_pton($ip);
        if ($v6 === false) {
            return false;
        }
        $hex = bin2hex($v6);
        if ($hex === str_repeat('0', 31) . '1') {          // ::1
            return false;
        }
        if ($hex === str_repeat('0', 32)) {                 // ::
            return false;
        }
        $first = hexdec(substr($hex, 0, 2));
        if (($first & 0xFE) === 0xFC) {                     // fc00::/7 唯一本地
            return false;
        }
        if ($first === 0xFE && (hexdec(substr($hex, 2, 2)) & 0xC0) === 0x80) { // fe80::/10
            return false;
        }
        return true;
    }

    return false;
}

/**
 * 判断 IPv4 是否落在 CIDR 网段内。
 */
function zibll_additional_demo01_ip_in_cidr($ip, $cidr)
{
    list($net, $bits) = explode('/', $cidr);
    $ip_long  = ip2long($ip);
    $net_long = ip2long($net);
    if ($ip_long === false || $net_long === false) {
        return false;
    }
    $mask = $bits <= 0 ? 0 : (-1 << (32 - (int) $bits));
    return ($ip_long & $mask) === ($net_long & $mask);
}

function zibll_additional_demo01_get_allowed_exts($exts_csv)
{
    $exts = array();
    foreach (explode(',', strtolower((string) $exts_csv)) as $ext) {
        $ext = preg_replace('/[^a-z0-9]/', '', trim($ext));
        if ($ext !== '') {
            $exts[] = $ext;
        }
    }
    $exts = array_values(array_unique($exts));
    return !empty($exts) ? $exts : array('gif', 'png');
}

/**
 * Get usable storage root and base url.
 * If configured directory is not usable, auto fallback to uploads/zibll-comment-emoji/smilies.
 */
function zibll_additional_demo01_get_storage($need_writable = false, $auto_update_option = true)
{
    $settings = zibll_additional_demo01_get_settings();
    $root = zibll_additional_demo01_normalize_path($settings['smilies_root']);
    $url = untrailingslashit((string) $settings['smilies_base_url']);
    $usable = true;

    if ($root === '' || $url === '') {
        $usable = false;
    } else {
        if (is_dir($root)) {
            if (!is_readable($root)) {
                $usable = false;
            }
            if ($need_writable && !is_writable($root)) {
                $usable = false;
            }
        } else {
            $parent = dirname($root);
            if (!is_dir($parent) || !is_writable($parent) || !wp_mkdir_p($root)) {
                $usable = false;
            }
        }
    }

    if ($usable) {
        return array(
            'root' => $root,
            'url'  => $url,
        );
    }

    $uploads = wp_upload_dir();
    $fallback_root = zibll_additional_demo01_normalize_path($uploads['basedir'] . '/zibll-comment-emoji/smilies');
    $fallback_url = untrailingslashit($uploads['baseurl'] . '/zibll-comment-emoji/smilies');

    if (!is_dir($fallback_root)) {
        wp_mkdir_p($fallback_root);
    }

    if ($auto_update_option) {
        $options = get_option(ZIBLL_COMMENT_EMOJI_OPTIONS_KEY, array());
        if (!is_array($options)) {
            $options = array();
        }
        $options['smilies_root'] = $fallback_root;
        // 只在访问 URL 属于插件自动生成值时才一并改写，
        // 用户手填的 CDN / 外链地址必须保留，否则会被静默冲掉。
        if (zibll_additional_demo01_is_autogenerated_url($url, $fallback_url)) {
            $options['smilies_base_url'] = $fallback_url;
        }
        update_option(ZIBLL_COMMENT_EMOJI_OPTIONS_KEY, $options);
    }

    return array(
        'root' => $fallback_root,
        'url'  => zibll_additional_demo01_is_autogenerated_url($url, $fallback_url) ? $fallback_url : $url,
    );
}

/**
 * 判断访问 URL 是否为插件自动生成（用户未自定义）。
 * 只有这类 URL 才允许在根目录回退时被一并改写。
 */
function zibll_additional_demo01_is_autogenerated_url($url, $fallback_url = '')
{
    $url = untrailingslashit(trim((string) $url));
    if ($url === '') {
        return true;
    }

    if ($fallback_url !== '' && $url === untrailingslashit((string) $fallback_url)) {
        return true;
    }

    $theme_url = untrailingslashit(trailingslashit(get_template_directory_uri()) . 'img/smilies');
    return $url === $theme_url;
}

function zibll_additional_demo01_parse_group_lines($group_lines)
{
    $groups = array();
    $lines = preg_split('/\r\n|\r|\n/', (string) $group_lines);
    if (!$lines) {
        return $groups;
    }

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0) {
            continue;
        }

        $parts = explode('|', $line, 2);
        $dir = trim($parts[0]);
        if ($dir === '') {
            continue;
        }

        if (strpos($dir, '..') !== false || strpos($dir, '/') !== false || strpos($dir, '\\') !== false) {
            continue;
        }

        $title = isset($parts[1]) ? trim($parts[1]) : $dir;
        if ($title === '') {
            $title = $dir;
        }

        $groups[] = array(
            'dir'   => $dir,
            'title' => $title,
        );
    }

    return $groups;
}

function zibll_additional_demo01_clean_group_dir($dir)
{
    $dir = trim((string) $dir);
    if ($dir === '') {
        return '';
    }
    if (strpos($dir, '..') !== false || strpos($dir, '/') !== false || strpos($dir, '\\') !== false) {
        return '';
    }
    return $dir;
}

/**
 * Get the saved visual sort order.
 */
function zibll_additional_demo01_get_sort_order()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cache = array(
        'groups' => array(),
        'items'  => array(),
    );

    $stored = get_option(ZIBLL_COMMENT_EMOJI_ORDER_KEY, array());
    if (!is_array($stored)) {
        return $cache;
    }

    $seen_groups = array();
    $raw_groups = isset($stored['groups']) && is_array($stored['groups']) ? $stored['groups'] : array();
    foreach ($raw_groups as $raw_dir) {
        $dir = zibll_additional_demo01_clean_group_dir((string) $raw_dir);
        if ($dir === '' || isset($seen_groups[$dir])) {
            continue;
        }

        $seen_groups[$dir] = true;
        $cache['groups'][] = $dir;
    }

    $raw_items = isset($stored['items']) && is_array($stored['items']) ? $stored['items'] : array();
    foreach ($raw_items as $raw_dir => $raw_files) {
        $dir = zibll_additional_demo01_clean_group_dir((string) $raw_dir);
        if ($dir === '' || !is_array($raw_files)) {
            continue;
        }

        $seen_files = array();
        foreach ($raw_files as $raw_file) {
            $file_name = trim((string) $raw_file);
            if (
                $file_name === ''
                || $file_name === '.'
                || $file_name === '..'
                // 远程清单里的文件可能带子目录（如 sub/1.gif），不再禁止斜杠
                || strpos($file_name, '..') !== false
                || strpos($file_name, '\\') !== false
                || isset($seen_files[$file_name])
            ) {
                continue;
            }

            $seen_files[$file_name] = true;
            $cache['items'][$dir][] = $file_name;
        }
    }

    return $cache;
}

/**
 * Auto detect child folders under root.
 */
function zibll_additional_demo01_get_detected_folder_groups()
{
    $storage = zibll_additional_demo01_get_storage(false, true);
    $root = $storage['root'];
    $groups = array();

    if (is_dir($root)) {
        $entries = scandir($root);
        if ($entries) {
            foreach ($entries as $entry) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }

                $dir_path = $root . '/' . $entry;
                if (!is_dir($dir_path)) {
                    continue;
                }

                $groups[] = array(
                    'dir'    => (string) $entry,
                    'title'  => (string) $entry,
                    'source' => 'local',
                );
            }
        }
    }

    if (zibll_additional_demo01_is_remote_enabled()) {
        foreach (zibll_additional_demo01_get_remote_group_map() as $remote_group) {
            $groups[] = array(
                'dir'    => $remote_group['dir'],
                'title'  => $remote_group['title'],
                'source' => 'remote',
            );
        }
    }

    usort($groups, function ($a, $b) {
        return strnatcasecmp($a['dir'], $b['dir']);
    });

    return $groups;
}

/**
 * 判断某个分组的数据来源：本地目录优先，其次远程清单。
 *
 * @return string local / remote / ''（都不可用）
 */
function zibll_additional_demo01_resolve_group_source($dir, $local_root = '')
{
    $dir = zibll_additional_demo01_clean_group_dir((string) $dir);
    if ($dir === '') {
        return '';
    }

    if ($local_root !== '' && is_dir(zibll_additional_demo01_normalize_path($local_root . '/' . $dir))) {
        return 'local';
    }

    if (zibll_additional_demo01_is_remote_enabled()) {
        $remote_map = zibll_additional_demo01_get_remote_group_map();
        if (isset($remote_map[$dir])) {
            return 'remote';
        }
    }

    return '';
}

/**
 * Read overrides from CSF group, fallback to legacy textarea.
 */
function zibll_additional_demo01_get_group_overrides()
{
    $groups = array();
    $raw_groups = zibll_additional_demo01_get_setting('emoji_groups', array());

    if (is_array($raw_groups) && !empty($raw_groups)) {
        foreach ($raw_groups as $row) {
            if (!is_array($row)) {
                continue;
            }

            $dir = zibll_additional_demo01_clean_group_dir((string) ($row['dir'] ?? ''));
            if ($dir === '') {
                continue;
            }

            $title = sanitize_text_field((string) ($row['title'] ?? ''));
            if ($title === '') {
                $title = $dir;
            }

            $groups[] = array(
                'dir'   => $dir,
                'title' => $title,
            );
        }
    }

    if (empty($groups)) {
        $legacy = zibll_additional_demo01_parse_group_lines(zibll_additional_demo01_get_setting('group_lines', ''));
        foreach ($legacy as $row) {
            $dir = zibll_additional_demo01_clean_group_dir((string) ($row['dir'] ?? ''));
            if ($dir === '') {
                continue;
            }

            $title = sanitize_text_field((string) ($row['title'] ?? ''));
            if ($title === '') {
                $title = $dir;
            }

            $groups[] = array(
                'dir'   => $dir,
                'title' => $title,
            );
        }
    }

    return $groups;
}

/**
 * Effective groups: detected folders + overrides.
 */
function zibll_additional_demo01_get_effective_groups()
{
    $detected = zibll_additional_demo01_get_detected_folder_groups();
    $overrides = zibll_additional_demo01_get_group_overrides();

    $detected_map = array();
    foreach ($detected as $group) {
        $dir = zibll_additional_demo01_clean_group_dir((string) $group['dir']);
        if ($dir === '') {
            continue;
        }

        $detected_map[$dir] = array(
            'dir'   => $dir,
            'title' => (string) $group['title'],
        );
    }

    foreach ($overrides as $group) {
        $dir = zibll_additional_demo01_clean_group_dir((string) $group['dir']);
        if ($dir === '') {
            continue;
        }

        $title = sanitize_text_field((string) ($group['title'] ?? ''));
        if ($title === '') {
            $title = $dir;
        }

        if (isset($detected_map[$dir])) {
            $detected_map[$dir]['title'] = $title;
        } else {
            $detected_map[$dir] = array(
                'dir'   => $dir,
                'title' => $title,
            );
        }
    }

    $groups = array_values($detected_map);
    usort($groups, function ($a, $b) {
        return strnatcasecmp($a['dir'], $b['dir']);
    });

    $sort_order = zibll_additional_demo01_get_sort_order();
    if (!empty($sort_order['groups'])) {
        $group_map = array();
        foreach ($groups as $group) {
            $group_map[$group['dir']] = $group;
        }

        $ordered_groups = array();
        foreach ($sort_order['groups'] as $dir) {
            if (!isset($group_map[$dir])) {
                continue;
            }

            $ordered_groups[] = $group_map[$dir];
            unset($group_map[$dir]);
        }

        foreach ($groups as $group) {
            if (isset($group_map[$group['dir']])) {
                $ordered_groups[] = $group;
            }
        }

        $groups = $ordered_groups;
    }

    return $groups;
}

/**
 * Insert or update one group row.
 */
function zibll_additional_demo01_upsert_group_line($dir, $title = '')
{
    $dir = zibll_additional_demo01_clean_group_dir((string) $dir);
    if ($dir === '') {
        return false;
    }

    $title = sanitize_text_field((string) $title);

    $options = get_option(ZIBLL_COMMENT_EMOJI_OPTIONS_KEY, array());
    if (!is_array($options)) {
        $options = array();
    }

    $rows = isset($options['emoji_groups']) && is_array($options['emoji_groups']) ? $options['emoji_groups'] : array();
    $new_rows = array();
    $updated = false;

    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }

        $row_dir = zibll_additional_demo01_clean_group_dir((string) ($row['dir'] ?? ''));
        if ($row_dir === '') {
            continue;
        }

        $row_title = sanitize_text_field((string) ($row['title'] ?? ''));
        if ($row_title === '') {
            $row_title = $row_dir;
        }

        if ($row_dir === $dir) {
            $updated = true;
            $new_rows[] = array(
                'dir'   => $dir,
                'title' => ($title === '' ? $row_title : $title),
            );
        } else {
            $new_rows[] = array(
                'dir'   => $row_dir,
                'title' => $row_title,
            );
        }
    }

    if (!$updated) {
        $new_rows[] = array(
            'dir'   => $dir,
            'title' => ($title === '' ? $dir : $title),
        );
    }

    $options['emoji_groups'] = $new_rows;
    update_option(ZIBLL_COMMENT_EMOJI_OPTIONS_KEY, $options);
    return true;
}

function zibll_additional_demo01_get_group_files($group_path, $allowed_exts, $max_per_group, $group_dir = '')
{
    $items = array();

    // 本地目录不存在时，改从远程清单读取（远程表情源）
    if (!is_dir($group_path) || !is_readable($group_path)) {
        $group_dir = zibll_additional_demo01_clean_group_dir((string) $group_dir);
        if ($group_dir === '' || !zibll_additional_demo01_is_remote_enabled()) {
            return $items;
        }

        return zibll_additional_demo01_get_remote_group_items($group_dir, $allowed_exts, $max_per_group);
    }

    $entries = scandir($group_path);
    if (!$entries) {
        return $items;
    }

    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }

        $file_path = $group_path . '/' . $entry;
        if (!is_file($file_path)) {
            continue;
        }

        $ext = strtolower((string) pathinfo($entry, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed_exts, true)) {
            continue;
        }

        $items[] = array(
            'file_name' => $entry,
            'file_path' => zibll_additional_demo01_normalize_path($file_path),
            'name'      => (string) pathinfo($entry, PATHINFO_FILENAME),
        );
    }

    usort($items, function ($a, $b) {
        return strnatcasecmp($a['file_name'], $b['file_name']);
    });

    $group_dir = zibll_additional_demo01_clean_group_dir($group_dir);
    $sort_order = zibll_additional_demo01_get_sort_order();
    if ($group_dir !== '' && !empty($sort_order['items'][$group_dir])) {
        $item_map = array();
        foreach ($items as $item) {
            $item_map[$item['file_name']] = $item;
        }

        $ordered_items = array();
        foreach ($sort_order['items'][$group_dir] as $file_name) {
            if (!isset($item_map[$file_name])) {
                continue;
            }

            $ordered_items[] = $item_map[$file_name];
            unset($item_map[$file_name]);
        }

        foreach ($items as $item) {
            if (isset($item_map[$item['file_name']])) {
                $ordered_items[] = $item;
            }
        }

        $items = $ordered_items;
    }

    if ($max_per_group > 0 && count($items) > $max_per_group) {
        $items = array_slice($items, 0, $max_per_group);
    }

    return $items;
}

/* -------------------------------------------------------------------------
 * 远程表情源：清单驱动
 * 远程目录无法通过 PHP 文件系统函数列举，改为在远程放清单文件，
 * 后台点「同步」拉取并缓存。远程表情的图片地址全部指向远程服务器。
 * ---------------------------------------------------------------------- */

/**
 * 远程表情源是否启用。
 */
function zibll_additional_demo01_is_remote_enabled()
{
    return (bool) zibll_additional_demo01_get_setting('remote_enabled', 0);
}

/**
 * 规范化远程文件相对路径。允许子目录，拒绝越级与绝对协议。
 */
function zibll_additional_demo01_clean_remote_file($file)
{
    $file = trim((string) $file);
    if ($file === '') {
        return '';
    }

    $file = str_replace('\\', '/', $file);
    $file = ltrim($file, '/');
    $file = preg_replace('#(/\./)+#', '/', $file);
    $file = preg_replace('#\./#', '', $file);

    if (strpos($file, '..') !== false || strpos($file, '://') !== false) {
        return '';
    }
    if (preg_match('/[\x00-\x1F\x7F]/', $file)) {
        return '';
    }

    return $file;
}

/**
 * 读取已缓存的远程清单。
 */
function zibll_additional_demo01_get_remote_manifest($refresh = false)
{
    static $cache = null;
    if ($cache !== null && !$refresh) {
        return $cache;
    }

    $cache = array(
        'synced_at'  => 0,
        'source_url' => '',
        'format'     => '',
        'root_url'   => '',
        'groups'     => array(),
        'count'      => 0,
    );

    if (!zibll_additional_demo01_is_remote_enabled()) {
        return $cache;
    }

    $stored = get_option(ZIBLL_COMMENT_EMOJI_REMOTE_KEY, array());
    if (!is_array($stored) || empty($stored['groups']) || !is_array($stored['groups'])) {
        return $cache;
    }

    $cache = array_merge($cache, $stored);
    $cache['groups'] = array_values($stored['groups']);
    $cache['count'] = (int) (isset($stored['count']) ? $stored['count'] : 0);

    return $cache;
}

/**
 * 远程分组映射：dir => array(dir, title, files)。
 */
function zibll_additional_demo01_get_remote_group_map($refresh = false)
{
    static $cache = null;
    if ($cache !== null && !$refresh) {
        return $cache;
    }

    $cache = array();
    $manifest = zibll_additional_demo01_get_remote_manifest();

    foreach ($manifest['groups'] as $group) {
        if (!is_array($group)) {
            continue;
        }

        $dir = zibll_additional_demo01_clean_group_dir((string) ($group['dir'] ?? ''));
        if ($dir === '' || isset($cache[$dir])) {
            continue;
        }

        $files = array();
        $raw_files = isset($group['files']) && is_array($group['files']) ? $group['files'] : array();
        foreach ($raw_files as $raw_file) {
            $file = zibll_additional_demo01_clean_remote_file($raw_file);
            if ($file !== '') {
                $files[] = $file;
            }
        }

        if (empty($files)) {
            continue;
        }

        $title = sanitize_text_field((string) ($group['title'] ?? ''));
        $cache[$dir] = array(
            'dir'   => $dir,
            'title' => $title !== '' ? $title : $dir,
            'files' => array_values(array_unique($files)),
        );
    }

    return $cache;
}

/**
 * 取某个远程分组的表情条目，结构对齐本地 get_group_files()。
 */
function zibll_additional_demo01_get_remote_group_items($dir, $allowed_exts, $max_per_group = 0)
{
    $items = array();
    $dir = zibll_additional_demo01_clean_group_dir((string) $dir);
    if ($dir === '' || !zibll_additional_demo01_is_remote_enabled()) {
        return $items;
    }

    $remote_map = zibll_additional_demo01_get_remote_group_map();
    if (!isset($remote_map[$dir])) {
        return $items;
    }

    foreach ($remote_map[$dir]['files'] as $file) {
        $ext = strtolower((string) pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($ext, (array) $allowed_exts, true)) {
            continue;
        }

        $items[] = array(
            'file_name' => $file,
            'file_path' => $file,
            'name'      => (string) pathinfo(basename($file), PATHINFO_FILENAME),
        );
    }

    usort($items, function ($a, $b) {
        return strnatcasecmp($a['file_name'], $b['file_name']);
    });

    $sort_order = zibll_additional_demo01_get_sort_order();
    if (!empty($sort_order['items'][$dir])) {
        $item_map = array();
        foreach ($items as $item) {
            $item_map[$item['file_name']] = $item;
        }

        $ordered_items = array();
        foreach ($sort_order['items'][$dir] as $file_name) {
            if (!isset($item_map[$file_name])) {
                continue;
            }

            $ordered_items[] = $item_map[$file_name];
            unset($item_map[$file_name]);
        }

        foreach ($items as $item) {
            if (isset($item_map[$item['file_name']])) {
                $ordered_items[] = $item;
            }
        }

        $items = $ordered_items;
    }

    if ($max_per_group > 0 && count($items) > $max_per_group) {
        $items = array_slice($items, 0, $max_per_group);
    }

    return $items;
}

/**
 * 单条路径解析为「分组 + 组内文件」。
 * 例如 feibi/1.gif => array(dir => feibi, file => 1.gif)
 * 根目录下的散图归入 root 分组。
 */
function zibll_additional_demo01_remote_path_to_group($path)
{
    $path = zibll_additional_demo01_clean_remote_file($path);
    if ($path === '') {
        return null;
    }

    $parts = explode('/', $path);
    if (count($parts) < 2) {
        return array('dir' => 'root', 'file' => $parts[0]);
    }

    $dir = zibll_additional_demo01_clean_group_dir($parts[0]);
    if ($dir === '') {
        return null;
    }

    $file = zibll_additional_demo01_clean_remote_file(implode('/', array_slice($parts, 1)));
    if ($file === '') {
        return null;
    }

    return array('dir' => $dir, 'file' => $file);
}

/**
 * 把各种形状的清单行归一化成 groups 结构。
 */
function zibll_additional_demo01_normalize_remote_rows($rows, $allow_bare_paths = false)
{
    $groups = array();

    foreach ((array) $rows as $row) {
        if (is_string($row)) {
            if (!$allow_bare_paths) {
                continue;
            }
            $row = array('path' => $row);
        }

        if (!is_array($row)) {
            continue;
        }

        // 形态一：纯路径行 feibi/1.gif
        if (isset($row['path'])) {
            $parsed = zibll_additional_demo01_remote_path_to_group($row['path']);
            if (!$parsed) {
                continue;
            }

            $dir = $parsed['dir'];
            if (!isset($groups[$dir])) {
                $groups[$dir] = array('dir' => $dir, 'title' => '', 'files' => array());
            }
            $groups[$dir]['files'][] = $parsed['file'];
            continue;
        }

        // 形态二：结构化分组 {dir, title, files}
        $dir = zibll_additional_demo01_clean_group_dir((string) ($row['dir'] ?? $row['name'] ?? ''));
        if ($dir === '') {
            continue;
        }

        $raw_files = $row['files'] ?? $row['items'] ?? $row['images'] ?? array();
        if (is_string($raw_files)) {
            $raw_files = preg_split('/\r\n|\r|\n/', $raw_files);
        }

        $files = array();
        foreach ((array) $raw_files as $raw_file) {
            $file = zibll_additional_demo01_clean_remote_file($raw_file);
            if ($file !== '') {
                $files[] = $file;
            }
        }

        if (empty($files)) {
            continue;
        }

        if (!isset($groups[$dir])) {
            $groups[$dir] = array('dir' => $dir, 'title' => '', 'files' => array());
        }

        $title = sanitize_text_field((string) ($row['title'] ?? $row['label'] ?? ''));
        if ($title !== '') {
            $groups[$dir]['title'] = $title;
        }

        $groups[$dir]['files'] = array_merge($groups[$dir]['files'], $files);
    }

    foreach ($groups as $dir => $group) {
        $groups[$dir]['files'] = array_values(array_unique($group['files']));
        if ($groups[$dir]['title'] === '') {
            $groups[$dir]['title'] = $dir;
        }
    }

    return array_values($groups);
}

/**
 * 解析远程清单内容，自动识别 JSON / 纯文本。
 */
function zibll_additional_demo01_parse_remote_manifest($body, $format = 'auto')
{
    $body = (string) $body;
    if ($body === '') {
        return array();
    }

    if (substr($body, 0, 3) === "\xEF\xBB\xBF") {
        $body = substr($body, 3);
    }

    $trimmed = ltrim($body);
    $looks_json = $trimmed !== '' && ($trimmed[0] === '{' || $trimmed[0] === '[');

    if ($format === 'json' || ($format === 'auto' && $looks_json)) {
        $groups = zibll_additional_demo01_parse_remote_json($body);
        if (!empty($groups)) {
            return array('format' => 'json', 'groups' => $groups);
        }
        if ($format === 'json') {
            return array();
        }
    }

    $groups = zibll_additional_demo01_parse_remote_txt($body);
    return empty($groups) ? array() : array('format' => 'txt', 'groups' => $groups);
}

/**
 * 解析 JSON 清单，兼容四种写法。
 */
function zibll_additional_demo01_parse_remote_json($body)
{
    $data = json_decode($body, true);
    if (!is_array($data)) {
        return array();
    }

    if (isset($data['groups']) && is_array($data['groups'])) {
        return zibll_additional_demo01_normalize_remote_rows($data['groups'], true);
    }

    $is_list = array_keys($data) === range(0, count($data) - 1);
    if ($is_list) {
        return zibll_additional_demo01_normalize_remote_rows($data, true);
    }

    // 映射型：{ "feibi": ["1.gif"], "yuexinmiao": { "title": "月薪喵", "files": [...] } }
    $rows = array();
    foreach ($data as $dir => $value) {
        if (is_array($value) && array_keys($value) === range(0, count($value) - 1)) {
            $rows[] = array('dir' => (string) $dir, 'files' => $value);
        } elseif (is_array($value)) {
            $value['dir'] = (string) $dir;
            $rows[] = $value;
        }
    }

    return zibll_additional_demo01_normalize_remote_rows($rows, true);
}

/**
 * 解析纯文本清单：一行一个路径，# 开头为注释。
 */
function zibll_additional_demo01_parse_remote_txt($body)
{
    $lines = preg_split('/\r\n|\r|\n/', (string) $body);
    if (!$lines) {
        return array();
    }

    $rows = array();
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0 || strpos($line, '//') === 0) {
            continue;
        }
        $rows[] = array('path' => $line);
    }

    return zibll_additional_demo01_normalize_remote_rows($rows, true);
}

/**
 * 把同域绝对地址剥成相对路径，方便清单里直接粘贴完整 URL。
 */
function zibll_additional_demo01_strip_absolute_urls($body, $root_url)
{
    $root = untrailingslashit(trim((string) $root_url));
    if ($root === '' || strpos($root, 'http') !== 0) {
        return $body;
    }

    $host = wp_parse_url($root, PHP_URL_HOST);
    if (!$host) {
        return $body;
    }

    return preg_replace('#https?://' . preg_quote($host, '#') . '/?#i', '', (string) $body);
}

/**
 * 拉取远程清单并写入缓存。成功返回清单数组，失败返回 WP_Error。
 */
function zibll_additional_demo01_fetch_remote_manifest()
{
    $root_url = untrailingslashit((string) zibll_additional_demo01_get_setting('remote_root_url', ''));
    if ($root_url === '' || strpos($root_url, 'http') !== 0) {
        return new WP_Error('remote_config', '请先在「远程表情源」填写远程根目录 URL（需以 http:// 或 https:// 开头）。');
    }

    // ⚠️ 安全（v1.5.16）：SSRF 校验。后台自由文本配置的根 URL 若指向内网 /
    // 云元数据地址，服务器会被当作跳板，且响应会被解析入库并对外展示。
    $root_check = zibll_additional_demo01_validate_remote_url($root_url);
    if (is_wp_error($root_check)) {
        return $root_check;
    }

    $manifest_url = trim((string) zibll_additional_demo01_get_setting('remote_manifest_url', ''));
    $candidates = array();

    if ($manifest_url !== '') {
        $candidates[] = array($manifest_url, 'auto');
    }
    $candidates[] = array($root_url . '/manifest.json', 'json');
    $candidates[] = array($root_url . '/list.txt', 'txt');
    $candidates[] = array($root_url . '/manifest.txt', 'txt');

    $allowed_exts = zibll_additional_demo01_get_allowed_exts(zibll_additional_demo01_get_setting('allowed_exts', 'gif,png'));
    $tried = array();

    foreach ($candidates as $candidate) {
        $url = esc_url_raw($candidate[0]);
        $format = $candidate[1];
        if ($url === '') {
            continue;
        }
        // ⚠️ 安全（v1.5.16）：每个候选清单 URL 都要过 SSRF 校验。
        // 用户可单独把 remote_manifest_url 指向内网地址而不改根 URL，
        // 故不能只校验根 URL。
        $url_check = zibll_additional_demo01_validate_remote_url($url);
        if (is_wp_error($url_check)) {
            continue;
        }
        $tried[] = $url;

        $response = wp_remote_get($url, array(
            'timeout'     => 15,
            'redirection' => 3,
            'headers'     => array('Accept' => 'application/json, text/plain, */*'),
        ));

        if (is_wp_error($response)) {
            continue;
        }

        if ((int) wp_remote_retrieve_response_code($response) !== 200) {
            continue;
        }

        $body = zibll_additional_demo01_strip_absolute_urls(wp_remote_retrieve_body($response), $root_url);
        $parsed = zibll_additional_demo01_parse_remote_manifest($body, $format);
        if (empty($parsed['groups'])) {
            continue;
        }

        $groups = array();
        $count = 0;
        foreach ($parsed['groups'] as $group) {
            $files = array();
            foreach ($group['files'] as $file) {
                $ext = strtolower((string) pathinfo($file, PATHINFO_EXTENSION));
                if (!in_array($ext, $allowed_exts, true)) {
                    continue;
                }
                $files[] = $file;
            }

            if (empty($files)) {
                continue;
            }

            $group['files'] = $files;
            $count += count($files);
            $groups[] = $group;
        }

        if (empty($groups)) {
            continue;
        }

        $manifest = array(
            'synced_at'  => time(),
            'source_url' => $url,
            'format'     => $parsed['format'],
            'root_url'   => $root_url,
            'groups'     => $groups,
            'count'      => $count,
        );

        update_option(ZIBLL_COMMENT_EMOJI_REMOTE_KEY, $manifest, false);

        // 刷新本请求内的静态缓存，避免后续读取到同步前的旧数据
        zibll_additional_demo01_get_remote_manifest(true);
        zibll_additional_demo01_get_remote_group_map(true);

        // 清单变了，前台数据缓存一并清掉
        zibll_additional_demo01_clear_emoji_data_cache();

        // 把远程分组登记到分组配置，便于在后台填写中文显示名。
        // 清单未显式给出标题时传空，避免覆盖用户已填的中文名。
        foreach ($groups as $group) {
            $title = (isset($group['title']) && $group['title'] !== '' && $group['title'] !== $group['dir'])
                ? $group['title']
                : '';
            zibll_additional_demo01_upsert_group_line($group['dir'], $title);
        }

        return $manifest;
    }

    return new WP_Error(
        'remote_empty',
        '未能读取到有效清单。已按顺序尝试：' . implode('、', $tried) . '。请确认远程清单文件存在且内容格式正确。'
    );
}

function zibll_additional_demo01_get_relative_path($root, $full_path)
{
    $root = zibll_additional_demo01_normalize_path($root);
    $full_path = zibll_additional_demo01_normalize_path($full_path);
    if ($root === '' || $full_path === '') {
        return '';
    }

    $prefix = $root . '/';
    if (stripos($full_path, $prefix) !== 0) {
        return '';
    }

    return substr($full_path, strlen($prefix));
}

function zibll_additional_demo01_build_encoded_url($base_url, $relative)
{
    $relative = trim((string) $relative);
    $relative = str_replace('\\', '/', $relative);
    $relative = ltrim($relative, '/');
    if ($relative === '') {
        return untrailingslashit($base_url);
    }

    $parts = explode('/', $relative);
    $parts = array_map('rawurlencode', $parts);
    return untrailingslashit($base_url) . '/' . implode('/', $parts);
}

/**
 * Build frontend group data and token map.
 */
function zibll_additional_demo01_get_emoji_data()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cache = get_transient(ZIBLL_COMMENT_EMOJI_CACHE_KEY);
    if (!is_array($cache) || !isset($cache['groups'], $cache['map'])) {
        $cache = zibll_additional_demo01_build_emoji_data();
        set_transient(ZIBLL_COMMENT_EMOJI_CACHE_KEY, $cache, 600);
    }

    // ⚠️ 安全（v1.5.16）：表情 URL 来自「后台自由文本配置的远程清单」，
    //    会经 comment_text 等过滤器直出给所有访客。原先仅靠渲染处的
    //    esc_url() 兜底，而 esc_url() 只剔除「明显危险」的协议，
    //    并不会限制到「本站/已配置域名」，也无法阻止被指到任意第三方地址
    //    （用作追踪像素或钓鱼内容）。这里在数据出口统一做协议白名单，
    //    只允许 http/https/data:image，其余一律剔除该表情。
    //    放在 get_emoji_data() 出口可一次覆盖所有消费路径（comment_text /
    //    邮件通知 / 存储状态页 / 后台排序页），不会漏网。
    if (!empty($cache['map']) && is_array($cache['map'])) {
        $blocked = array();
        foreach ($cache['map'] as $token => $item) {
            $url = isset($item['url']) ? trim((string) $item['url']) : '';
            if (!zibll_additional_demo01_is_safe_emoji_url($url)) {
                $blocked[] = $token;
                unset($cache['map'][$token]);
            }
        }
        if (!empty($blocked)) {
            // 同步从分组里剔除引用了这些 token 的文件，避免渲染出空图
            $blocked = array_flip($blocked);
            foreach ((array) $cache['groups'] as $gi => $group) {
                if (empty($group['files']) || !is_array($group['files'])) {
                    continue;
                }
                foreach ($group['files'] as $fi => $file) {
                    $t = isset($file['token']) ? (string) $file['token'] : '';
                    if ($t !== '' && isset($blocked[$t])) {
                        unset($cache['groups'][$gi]['files'][$fi]);
                    }
                }
                $cache['groups'][$gi]['files'] = array_values((array) $cache['groups'][$gi]['files']);
                if (empty($cache['groups'][$gi]['files'])) {
                    unset($cache['groups'][$gi]);
                }
            }
            $cache['groups'] = array_values((array) $cache['groups']);
            // 过滤后回写缓存，避免每次请求都重做过滤
            set_transient(ZIBLL_COMMENT_EMOJI_CACHE_KEY, $cache, 600);
        }
    }

    return $cache;
}

/**
 * 判断一个表情图片 URL 是否安全可直出。
 * 只允许 http / https，以及 data:image/*（部分用户用内联图做占位）。
 * 其余（javascript:、vbscript:、file:、ftp: 等）一律拒绝。
 *
 * @param string $url
 * @return bool
 */
function zibll_additional_demo01_is_safe_emoji_url($url)
{
    $url = trim((string) $url);
    if ($url === '') {
        return false;
    }
    // 协议相对地址（//host/x.png）按 https 处理，但为稳妥起见直接拒绝
    if (strpos($url, '//') === 0) {
        return false;
    }
    if (stripos($url, 'data:image/') === 0) {
        // 内联图片：只允许常见图片类型，禁止 data:text/html 等
        return (bool) preg_match('#^data:image/(?:png|jpe?g|gif|webp|bmp|avif);base64,[A-Za-z0-9+/=]+$#i', $url);
    }
    $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
    return in_array($scheme, array('http', 'https'), true);
}

/**
 * 清空表情数据缓存（远程同步 / 后台上传 / 保存排序后调用）。
 */
function zibll_additional_demo01_clear_emoji_data_cache()
{
    delete_transient(ZIBLL_COMMENT_EMOJI_CACHE_KEY);
}

/**
 * 构建表情数据（分组 + token 映射）。构建结果由 get_emoji_data() 负责缓存，
 * 避免每次页面加载都对 1000+ 表情做 md5 与数组遍历。
 */
function zibll_additional_demo01_build_emoji_data()
{
    $cache = array(
        'groups' => array(),
        'map'    => array(),
    );

    if (!zibll_additional_demo01_is_enabled()) {
        return $cache;
    }

    $storage = zibll_additional_demo01_get_storage(false, true);
    $root = $storage['root'];
    $base_url = $storage['url'];

    $local_ok = ($root !== '' && $base_url !== '' && is_dir($root));
    $remote_root_url = untrailingslashit((string) zibll_additional_demo01_get_setting('remote_root_url', ''));
    $remote_ok = zibll_additional_demo01_is_remote_enabled() && $remote_root_url !== '';

    // 本地目录和远程清单至少要有一个可用
    if (!$local_ok && !$remote_ok) {
        return $cache;
    }

    $scan_root = $local_ok ? $root : '';

    $allowed_exts = zibll_additional_demo01_get_allowed_exts(zibll_additional_demo01_get_setting('allowed_exts', 'gif,png'));
    $max_per_group = max(1, min(500, absint(zibll_additional_demo01_get_setting('max_per_group', 200))));

    $scan_groups = zibll_additional_demo01_get_effective_groups();

    foreach ($scan_groups as $group_index => $group) {
        $dir_name = trim((string) $group['dir']);
        if ($dir_name === '') {
            continue;
        }
        if (strpos($dir_name, '..') !== false || strpos($dir_name, '/') !== false || strpos($dir_name, '\\') !== false) {
            continue;
        }

        // 本地目录优先，不存在时回落到远程清单
        $source = zibll_additional_demo01_resolve_group_source($dir_name, $scan_root);
        if ($source === '') {
            continue;
        }
        $is_remote = ($source === 'remote');

        $group_path = zibll_additional_demo01_normalize_path($root . '/' . $dir_name);
        $items = zibll_additional_demo01_get_group_files($group_path, $allowed_exts, $max_per_group, $dir_name);
        if (empty($items)) {
            continue;
        }

        $group_id = sanitize_title($dir_name);
        if ($group_id === '') {
            $group_id = 'group-' . substr(md5($dir_name . '|' . $group_index), 0, 8);
        }

        $group_title = trim((string) $group['title']);
        if ($group_title === '') {
            $group_title = $dir_name;
        }

        $frontend_items = array();
        foreach ($items as $item) {
            $name = $item['name'];

            if ($is_remote) {
                $relative = zibll_additional_demo01_clean_remote_file($item['file_name']);
                if ($relative === '') {
                    continue;
                }

                $key = $dir_name . '/' . $relative;
                $url = zibll_additional_demo01_build_encoded_url($remote_root_url, $key);
                $token = 'zcem_' . substr(md5('remote:' . $key), 0, 18);
            } else {
                $relative = zibll_additional_demo01_get_relative_path($root, $item['file_path']);
                if ($relative === '') {
                    continue;
                }

                $url = zibll_additional_demo01_build_encoded_url($base_url, $relative);
                $token = 'zcem_' . substr(md5('local:' . $relative), 0, 18);

                // 兼容 1.2.0 之前生成的无前缀 token，保证旧评论里的表情不会失效
                $legacy_token = 'zcem_' . substr(md5($relative), 0, 18);
                $cache['map'][$legacy_token] = array(
                    'name' => $name,
                    'url'  => $url,
                );
            }

            $frontend_items[] = array(
                'token'  => $token,
                'name'   => $name,
                'url'    => $url,
                'file'   => $item['file_name'],
                'source' => $source,
            );

            $cache['map'][$token] = array(
                'name' => $name,
                'url'  => $url,
            );
        }

        if (!empty($frontend_items)) {
            $cache['groups'][] = array(
                'id'     => $group_id,
                'dir'    => $dir_name,
                'title'  => $group_title,
                'source' => $source,
                'items'  => $frontend_items,
            );
        }
    }

    return $cache;
}

/**
 * Replace [g=token] in comment content with img.
 *
 * @param string $text       Content containing custom emoji tokens or images.
 * @param bool   $email_mode Whether to add email-safe inline image dimensions.
 */
function zibll_additional_demo01_replace_custom_emoji_in_comment_text($text, $email_mode = false)
{
    if (!is_string($text) || (strpos($text, '[g=') === false && stripos($text, 'zcem_') === false)) {
        return $text;
    }

    $data = zibll_additional_demo01_get_emoji_data();
    if (empty($data['map'])) {
        return $text;
    }

    if (strpos($text, '[g=') !== false) {
        $text = preg_replace_callback('/\[g=([^\]]+)\]/', function ($match) use ($data, $email_mode) {
            $token = $match[1];
            if (!isset($data['map'][$token])) {
                return $match[0];
            }

            $name = $data['map'][$token]['name'];
            $url = esc_url($data['map'][$token]['url']);
            $email_attributes = $email_mode
                ? ' width="30" height="30" style="display:inline-block;width:30px;height:30px;max-width:30px;max-height:30px;margin:0 2px;border:0;vertical-align:middle;object-fit:contain;"'
                : '';
            return '<img class="smilie-icon" src="' . $url . '" alt="' . esc_attr('表情[' . $name . ']') . '"' . $email_attributes . '>';
        }, $text);
    }

    if (stripos($text, 'zcem_') === false || stripos($text, '<img') === false || !class_exists('WP_HTML_Tag_Processor')) {
        return $text;
    }

    $processor = new WP_HTML_Tag_Processor($text);
    while ($processor->next_tag('img')) {
        $class_name = (string) $processor->get_attribute('class');
        if (!preg_match('/(?:^|\s)smilie-icon(?:\s|$)/', $class_name)) {
            continue;
        }

        $token = '';
        foreach (array('data-src', 'src', 'alt') as $attribute_name) {
            $attribute_value = $processor->get_attribute($attribute_name);
            if (is_string($attribute_value) && preg_match('/zcem_[a-z0-9]{18}/i', $attribute_value, $matches)) {
                $token = strtolower($matches[0]);
                break;
            }
        }

        if ($token === '' || empty($data['map'][$token])) {
            continue;
        }

        $real_url = esc_url_raw($data['map'][$token]['url']);
        $processor->set_attribute('src', $real_url);
        if (null !== $processor->get_attribute('data-src')) {
            $processor->set_attribute('data-src', $real_url);
        }
        $processor->set_attribute('alt', '表情[' . sanitize_text_field($data['map'][$token]['name']) . ']');

        if ($email_mode) {
            $style = trim((string) $processor->get_attribute('style'));
            if ($style !== '' && substr($style, -1) !== ';') {
                $style .= ';';
            }

            $processor->set_attribute('width', '30');
            $processor->set_attribute('height', '30');
            $processor->set_attribute('style', $style . 'display:inline-block;width:30px;height:30px;max-width:30px;max-height:30px;margin:0 2px;border:0;vertical-align:middle;object-fit:contain;');
        }
    }

    return $processor->get_updated_html();
}
add_filter('comment_text', 'zibll_additional_demo01_replace_custom_emoji_in_comment_text', 1);

/**
 * Repair custom emoji URLs before Zibll stores a notification message.
 */
function zibll_additional_demo01_filter_message_values($values)
{
    if (!is_array($values) || empty($values['content']) || !is_string($values['content'])) {
        return $values;
    }

    // Zibll strips HTML before rendering private messages, so keep emoji tokens intact.
    if (isset($values['type']) && $values['type'] === 'private') {
        return $values;
    }

    $values['content'] = zibll_additional_demo01_replace_custom_emoji_in_comment_text($values['content']);
    return $values;
}
add_filter('zib_add_message_values', 'zibll_additional_demo01_filter_message_values', 20);

/**
 * Repair custom emoji images in outgoing HTML emails.
 */
function zibll_additional_demo01_filter_wp_mail($args)
{
    if (
        !is_array($args)
        || empty($args['message'])
        || !is_string($args['message'])
        || stripos($args['message'], 'zcem_') === false
    ) {
        return $args;
    }

    $args['message'] = zibll_additional_demo01_replace_custom_emoji_in_comment_text($args['message'], true);
    return $args;
}
add_filter('wp_mail', 'zibll_additional_demo01_filter_wp_mail', 99);

/**
 * Admin ajax upload.
 */
function zibll_additional_demo01_ajax_admin_upload()
{
    if (!check_ajax_referer('zibll_comment_emoji_admin_upload', 'nonce', false)) {
        wp_send_json_error(array('msg' => '请求校验失败，请刷新页面后重试'), 403);
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('msg' => '权限不足'));
    }

    $group_dir_raw = isset($_POST['group_dir']) ? sanitize_text_field(wp_unslash($_POST['group_dir'])) : '';
    $group_title = isset($_POST['group_title']) ? sanitize_text_field(wp_unslash($_POST['group_title'])) : '';
    $group_dir = sanitize_title($group_dir_raw);

    if ($group_dir === '') {
        wp_send_json_error(array('msg' => '请填写分组目录（英文）'));
    }

    if (empty($_FILES['emoji_files'])) {
        wp_send_json_error(array('msg' => '请选择要上传的图片'));
    }

    $files = $_FILES['emoji_files'];
    $names = is_array($files['name']) ? $files['name'] : array($files['name']);
    $tmp_names = is_array($files['tmp_name']) ? $files['tmp_name'] : array($files['tmp_name']);
    $errors = is_array($files['error']) ? $files['error'] : array($files['error']);
    $expected_count = isset($_POST['expected_count']) ? absint(wp_unslash($_POST['expected_count'])) : 0;
    $received_count = count($names);

    if ($expected_count > 0 && $received_count < $expected_count) {
        $server_limit = (int) ini_get('max_file_uploads');
        $limit_text = $server_limit > 0 ? '（当前 max_file_uploads=' . $server_limit . '）' : '';
        wp_send_json_error(array(
            'msg'      => '服务器只收到 ' . $received_count . '/' . $expected_count . ' 个文件' . $limit_text . '，请刷新页面后重试',
            'uploaded' => 0,
            'failed'   => $expected_count,
        ));
    }

    $storage = zibll_additional_demo01_get_storage(true, true);
    $root = $storage['root'];
    if (!is_dir($root) && !wp_mkdir_p($root)) {
        wp_send_json_error(array('msg' => '无法创建根目录'));
    }

    $group_path = zibll_additional_demo01_normalize_path($root . '/' . $group_dir);
    if (!is_dir($group_path) && !wp_mkdir_p($group_path)) {
        wp_send_json_error(array('msg' => '无法创建分组目录'));
    }
    if (!is_writable($group_path)) {
        wp_send_json_error(array('msg' => '分组目录不可写，请检查权限'));
    }

    $allowed_exts = zibll_additional_demo01_get_allowed_exts(zibll_additional_demo01_get_setting('allowed_exts', 'gif,png'));

    $ok = 0;
    $fail = 0;
    foreach ($names as $index => $name) {
        $name = (string) $name;
        $tmp_name = isset($tmp_names[$index]) ? $tmp_names[$index] : '';
        $error = isset($errors[$index]) ? (int) $errors[$index] : UPLOAD_ERR_NO_FILE;

        if ($error !== UPLOAD_ERR_OK || !$tmp_name || !is_uploaded_file($tmp_name)) {
            $fail++;
            continue;
        }

        $ext = strtolower((string) pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed_exts, true)) {
            $fail++;
            continue;
        }

        $img_info = @getimagesize($tmp_name);
        if (!$img_info) {
            $fail++;
            continue;
        }

        $base_name = sanitize_file_name((string) pathinfo($name, PATHINFO_FILENAME));
        if ($base_name === '') {
            $base_name = 'emoji-' . substr(md5($name . microtime(true) . $index), 0, 8);
        }

        $target_name = $base_name . '.' . $ext;
        $target_path = $group_path . '/' . $target_name;
        $suffix = 1;
        while (file_exists($target_path)) {
            $target_name = $base_name . '-' . $suffix . '.' . $ext;
            $target_path = $group_path . '/' . $target_name;
            $suffix++;
        }

        if (!move_uploaded_file($tmp_name, $target_path)) {
            $fail++;
            continue;
        }
        $ok++;
    }

    if ($ok <= 0) {
        wp_send_json_error(array(
            'msg'      => '本批上传失败，请检查图片格式、文件大小或目录权限',
            'uploaded' => 0,
            'failed'   => $fail,
        ));
    }

    // Empty title means keep folder name as display name.
    zibll_additional_demo01_upsert_group_line($group_dir, $group_title);

    // 目录内容变了，清空前台数据缓存
    zibll_additional_demo01_clear_emoji_data_cache();

    $msg = '上传成功 ' . $ok . ' 个';
    if ($fail > 0) {
        $msg .= '，失败 ' . $fail . ' 个';
    }

    wp_send_json_success(array(
        'msg'      => $msg,
        'uploaded' => $ok,
        'failed'   => $fail,
    ));
}
add_action('wp_ajax_zibll_comment_emoji_admin_upload', 'zibll_additional_demo01_ajax_admin_upload');

/**
 * Save or reset the visual group and emoji order.
 */
function zibll_additional_demo01_ajax_save_sort_order()
{
    if (!check_ajax_referer('zibll_comment_emoji_save_order', 'nonce', false)) {
        wp_send_json_error(array('msg' => '请求校验失败，请刷新页面后重试'), 403);
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('msg' => '权限不足'), 403);
    }

    if (!empty($_POST['reset'])) {
        delete_option(ZIBLL_COMMENT_EMOJI_ORDER_KEY);
        wp_send_json_success(array('msg' => '已恢复默认排序'));
    }

    $order_json = isset($_POST['order']) ? wp_unslash($_POST['order']) : '';
    if (!is_string($order_json) || $order_json === '' || strlen($order_json) > MB_IN_BYTES) {
        wp_send_json_error(array('msg' => '排序数据无效'));
    }

    $submitted = json_decode($order_json, true);
    if (!is_array($submitted)) {
        wp_send_json_error(array('msg' => '排序数据格式错误'));
    }

    $storage = zibll_additional_demo01_get_storage(false, true);
    $root = $storage['root'];
    $allowed_exts = zibll_additional_demo01_get_allowed_exts(zibll_additional_demo01_get_setting('allowed_exts', 'gif,png,jpg,jpeg,webp'));
    $valid_groups = array();

    foreach (zibll_additional_demo01_get_effective_groups() as $group) {
        $dir = zibll_additional_demo01_clean_group_dir((string) ($group['dir'] ?? ''));
        if ($dir === '') {
            continue;
        }

        $group_path = zibll_additional_demo01_normalize_path($root . '/' . $dir);

        // 不强制要求本地目录存在，远程清单分组同样参与排序
        $files = zibll_additional_demo01_get_group_files($group_path, $allowed_exts, 0, $dir);
        if (empty($files)) {
            continue;
        }

        $valid_groups[$dir] = $files;
    }

    if (empty($valid_groups)) {
        wp_send_json_error(array('msg' => '未找到可排序的表情分组'));
    }

    $saved_groups = array();
    $seen_groups = array();
    $submitted_groups = isset($submitted['groups']) && is_array($submitted['groups']) ? $submitted['groups'] : array();
    foreach ($submitted_groups as $raw_dir) {
        $dir = zibll_additional_demo01_clean_group_dir((string) $raw_dir);
        if ($dir === '' || !isset($valid_groups[$dir]) || isset($seen_groups[$dir])) {
            continue;
        }

        $seen_groups[$dir] = true;
        $saved_groups[] = $dir;
    }

    foreach (array_keys($valid_groups) as $dir) {
        if (!isset($seen_groups[$dir])) {
            $seen_groups[$dir] = true;
            $saved_groups[] = $dir;
        }
    }

    $submitted_items = isset($submitted['items']) && is_array($submitted['items']) ? $submitted['items'] : array();
    $saved_items = array();

    foreach ($valid_groups as $dir => $files) {
        $valid_file_names = array();
        foreach ($files as $file) {
            $valid_file_names[$file['file_name']] = true;
        }

        $seen_files = array();
        $group_items = isset($submitted_items[$dir]) && is_array($submitted_items[$dir]) ? $submitted_items[$dir] : array();
        foreach ($group_items as $raw_file_name) {
            $file_name = (string) $raw_file_name;
            if (!isset($valid_file_names[$file_name]) || isset($seen_files[$file_name])) {
                continue;
            }

            $seen_files[$file_name] = true;
            $saved_items[$dir][] = $file_name;
        }

        foreach ($files as $file) {
            $file_name = $file['file_name'];
            if (!isset($seen_files[$file_name])) {
                $seen_files[$file_name] = true;
                $saved_items[$dir][] = $file_name;
            }
        }
    }

    $sort_order = array(
        'groups' => $saved_groups,
        'items'  => $saved_items,
    );
    update_option(ZIBLL_COMMENT_EMOJI_ORDER_KEY, $sort_order, false);

    zibll_additional_demo01_clear_emoji_data_cache();

    wp_send_json_success(array('msg' => '排序已保存'));
}
add_action('wp_ajax_zibll_comment_emoji_save_order', 'zibll_additional_demo01_ajax_save_sort_order');

/**
 * 同步远程表情清单。
 */
function zibll_additional_demo01_ajax_sync_remote()
{
    if (!check_ajax_referer('zibll_comment_emoji_sync_remote', 'nonce', false)) {
        wp_send_json_error(array('msg' => '请求校验失败，请刷新页面后重试'), 403);
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('msg' => '权限不足'), 403);
    }

    $manifest = zibll_additional_demo01_fetch_remote_manifest();
    if (is_wp_error($manifest)) {
        wp_send_json_error(array('msg' => $manifest->get_error_message()));
    }

    $group_lines = array();
    foreach ($manifest['groups'] as $group) {
        $group_lines[] = $group['dir'] . '（' . count($group['files']) . ' 张）';
    }

    wp_send_json_success(array(
        'msg'       => '同步成功：' . count($manifest['groups']) . ' 个分组，共 ' . (int) $manifest['count'] . ' 张表情',
        'groups'    => $group_lines,
        'count'     => (int) $manifest['count'],
        'synced_at' => (int) $manifest['synced_at'],
        'source'    => (string) $manifest['source_url'],
    ));
}
add_action('wp_ajax_zibll_comment_emoji_sync_remote', 'zibll_additional_demo01_ajax_sync_remote');

/**
 * 前台 AJAX：返回单个分组的表情项（点击分组时按需加载）。
 */
function zibll_additional_demo01_ajax_get_group()
{
    $dir = isset($_POST['dir']) ? sanitize_text_field(wp_unslash($_POST['dir'])) : '';
    $dir = zibll_additional_demo01_clean_group_dir($dir);
    if ($dir === '') {
        wp_send_json_error(array('msg' => '分组参数无效'));
    }

    $data = zibll_additional_demo01_get_emoji_data();
    foreach ($data['groups'] as $group) {
        if ($group['dir'] === $dir) {
            wp_send_json_success($group);
        }
    }

    wp_send_json_error(array('msg' => '分组不存在'));
}
add_action('wp_ajax_zibll_comment_emoji_get_group', 'zibll_additional_demo01_ajax_get_group');
add_action('wp_ajax_nopriv_zibll_comment_emoji_get_group', 'zibll_additional_demo01_ajax_get_group');

/**
 * 前台 AJAX：批量解析 zcem_ token 为图片信息。
 * 页面只提交实际出现的 token（例如私信预览里的 [表情:token]），
 * 服务端返回 { token: {name,url} }，避免把全量映射内联进 HTML。
 */
function zibll_additional_demo01_ajax_resolve_tokens()
{
    $raw = isset($_POST['tokens']) ? wp_unslash($_POST['tokens']) : '';
    $submitted = array();

    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
        $submitted = is_array($decoded) ? $decoded : explode(',', $raw);
    }

    if (!is_array($submitted) || empty($submitted)) {
        wp_send_json_error(array('msg' => '参数无效'));
    }

    $submitted = array_slice($submitted, 0, 200);
    $data = zibll_additional_demo01_get_emoji_data();

    $map = array();
    foreach ($submitted as $token) {
        $token = strtolower((string) $token);
        $token = preg_replace('/[^a-z0-9_]/', '', $token);
        if ($token === '' || !isset($data['map'][$token])) {
            continue;
        }
        $map[$token] = $data['map'][$token];
    }

    wp_send_json_success(array('map' => $map));
}
add_action('wp_ajax_zibll_comment_emoji_resolve_tokens', 'zibll_additional_demo01_ajax_resolve_tokens');
add_action('wp_ajax_nopriv_zibll_comment_emoji_resolve_tokens', 'zibll_additional_demo01_ajax_resolve_tokens');

/**
 * Admin visual sorting shell. Items are rendered by admin.js on demand.
 */
function zibll_additional_demo01_get_sort_manager_html()
{
    $data = zibll_additional_demo01_get_emoji_data();
    if (empty($data['groups'])) {
        return '<p class="description">暂无可排序的表情，请先上传表情并启用插件功能。</p>';
    }

    $html  = '<div class="zibll-emoji-sort-manager">';
    $html .= '<ul class="zibll-emoji-sort-groups" aria-label="表情分组排序"></ul>';
    $html .= '<div class="zibll-emoji-sort-heading">';
    $html .= '<strong class="zibll-emoji-sort-current-title"></strong>';
    $html .= '<span class="zibll-emoji-sort-count"></span>';
    $html .= '</div>';
    $html .= '<div class="zibll-emoji-sort-items" aria-label="组内表情排序"></div>';
    $html .= '<div class="zibll-emoji-sort-actions">';
    $html .= '<button type="button" class="button zibll-emoji-sort-reset">恢复默认排序</button>';
    $html .= '<span class="zibll-emoji-sort-status" aria-live="polite"></span>';
    $html .= '<span class="spinner"></span>';
    $html .= '<button type="button" class="button button-primary zibll-emoji-sort-save" disabled>保存排序</button>';
    $html .= '</div>';
    $html .= '</div>';

    return $html;
}

/**
 * Admin group list html.
 */
function zibll_additional_demo01_get_group_list_html()
{
    $data = zibll_additional_demo01_get_emoji_data();
    if (empty($data['groups'])) {
        return '<p class="description">暂无分组，请先上传表情。</p>';
    }

    $html = '<ul class="zibll-emoji-admin-group-list">';
    foreach ($data['groups'] as $group) {
        $html .= '<li><strong>' . esc_html($group['title']) . '</strong>（' . esc_html((string) count($group['items'])) . '）'
            . '<span class="zibll-emoji-source-tag">' . ($group['source'] === 'remote' ? '远程' : '本地') . '</span></li>';
    }
    $html .= '</ul>';
    return $html;
}

/**
 * 当前本地存储状态，便于确认根目录与访问 URL 是否匹配。
 */
function zibll_additional_demo01_get_storage_state_html()
{
    $storage = zibll_additional_demo01_get_storage(false, true);
    $configured_root = zibll_additional_demo01_normalize_path(zibll_additional_demo01_get_setting('smilies_root', ''));
    $fallback_applied = ($configured_root !== '' && $configured_root !== $storage['root']);

    $html  = '<div class="zibll-emoji-storage-state">';
    $html .= '<p><strong>当前本地根目录：</strong><code>' . esc_html($storage['root']) . '</code></p>';
    $html .= '<p><strong>当前访问 URL：</strong><code>' . esc_html($storage['url']) . '</code></p>';

    if ($fallback_applied) {
        $html .= '<p class="zibll-emoji-notice">配置的根目录不可用，已回退到 uploads。你手填的访问 URL 已原样保留，请确认两者是否匹配。</p>';
    }

    $html .= '<p class="description">建议把表情放在 uploads 目录下；父主题目录中的表情会在主题升级时丢失。</p>';
    $html .= '</div>';

    return $html;
}

/**
 * 远程表情同步面板。
 */
function zibll_additional_demo01_get_remote_sync_html()
{
    $root_url = trim((string) zibll_additional_demo01_get_setting('remote_root_url', ''));
    $manifest = zibll_additional_demo01_get_remote_manifest();
    $sample_root = $root_url !== '' ? untrailingslashit($root_url) : 'https://cdnjs.hoarfall.cn/smilies';

    $html  = '<div class="zibll-emoji-remote-sync">';
    $html .= '<p>远程目录无法被 PHP 扫描，需要在远程放一份清单文件。点「立即同步」后，插件按清单生成分组，<strong>图片仍由远程服务器提供</strong>，本地不保存图片。</p>';

    $html .= '<div class="zibll-emoji-admin-row">';
    $html .= '<button type="button" class="button button-primary zibll-emoji-remote-sync-btn">立即同步</button>';
    $html .= '<span class="spinner"></span>';
    $html .= '</div>';
    $html .= '<div class="zibll-emoji-remote-result"></div>';

    $html .= '<div class="zibll-emoji-remote-state">';
    if (!empty($manifest['groups'])) {
        $html .= '<p><strong>上次同步：</strong>' . esc_html(date_i18n('Y-m-d H:i:s', (int) $manifest['synced_at']))
            . '，共 ' . (int) $manifest['count'] . ' 张，来源 <code>' . esc_html((string) $manifest['source_url']) . '</code>（'
            . esc_html((string) $manifest['format']) . '）</p>';
        $html .= '<ul class="zibll-emoji-admin-group-list">';
        foreach ($manifest['groups'] as $group) {
            $title = isset($group['title']) ? (string) $group['title'] : '';
            $suffix = ($title !== '' && $title !== $group['dir']) ? ' → ' . $title : '';
            $html .= '<li><strong>' . esc_html((string) $group['dir']) . '</strong>（'
                . esc_html((string) count($group['files'])) . ' 张）' . esc_html($suffix) . '</li>';
        }
        $html .= '</ul>';
    } else {
        $html .= '<p class="description">尚未同步过远程清单。</p>';
    }
    $html .= '</div>';

    $html .= '<hr><h4>清单格式</h4>';
    $html .= '<p class="description">同步时按顺序尝试 <code>manifest.json</code> → <code>list.txt</code> → <code>manifest.txt</code>，也可以在上方直接指定清单地址。</p>';

    $html .= '<p><strong>写法一（最简单）</strong> —— <code>' . esc_html($sample_root) . '/list.txt</code>，一行一个路径：</p>';
    $html .= '<pre class="zibll-emoji-code"># 井号开头是注释
feibi/1.gif
feibi/2.png
yuexinmiao/a.gif</pre>';

    $html .= '<p><strong>写法二（可自带中文名）</strong> —— <code>' . esc_html($sample_root) . '/manifest.json</code>：</p>';
    $html .= '<pre class="zibll-emoji-code">{
  "groups": [
    { "dir": "feibi", "title": "菲比", "files": ["1.gif", "2.png"] },
    { "dir": "yuexinmiao", "title": "月薪喵", "files": ["a.gif"] }
  ]
}</pre>';

    $html .= '<p class="description">也可以只写路径数组 <code>["feibi/1.gif", "yuexinmiao/a.gif"]</code>，或写成完整 URL（同域会自动剥成相对路径）。'
        . '目录名建议用英文，同步后去「基础设置 → 分组配置」把显示名改成中文即可。</p>';
    $html .= '</div>';

    return $html;
}
