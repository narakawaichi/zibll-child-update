<?php
/**
 * 爱发电（Afdian）Webhook 接收入口
 * ─────────────────────────────────────────────────────────────
 * 放置于子主题根目录，公开访问地址即后台展示的「Webhook 接收地址」：
 *   https://<站点域名>/wp-content/themes/zibll-child/afdian-notify.php
 * 需在爱发电开发者后台（https://ifdian.net/dashboard/dev）将「通知地址」
 * 配置为上述地址。
 *
 * 业务逻辑全部在 includes/functions/afdian-pay.php，本文件仅做：
 *   加载 WordPress（从而加载子主题与父主题 ZibPay）→ 调用处理 → 输出 JSON。
 *
 * 爱发电要求：接口必须返回 {"ec":200,"em":""} 才视为成功，否则会重试。
 *
 * @package zibll-child
 * @author  依岸归
 */

header('Content-type: application/json; Charset=utf-8');

// 加载 WordPress（路径：zibll-child → themes → wp-content → 站点根）
$wp_load = dirname(__FILE__) . '/../../../wp-load.php';
if (!file_exists($wp_load)) {
    // 极端情况下路径推断失败，直接 ack 避免对方无限重试
    echo json_encode(array('ec' => 200, 'em' => ''));
    exit;
}

require_once $wp_load;

// 主题函数（含 zibll_child_afdian_handle_webhook）与父主题 ZibPay 均已就绪
if (!function_exists('zibll_child_afdian_handle_webhook')) {
    echo json_encode(array('ec' => 200, 'em' => ''));
    exit;
}

$resp = zibll_child_afdian_handle_webhook();
echo json_encode($resp);
exit;
