<?php
/**
 * 修复：图片灯箱(Swiper)关闭后残留键盘监听劫持评论框/私聊方向键
 * 对应前端脚本 assets/js/fix-imgbox-keyboard.js（仅在访客前端加载）。
 *
 * 不修改父主题任何文件；父主题更新不会影响本修复。
 */
if (!defined('ABSPATH')) {
    exit;
}

function zibll_child_fix_imgbox_keyboard_assets() {
    $uri = get_stylesheet_directory_uri();
    $ver = @filemtime(get_stylesheet_directory() . '/assets/js/fix-imgbox-keyboard.js') ?: '1.0';
    wp_enqueue_script(
        'zc-fix-imgbox-keyboard',
        $uri . '/assets/js/fix-imgbox-keyboard.js',
        array('jquery'),
        $ver,
        true
    );
}
add_action('wp_enqueue_scripts', 'zibll_child_fix_imgbox_keyboard_assets', 30);
