/*
 * 私信实时推送 —— 前端
 *
 * 归属：子比子主题 includes/functions/private-push.php 的配套脚本
 *
 * 设计：脚本全局加载但什么都不做，直到检测到「真的有私信窗口打开」，
 *       才去连 WebSocket。所以除私信以外的任何页面都不会连出去。
 *
 * 收到推送后：
 *   · 当前对话 → 气泡直接插进聊天窗口（复用父主题 HTML，样式完全一致）
 *   · 任意对话 → 左侧会话列表整块刷新（红点 / 最新一句 / 时间 / 新联系人）
 *   · 已读回执 → 去掉自己消息上的「未读」字样
 * 推送断开则自动降级为轮询。
 */
(function () {
    'use strict';

    if (typeof window.ZC_PRIVATE_PUSH === 'undefined' || !window.ZC_PRIVATE_PUSH) {
        return;
    }
    if (typeof window.jQuery === 'undefined') {
        return;
    }

    var $ = window.jQuery;
    var CFG = window.ZC_PRIVATE_PUSH;

    /* ---------------------------------------------------------------
     * 状态
     * ------------------------------------------------------------ */
    var session = null;      // { peer, ws, tries, dead, poll, listTimer, lastId }
    var seen = {};           // 已处理过的消息 ID，防止重复插入
    var seenCount = 0;
    var currentPeer = 0;     // 当前正在聊天的对方 ID（0 = 没开窗口）

    /* ---------------------------------------------------------------
     * 工具
     * ------------------------------------------------------------ */

    function api(action, data) {
        var payload = $.extend({ action: action, nonce: CFG.nonce }, data || {});
        return $.post(CFG.ajax, payload);
    }

    function markSeen(id) {
        if (!id || seen[id]) {
            return false;
        }
        seen[id] = 1;
        seenCount++;
        if (seenCount > 800) {          // 简单防膨胀
            seen = {};
            seenCount = 0;
            seen[id] = 1;
        }
        return true;
    }

    /**
     * 找到当前「真正可见」的私信窗口对应的对方 ID
     * 消息中心的占位窗口没有 receive_user 隐藏域，所以选不中，正好
     */
    function activePeer() {
        var peer = 0;

        $('.from-private input[name="receive_user"]').each(function () {
            var $input = $(this);
            var $form = $input.closest('.from-private');

            if (!$form.length || !$form.closest('.private-window').length) {
                return;
            }
            if (!$form.is(':visible')) {
                return;
            }

            var v = parseInt($input.val(), 10);
            if (v > 0) {
                peer = v;
            }
        });

        return peer;
    }

    function chatBox() {
        return $('.private-window-content').first();
    }

    /* ---------------------------------------------------------------
     * 插入气泡
     * ------------------------------------------------------------ */

    function appendBubble(html) {
        if (!html) {
            return;
        }
        var $box = chatBox();
        if (!$box.length) {
            return;
        }

        // 与父主题发送成功后的结构保持一致
        $box.append('<div class="private-item">' + html + '</div>');
        $box.animate({ scrollTop: $box.prop('scrollHeight') }, 200);
    }

    /* ---------------------------------------------------------------
     * 左侧会话列表：重新拉一份最新的替换掉
     * ------------------------------------------------------------ */

    function refreshChatList(s) {
        if (!s || s.dead) {
            return;
        }
        var $list = $('#user_chat_lists');
        if (!$list.length) {
            return;   // 不在消息中心那页，跳过
        }

        if (s.listTimer) {
            clearTimeout(s.listTimer);
        }

        s.listTimer = setTimeout(function () {
            if (s.dead) {
                return;
            }
            var have = $list.find('.chat-lists').length || 10;

            api('zibll_child_pp_chatlist', { limit: have }).done(function (r) {
                if (s.dead || !r || !r.success || !r.data) {
                    return;
                }
                if (typeof r.data.html === 'string' && r.data.html) {
                    $list.html(r.data.html);
                }
            });
        }, 300);
    }

    /* ---------------------------------------------------------------
     * 已读回执
     * ------------------------------------------------------------ */

    var ackTimer = null;

    function ack(s) {
        if (!s) {
            return;
        }
        if (ackTimer) {
            clearTimeout(ackTimer);
        }
        ackTimer = setTimeout(function () {
            if (s.dead) {
                return;
            }
            api('zibll_child_pp_ack', { peer: s.peer });
        }, 400);
    }

    /* ---------------------------------------------------------------
     * 收到一条推送
     * ------------------------------------------------------------ */

    function handlePush(s, data) {
        if (!s || s.dead || !data) {
            return;
        }

        /* ① 已读回执：对方看过了，把我这边的「未读」字样去掉 */
        if (data.type === 'read') {
            if (parseInt(data.from, 10) === s.peer) {
                $('.private-window-content .readed-badge').remove();
            }
            return;
        }

        /* ② 普通消息 */
        if (!data.msg_id) {
            return;
        }
        if (!markSeen(data.msg_id)) {
            return;
        }

        var from = parseInt(data.from, 10);

        if (from === s.peer) {
            appendBubble(data.html);
            ack(s);
        }

        // 不管是不是当前对话，左侧列表都要跟着变
        refreshChatList(s);
    }

    /* ---------------------------------------------------------------
     * 兜底轮询
     * ------------------------------------------------------------ */

    function startPolling(s) {
        if (!s || s.dead || s.poll) {
            return;
        }

        var interval = Math.max(3, parseInt(CFG.fallback, 10) || 5) * 1000;

        s.poll = setInterval(function () {
            if (s.dead) {
                return;
            }
            api('zibll_child_pp_poll', { peer: s.peer, last_id: s.lastId || 0 })
                .done(function (r) {
                    if (s.dead || !r || !r.success || !r.data) {
                        return;
                    }

                    var list = r.data.messages || [];
                    var got = false;

                    for (var i = 0; i < list.length; i++) {
                        var m = list[i];
                        if (!markSeen(m.id)) {
                            continue;
                        }
                        s.lastId = Math.max(s.lastId || 0, m.id);
                        appendBubble(m.html);
                        got = true;
                    }

                    if (r.data.last_id) {
                        s.lastId = Math.max(s.lastId || 0, r.data.last_id);
                    }
                    if (got) {
                        ack(s);
                    }
                });
        }, interval);
    }

    function stopPolling(s) {
        if (s && s.poll) {
            clearInterval(s.poll);
            s.poll = null;
        }
    }

    /* ---------------------------------------------------------------
     * WebSocket 连接
     * ------------------------------------------------------------ */

    function connect(s) {
        if (!s || s.dead) {
            return;
        }

        api('zibll_child_pp_ticket')
            .done(function (r) {
                if (s.dead) {
                    return;
                }
                if (!r || !r.success || !r.data || !r.data.ws) {
                    startPolling(s);
                    return;
                }

                var url = r.data.ws + '?ticket=' + encodeURIComponent(r.data.ticket);
                var sock;

                try {
                    sock = new WebSocket(url);
                } catch (e) {
                    startPolling(s);
                    return;
                }

                s.ws = sock;

                sock.onopen = function () {
                    if (s.dead) {
                        return;
                    }
                    s.tries = 0;
                    stopPolling(s);
                };

                sock.onmessage = function (ev) {
                    var data;
                    try {
                        data = JSON.parse(ev.data);
                    } catch (e) {
                        return;
                    }
                    if (data) {
                        handlePush(s, data);
                    }
                };

                sock.onclose = function () {
                    if (s.dead) {
                        return;
                    }
                    s.ws = null;
                    s.tries = (s.tries || 0) + 1;

                    if (s.tries >= 3) {
                        startPolling(s);      // 连续失败 → 降级，别让用户收不到
                        return;
                    }

                    var wait = Math.min(1000 * Math.pow(2, s.tries), 15000);
                    setTimeout(function () {
                        connect(s);
                    }, wait);
                };

                sock.onerror = function () {
                    // 交给 onclose 统一处理
                };
            })
            .fail(function () {
                if (!s.dead) {
                    startPolling(s);
                }
            });
    }

    /* ---------------------------------------------------------------
     * 会话开关
     * ------------------------------------------------------------ */

    function stopSession() {
        if (!session) {
            return;
        }
        session.dead = true;
        stopPolling(session);
        if (session.listTimer) {
            clearTimeout(session.listTimer);
        }
        if (session.ws) {
            try {
                session.ws.onclose = null;
                session.ws.close();
            } catch (e) {}
            session.ws = null;
        }
        session = null;
    }

    function startSession(peer) {
        stopSession();

        var s = {
            peer: peer,
            ws: null,
            tries: 0,
            dead: false,
            poll: null,
            listTimer: null,
            lastId: 0
        };
        session = s;

        // 先取一次基线：把窗口里已经显示的历史消息标记为「已处理」，
        // 避免轮询时把它们当成新消息再插一遍
        api('zibll_child_pp_poll', { peer: peer, last_id: 0 })
            .done(function (r) {
                if (s.dead || session !== s) {
                    return;
                }
                if (r && r.success && r.data) {
                    var list = r.data.messages || [];
                    for (var i = 0; i < list.length; i++) {
                        markSeen(list[i].id);
                    }
                    s.lastId = r.data.last_id || 0;
                }
                connect(s);
            })
            .fail(function () {
                if (!s.dead && session === s) {
                    connect(s);
                }
            });
    }

    /* ---------------------------------------------------------------
     * 主循环：盯着有没有私信窗口
     * ------------------------------------------------------------ */

    function tick() {
        var peer = activePeer();

        if (peer === currentPeer) {
            return;
        }

        currentPeer = peer;

        if (peer > 0) {
            startSession(peer);
        } else {
            stopSession();
        }
    }

    setInterval(tick, 500);

    // 网络恢复 / 标签页切回来时，立刻重连一次
    window.addEventListener('online', function () {
        if (session && !session.ws && !session.dead) {
            session.tries = 0;
            stopPolling(session);
            connect(session);
        }
    });

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden && session && !session.ws && !session.dead) {
            session.tries = 0;
            stopPolling(session);
            connect(session);
        }
    });
})();
